#!/usr/bin/env bash
# YumiCord v2.1 build: v2's patched APK (work_patched.apk from the v2 build) + new manifest version + new loader bundle,
# then LSPatch with the same module and key as v2.
set -euo pipefail
cd "$(dirname "$0")"
B=${B:-/home/user/tab/tasks/b26877ff-c305-4644-9e1b-f19ee17b2617}
BT=${BT:-/home/user/android-sdk/build-tools/35.0.0}
J=${J:-$B/tools/jdk-21.0.13+9/bin}
KS=${KS:?keystore}; KSPASS=${KSPASS:?password}
E=$B/tools/node/node_modules/esbuild/bin/esbuild
node --check yumicord.js
$E yumicord.js --minify-whitespace --log-level=error > yumicord.min.js
node --check yumicord.min.js
python3 build_v21_zip.py $B/work_patched.apk patched_unaligned.apk AndroidManifest.xml yumicord.min.js
$BT/zipalign -f -p 4 patched_unaligned.apk patched.apk
rm -rf lsp_out; mkdir -p lsp_out
$J/java -jar $B/tools/lspatch-vd.jar patched.apk -o lsp_out -l 0 -v -m $B/mod/yumicord-module.apk -k "$KS" "$KSPASS" rihan "$KSPASS"
ls -la lsp_out
