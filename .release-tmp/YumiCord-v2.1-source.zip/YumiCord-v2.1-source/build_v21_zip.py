
import sys, zipfile
# YumiCord v2.1: take the v2 patched (pre-LSPatch) APK, swap in the new manifest (versionCode/versionName) and loader bundle.
src, dst, manifest, bundle = sys.argv[1:5]
rep = {"AndroidManifest.xml": manifest, "assets/yumicord/bundle.js": bundle}
zin = zipfile.ZipFile(src); zout = zipfile.ZipFile(dst, "w")
seen = set()
for info in zin.infolist():
    data = open(rep[info.filename], "rb").read() if info.filename in rep else zin.read(info.filename)
    seen.add(info.filename)
    ni = zipfile.ZipInfo(info.filename, date_time=info.date_time); ni.compress_type = info.compress_type; ni.external_attr = info.external_attr
    zout.writestr(ni, data)
assert set(rep) <= seen, set(rep) - seen
zout.close()
