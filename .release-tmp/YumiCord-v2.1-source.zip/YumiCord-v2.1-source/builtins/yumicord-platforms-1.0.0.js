(function () {
  "use strict";
  /*
   * YumiCord Platforms v1.0.0
   * Shows which device(s) a user is online on, next to their name:
   *   member list rows, the user profile name, and the chat message author.
   *   desktop / mobile / web / console (embedded) / VR, coloured by status (green online, yellow idle, red dnd).
   *
   * Crash-safe by design: every lookup, patch, timer and render is wrapped; a failure is recorded and shown on the
   * plugin's settings screen (Diagnostics) instead of reaching Discord. Our rendered icons sit inside their own
   * error boundary, so even a render error inside them shows nothing rather than a crash screen.
   *
   * Credits: idea, data source (PresenceStore clientStatuses + SessionsStore for yourself) and the five platform
   * icon images come from "PlatformIndicators" by MSMA / martinz64
   * (https://github.com/Martinz64/vendetta-plugins, The Unlicense). Re-written for Discord 350.8, where the original
   * stops at load (module-level lookups that no longer exist throw before the plugin can start).
   *
   * Discord 350.8 (Hermes bytecode) facts this relies on, read from the app bundle:
   *  - PresenceStore.getClientStatus(userId) -> {desktop|mobile|web|embedded|vr: "online"|"idle"|"dnd"}.
   *  - SessionsStore.getSessions() -> {id: {clientInfo:{client}, status}} for your own account.
   *  - Profile: component "DisplayName" ({user, guildId, name, ...}) renders the profile name.
   *  - Member list: component "UserRow" ({user, nickname, roleColors, ...}) renders a TableRow with props.label.
   *  - Chat: messages are drawn natively from rows built by RowManager.prototype.generate; we append emoji to
   *    row.message.username (plain text, so no status colour in chat).
   */
  var VERSION = "1.0.0";
  var PLATFORMS = ["desktop", "mobile", "web", "embedded", "vr"];
  var EMOJI = { desktop: "\ud83d\udda5\ufe0f", mobile: "\ud83d\udcf1", web: "\ud83c\udf10", embedded: "\ud83c\udfae", vr: "\ud83e\udd7d" };
  var NAMES = { desktop: "PC", mobile: "Phone", web: "Browser", embedded: "Console", vr: "VR" };
  var COLORS = { online: "#23a55a", idle: "#f0b232", dnd: "#f23f43", streaming: "#593695", offline: "#80848e", invisible: "#80848e" };
  var ICONS = {
    desktop: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAMAAABiM0N1AAAAVFBMVEUAAACvv7+3u7+5u7+2ub+4u726vL65u765vL65vMG5u723ub23v7+3t7+6vL+4ur+6u765u764vL+4ur23t7+7vb+3ur25ur64ur+7u766ur6vr7/+1nXbAAAAHHRSTlMAEEB/UHDv/99fgIAgQJ+f7++fnyB/YN9vTz8QSaZf3QAAAI1JREFUeAHt1tUBwkAURNEXHZzg1n+d2Fc8u4OTOQXcyKqJ3ARh5C22qiQFYTC0khFIYyuYgDYthGagzQuhDLRFIYS7yBPuakLmSaF2CimkkEIKKfT8I5un0MdCT7v6LUFbFUIhaGsr2IAUWcl2B0K2t6pDVKttGR5P3BJvpxCnfdTMHVo9NaRQ1MpKRC5jHSw3VFQzIwAAAABJRU5ErkJggg==",
    web: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAQAAAD/5HvMAAADgklEQVR42u3a32vVdRzH8VdOv2NzGzM7bkp0E9F9RQSbOmK6groQpeugOzXJfnCW3YwgC4IyHCldrBmFELtQRxfK2MHp1sjVZRfBMSJFYu6cMUnOOZPz9Gb45uyc79fv5/tDvDiPv+DJh/fn8+HL56umpqbHFZsZ4hjjzJOnQJkyBfLMM87H7GWzHh16OcoVKgQpM8N79Cht7GaSVcJa5QK7lBZe5SpRzDCgpLGdH6gS3SRPKzm8xTJxFTmgJNDKtyRllFbFQxfTRLVCvSk6FR3b+J3onuRTlllvgUzk1YmVsyJJdPMN1bqkzmizM00cc1rDIP9SawpPrjhFPAf1AN1cotZJ940ezwKb1q33BLX2Kzx2sBwzZ7vWoYXvAVOkV2FxlqjuMMtBNqkBNpIDzI/h7ywnTsfIP5gquxUGV3EiB7zMPcxlPRwDOJITTgNmpx6GyZSDnqKAOa9g9LKKIzniA0yFbQrC+5B6UDf/Y44oCFdwdUPOGMfkgr8kyrg6Lmf0YUq0yw9DuLnBcTw5YwNFzB754RhmkYaUCH7BDMsPZzDDZFMM+gQzJj/8inlTYiS1oNcws/LD35jnJUtKPOgFzHX5YQmzdmCRTSXoGcyi/FDGtEqWlHhQG6YULsjTA4zg5iZf4CkAXrig25gtUowk+FwB2IpZDDfUz8pEWiUF4DnM9XDbfkiKl6QAvB5u248H38KMJBZ0FDMW7uo4qwbIJhQ0gcnKD3sxN3lCirNKgZfrf5hB+aGdEuYVNUQ2dtAuTIk2+WMG87V8MBIzaBQzrdDDVqBDPuIE0cUy5rCC0MMq5lAqQR9hKmRcPoNu0ZF0EN0sYs7JBAyc+UwNsUJYd7nGO2zUGr4CTL9MqMGu8KIaYB43C2yVJPq4h8kpDAaoYv6kS3U4jKvfaGELeUyVfoXDT4C5wAatg8cfuHqbS4A54/K8UgTMd/WnNjuckyqAKdCj8DhArdO0NFilQ8xxhyiq7JMbRqk1GXAEuDshV3hMUesvXkoo6CKe3NHJArUqfEln7KBrdCgaMnVJcIsPa6OcczKKjk6mqFfkFH20RAi6SIfiweMkjS0xwTBvEFaVE3hKAvspEleBfUoOvTGfOH+mJ40X6ctEkaNfaWEn56kQVoVz9CltZDhCjhJBSuR4l4weHdrZwzBjzJFniTJlbpNnljGyDNLW/BmlqelxdR++AoGbDB4jjAAAAABJRU5ErkJggg==",
    mobile: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAMAAADVRocKAAAAXVBMVEUAAAAwMDgwMDUwMDUuMDYwMDYvMTcvMTYvMTYwMDYwMDUvMTYwMjUvMTUvMjYvMTUuMDUuMDQvMDUtMTUwMDgvMDUwMDAtMDYuMDYwMDAtMDUvMDYuMDUtMDcpMTo5aAq8AAAAH3RSTlMAIGBvf1C//89fMN9g75+/j3+fP0C/IFBfMGDPb08fcZ9WCgAAAMNJREFUeAHt2YWNxQAMg2EX/fiVud1/zBuhSaRjfwv8UsQx5J9L0iw/VySIyUoaXa7wu93pcE/g9KDTFS4F+amF5Em3ZwK7FwPeMEsYcoNVxZAaViX5uTd6MuQJKwY5A01u9goFWph1fyKggAIKKKCAAgoooIACCiiggAIKKKCAAgoooIACn/l9d/t3gU/fcEqG9LDKGVLB6saQAZ97owZ2w5NuzwEOKd1G4FMLE5wG36Y/w29ZadRviBn2/Nw2HfjTPgD3/UVA1TCAGgAAAABJRU5ErkJggg==",
    embedded: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAMAAABiM0N1AAAAk1BMVEUAAAC3u7+4ur+5vL+5u765u7+6vL+2ub+3v7+6u7+5vL66v7+6vL65u761ur+4u765vL+3t7+6u765u7+9vb23t7+7vb+6u766ur+5ur6/v7+vv7+9vcW1tb+5u727u763ur25vL+6vL+3ub24ur+5u7+4vL+5ur66ur64ur25vL+6u764ur24u722uby5u76vr7/eehxsAAAAMXRSTlMAQJ/f/8+fUCC/3zDv7zC/UEDvfx8gf88w3xAQHzCAT2Bfb4Bvj5/PP6+vv59wUM8QEONx+AAAAWZJREFUeAHt1dWa6zAMBOA5PSqzs2Vmhvd/uWWcVFHqr5f+r+3JRqtJ8UhBEAT/Mv8lpWwuD02hKHcpFXBTuSJ3qtZwQ0HPUVULiCuJhzpiGuKlCZaTL3gnxEVPaLWdkAxYJznIdfGmy0k9MEkOivChLQSkbwS18KElZEBBLSMIX4QMuRxaEJ0vCBndCkJMbEZjIRO6MTWCqjWlRjO6MTeCpLoooDWuCFvSjcgK0pYzohsrM0hZzhXdWJtBynJyR4rGv19dzrp3EC3nhoJKZpCynNxalzqIlrPKU7WDlOXUym8H0XIOufy+htxZX9tHBU24/L5mXH5fSy6/r4jL/8sOidYJv2x7fu0k84SgIn/Qmb50dT2oB6YXk+tf4hElWuuPdeaIlCFx/fkLeM+Q1Ferw3RQZ9SmP8jQlR9H/NZ3tKmG08+sW/SMnrxzZ6Qy/TrfBWkdL+Lq0RUptaYHJyU+HwRB4O0FjTMnvIkvoBQAAAAASUVORK5CYII=",
    vr: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAMAAABiM0N1AAAANlBMVEVMaXHv7/Hv7/Hv7/Hv7/Hv7/Hv7/Hv7/Hv7/Hs7PTu7vHv7/Hv7/Hv7/Hv7/Hv7/Hv7/Hv7/EEUZf/AAAAEXRSTlMAzGV4UNr78OcJFDufKb6ri3Gd0SEAAAHQSURBVFjD7VbHdsQgDDRNiOby/z+bjY0N2LRk95C8xxwNHo0KkqZpYGBg4PMwbBa4ZYFiZqaPRVGxNSCoavPwJs0ujLbk2K0TtipKz1s3Zl3RE/PILGKmsqbLL8JcwZ5y9LJmi3E+k8Ib1UH8xcI95Utnaeb2TAnmbzLP01NsnilfBEcBCW9FVXWpwzvxrGYiE785ASC1p2DO3M5xlWty5ZREyrEmKlQK0Tedweu1npUdNPxDVBrlHe5bIHQQue1m/YVIEKjIGKmGG7ZbPKYpqnsMnsGqqxUQNSzpP8WdJoSaNUop7nwFInZF600ijT0F3kE06dXS6RNEXfh7ROI/EMG7RPAM2++I8D48wqefZe0cJy74Bo+HaixBJPbRLXX0k5ueDenWgtzVYojLz670edNL55y2wSgPQPOtFhPbirPlKYlDPOyBPwUtjD8auzr6GwYXDKRrA4RAucMFmR0PvuXjeZ3K+wIiT++MD8Wa32n8KSxc67ArSOYcOzln6rTmi5eKhWbMIbMGyV2gkZkjKE4ZVr6cM1Lp6qxslN6ZoDodeLoVi6igTbqlYmOJ0muIBrIku4oFK7Ix9I7atAQ2SWym1F5HEjB3NDAwMPAuvgCPRUw2yKsaYwAAAABJRU5ErkJggg=="
  };

  var diag = {
    version: VERSION,
    loadedAt: 0,
    stores: "not tried",
    jsx: "not tried",
    chat: "not tried",
    live: "not tried",
    profileSeen: 0, profileAdded: 0,
    membersSeen: 0, membersAdded: 0, membersNoLabel: 0,
    chatSeen: 0, chatAdded: 0,
    found: {},
    errors: []
  };
  var unpatches = [];
  var listeners = [];
  var subs = [];
  var active = false;
  var presenceTimer = null;
  var storeUnsubs = [];

  var vd = null, metro = null, patcher = null, React = null, RN = null, storage = {}, log = null;
  var PresenceStore = null, SessionsStore = null, UserStore = null;

  function note(where, e) {
    try {
      var msg = where + ": " + String((e && (e.message || e)) || e);
      if (diag.errors.length && diag.errors[0].indexOf(msg) !== -1) return;
      diag.errors.unshift(new Date().toLocaleTimeString() + "  " + msg);
      if (diag.errors.length > 8) diag.errors.length = 8;
      try { log && log.error && log.error("YumiCord Platforms " + msg); } catch (x) {}
      notify();
    } catch (x) {}
  }
  function notify() {
    for (var i = 0; i < listeners.length; i++) { try { listeners[i](); } catch (e) {} }
  }

  try {
    vd = vendetta;
    metro = vd.metro;
    patcher = vd.patcher;
    React = metro.common.React;
    RN = metro.common.ReactNative;
    storage = (vd.plugin && vd.plugin.storage) || {};
    log = vd.logger || null;
  } catch (e) { note("init", e); }

  function sget(k, d) { try { var v = storage[k]; return v === undefined || v === null ? d : v; } catch (e) { return d; } }
  function sset(k, v) { try { storage[k] = v; } catch (e) {} }
  function h() { return React.createElement.apply(React, arguments); }

  // ---------- data ----------
  function findStore(n) {
    try { return (metro.findByStoreName && metro.findByStoreName(n)) || null; } catch (e) { note("store " + n, e); return null; }
  }
  function initStores() {
    PresenceStore = findStore("PresenceStore");
    SessionsStore = findStore("SessionsStore");
    UserStore = findStore("UserStore");
    diag.stores = (PresenceStore ? "Presence OK" : "Presence MISSING") + ", " +
      (SessionsStore ? "Sessions OK" : "Sessions MISSING") + ", " + (UserStore ? "User OK" : "User MISSING");
  }

  var cachedMe = null;
  function myId() {
    try {
      if (cachedMe) return cachedMe;
      var u = UserStore && UserStore.getCurrentUser && UserStore.getCurrentUser();
      if (u && u.id) cachedMe = String(u.id);
      return cachedMe;
    } catch (e) { return null; }
  }

  function rawStatuses(uid) {
    var res = null;
    if (uid && uid === myId() && SessionsStore && typeof SessionsStore.getSessions === "function") {
      var s = SessionsStore.getSessions() || {};
      var out = {}, any = false;
      Object.keys(s).forEach(function (k) {
        var x = s[k];
        var c = x && x.clientInfo && x.clientInfo.client;
        if (c && c !== "unknown") { out[c] = x.status || "online"; any = true; }
      });
      if (any) res = out;
    }
    if (!res && PresenceStore) {
      if (typeof PresenceStore.getClientStatus === "function") res = PresenceStore.getClientStatus(uid);
      else if (typeof PresenceStore.getState === "function") {
        var st = PresenceStore.getState();
        res = st && st.clientStatuses ? st.clientStatuses[uid] : null;
      }
    }
    return res && typeof res === "object" ? res : null;
  }

  // -> [[platform, status], ...] in a fixed order, only active platforms
  function entries(uid) {
    try {
      if (!uid) return [];
      uid = String(uid);
      var raw = rawStatuses(uid);
      if (!raw) return [];
      var showExtra = !!sget("showConsole", true);
      var out = [];
      var keys = PLATFORMS.concat(Object.keys(raw).filter(function (k) { return PLATFORMS.indexOf(k) === -1; }));
      keys.forEach(function (p) {
        var s = raw[p];
        if (!s || typeof s !== "string" || s === "offline" || s === "invisible") return;
        if (!showExtra && (p === "embedded" || p === "vr")) return;
        out.push([p, s]);
      });
      return out;
    } catch (e) { note("status read", e); return []; }
  }
  function sigOf(list) { return list.map(function (x) { return x[0] + ":" + x[1]; }).join("|"); }
  function emojiText(uid) {
    var list = entries(uid);
    return list.map(function (x) { return EMOJI[x[0]] || "\u2022"; }).join("");
  }

  // live updates: one store listener, batched, each icon re-renders only if its own user's status changed
  function onPresence() {
    try {
      if (presenceTimer) return;
      presenceTimer = setTimeout(function () {
        presenceTimer = null;
        cachedMe = null;
        var list = subs.slice();
        for (var i = 0; i < list.length; i++) { try { list[i](); } catch (e) {} }
      }, 1000);
    } catch (e) {}
  }
  function startLive() {
    try {
      var n = 0;
      [PresenceStore, SessionsStore].forEach(function (st) {
        if (st && typeof st.addChangeListener === "function") {
          st.addChangeListener(onPresence);
          storeUnsubs.push(function () { try { st.removeChangeListener(onPresence); } catch (e) {} });
          n++;
        }
      });
      diag.live = n ? "OK" : "NOT FOUND (icons update when the row re-renders)";
    } catch (e) { diag.live = "FAILED"; note("live updates", e); }
  }

  // ---------- error boundary ----------
  var Boundary = null;
  try {
    Boundary = function (props) { React.Component.call(this, props); this.state = { err: null }; };
    Boundary.prototype = Object.create(React.Component.prototype);
    Boundary.prototype.constructor = Boundary;
    Boundary.getDerivedStateFromError = function (e) { return { err: e }; };
    Boundary.prototype.componentDidCatch = function (e) { note(this.props.where || "render", e); };
    Boundary.prototype.render = function () {
      if (this.state && this.state.err) {
        if (this.props.quiet) return null;
        return React.createElement(RN.Text, { style: { color: "#f23f43", padding: 16 } },
          "YumiCord Platforms error: " + String((this.state.err && this.state.err.message) || this.state.err));
      }
      return this.props.children === undefined ? null : this.props.children;
    };
  } catch (e) { Boundary = null; note("boundary", e); }

  // ---------- icons ----------
  function IconsInner(props) {
    var uid = props.userId ? String(props.userId) : null;
    var tick = React.useState(0);
    var last = React.useRef("");
    React.useEffect(function () {
      var fn = function () {
        try {
          var s = sigOf(entries(uid));
          if (s !== last.current) tick[1](function (x) { return x + 1; });
        } catch (e) {}
      };
      subs.push(fn);
      return function () { var i = subs.indexOf(fn); if (i !== -1) subs.splice(i, 1); };
    }, [uid]);
    var list = entries(uid);
    last.current = sigOf(list);
    if (!list.length) return null;
    var size = props.size || 16;
    var emoji = sget("style", "icons") === "emoji";
    return h(RN.View, { style: { flexDirection: "row", alignItems: "center", marginLeft: 4, flexShrink: 0 } },
      list.map(function (x) {
        var p = x[0], s = x[1], col = COLORS[s] || COLORS.online;
        var label = (NAMES[p] || p) + " " + s;
        if (emoji || !ICONS[p]) {
          if (!EMOJI[p]) return h(RN.View, { key: p, accessibilityLabel: label, style: { width: size * 0.6, height: size * 0.6, borderRadius: size, backgroundColor: col, marginLeft: 2 } });
          return h(RN.Text, { key: p, accessibilityLabel: label, style: { fontSize: Math.round(size * 0.8), marginLeft: 2, color: col } }, EMOJI[p]);
        }
        return h(RN.Image, { key: p, accessibilityLabel: label, source: { uri: ICONS[p] }, style: { width: size, height: size, tintColor: col, marginLeft: 2 } });
      }));
  }
  function PlatformIcons(props) {
    try {
      var inner = h(IconsInner, props);
      return Boundary ? h(Boundary, { quiet: true, where: "icons" }, inner) : inner;
    } catch (e) { note("icons", e); return null; }
  }
  function withIcons(child, uid, size) {
    return h(RN.View, { style: { flexDirection: "row", alignItems: "center", flexShrink: 1 } },
      h(RN.View, { style: { flexShrink: 1 } }, child),
      h(PlatformIcons, { userId: uid, size: size }));
  }
  function isEl(x) { return !!x && typeof x === "object" && "props" in x && "type" in x; }

  // ---------- where the icons go ----------
  function modDisplayName(props, out) {
    if (!active || !sget("profile", true)) return out;
    diag.profileSeen++;
    var uid = props && props.user && props.user.id;
    if (!uid || !isEl(out)) return out;
    diag.profileAdded++;
    return withIcons(out, String(uid), 18);
  }
  function modUserRow(props, out) {
    if (!active || !sget("members", true)) return out;
    diag.membersSeen++;
    var uid = props && props.user && props.user.id;
    if (!uid || !isEl(out) || !out.props) return out;
    var label = out.props.label;
    if (!label || (typeof label !== "string" && !isEl(label))) { diag.membersNoLabel++; return out; }
    diag.membersAdded++;
    var lab = typeof label === "string" ? h(RN.Text, { numberOfLines: 1, style: { color: "#f2f3f5", fontSize: 16, fontWeight: "600" } }, label) : label;
    return React.cloneElement(out, { label: withIcons(lab, String(uid), 16) });
  }
  var TARGETS = { DisplayName: modDisplayName, UserRow: modUserRow };

  // ---------- jsx hook: finds DisplayName / UserRow however they are exported ----------
  var fnCache = typeof WeakMap === "function" ? new WeakMap() : null;
  var objSeen = typeof WeakSet === "function" ? new WeakSet() : null;

  function targetOf(fn) {
    if (typeof fn !== "function" || fn.__ycPlatforms) return null;
    if (fn.prototype && fn.prototype.isReactComponent) return null;
    var n = fn.displayName || fn.name;
    return n && Object.prototype.hasOwnProperty.call(TARGETS, n) ? n : null;
  }
  function makeWrapper(orig, name) {
    var mod = TARGETS[name];
    var W = function () {
      var out = orig.apply(this, arguments);
      if (!active) return out;
      try { return mod(arguments[0], out); } catch (e) { note(name + " patch", e); return out; }
    };
    W.__ycPlatforms = true;
    try { W.displayName = name; } catch (e) {}
    try { if (orig.defaultProps) W.defaultProps = orig.defaultProps; } catch (e) {}
    return W;
  }
  function found(name, how) {
    diag.found[name] = (diag.found[name] ? diag.found[name] + ", " : "") + how;
    notify();
  }
  function jsxBefore(args) {
    try {
      if (!active) return;
      var t = args[0];
      if (!t || typeof t === "string") return;
      if (typeof t === "function") {
        if (!fnCache) return;
        var w = fnCache.get(t);
        if (w === undefined) {
          var n = targetOf(t);
          w = n ? makeWrapper(t, n) : null;
          fnCache.set(t, w);
          if (n) found(n, "function");
        }
        if (w) args[0] = w;
        return;
      }
      if (typeof t === "object" && objSeen && !objSeen.has(t)) {
        objSeen.add(t);
        var holder = t, key = typeof t.type === "function" ? "type" : (typeof t.render === "function" ? "render" : null);
        if (!key && t.type && typeof t.type === "object" && typeof t.type.render === "function") { holder = t.type; key = "render"; }
        if (!key) return;
        var nm = targetOf(holder[key]);
        if (!nm) return;
        var mod = TARGETS[nm];
        unpatches.push(patcher.after(key, holder, function (a, ret) {
          if (!active) return;
          try { return mod(a && a[0], ret); } catch (e) { note(nm + " patch", e); }
        }));
        found(nm, key === "type" ? "memo" : "forwardRef");
      }
    } catch (e) { note("jsx hook", e); }
  }
  function patchJsx() {
    try {
      var rt = metro.findByProps("jsx", "jsxs");
      if (!rt) { diag.jsx = "NOT FOUND"; return; }
      unpatches.push(patcher.before("jsx", rt, jsxBefore));
      unpatches.push(patcher.before("jsxs", rt, jsxBefore));
      diag.jsx = "OK";
    } catch (e) { diag.jsx = "FAILED"; note("jsx", e); }
  }

  // ---------- chat (native rows) ----------
  var baseNames = typeof WeakMap === "function" ? new WeakMap() : null;
  function chatAfter(args, row) {
    try {
      if (!active || !sget("chat", true) || !baseNames) return;
      var m = row && row.message;
      if (!m || typeof m !== "object" || typeof m.username !== "string") return;
      diag.chatSeen++;
      var base = baseNames.get(m);
      if (base === undefined) { base = m.username; baseNames.set(m, base); }
      var src = args && args[0] && args[0].message;
      var uid = m.authorId || (src && src.author && src.author.id);
      if (!uid) return;
      var e = emojiText(String(uid));
      var next = e ? base + " " + e : base;
      if (m.username !== next) m.username = next;
      if (e) diag.chatAdded++;
    } catch (e) { note("chat patch", e); }
  }
  function patchChat() {
    try {
      var RM = null;
      try { RM = metro.findByName("RowManager"); } catch (e) {}
      if (!RM || !RM.prototype || typeof RM.prototype.generate !== "function") { diag.chat = "NOT FOUND"; return; }
      unpatches.push(patcher.after("generate", RM.prototype, chatAfter));
      diag.chat = "OK";
    } catch (e) { diag.chat = "FAILED"; note("chat", e); }
  }

  // ---------- settings ----------
  function toast(msg) {
    try { if (vd.ui && vd.ui.toasts && vd.ui.toasts.showToast) vd.ui.toasts.showToast(msg); } catch (e) {}
  }

  function SettingsInner() {
    var forceState = React.useState(0);
    var force = forceState[1];
    React.useEffect(function () {
      var fn = function () { try { force(function (x) { return x + 1; }); } catch (e) {} };
      listeners.push(fn);
      subs.push(fn);
      return function () {
        var i = listeners.indexOf(fn); if (i !== -1) listeners.splice(i, 1);
        var j = subs.indexOf(fn); if (j !== -1) subs.splice(j, 1);
      };
    }, []);
    var me = myId();
    var mine = me ? entries(me) : [];
    var txt = { color: "#f2f3f5", fontSize: 15, marginBottom: 6 };
    var sub = { color: "#b5bac1", fontSize: 13, marginBottom: 6 };
    var good = { color: "#3ba55c", fontSize: 15, marginBottom: 6, fontWeight: "600" };
    var bad = { color: "#f23f43", fontSize: 15, marginBottom: 6, fontWeight: "600" };
    var card = { backgroundColor: "#2b2d31", borderRadius: 12, padding: 16, marginBottom: 12 };
    var title = { color: "#ffffff", fontSize: 17, fontWeight: "700", marginBottom: 10 };
    function line(ok, text) { return h(RN.Text, { style: ok ? good : bad }, (ok ? "\u2705 " : "\u274c ") + text); }
    var Switch = RN.Switch;
    function toggle(key, def, label, hint) {
      return h(RN.View, { key: key, style: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 8 } },
        h(RN.View, { style: { flex: 1, paddingRight: 8 } },
          h(RN.Text, { style: txt }, label),
          hint ? h(RN.Text, { style: sub }, hint) : null),
        Switch ? h(Switch, { value: !!sget(key, def), onValueChange: function (v) { sset(key, !!v); notify(); onPresence(); } }) : null);
    }
    var foundTxt = Object.keys(diag.found).map(function (k) { return k + " (" + diag.found[k] + ")"; }).join("; ") || "abhi koi nahi (member list / profile kholo)";
    return h(RN.ScrollView, { style: { flex: 1 }, contentContainerStyle: { padding: 16 } },
      h(RN.View, { style: card },
        h(RN.Text, { style: title }, "YumiCord Platforms v" + VERSION),
        line(active, active ? "Plugin chal raha hai" : "Plugin band hai"),
        h(RN.Text, { style: sub }, "\ud83d\udcf1 Phone   \ud83d\udda5\ufe0f PC   \ud83c\udf10 Browser   \ud83c\udfae Console"),
        h(RN.Text, { style: sub }, "Rang: hara = online, peela = idle, laal = DND")
      ),
      h(RN.View, { style: card },
        h(RN.Text, { style: title }, "Tumhare devices (live)"),
        h(RN.Text, { style: txt }, "User ID: " + (me || "pata nahi chala")),
        h(RN.View, { style: { flexDirection: "row", alignItems: "center", marginBottom: 6 } },
          h(RN.Text, { style: txt }, mine.length ? "Abhi online: " : "Koi device nahi mila"),
          me ? h(PlatformIcons, { userId: me, size: 20 }) : null),
        mine.length ? h(RN.Text, { style: sub }, mine.map(function (x) { return (NAMES[x[0]] || x[0]) + " = " + x[1]; }).join(", ")) : null
      ),
      h(RN.View, { style: card },
        h(RN.Text, { style: title }, "Kahan dikhana hai"),
        toggle("members", true, "Member list"),
        toggle("profile", true, "Profile pe naam ke paas"),
        toggle("chat", true, "Chat mein naam ke paas", "Chat mein emoji aate hain (rang nahi). Naye messages pe dikhte hain."),
        toggle("showConsole", true, "Console \ud83c\udfae / VR bhi dikhao"),
        h(RN.View, { style: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 8 } },
          h(RN.Text, { style: txt }, "Style: " + (sget("style", "icons") === "emoji" ? "Emoji" : "Rangeen icons")),
          h(RN.TouchableOpacity, {
            onPress: function () { try { sset("style", sget("style", "icons") === "emoji" ? "icons" : "emoji"); notify(); onPresence(); } catch (e) { note("style", e); } },
            style: { backgroundColor: "#5865f2", borderRadius: 8, paddingVertical: 8, paddingHorizontal: 14 }
          }, h(RN.Text, { style: { color: "#ffffff", fontWeight: "600" } }, "Badlo")))
      ),
      h(RN.View, { style: card },
        h(RN.Text, { style: title }, "Diagnostics"),
        line(diag.stores.indexOf("Presence OK") === 0, "Stores: " + diag.stores),
        line(diag.jsx === "OK", "Member list + profile hook: " + diag.jsx),
        line(diag.chat === "OK", "Chat patch: " + diag.chat),
        line(diag.live === "OK", "Live update: " + diag.live),
        h(RN.Text, { style: sub }, "Mile: " + foundTxt),
        h(RN.Text, { style: sub }, "Profile: " + diag.profileSeen + "/" + diag.profileAdded +
          " | Members: " + diag.membersSeen + "/" + diag.membersAdded + (diag.membersNoLabel ? " (no label " + diag.membersNoLabel + ")" : "") +
          " | Chat: " + diag.chatSeen + "/" + diag.chatAdded),
        h(RN.Text, { style: sub }, "Last error: " + (diag.errors[0] || "koi nahi")),
        diag.errors.length > 1 ? h(RN.Text, { style: sub }, diag.errors.slice(1).join("\n")) : null,
        toggle("testToast", false, "App khulne pe test message")
      )
    );
  }
  function Settings() {
    try {
      var inner = React.createElement(SettingsInner);
      return Boundary ? React.createElement(Boundary, { where: "settings screen" }, inner) : inner;
    } catch (e) { note("settings screen", e); return null; }
  }

  if (typeof globalThis !== "undefined" && globalThis.__YC_TEST__) {
    var T = globalThis.__YC_TEST__;
    T.diag = diag; T.entries = entries; T.emojiText = emojiText; T.jsxBefore = jsxBefore; T.chatAfter = chatAfter;
    T.modUserRow = modUserRow; T.modDisplayName = modDisplayName; T.PlatformIcons = PlatformIcons; T.IconsInner = IconsInner;
    T.SettingsInner = SettingsInner; T.subs = subs; T.onPresence = onPresence;
  }

  return {
    onLoad: function () {
      try {
        active = true;
        diag.loadedAt = Date.now();
        initStores();
        startLive();
        patchJsx();
        patchChat();
        if (sget("testToast", false)) {
          setTimeout(function () {
            try {
              var me = myId();
              toast("YumiCord Platforms ON | " + (me ? (emojiText(me) || "koi device nahi") : "ID ?"));
            } catch (e) {}
          }, 4000);
        }
      } catch (e) { note("onLoad", e); }
    },
    onUnload: function () {
      active = false;
      try { if (presenceTimer) clearTimeout(presenceTimer); } catch (e) {}
      presenceTimer = null;
      storeUnsubs.forEach(function (u) { try { u(); } catch (e) {} });
      storeUnsubs = [];
      unpatches.forEach(function (u) { try { u(); } catch (e) {} });
      unpatches = [];
      subs.length = 0;
    },
    settings: Settings
  };
})()
