(function () {
  "use strict";
  /*
   * YumiCord Badges v2.0.0
   * Shows custom YumiCord badges on user profiles. Badge list: https://yumicord-badges.sites.tab.bot/badges.json
   * (edited from https://yumicord-badges.sites.tab.bot/admin).
   *
   * v2.0.0: crash-safe. Every patch, fetch, timer and the settings screen is wrapped so a failure can never
   * crash Discord; failures are recorded and shown on the plugin's settings (diagnostics) screen.
   *
   * Credits: the badge patching approach (patch Discord's useBadges hook, then fix up the rendered badge
   * element) comes from Revenge's built-in Badges plugin by pylixonly (revenge-mod/revenge-bundle,
   * BSD-3-Clause) and Kettu's Badges plugin by cocobo1 (C0C0B01/Kettu, BSD-3-Clause).
   * Emoji images: Twemoji (jdecked/twemoji), CC-BY 4.0.
   *
   * Discord 350.8 (Hermes bytecode) facts this relies on:
   *  - useBadges(displayProfile) returns [{id, description, icon, ...}] (the "classic" list).
   *  - ProfileBadgeRows({userId, badges, catalogBadges, ...}) renders each classic badge as ProfileBadge with
   *    source {uri: getProfileBadgeIconUrl(b)}, getProfileBadgeIconUrl(b) = b.iconSrc ?? cdn(b.icon).
   *  - With Discord's NEW badge system (badge management) on, ProfileBadgeRows renders catalogBadges when they
   *    are not null and skips the classic list. For users that have YumiCord badges we pass catalogBadges as
   *    undefined, so the classic list (Discord's badges + ours) renders there, in the full profile, the profile
   *    sheet and the Edit Profile preview alike.
   */
  var SITE = "https://yumicord-badges.sites.tab.bot/";
  var DATA_URL = SITE + "badges.json";
  var VERSION = "2.0.0";
  var REFRESH_MS = 5 * 60 * 1000;
  var PROFILE_REFRESH_MS = 60 * 1000;
  var ID_PREFIX = "yumicord-";

  var diag = {
    version: VERSION,
    loadedAt: 0,
    useBadges: "not tried",
    rows: "not tried",
    badgeFix: "not tried",
    rowsSeen: 0,
    rowsChanged: 0,
    hookCalls: 0,
    hookAdded: 0,
    errors: []
  };
  var state = { data: null, version: 0, lastTry: 0, lastOk: 0, error: null, fetching: false };
  var elementProps = {};
  var memo = typeof WeakMap === "function" ? new WeakMap() : null;
  var unpatches = [];
  var timer = null;
  var listeners = [];

  var vd = null, metro = null, patcher = null, React = null, RN = null, storage = {}, log = null;

  function note(where, e) {
    try {
      var msg = where + ": " + String((e && (e.message || e)) || e);
      diag.errors.unshift(new Date().toLocaleTimeString() + "  " + msg);
      if (diag.errors.length > 8) diag.errors.length = 8;
      try { log && log.error && log.error("YumiCord Badges " + msg); } catch (x) {}
      notify();
    } catch (x) {}
  }
  function notify() {
    for (var i = 0; i < listeners.length; i++) { try { listeners[i](); } catch (e) {} }
  }

  try {
    vd = vendetta;
    metro = vd.metro;
    patcher = vd.patcher;
    React = metro.common.React;
    RN = metro.common.ReactNative;
    storage = (vd.plugin && vd.plugin.storage) || {};
    log = vd.logger || null;
  } catch (e) { note("init", e); }

  function sget(k, d) { try { var v = storage[k]; return v === undefined ? d : v; } catch (e) { return d; } }
  function sset(k, v) { try { storage[k] = v; } catch (e) {} }

  function emojiToTwemoji(emoji) {
    var cps = [];
    var hasZwj = emoji.indexOf("\u200d") !== -1;
    for (var i = 0; i < emoji.length; i++) {
      var c = emoji.charCodeAt(i);
      if (c >= 0xd800 && c <= 0xdbff && i + 1 < emoji.length) {
        var d = emoji.charCodeAt(i + 1);
        c = (c - 0xd800) * 0x400 + (d - 0xdc00) + 0x10000;
        i++;
      }
      if (c === 0xfe0f && !hasZwj) continue;
      cps.push(c.toString(16));
    }
    return "https://cdn.jsdelivr.net/gh/jdecked/twemoji@15.1.0/assets/72x72/" + cps.join("-") + ".png";
  }

  // Always returns an absolute https URL (or null).
  function iconUrl(icon) {
    if (!icon || typeof icon !== "string") return null;
    icon = icon.trim();
    if (/^https?:\/\//i.test(icon)) return icon;
    if (/^\/\//.test(icon)) return "https:" + icon;
    var m = /^<a?:\w+:(\d+)>$/.exec(icon);
    if (m) return "https://cdn.discordapp.com/emojis/" + m[1] + ".png?size=64";
    if (/\.(png|jpe?g|webp|gif)(\?.*)?$/i.test(icon) || icon.indexOf("/") !== -1) return SITE + icon.replace(/^\.?\/+/, "");
    return emojiToTwemoji(icon);
  }

  // {badges:{"1":{name,icon}}, users:{"<id>":[1,5]}} -> lookup table
  function normalise(raw) {
    var out = { defs: {}, users: {} };
    if (!raw || typeof raw !== "object") return out;
    var defs = raw.badges || {};
    Object.keys(defs).forEach(function (k) {
      var b = defs[k] || {};
      var url = iconUrl(b.image || b.icon) || (b.emoji ? emojiToTwemoji(String(b.emoji)) : null);
      if (url && b.name) out.defs[String(k)] = { name: String(b.name), url: url };
    });
    var users = raw.users || {};
    Object.keys(users).forEach(function (uid) {
      var list = users[uid];
      if (!Array.isArray(list)) return;
      var clean = [];
      list.forEach(function (n) {
        n = String(n);
        if (out.defs[n] && clean.indexOf(n) === -1) clean.push(n);
      });
      if (clean.length) out.users[String(uid).trim()] = clean;
    });
    return out;
  }

  function setData(raw) {
    state.data = normalise(raw);
    state.version++;
    elementProps = {};
    notify();
  }

  function doFetch(url) {
    return fetch(url, { cache: "no-store", headers: { "cache-control": "no-cache" } }).then(function (r) {
      if (!r.ok) throw new Error("HTTP " + r.status);
      return r.json();
    });
  }

  function refresh(force) {
    try {
      var now = Date.now();
      if (state.fetching) return;
      if (!force && now - state.lastTry < 10 * 1000) return;
      state.fetching = true;
      state.lastTry = now;
      notify();
      doFetch(DATA_URL + "?t=" + now)
        .then(function (raw) {
          state.fetching = false;
          state.error = null;
          state.lastOk = Date.now();
          sset("cache", raw);
          sset("lastOk", state.lastOk);
          setData(raw);
        })
        .catch(function (e) {
          state.fetching = false;
          state.error = String((e && e.message) || e);
          note("download", e);
          if (!state.data) {
            doFetch(SITE + "badges.static.json").then(function (raw) { if (raw && !state.data) setData(raw); }).catch(function () {});
          }
        });
    } catch (e) {
      state.fetching = false;
      note("refresh", e);
    }
  }

  function badgesFor(userId) {
    var d = state.data;
    if (!d || !userId) return [];
    var list = d.users[String(userId)];
    if (!list) return [];
    var out = [];
    list.forEach(function (n) {
      var def = d.defs[n];
      if (!def) return;
      var id = ID_PREFIX + userId + "-" + n;
      elementProps[id] = { source: { uri: def.url }, label: def.name };
      out.push({ id: id, description: def.name, icon: "yumicord", iconSrc: def.url });
    });
    return out;
  }

  function withOurs(userId, base) {
    var mine = badgesFor(userId);
    if (!mine.length) return null;
    var rest = (Array.isArray(base) ? base : []).filter(function (b) {
      return !(b && typeof b.id === "string" && b.id.indexOf(ID_PREFIX) === 0);
    });
    return mine.concat(rest);
  }

  function myId() {
    try {
      var US = metro.findByStoreName && metro.findByStoreName("UserStore");
      var u = US && US.getCurrentUser && US.getCurrentUser();
      return u && u.id ? String(u.id) : null;
    } catch (e) { return null; }
  }

  // 1) classic badge list
  function patchUseBadges() {
    try {
      var mod = null;
      try { mod = metro.findByName("useBadges", false); } catch (e) {}
      if (!mod || typeof mod.default !== "function") {
        diag.useBadges = "NOT FOUND";
        return;
      }
      unpatches.push(patcher.after("default", mod, function (args, ret) {
        try {
          diag.hookCalls++;
          var user = args && args[0];
          var userId = user && (user.userId || (user.user && user.user.id));
          if (!userId) return;
          userId = String(userId);
          if (Date.now() - state.lastTry > PROFILE_REFRESH_MS) refresh(false);
          var sig = state.version + ":" + userId;
          var cached = memo && Array.isArray(ret) ? memo.get(ret) : null;
          if (cached && cached.sig === sig) return cached.arr;
          var arr = withOurs(userId, ret);
          if (!arr) return;
          diag.hookAdded++;
          if (memo && Array.isArray(ret)) memo.set(ret, { sig: sig, arr: arr });
          return arr;
        } catch (e) { note("useBadges patch", e); }
      }));
      diag.useBadges = "OK";
    } catch (e) {
      diag.useBadges = "FAILED";
      note("useBadges", e);
    }
  }

  // 2) new badge system + image fix-up, on element creation
  function patchJsx() {
    try {
      var rt = metro.findByProps("jsx", "jsxs");
      if (!rt) { diag.rows = diag.badgeFix = "NOT FOUND"; return; }
      var rowsMemo = memo ? new WeakMap() : null;
      var before = function (args) {
        try {
          var p = args[1];
          // ProfileBadgeRows-shaped props: {userId, badges, catalogBadges, ...}
          if (!p || typeof p !== "object" || !("catalogBadges" in p) || !p.userId) return;
          diag.rowsSeen++;
          var uid = String(p.userId);
          if (!state.data || !state.data.users[uid]) return;
          var sig = state.version + ":" + uid;
          var c = rowsMemo && p.badges && typeof p.badges === "object" ? rowsMemo.get(p.badges) : null;
          var merged = c && c.sig === sig ? c.arr : withOurs(uid, p.badges);
          if (!merged) return;
          if (rowsMemo && p.badges && typeof p.badges === "object") rowsMemo.set(p.badges, { sig: sig, arr: merged });
          var np = {};
          for (var k in p) np[k] = p[k];
          np.catalogBadges = undefined;
          np.badges = merged;
          args[1] = np;
          diag.rowsChanged++;
        } catch (e) { note("rows patch", e); }
      };
      var after = function (args, ret) {
        try {
          var props = ret && ret.props;
          var id = props && props.id;
          if (typeof id !== "string" || id.indexOf(ID_PREFIX) !== 0) return;
          var e = elementProps[id];
          if (!e) return;
          if (!props.source || !props.source.uri) props.source = e.source;
          if (!props.label) props.label = e.label;
        } catch (x) { note("badge image fix", x); }
      };
      unpatches.push(patcher.before("jsx", rt, before));
      unpatches.push(patcher.before("jsxs", rt, before));
      diag.rows = "OK";
      unpatches.push(patcher.after("jsx", rt, after));
      unpatches.push(patcher.after("jsxs", rt, after));
      diag.badgeFix = "OK";
    } catch (e) {
      if (diag.rows !== "OK") diag.rows = "FAILED";
      if (diag.badgeFix !== "OK") diag.badgeFix = "FAILED";
      note("jsx", e);
    }
  }

  function ago(t) {
    if (!t) return "kabhi nahi";
    var s = Math.round((Date.now() - t) / 1000);
    if (s < 60) return s + " sec pehle";
    if (s < 3600) return Math.round(s / 60) + " min pehle";
    return Math.round(s / 3600) + " ghante pehle";
  }

  function toast(msg) {
    try {
      if (vd.ui && vd.ui.toasts && vd.ui.toasts.showToast) vd.ui.toasts.showToast(msg);
    } catch (e) {}
  }

  function SettingsInner() {
    var h = React.createElement;
    var forceState = React.useState(0);
    var force = forceState[1];
    React.useEffect(function () {
      var fn = function () { try { force(function (x) { return x + 1; }); } catch (e) {} };
      listeners.push(fn);
      return function () {
        var i = listeners.indexOf(fn);
        if (i !== -1) listeners.splice(i, 1);
      };
    }, []);
    var d = state.data || { defs: {}, users: {} };
    var me = myId();
    var mine = me && d.users[me] ? d.users[me] : null;
    var txt = { color: "#f2f3f5", fontSize: 15, marginBottom: 6 };
    var sub = { color: "#b5bac1", fontSize: 13, marginBottom: 6 };
    var good = { color: "#3ba55c", fontSize: 15, marginBottom: 6, fontWeight: "600" };
    var bad = { color: "#f23f43", fontSize: 15, marginBottom: 6, fontWeight: "600" };
    var card = { backgroundColor: "#2b2d31", borderRadius: 12, padding: 16, marginBottom: 12 };
    var title = { color: "#ffffff", fontSize: 17, fontWeight: "700", marginBottom: 10 };
    function btn(label, color, onPress) {
      return h(RN.TouchableOpacity, {
        onPress: function () { try { onPress(); } catch (e) { note("button", e); } },
        style: { backgroundColor: color, borderRadius: 8, paddingVertical: 12, alignItems: "center", marginTop: 8 }
      }, h(RN.Text, { style: { color: "#ffffff", fontSize: 15, fontWeight: "600" } }, label));
    }
    function line(ok, text) { return h(RN.Text, { style: ok ? good : bad }, (ok ? "\u2705 " : "\u274c ") + text); }
    var names = mine ? mine.map(function (n) { return n + " " + d.defs[n].name; }).join(", ") : "";
    var Switch = RN.Switch;
    return h(RN.ScrollView, { style: { flex: 1 }, contentContainerStyle: { padding: 16 } },
      h(RN.View, { style: card },
        h(RN.Text, { style: title }, "YumiCord Badges v" + VERSION),
        line(true, "Plugin chal raha hai"),
        line(!!state.data, state.data ? "Badge list mili (" + Object.keys(d.users).length + " users, " + Object.keys(d.defs).length + " badges)" : "Badge list abhi nahi mili"),
        h(RN.Text, { style: sub }, "Last update: " + ago(state.lastOk) + (state.fetching ? "  (refresh ho raha hai...)" : "")),
        state.error ? h(RN.Text, { style: bad }, "Download error: " + state.error) : null,
        btn(state.fetching ? "Refresh ho raha hai..." : "Abhi refresh karo", "#5865f2", function () { refresh(true); })
      ),
      h(RN.View, { style: card },
        h(RN.Text, { style: title }, "Tumhara account"),
        h(RN.Text, { style: txt }, "Tumhari user ID: " + (me || "pata nahi chala")),
        me ? line(!!mine, mine ? "Ye ID list mein hai: " + names : "Ye ID list mein NAHI hai. Admin page pe yahi ID daalo.") : null,
        me ? btn("Meri ID copy karo", "#4e5058", function () {
          try { metro.common.clipboard.setString(me); toast("ID copy ho gayi"); } catch (e) { note("copy", e); }
        }) : null,
        btn("Admin page kholo", "#3ba55c", function () { RN.Linking.openURL(SITE + "admin"); })
      ),
      h(RN.View, { style: card },
        h(RN.Text, { style: title }, "Diagnostics"),
        line(diag.useBadges === "OK", "Classic badges patch: " + diag.useBadges),
        line(diag.rows === "OK", "New badges patch: " + diag.rows),
        line(diag.badgeFix === "OK", "Badge image fix: " + diag.badgeFix),
        h(RN.Text, { style: sub }, "Profiles dekhe: " + diag.hookCalls + " | badge lagaye: " + diag.hookAdded + " | badge rows: " + diag.rowsSeen + "/" + diag.rowsChanged),
        h(RN.Text, { style: sub }, "Last error: " + (diag.errors[0] || "koi nahi")),
        diag.errors.length > 1 ? h(RN.Text, { style: sub }, diag.errors.slice(1).join("\n")) : null,
        Switch ? h(RN.View, { style: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 10 } },
          h(RN.Text, { style: txt }, "App khulne pe test message"),
          h(Switch, { value: !!sget("testToast", false), onValueChange: function (v) { sset("testToast", !!v); notify(); } })
        ) : null
      )
    );
  }

  // Error boundary so a problem in the settings screen shows a message instead of crashing Discord.
  var Boundary = null;
  try {
    Boundary = function (props) { React.Component.call(this, props); this.state = { err: null }; };
    Boundary.prototype = Object.create(React.Component.prototype);
    Boundary.prototype.constructor = Boundary;
    Boundary.getDerivedStateFromError = function (e) { return { err: e }; };
    Boundary.prototype.componentDidCatch = function (e) { note("settings screen", e); };
    Boundary.prototype.render = function () {
      if (this.state && this.state.err) {
        return React.createElement(RN.Text, { style: { color: "#f23f43", padding: 16 } },
          "YumiCord Badges settings error: " + String((this.state.err && this.state.err.message) || this.state.err));
      }
      return this.props.children;
    };
  } catch (e) { Boundary = null; note("boundary", e); }

  function Settings() {
    try {
      var inner = React.createElement(SettingsInner);
      return Boundary ? React.createElement(Boundary, null, inner) : inner;
    } catch (e) {
      note("settings screen", e);
      return null;
    }
  }

  if (typeof globalThis !== "undefined" && globalThis.__YC_TEST__) {
    var T = globalThis.__YC_TEST__;
    T.normalise = normalise; T.iconUrl = iconUrl; T.setData = setData; T.badgesFor = badgesFor;
    T.withOurs = withOurs; T.diag = diag; T.state = state;
  }

  return {
    onLoad: function () {
      try {
        diag.loadedAt = Date.now();
        state.lastOk = sget("lastOk", 0) || 0;
        var cache = sget("cache", null);
        if (cache) { try { setData(cache); } catch (e) { note("cache", e); } }
        patchUseBadges();
        patchJsx();
        refresh(true);
        try { timer = setInterval(function () { refresh(true); }, REFRESH_MS); } catch (e) { note("timer", e); }
        if (sget("testToast", false)) {
          setTimeout(function () {
            try {
              var me = myId();
              var d = state.data;
              toast("YumiCord Badges ON | ID " + (me || "?") + (d && me && d.users[me] ? " list mein hai" : " list mein nahi"));
            } catch (e) {}
          }, 4000);
        }
      } catch (e) { note("onLoad", e); }
    },
    onUnload: function () {
      try { if (timer) clearInterval(timer); } catch (e) {}
      timer = null;
      unpatches.forEach(function (u) { try { u(); } catch (e) {} });
      unpatches = [];
    },
    settings: Settings
  };
})()
