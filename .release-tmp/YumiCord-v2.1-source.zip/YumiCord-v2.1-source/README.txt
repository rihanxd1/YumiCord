YumiCord v2.1 — source & build notes (UNTESTED build: not run on a phone)
==========================================================================

Base: YumiCord v2 (see YumiCord-v2-source.zip). Same Discord 350.8, same RevengeXposed module (byte-identical), same
LSPatch, same signing key (cert SHA-256 3651ab84d07aecf03a36855e0db40aebbbbf88fb3cd8e53110d626a1ed13097c).
Changes in v2.1:
- AndroidManifest: versionCode 350008 -> 350009, versionName "YumiCord v2.1" (patcher/YumiVersionPatcher.java, pxb axml).
  Discord's own client info uses compiled-in constants ("350.8", 350008), so this does not change what Discord reports.
- Loader bundle (bundle/yumicord-v2-to-v2.1.diff):
  * Built-in features, started at app start like a plugin (same 'vendetta' API, indirect eval like the plugin loader),
    every step in try/catch, skipped in Safe Mode:
      - YumiCord Badges 2.0.0 (builtins/yumicord-badges-2.0.0.js, unmodified copy of the URL plugin) — sets globalThis.__ycBadgesActive
      - YumiCord Platforms 1.0.0 (builtins/yumicord-platforms-1.0.0.js, unmodified copy of the URL plugin) — sets globalThis.__ycPlatformsActive
    If the same plugin is ALSO installed from its URL (yumicord-badges / yumicord-platforms .sites.tab.bot), that copy is
    turned into a no-op while the built-in runs, so nothing shows twice; its settings page shows the built-in's screen.
    Settings -> YumiCord section -> "Built-in features": an ON/OFF switch per built-in (applies after restart) and each one's
    settings/diagnostics. globalThis.__yumicord holds status/errors.
  * Pre-installed plugins: plugins-seed.json (also inline in the bundle as YUMI_SEED). ~12 s after start (once per seed
    version), each URL not already present is fetched with the loader's own fetchPlugin, which adds it DISABLED. Skipped:
    URLs already installed and any plugin whose name matches an installed one. Each URL is seeded once (a plugin the user
    removes is not re-added). Failed fetches retry on the next start. Plugin code is NOT modified or bundled; only URLs are listed.
  * Loader tweaks for a big list: fetchPlugin no longer rewrites storage when the plugin's hash is unchanged; the
    background refresh of disabled plugins runs 30 s after start instead of immediately.
  * Settings row shows "(v2.1)", version string "v2.1".
Build: build.sh (needs the v2 build dir for work_patched.apk, tools, module APK; keystore not included).
Tests: test-harness.js (mock storage/fetch: built-ins, dedupe, seeding, safe mode, failures), test-settings-page.js (react-test-renderer).
Licenses: as v2 (Revenge BSD-3-Clause, RevengeXposed GPL-3.0, LSPatch GPL-3.0). Seeded plugins belong to their authors;
YumiCord Platforms credits PlatformIndicators by MSMA/martinz64 (The Unlicense).
