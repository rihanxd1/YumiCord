"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __esm = (fn, res) => function __init() {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  };
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function")
      for (var keys = __getOwnPropNames(from), i = 0, n = keys.length, key; i < n; i++) {
        key = keys[i];
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: ((k) => from[k]).bind(null, key), enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
      }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // shims/asyncIteratorSymbol.js
  var asyncIteratorSymbol;
  var init_asyncIteratorSymbol = __esm({
    "shims/asyncIteratorSymbol.js"() {
      "use strict";
      asyncIteratorSymbol = Symbol("Symbol.asyncIterator");
    }
  });

  // shims/promiseAllSettled.js
  var allSettledFulfill, allSettledReject, mapAllSettled, allSettled;
  var init_promiseAllSettled = __esm({
    "shims/promiseAllSettled.js"() {
      "use strict";
      allSettledFulfill = (value) => ({
        status: "fulfilled",
        value
      });
      allSettledReject = (reason) => ({
        status: "rejected",
        reason
      });
      mapAllSettled = (item) => Promise.resolve(item).then(allSettledFulfill, allSettledReject);
      allSettled = Promise.allSettled ??= (iterator) => {
        return Promise.all(Array.from(iterator).map(mapAllSettled));
      };
    }
  });

  // node_modules/@swc/helpers/esm/_async_to_generator.js
  function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
      var info = gen[key](arg);
      var value = info.value;
    } catch (error) {
      reject(error);
      return;
    }
    if (info.done)
      resolve(value);
    else
      Promise.resolve(value).then(_next, _throw);
  }
  function _async_to_generator(fn) {
    return function() {
      var self = this, args = arguments;
      return new Promise(function(resolve, reject) {
        var gen = fn.apply(self, args);
        function _next(value) {
          asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
        }
        function _throw(err) {
          asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
        }
        _next(void 0);
      });
    };
  }
  var init_async_to_generator = __esm({
    "node_modules/@swc/helpers/esm/_async_to_generator.js"() {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
    }
  });

  // node_modules/spitroast/dist/cjs.js
  var require_cjs = __commonJS({
    "node_modules/spitroast/dist/cjs.js"(exports, module) {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      var __defProp2 = Object.defineProperty;
      var __getOwnPropDesc2 = Object.getOwnPropertyDescriptor;
      var __getOwnPropNames2 = Object.getOwnPropertyNames;
      var __hasOwnProp2 = Object.prototype.hasOwnProperty;
      var __export2 = (target, all) => {
        for (var name in all)
          __defProp2(target, name, {
            get: all[name],
            enumerable: true
          });
      };
      var __copyProps2 = (to, from, except, desc) => {
        if (from && typeof from === "object" || typeof from === "function") {
          var _loop3 = function(key2) {
            if (!__hasOwnProp2.call(to, key2) && key2 !== except)
              __defProp2(to, key2, {
                get: () => from[key2],
                enumerable: !(desc = __getOwnPropDesc2(from, key2)) || desc.enumerable
              });
          };
          for (var key of __getOwnPropNames2(from))
            _loop3(key);
        }
        return to;
      };
      var __toCommonJS2 = (mod) => __copyProps2(__defProp2({}, "__esModule", {
        value: true
      }), mod);
      var src_exports2 = {};
      __export2(src_exports2, {
        after: () => after2,
        before: () => before3,
        instead: () => instead4,
        unpatchAll: () => unpatchAll
      });
      module.exports = __toCommonJS2(src_exports2);
      var patchTypes = [
        "a",
        "b",
        "i"
      ];
      var patchedObjects = /* @__PURE__ */ new Map();
      function hook_default(funcName, funcParent, funcArgs, ctxt, isConstruct) {
        var patch = patchedObjects.get(funcParent)?.[funcName];
        if (!patch)
          return isConstruct ? Reflect.construct(funcParent[funcName], funcArgs, ctxt) : funcParent[funcName].apply(ctxt, funcArgs);
        for (var hook of patch.b.values()) {
          var maybefuncArgs = hook.call(ctxt, funcArgs);
          if (Array.isArray(maybefuncArgs))
            funcArgs = maybefuncArgs;
        }
        var workingRetVal = [
          ...patch.i.values()
        ].reduce(
          (prev, current) => (...args) => current.call(ctxt, args, prev),
          // This calls the original function
          (...args) => isConstruct ? Reflect.construct(patch.o, args, ctxt) : patch.o.apply(ctxt, args)
        )(...funcArgs);
        for (var hook1 of patch.a.values())
          workingRetVal = hook1.call(ctxt, funcArgs, workingRetVal) ?? workingRetVal;
        return workingRetVal;
      }
      function unpatch(funcParent, funcName, hookId, type) {
        var patchedObject = patchedObjects.get(funcParent);
        var patch = patchedObject?.[funcName];
        if (!patch?.[type].has(hookId))
          return false;
        patch[type].delete(hookId);
        if (patchTypes.every((t) => patch[t].size === 0)) {
          var success = Reflect.defineProperty(funcParent, funcName, {
            value: patch.o,
            writable: true,
            configurable: true
          });
          if (!success)
            funcParent[funcName] = patch.o;
          delete patchedObject[funcName];
        }
        if (Object.keys(patchedObject).length == 0)
          patchedObjects.delete(funcParent);
        return true;
      }
      function unpatchAll() {
        for (var [parentObject, patchedObject] of patchedObjects.entries())
          for (var funcName in patchedObject)
            for (var hookType of patchTypes)
              for (var hookId of patchedObject[funcName]?.[hookType].keys() ?? [])
                unpatch(parentObject, funcName, hookId, hookType);
      }
      var getPatchFunc_default = (patchType) => (funcName, funcParent, callback, oneTime = false) => {
        if (typeof funcParent[funcName] !== "function")
          throw new Error(`${funcName} is not a function in ${funcParent.constructor.name}`);
        if (!patchedObjects.has(funcParent))
          patchedObjects.set(funcParent, /* @__PURE__ */ Object.create(null));
        var parentInjections = patchedObjects.get(funcParent);
        if (!parentInjections[funcName]) {
          var origFunc = funcParent[funcName];
          parentInjections[funcName] = {
            o: origFunc,
            b: /* @__PURE__ */ new Map(),
            i: /* @__PURE__ */ new Map(),
            a: /* @__PURE__ */ new Map()
          };
          var runHook = (ctxt, args, construct) => {
            var ret = hook_default(funcName, funcParent, args, ctxt, construct);
            if (oneTime)
              unpatchThisPatch();
            return ret;
          };
          var replaceProxy = new Proxy(origFunc, {
            apply: (_2, ctxt, args) => runHook(ctxt, args, false),
            construct: (_2, args) => runHook(origFunc, args, true),
            get: (target, prop, receiver) => prop == "toString" ? origFunc.toString.bind(origFunc) : Reflect.get(target, prop, receiver)
          });
          var success = Reflect.defineProperty(funcParent, funcName, {
            value: replaceProxy,
            configurable: true,
            writable: true
          });
          if (!success)
            funcParent[funcName] = replaceProxy;
        }
        var hookId = Symbol();
        var unpatchThisPatch = () => unpatch(funcParent, funcName, hookId, patchType);
        parentInjections[funcName][patchType].set(hookId, callback);
        return unpatchThisPatch;
      };
      var before3 = getPatchFunc_default("b");
      var instead4 = getPatchFunc_default("i");
      var after2 = getPatchFunc_default("a");
    }
  });

  // src/lib/api/native/modules/index.ts
  var modules_exports = {};
  __export(modules_exports, {
    BundleUpdaterManager: () => BundleUpdaterManager,
    NativeCacheModule: () => NativeCacheModule,
    NativeClientInfoModule: () => NativeClientInfoModule,
    NativeDeviceModule: () => NativeDeviceModule,
    NativeFileModule: () => NativeFileModule,
    NativeThemeModule: () => NativeThemeModule
  });
  function getNativeModule(...names) {
    for (var name of names) {
      if (globalThis.__turboModuleProxy) {
        var module = globalThis.__turboModuleProxy(name);
        if (module)
          return module;
      }
      if (nmp[name])
        return nmp[name];
    }
    return void 0;
  }
  var nmp, NativeCacheModule, NativeFileModule, NativeClientInfoModule, NativeDeviceModule, NativeThemeModule, BundleUpdaterManager;
  var init_modules = __esm({
    "src/lib/api/native/modules/index.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      nmp = globalThis.nativeModuleProxy;
      NativeCacheModule = getNativeModule("NativeCacheModule", "MMKVManager");
      NativeFileModule = getNativeModule("NativeFileModule", "RTNFileManager", "DCDFileManager");
      NativeClientInfoModule = getNativeModule("NativeClientInfoModule", "RTNClientInfoManager", "InfoDictionaryManager");
      NativeDeviceModule = getNativeModule("NativeDeviceModule", "RTNDeviceManager", "DCDDeviceManager");
      NativeThemeModule = getNativeModule("NativeThemeModule", "RTNThemeManager", "DCDTheme");
      BundleUpdaterManager = getNativeModule("BundleUpdaterManager");
    }
  });

  // src/lib/api/native/fs.ts
  var fs_exports = {};
  __export(fs_exports, {
    clearFolder: () => clearFolder,
    downloadFile: () => downloadFile,
    fileExists: () => fileExists,
    readFile: () => readFile,
    removeCacheFile: () => removeCacheFile,
    removeFile: () => removeFile,
    writeFile: () => writeFile
  });
  function clearFolder(_0) {
    return _async_to_generator(function* (path, { prefix = "pyoncord/" } = {}) {
      if (typeof NativeFileModule.clearFolder !== "function")
        throw new Error("'fs.clearFolder' is not supported");
      return void (yield NativeFileModule.clearFolder("documents", `${prefix}${path}`));
    }).apply(this, arguments);
  }
  function removeFile(_0) {
    return _async_to_generator(function* (path, { prefix = "pyoncord/" } = {}) {
      if (typeof NativeFileModule.removeFile !== "function")
        throw new Error("'fs.removeFile' is not supported");
      return void (yield NativeFileModule.removeFile("documents", `${prefix}${path}`));
    }).apply(this, arguments);
  }
  function removeCacheFile(path, prefix = "pyoncord/") {
    return _async_to_generator(function* () {
      if (typeof NativeFileModule.removeFile !== "function")
        throw new Error("'fs.removeFile' is not supported");
      return void (yield NativeFileModule.removeFile("cache", `${prefix}${path}`));
    })();
  }
  function fileExists(_0) {
    return _async_to_generator(function* (path, { prefix = "pyoncord/" } = {}) {
      return yield NativeFileModule.fileExists(`${NativeFileModule.getConstants().DocumentsDirPath}/${prefix}${path}`);
    }).apply(this, arguments);
  }
  function writeFile(_0, _1) {
    return _async_to_generator(function* (path, data, { prefix = "pyoncord/" } = {}) {
      if (typeof data !== "string")
        throw new Error("Argument 'data' must be a string");
      return void (yield NativeFileModule.writeFile("documents", `${prefix}${path}`, data, "utf8"));
    }).apply(this, arguments);
  }
  function readFile(_0) {
    return _async_to_generator(function* (path, { prefix = "pyoncord/" } = {}) {
      try {
        return yield NativeFileModule.readFile(`${NativeFileModule.getConstants().DocumentsDirPath}/${prefix}${path}`, "utf8");
      } catch (err) {
        throw new Error(`An error occured while writing to '${path}'`, {
          cause: err
        });
      }
    }).apply(this, arguments);
  }
  function downloadFile(_0, _1) {
    return _async_to_generator(function* (url2, path, { prefix = "pyoncord/" } = {}) {
      var response = yield fetch(url2);
      if (!response.ok) {
        throw new Error(`Failed to download file from ${url2}: ${response.status}`);
      }
      var arrayBuffer = yield response.arrayBuffer();
      var data = Buffer.from(arrayBuffer).toString("base64");
      yield NativeFileModule.writeFile("documents", `${prefix}${path}`, data, "base64");
    }).apply(this, arguments);
  }
  var init_fs = __esm({
    "src/lib/api/native/fs.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_async_to_generator();
      init_modules();
    }
  });

  // node_modules/@swc/helpers/esm/_class_call_check.js
  function _class_call_check(instance, Constructor) {
    if (!(instance instanceof Constructor))
      throw new TypeError("Cannot call a class as a function");
  }
  var init_class_call_check = __esm({
    "node_modules/@swc/helpers/esm/_class_call_check.js"() {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
    }
  });

  // node_modules/@swc/helpers/esm/_create_class.js
  function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor)
        descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  function _create_class(Constructor, protoProps, staticProps) {
    if (protoProps)
      _defineProperties(Constructor.prototype, protoProps);
    if (staticProps)
      _defineProperties(Constructor, staticProps);
    return Constructor;
  }
  var init_create_class = __esm({
    "node_modules/@swc/helpers/esm/_create_class.js"() {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
    }
  });

  // node_modules/@swc/helpers/esm/_define_property.js
  function _define_property(obj, key, value) {
    if (key in obj) {
      Object.defineProperty(obj, key, {
        value,
        enumerable: true,
        configurable: true,
        writable: true
      });
    } else
      obj[key] = value;
    return obj;
  }
  var init_define_property = __esm({
    "node_modules/@swc/helpers/esm/_define_property.js"() {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
    }
  });

  // node_modules/@swc/helpers/esm/_get_prototype_of.js
  function _get_prototype_of(o) {
    _get_prototype_of = Object.setPrototypeOf ? Object.getPrototypeOf : function getPrototypeOf(o2) {
      return o2.__proto__ || Object.getPrototypeOf(o2);
    };
    return _get_prototype_of(o);
  }
  var init_get_prototype_of = __esm({
    "node_modules/@swc/helpers/esm/_get_prototype_of.js"() {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
    }
  });

  // node_modules/@swc/helpers/esm/_is_native_reflect_construct.js
  function _is_native_reflect_construct() {
    try {
      var result = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
      }));
    } catch (_2) {
    }
    return (_is_native_reflect_construct = function _is_native_reflect_construct2() {
      return !!result;
    })();
  }
  var init_is_native_reflect_construct = __esm({
    "node_modules/@swc/helpers/esm/_is_native_reflect_construct.js"() {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
    }
  });

  // node_modules/@swc/helpers/esm/_assert_this_initialized.js
  function _assert_this_initialized(self) {
    if (self === void 0)
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return self;
  }
  var init_assert_this_initialized = __esm({
    "node_modules/@swc/helpers/esm/_assert_this_initialized.js"() {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
    }
  });

  // node_modules/@swc/helpers/esm/_type_of.js
  function _type_of(obj) {
    "@swc/helpers - typeof";
    return obj && typeof Symbol !== "undefined" && obj.constructor === Symbol ? "symbol" : typeof obj;
  }
  var init_type_of = __esm({
    "node_modules/@swc/helpers/esm/_type_of.js"() {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
    }
  });

  // node_modules/@swc/helpers/esm/_possible_constructor_return.js
  function _possible_constructor_return(self, call) {
    if (call && (_type_of(call) === "object" || typeof call === "function"))
      return call;
    return _assert_this_initialized(self);
  }
  var init_possible_constructor_return = __esm({
    "node_modules/@swc/helpers/esm/_possible_constructor_return.js"() {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_assert_this_initialized();
      init_type_of();
    }
  });

  // node_modules/@swc/helpers/esm/_call_super.js
  function _call_super(_this, derived, args) {
    derived = _get_prototype_of(derived);
    return _possible_constructor_return(_this, _is_native_reflect_construct() ? Reflect.construct(derived, args || [], _get_prototype_of(_this).constructor) : derived.apply(_this, args));
  }
  var init_call_super = __esm({
    "node_modules/@swc/helpers/esm/_call_super.js"() {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_get_prototype_of();
      init_is_native_reflect_construct();
      init_possible_constructor_return();
    }
  });

  // node_modules/@swc/helpers/esm/_set_prototype_of.js
  function _set_prototype_of(o, p) {
    _set_prototype_of = Object.setPrototypeOf || function setPrototypeOf(o2, p2) {
      o2.__proto__ = p2;
      return o2;
    };
    return _set_prototype_of(o, p);
  }
  var init_set_prototype_of = __esm({
    "node_modules/@swc/helpers/esm/_set_prototype_of.js"() {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
    }
  });

  // node_modules/@swc/helpers/esm/_inherits.js
  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function");
    }
    subClass.prototype = Object.create(superClass && superClass.prototype, {
      constructor: {
        value: subClass,
        writable: true,
        configurable: true
      }
    });
    if (superClass)
      _set_prototype_of(subClass, superClass);
  }
  var init_inherits = __esm({
    "node_modules/@swc/helpers/esm/_inherits.js"() {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_set_prototype_of();
    }
  });

  // node_modules/@swc/helpers/esm/_construct.js
  function _construct(Parent, args, Class) {
    if (_is_native_reflect_construct())
      _construct = Reflect.construct;
    else {
      _construct = function construct(Parent2, args2, Class2) {
        var a = [
          null
        ];
        a.push.apply(a, args2);
        var Constructor = Function.bind.apply(Parent2, a);
        var instance = new Constructor();
        if (Class2)
          _set_prototype_of(instance, Class2.prototype);
        return instance;
      };
    }
    return _construct.apply(null, arguments);
  }
  var init_construct = __esm({
    "node_modules/@swc/helpers/esm/_construct.js"() {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_is_native_reflect_construct();
      init_set_prototype_of();
    }
  });

  // node_modules/@swc/helpers/esm/_is_native_function.js
  function _is_native_function(fn) {
    return Function.toString.call(fn).indexOf("[native code]") !== -1;
  }
  var init_is_native_function = __esm({
    "node_modules/@swc/helpers/esm/_is_native_function.js"() {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
    }
  });

  // node_modules/@swc/helpers/esm/_wrap_native_super.js
  function _wrap_native_super(Class) {
    var _cache = typeof Map === "function" ? /* @__PURE__ */ new Map() : void 0;
    _wrap_native_super = function _wrap_native_super2(Class2) {
      if (Class2 === null || !_is_native_function(Class2))
        return Class2;
      if (typeof Class2 !== "function")
        throw new TypeError("Super expression must either be null or a function");
      if (typeof _cache !== "undefined") {
        if (_cache.has(Class2))
          return _cache.get(Class2);
        _cache.set(Class2, Wrapper);
      }
      function Wrapper() {
        return _construct(Class2, arguments, _get_prototype_of(this).constructor);
      }
      Wrapper.prototype = Object.create(Class2.prototype, {
        constructor: {
          value: Wrapper,
          enumerable: false,
          writable: true,
          configurable: true
        }
      });
      return _set_prototype_of(Wrapper, Class2);
    };
    return _wrap_native_super(Class);
  }
  var init_wrap_native_super = __esm({
    "node_modules/@swc/helpers/esm/_wrap_native_super.js"() {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_construct();
      init_get_prototype_of();
      init_is_native_function();
      init_set_prototype_of();
    }
  });

  // node_modules/es-toolkit/dist/function/debounce.mjs
  function debounce(func, debounceMs, { signal, edges } = {}) {
    var pendingThis = void 0;
    var pendingArgs = null;
    var leading = edges != null && edges.includes("leading");
    var trailing = edges == null || edges.includes("trailing");
    var invoke = () => {
      if (pendingArgs !== null) {
        func.apply(pendingThis, pendingArgs);
        pendingThis = void 0;
        pendingArgs = null;
      }
    };
    var onTimerEnd = () => {
      if (trailing)
        invoke();
      cancel();
    };
    var timeoutId = null;
    var schedule = () => {
      if (timeoutId != null)
        clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        timeoutId = null;
        onTimerEnd();
      }, debounceMs);
    };
    var cancelTimer = () => {
      if (timeoutId !== null) {
        clearTimeout(timeoutId);
        timeoutId = null;
      }
    };
    var cancel = () => {
      cancelTimer();
      pendingThis = void 0;
      pendingArgs = null;
    };
    var flush = () => {
      invoke();
    };
    var debounced = function debounced2(...args) {
      if (signal?.aborted)
        return;
      pendingThis = this;
      pendingArgs = args;
      var isFirstCall = timeoutId == null;
      schedule();
      if (leading && isFirstCall)
        invoke();
    };
    debounced.schedule = schedule;
    debounced.cancel = cancel;
    debounced.flush = flush;
    signal?.addEventListener("abort", cancel, {
      once: true
    });
    return debounced;
  }
  var init_debounce = __esm({
    "node_modules/es-toolkit/dist/function/debounce.mjs"() {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
    }
  });

  // node_modules/es-toolkit/dist/object/omit.mjs
  function omit(obj, keys) {
    var result = {
      ...obj
    };
    for (var i = 0; i < keys.length; i++) {
      var key = keys[i];
      delete result[key];
    }
    return result;
  }
  var init_omit = __esm({
    "node_modules/es-toolkit/dist/object/omit.mjs"() {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
    }
  });

  // node_modules/es-toolkit/dist/predicate/isNotNil.mjs
  function isNotNil(x2) {
    return x2 != null;
  }
  var init_isNotNil = __esm({
    "node_modules/es-toolkit/dist/predicate/isNotNil.mjs"() {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
    }
  });

  // node_modules/es-toolkit/dist/index.mjs
  var init_dist = __esm({
    "node_modules/es-toolkit/dist/index.mjs"() {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_debounce();
      init_omit();
      init_isNotNil();
    }
  });

  // src/metro/internals/enums.ts
  var ModuleFlags, ModulesMapInternal;
  var init_enums = __esm({
    "src/metro/internals/enums.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      ModuleFlags = /* @__PURE__ */ function(ModuleFlags2) {
        ModuleFlags2[ModuleFlags2["EXISTS"] = 1] = "EXISTS";
        ModuleFlags2[ModuleFlags2["BLACKLISTED"] = 2] = "BLACKLISTED";
        ModuleFlags2[ModuleFlags2["ASSET"] = 4] = "ASSET";
        return ModuleFlags2;
      }({});
      ModulesMapInternal = /* @__PURE__ */ function(ModulesMapInternal2) {
        ModulesMapInternal2[ModulesMapInternal2["FULL_LOOKUP"] = 0] = "FULL_LOOKUP";
        ModulesMapInternal2[ModulesMapInternal2["NOT_FOUND"] = 1] = "NOT_FOUND";
        return ModulesMapInternal2;
      }({});
    }
  });

  // src/lib/api/patcher.ts
  var patcher_exports = {};
  __export(patcher_exports, {
    _patcherDelaySymbol: () => _patcherDelaySymbol,
    after: () => after,
    before: () => before,
    default: () => patcher_default,
    instead: () => instead
  });
  function create(fn) {
    function patchFn(...args) {
      if (typeof args[1][_patcherDelaySymbol] === "function") {
        var delayCallback = args[1][_patcherDelaySymbol];
        var cancel = false;
        var unpatch = () => cancel = true;
        delayCallback((target) => {
          if (cancel)
            return;
          args[1] = target;
          unpatch = fn.apply(this, args);
        });
        return () => unpatch();
      }
      return fn.apply(this, args);
    }
    function promisePatchFn(...args) {
      var thenable = args[1];
      if (!thenable || !("then" in thenable))
        throw new Error("target is not a then-able object");
      var cancel = false;
      var unpatch = () => cancel = true;
      thenable.then((target) => {
        if (cancel)
          return;
        args[1] = target;
        unpatch = patchFn.apply(this, args);
      });
      return () => unpatch();
    }
    return Object.assign(patchFn, {
      await: promisePatchFn
    });
  }
  var _after, _before, _instead, _patcherDelaySymbol, after, before, instead, patcher_default;
  var init_patcher = __esm({
    "src/lib/api/patcher.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      ({ after: _after, before: _before, instead: _instead } = require_cjs());
      _patcherDelaySymbol = Symbol.for("bunny.api.patcher.delay");
      after = create(_after);
      before = create(_before);
      instead = create(_instead);
      patcher_default = {
        after,
        before,
        instead
      };
    }
  });

  // src/lib/api/assets/patches.ts
  var patches_exports = {};
  __export(patches_exports, {
    assetsModule: () => assetsModule,
    patchAssets: () => patchAssets
  });
  function patchAssets(module) {
    if (assetsModule)
      return;
    assetsModule = module;
    var unpatch = after("registerAsset", assetsModule, () => {
      var moduleId = getImportingModuleId();
      if (moduleId !== -1)
        indexAssetModuleFlag(moduleId);
    });
    return unpatch;
  }
  var assetsModule;
  var init_patches = __esm({
    "src/lib/api/assets/patches.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_patcher();
      init_caches();
      init_modules2();
    }
  });

  // src/core/vendetta/Emitter.ts
  var Events, Emitter;
  var init_Emitter = __esm({
    "src/core/vendetta/Emitter.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_class_call_check();
      init_create_class();
      init_define_property();
      Events = /* @__PURE__ */ function(Events2) {
        Events2["GET"] = "GET";
        Events2["SET"] = "SET";
        Events2["DEL"] = "DEL";
        return Events2;
      }({});
      Emitter = /* @__PURE__ */ function() {
        "use strict";
        function Emitter2() {
          _class_call_check(this, Emitter2);
          _define_property(this, "listeners", Object.values(Events).reduce((acc, val) => (acc[val] = /* @__PURE__ */ new Set(), acc), {}));
        }
        _create_class(Emitter2, [
          {
            key: "on",
            value: function on(event, listener) {
              if (!this.listeners[event].has(listener))
                this.listeners[event].add(listener);
            }
          },
          {
            key: "off",
            value: function off(event, listener) {
              this.listeners[event].delete(listener);
            }
          },
          {
            key: "once",
            value: function once(event, listener) {
              var once2 = (event2, data) => {
                this.off(event2, once2);
                listener(event2, data);
              };
              this.on(event, once2);
            }
          },
          {
            key: "emit",
            value: function emit(event, data) {
              for (var listener of this.listeners[event])
                listener(event, data);
            }
          }
        ]);
        return Emitter2;
      }();
    }
  });

  // src/metro/factories.ts
  var factories_exports = {};
  __export(factories_exports, {
    createFilterDefinition: () => createFilterDefinition,
    createSimpleFilter: () => createSimpleFilter
  });
  function createFilterDefinition(fn, uniqMaker) {
    function createHolder(func, args, raw) {
      return Object.assign(func, {
        filter: fn,
        raw,
        uniq: [
          raw && "raw::",
          uniqMaker(args)
        ].filter(Boolean).join("")
      });
    }
    var curry = (raw) => (...args) => {
      return createHolder((m2, id, defaultCheck) => {
        return fn(args, m2, id, defaultCheck);
      }, args, raw);
    };
    return Object.assign(curry(false), {
      byRaw: curry(true),
      uniqMaker
    });
  }
  function createSimpleFilter(filter, uniq) {
    return createFilterDefinition((_2, m2) => filter(m2), () => `dynamic::${uniq}`)();
  }
  var init_factories = __esm({
    "src/metro/factories.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
    }
  });

  // src/metro/filters.ts
  var filters_exports = {};
  __export(filters_exports, {
    byDisplayName: () => byDisplayName,
    byFilePath: () => byFilePath,
    byMutableProp: () => byMutableProp,
    byName: () => byName,
    byProps: () => byProps,
    byStoreName: () => byStoreName,
    byTypeName: () => byTypeName
  });
  var byProps, byName, byDisplayName, byTypeName, byStoreName, byFilePath, byMutableProp;
  var init_filters = __esm({
    "src/metro/filters.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_factories();
      init_modules2();
      byProps = createFilterDefinition((props, m2) => props.length === 0 ? m2[props[0]] : props.every((p) => m2[p]), (props) => `bunny.metro.byProps(${props.join(",")})`);
      byName = createFilterDefinition(([name], m2) => m2.name === name, (name) => `bunny.metro.byName(${name})`);
      byDisplayName = createFilterDefinition(([displayName], m2) => m2.displayName === displayName, (name) => `bunny.metro.byDisplayName(${name})`);
      byTypeName = createFilterDefinition(([typeName], m2) => m2.type?.name === typeName, (name) => `bunny.metro.byTypeName(${name})`);
      byStoreName = createFilterDefinition(([name], m2) => m2.getName?.length === 0 && m2.getName() === name, (name) => `bunny.metro.byStoreName(${name})`);
      byFilePath = createFilterDefinition(
        // module return depends on defaultCheck. if true, it'll return module.default, otherwise the whole module
        // unlike filters like byName, defaultCheck doesn't affect the return since we don't rely on exports, but only its ID
        // one could say that this is technically a hack, since defaultCheck is meant for filtering exports
        ([path, exportDefault], _2, id, defaultCheck) => exportDefault === defaultCheck && metroModules[id]?.__filePath === path,
        ([path, exportDefault]) => `bunny.metro.byFilePath(${path},${exportDefault})`
      );
      byMutableProp = createFilterDefinition(([prop], m2) => m2?.[prop] && !Object.getOwnPropertyDescriptor(m2, prop)?.get, (prop) => `bunny.metro.byMutableProp(${prop})`);
    }
  });

  // src/metro/finders.ts
  function filterExports(moduleExports, moduleId, filter) {
    if (moduleExports.default && moduleExports.__esModule && filter(moduleExports.default, moduleId, true)) {
      return {
        exports: filter.raw ? moduleExports : moduleExports.default,
        defaultExport: !filter.raw
      };
    }
    if (!filter.raw && filter(moduleExports, moduleId, false)) {
      return {
        exports: moduleExports,
        defaultExport: false
      };
    }
    return {};
  }
  function findModule(filter) {
    var { cacheId, finish } = getCacherForUniq(filter.uniq, false);
    for (var [id, moduleExports] of getModules(filter.uniq, false)) {
      var { exports: testedExports, defaultExport } = filterExports(moduleExports, id, filter);
      if (testedExports !== void 0) {
        cacheId(id, testedExports);
        return {
          id,
          defaultExport
        };
      }
    }
    finish(true);
    return {};
  }
  function findModuleId(filter) {
    return findModule(filter)?.id;
  }
  function findExports(filter) {
    var { id, defaultExport } = findModule(filter);
    if (id == null)
      return;
    return defaultExport ? requireModule(id).default : requireModule(id);
  }
  function findAllModule(filter) {
    var { cacheId, finish } = getCacherForUniq(filter.uniq, true);
    var foundExports = [];
    for (var [id, moduleExports] of getModules(filter.uniq, true)) {
      var { exports: testedExports, defaultExport } = filterExports(moduleExports, id, filter);
      if (testedExports !== void 0 && typeof defaultExport === "boolean") {
        foundExports.push({
          id,
          defaultExport
        });
        cacheId(id, testedExports);
      }
    }
    finish(foundExports.length === 0);
    return foundExports;
  }
  function findAllModuleId(filter) {
    return findAllModule(filter).map((e) => e.id);
  }
  function findAllExports(filter) {
    return findAllModule(filter).map((ret) => {
      if (!ret.id)
        return;
      var { id, defaultExport } = ret;
      return defaultExport ? requireModule(id).default : requireModule(id);
    });
  }
  var init_finders = __esm({
    "src/metro/finders.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_caches();
      init_modules2();
    }
  });

  // src/lib/utils/lazy.ts
  var lazy_exports = {};
  __export(lazy_exports, {
    getProxyFactory: () => getProxyFactory,
    lazyDestructure: () => lazyDestructure,
    proxyLazy: () => proxyLazy
  });
  function proxyLazy(factory, opts = {}) {
    var cache;
    var dummy = opts.hint !== "object" ? function() {
    } : {};
    var proxyFactory = () => cache ??= factory();
    var proxy = new Proxy(dummy, lazyHandler);
    factories.set(proxy, proxyFactory);
    proxyContextHolder.set(dummy, {
      factory,
      options: opts
    });
    return proxy;
  }
  function lazyDestructure(factory, opts = {}) {
    var proxiedObject = proxyLazy(factory);
    return new Proxy({}, {
      get(_2, property) {
        if (property === Symbol.iterator) {
          return function* () {
            yield proxiedObject;
            yield new Proxy({}, {
              get: (_3, p) => proxyLazy(() => proxiedObject[p], opts)
            });
            throw new Error("This is not a real iterator, this is likely used incorrectly");
          };
        }
        return proxyLazy(() => proxiedObject[property], opts);
      }
    });
  }
  function getProxyFactory(obj) {
    return factories.get(obj);
  }
  var unconfigurable, isUnconfigurable, factories, proxyContextHolder, lazyHandler;
  var init_lazy = __esm({
    "src/lib/utils/lazy.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      unconfigurable = /* @__PURE__ */ new Set([
        "arguments",
        "caller",
        "prototype"
      ]);
      isUnconfigurable = (key) => typeof key === "string" && unconfigurable.has(key);
      factories = /* @__PURE__ */ new WeakMap();
      proxyContextHolder = /* @__PURE__ */ new WeakMap();
      lazyHandler = {
        ...Object.fromEntries(Object.getOwnPropertyNames(Reflect).map((fnName) => {
          return [
            fnName,
            (target, ...args) => {
              var contextHolder = proxyContextHolder.get(target);
              var resolved = contextHolder?.factory();
              if (!resolved)
                throw new Error(`Trying to Reflect.${fnName} of ${typeof resolved}`);
              return Reflect[fnName](resolved, ...args);
            }
          ];
        })),
        has(target, p) {
          var contextHolder = proxyContextHolder.get(target);
          if (contextHolder?.options) {
            var { exemptedEntries: isolatedEntries } = contextHolder.options;
            if (isolatedEntries && p in isolatedEntries)
              return true;
          }
          var resolved = contextHolder?.factory();
          if (!resolved)
            throw new Error(`Trying to Reflect.has of ${typeof resolved}`);
          return Reflect.has(resolved, p);
        },
        get(target, p, receiver) {
          if (false)
            return true;
          var contextHolder = proxyContextHolder.get(target);
          if (contextHolder?.options) {
            var { exemptedEntries: isolatedEntries } = contextHolder.options;
            if (isolatedEntries?.[p])
              return isolatedEntries[p];
          }
          var resolved = contextHolder?.factory();
          if (!resolved)
            throw new Error(`Trying to Reflect.get of ${typeof resolved}`);
          return Reflect.get(resolved, p, receiver);
        },
        ownKeys: (target) => {
          var contextHolder = proxyContextHolder.get(target);
          var resolved = contextHolder?.factory();
          if (!resolved)
            throw new Error(`Trying to Reflect.ownKeys of ${typeof resolved}`);
          var cacheKeys = Reflect.ownKeys(resolved);
          unconfigurable.forEach((key) => !cacheKeys.includes(key) && cacheKeys.push(key));
          return cacheKeys;
        },
        getOwnPropertyDescriptor: (target, p) => {
          if (isUnconfigurable(p))
            return Reflect.getOwnPropertyDescriptor(target, p);
          var contextHolder = proxyContextHolder.get(target);
          var resolved = contextHolder?.factory();
          if (!resolved)
            throw new Error(`Trying to getOwnPropertyDescriptor of ${typeof resolved}`);
          var descriptor = Reflect.getOwnPropertyDescriptor(resolved, p);
          if (descriptor)
            Object.defineProperty(target, p, descriptor);
          return descriptor;
        }
      };
    }
  });

  // src/metro/lazy.ts
  var lazy_exports2 = {};
  __export(lazy_exports2, {
    _lazyContextSymbol: () => _lazyContextSymbol,
    createLazyModule: () => createLazyModule,
    getLazyContext: () => getLazyContext
  });
  function getIndexedFind(filter) {
    var modulesMap = getMetroCache().findIndex[filter.uniq];
    if (!modulesMap)
      return void 0;
    for (var k in modulesMap)
      if (k[0] !== "_")
        return Number(k);
  }
  function subscribeLazyModule(proxy, callback) {
    var info = getLazyContext(proxy);
    if (!info)
      throw new Error("Subscribing a module for non-proxy-find");
    if (!info.indexed)
      throw new Error("Attempting to subscribe to a non-indexed find");
    return subscribeModule(info.moduleId, () => {
      callback(findExports(info.filter));
    });
  }
  function getLazyContext(proxy) {
    return _lazyContexts.get(proxy);
  }
  function createLazyModule(filter) {
    var cache = void 0;
    var moduleId = getIndexedFind(filter);
    var context = {
      filter,
      indexed: !!moduleId,
      moduleId,
      getExports(cb) {
        if (!moduleId || metroModules[moduleId]?.isInitialized) {
          cb(this.forceLoad());
          return () => void 0;
        }
        return this.subscribe(cb);
      },
      subscribe(cb) {
        return subscribeLazyModule(proxy, cb);
      },
      get cache() {
        return cache;
      },
      forceLoad() {
        cache ??= findExports(filter);
        if (!cache)
          throw new Error(`${filter.uniq} is ${typeof cache}! (id ${context.moduleId ?? "unknown"})`);
        return cache;
      }
    };
    var proxy = proxyLazy(() => context.forceLoad(), {
      exemptedEntries: {
        [_lazyContextSymbol]: context,
        [_patcherDelaySymbol]: (cb) => context.getExports(cb)
      }
    });
    _lazyContexts.set(proxy, context);
    return proxy;
  }
  var _lazyContextSymbol, _lazyContexts;
  var init_lazy2 = __esm({
    "src/metro/lazy.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_patcher();
      init_lazy();
      init_finders();
      init_caches();
      init_modules2();
      _lazyContextSymbol = Symbol.for("bunny.metro.lazyContext");
      _lazyContexts = /* @__PURE__ */ new WeakMap();
    }
  });

  // src/metro/wrappers.ts
  var findByProps, findByPropsLazy, findByPropsAll, findByName, findByNameLazy, findByNameAll, findByDisplayName, findByDisplayNameLazy, findByDisplayNameAll, findByTypeName, findByTypeNameLazy, findByTypeNameAll, findByStoreName, findByStoreNameLazy, findByFilePath, findByFilePathLazy;
  var init_wrappers = __esm({
    "src/metro/wrappers.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_filters();
      init_finders();
      init_lazy2();
      findByProps = (...props) => findExports(byProps(...props));
      findByPropsLazy = (...props) => createLazyModule(byProps(...props));
      findByPropsAll = (...props) => findAllExports(byProps(...props));
      findByName = (name, expDefault = true) => findExports(expDefault ? byName(name) : byName.byRaw(name));
      findByNameLazy = (name, expDefault = true) => createLazyModule(expDefault ? byName(name) : byName.byRaw(name));
      findByNameAll = (name, expDefault = true) => findAllExports(expDefault ? byName(name) : byName.byRaw(name));
      findByDisplayName = (name, expDefault = true) => findExports(expDefault ? byDisplayName(name) : byDisplayName.byRaw(name));
      findByDisplayNameLazy = (name, expDefault = true) => createLazyModule(expDefault ? byDisplayName(name) : byDisplayName.byRaw(name));
      findByDisplayNameAll = (name, expDefault = true) => findAllExports(expDefault ? byDisplayName(name) : byDisplayName.byRaw(name));
      findByTypeName = (name, expDefault = true) => findExports(expDefault ? byTypeName(name) : byTypeName.byRaw(name));
      findByTypeNameLazy = (name, expDefault = true) => createLazyModule(expDefault ? byTypeName(name) : byTypeName.byRaw(name));
      findByTypeNameAll = (name, expDefault = true) => findAllExports(expDefault ? byTypeName(name) : byTypeName.byRaw(name));
      findByStoreName = (name) => findExports(byStoreName(name));
      findByStoreNameLazy = (name) => createLazyModule(byStoreName(name));
      findByFilePath = (path, expDefault = false) => findExports(byFilePath(path, expDefault));
      findByFilePathLazy = (path, expDefault = false) => createLazyModule(byFilePath(path, expDefault));
    }
  });

  // shims/depsModule.ts
  var require_depsModule = __commonJS({
    "shims/depsModule.ts"(exports, module) {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_wrappers();
      module.exports = {
        "react": findByPropsLazy("createElement"),
        "react-native": findByPropsLazy("AppRegistry"),
        "util": findByPropsLazy("inspect", "isNullOrUndefined"),
        "moment": findByPropsLazy("isMoment"),
        "chroma-js": findByPropsLazy("brewer"),
        "lodash": findByPropsLazy("forEachRight"),
        "react-native-webview": findByPropsLazy("WebView")
      };
    }
  });

  // globals:react-native
  var require_react_native = __commonJS({
    "globals:react-native"(exports, module) {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      module.exports = require_depsModule()["react-native"];
    }
  });

  // src/core/vendetta/storage.ts
  function createProxy(target = {}) {
    var emitter = new Emitter();
    var childrens = /* @__PURE__ */ new WeakMap();
    var proxiedChildrenSet = /* @__PURE__ */ new WeakSet();
    function createProxy1(target2, path) {
      return new Proxy(target2, {
        get(target3, prop) {
          if (prop === emitterSymbol)
            return emitter;
          var newPath = [
            ...path,
            prop
          ];
          var value = target3[prop];
          if (value !== void 0 && value !== null) {
            emitter.emit("GET", {
              path: newPath,
              value
            });
            if (typeof value === "object") {
              if (proxiedChildrenSet.has(value))
                return value;
              if (childrens.has(value))
                return childrens.get(value);
              var childrenProxy = createProxy1(value, newPath);
              childrens.set(value, childrenProxy);
              return childrenProxy;
            }
            return value;
          }
          return value;
        },
        set(target3, prop, value) {
          if (typeof value === "object") {
            if (childrens.has(value)) {
              target3[prop] = childrens.get(value);
            } else {
              var childrenProxy = createProxy1(value, [
                ...path,
                prop
              ]);
              childrens.set(value, childrenProxy);
              proxiedChildrenSet.add(value);
              target3[prop] = childrenProxy;
            }
          } else {
            target3[prop] = value;
          }
          emitter.emit("SET", {
            path: [
              ...path,
              prop
            ],
            value: target3[prop]
          });
          return true;
        },
        deleteProperty(target3, prop) {
          var value = typeof target3[prop] === "object" ? childrens.get(target3[prop]) : target3[prop];
          var success = delete target3[prop];
          if (success)
            emitter.emit("DEL", {
              value,
              path: [
                ...path,
                prop
              ]
            });
          return success;
        }
      });
    }
    return {
      proxy: createProxy1(target, []),
      emitter
    };
  }
  function useProxy(storage) {
    var emitter = storage?.[emitterSymbol];
    if (!emitter)
      throw new Error("storage?.[emitterSymbol] is undefined");
    var [, forceUpdate] = React.useReducer((n) => ~n, 0);
    React.useEffect(() => {
      var listener = (event, data) => {
        if (event === "DEL" && data.value === storage)
          return;
        forceUpdate();
      };
      emitter.on("SET", listener);
      emitter.on("DEL", listener);
      return () => {
        emitter.off("SET", listener);
        emitter.off("DEL", listener);
      };
    }, []);
    return storage;
  }
  function createStorage(backend) {
    return _async_to_generator(function* () {
      var data = yield backend.get();
      var { proxy, emitter } = createProxy(data);
      var handler = () => backend.set(proxy);
      emitter.on("SET", handler);
      emitter.on("DEL", handler);
      return proxy;
    })();
  }
  function wrapSync(store) {
    var awaited = void 0;
    var awaitQueue = [];
    var awaitInit = (cb) => awaited ? cb() : awaitQueue.push(cb);
    store.then((v2) => {
      awaited = v2;
      awaitQueue.forEach((cb) => cb());
    });
    return new Proxy({}, {
      ...Object.fromEntries(Object.getOwnPropertyNames(Reflect).map((k) => [
        k,
        (t, ...a) => Reflect[k](awaited ?? t, ...a)
      ])),
      get(target, prop, recv) {
        if (prop === syncAwaitSymbol)
          return awaitInit;
        return Reflect.get(awaited ?? target, prop, recv);
      }
    });
  }
  function awaitStorage(...stores) {
    return Promise.all(stores.map((store) => new Promise((res) => store[syncAwaitSymbol](res))));
  }
  var import_react_native, emitterSymbol, syncAwaitSymbol, ILLEGAL_CHARS_REGEX, filePathFixer, getMMKVPath, purgeStorage, createMMKVBackend, createFileBackend;
  var init_storage = __esm({
    "src/core/vendetta/storage.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_async_to_generator();
      init_Emitter();
      init_modules();
      import_react_native = __toESM(require_react_native());
      emitterSymbol = Symbol.for("vendetta.storage.emitter");
      syncAwaitSymbol = Symbol.for("vendetta.storage.accessor");
      ILLEGAL_CHARS_REGEX = /[<>:"/\\|?*]/g;
      filePathFixer = (file) => import_react_native.Platform.select({
        default: file,
        ios: NativeFileModule.saveFileToGallery ? file : `Documents/${file}`
      });
      getMMKVPath = (name) => {
        if (ILLEGAL_CHARS_REGEX.test(name)) {
          name = name.replace(ILLEGAL_CHARS_REGEX, "-").replace(/-+/g, "-");
        }
        return `vd_mmkv/${name}`;
      };
      purgeStorage = (store) => _async_to_generator(function* () {
        if (yield NativeCacheModule.getItem(store)) {
          NativeCacheModule.removeItem(store);
        }
        var mmkvPath = getMMKVPath(store);
        if (yield NativeFileModule.fileExists(`${NativeFileModule.getConstants().DocumentsDirPath}/${mmkvPath}`)) {
          yield NativeFileModule.removeFile?.("documents", mmkvPath);
        }
      })();
      createMMKVBackend = (store, defaultData = {}) => {
        var mmkvPath = getMMKVPath(store);
        var defaultStr = JSON.stringify(defaultData);
        return createFileBackend(mmkvPath, defaultData, (() => _async_to_generator(function* () {
          var path = `${NativeFileModule.getConstants().DocumentsDirPath}/${mmkvPath}`;
          if (yield NativeFileModule.fileExists(path))
            return;
          var oldData = (yield NativeCacheModule.getItem(store)) ?? defaultStr;
          if (oldData === "!!LARGE_VALUE!!") {
            var cachePath = `${NativeFileModule.getConstants().CacheDirPath}/mmkv/${store}`;
            if (yield NativeFileModule.fileExists(cachePath)) {
              oldData = yield NativeFileModule.readFile(cachePath, "utf8");
            } else {
              console.log(`${store}: Experienced data loss :(`);
              oldData = defaultStr;
            }
          }
          try {
            JSON.parse(oldData);
          } catch (unused) {
            console.error(`${store} had an unparseable data while migrating`);
            oldData = defaultStr;
          }
          yield NativeFileModule.writeFile("documents", filePathFixer(mmkvPath), oldData, "utf8");
          if ((yield NativeCacheModule.getItem(store)) !== null) {
            NativeCacheModule.removeItem(store);
            console.log(`Successfully migrated ${store} store from MMKV storage to fs`);
          }
        })())());
      };
      createFileBackend = (file, defaultData = {}, migratePromise) => {
        return {
          get: () => _async_to_generator(function* () {
            yield migratePromise;
            var path = `${NativeFileModule.getConstants().DocumentsDirPath}/${file}`;
            if (yield NativeFileModule.fileExists(path)) {
              var content = yield NativeFileModule.readFile(path, "utf8");
              try {
                return JSON.parse(content);
              } catch (unused) {
              }
            }
            yield NativeFileModule.writeFile("documents", filePathFixer(file), JSON.stringify(defaultData), "utf8");
            return JSON.parse(yield NativeFileModule.readFile(path, "utf8"));
          })(),
          set: (data) => _async_to_generator(function* () {
            yield migratePromise;
            yield NativeFileModule.writeFile("documents", filePathFixer(file), JSON.stringify(data), "utf8");
          })()
        };
      };
    }
  });

  // node_modules/@gullerya/object-observer/dist/object-observer.min.js
  var m, x, E, T, K, c, $, N, Y, I, B, D, R, z, y, g, q, H, G, J, F, P, L, C, Q, X, Z, _, b, S, V, U, W, v;
  var init_object_observer_min = __esm({
    "node_modules/@gullerya/object-observer/dist/object-observer.min.js"() {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_call_super();
      init_class_call_check();
      init_create_class();
      init_inherits();
      m = "insert";
      x = "update";
      E = "delete";
      T = "reverse";
      K = "shuffle";
      c = Symbol.for("object-observer-meta-key-0");
      $ = {
        async: 1
      };
      N = (o) => {
        if (!o || typeof o != "object")
          return null;
        var t = {}, e = [];
        for (var [r, n] of Object.entries(o))
          if (r === "path") {
            if (typeof n != "string" || n === "")
              throw new Error('"path" option, if/when provided, MUST be a non-empty string');
            t[r] = n;
          } else if (r === "pathsOf") {
            if (o.path)
              throw new Error('"pathsOf" option MAY NOT be specified together with "path" option');
            if (typeof n != "string")
              throw new Error('"pathsOf" option, if/when provided, MUST be a string (MAY be empty)');
            t[r] = o.pathsOf.split(".").filter(Boolean);
          } else if (r === "pathsFrom") {
            if (o.path || o.pathsOf)
              throw new Error('"pathsFrom" option MAY NOT be specified together with "path"/"pathsOf" option/s');
            if (typeof n != "string" || n === "")
              throw new Error('"pathsFrom" option, if/when provided, MUST be a non-empty string');
            t[r] = n;
          } else
            e.push(r);
        if (e.length)
          throw new Error(`'${e.join(", ")}' is/are not a valid observer option/s`);
        return t;
      };
      Y = (o, t, e) => {
        var r = {};
        r[c] = t;
        for (var n in o)
          r[n] = g(o[n], n, t, e);
        return r;
      };
      I = (o, t, e) => {
        var r = o.length;
        var n = new Array(r);
        n[c] = t;
        for (var i = 0; i < r; i++)
          n[i] = g(o[i], i, t, e);
        return n;
      };
      B = (o, t) => (o[c] = t, o);
      D = (o, t) => {
        if (o === null)
          return t;
        var e = t;
        if (o.path) {
          var r = o.path;
          e = t.filter((n2) => n2.path.join(".") === r);
        } else if (o.pathsOf) {
          var r1 = o.pathsOf, n = r1.join(".");
          e = t.filter((i) => (i.path.length === r1.length + 1 || i.path.length === r1.length && (i.type === T || i.type === K)) && i.path.join(".").startsWith(n));
        } else if (o.pathsFrom) {
          var r2 = o.pathsFrom;
          e = t.filter((n2) => n2.path.join(".").startsWith(r2));
        }
        return e;
      };
      R = (o, t) => {
        try {
          o(t);
        } catch (e) {
          console.error(`failed to notify listener ${o} with ${t}`, e);
        }
      };
      z = function z2() {
        var t = this.batches;
        this.batches = [];
        for (var [e, r] of t)
          R(e, r);
      };
      y = (o, t) => {
        var e = o, r, n, i, l, h, s;
        var u = t.length;
        do {
          for (r = e.options.async, n = e.observers, s = n.length; s--; )
            if ([i, l] = n[s], h = D(l, t), h.length)
              if (r) {
                e.batches.length === 0 && queueMicrotask(z.bind(e));
                var a = void 0;
                for (var p of e.batches)
                  if (p[0] === i) {
                    a = p;
                    break;
                  }
                a || (a = [
                  i,
                  []
                ], e.batches.push(a)), Array.prototype.push.apply(a[1], h);
              } else
                R(i, h);
          var f = e.parent;
          if (f) {
            for (var a1 = 0; a1 < u; a1++) {
              var p1 = t[a1];
              t[a1] = new b(p1.type, [
                e.ownKey,
                ...p1.path
              ], p1.value, p1.oldValue, p1.object);
            }
            e = f;
          } else
            e = null;
        } while (e);
      };
      g = (o, t, e, r) => r !== void 0 && r.has(o) ? null : typeof o != "object" || o === null ? o : Array.isArray(o) ? new U({
        target: o,
        ownKey: t,
        parent: e,
        visited: r
      }).proxy : ArrayBuffer.isView(o) ? new W({
        target: o,
        ownKey: t,
        parent: e
      }).proxy : o instanceof Date ? o : new V({
        target: o,
        ownKey: t,
        parent: e,
        visited: r
      }).proxy;
      q = function q2() {
        var t = this[c], e = t.target, r = e.length - 1;
        var n = e.pop();
        if (n && typeof n == "object") {
          var l = n[c];
          l && (n = l.detach());
        }
        var i = [
          new b(E, [
            r
          ], void 0, n, this)
        ];
        return y(t, i), n;
      };
      H = function H2() {
        var t = this[c], e = t.target, r = arguments.length, n = new Array(r), i = e.length;
        for (var s = 0; s < r; s++)
          n[s] = g(arguments[s], i + s, t);
        var l = Reflect.apply(e.push, e, n), h = [];
        for (var s1 = i, u = e.length; s1 < u; s1++)
          h[s1 - i] = new b(m, [
            s1
          ], e[s1], void 0, this);
        return y(t, h), l;
      };
      G = function G2() {
        var t = this[c], e = t.target;
        var r, n, i, l, h;
        for (r = e.shift(), r && typeof r == "object" && (h = r[c], h && (r = h.detach())), n = 0, i = e.length; n < i; n++)
          l = e[n], l && typeof l == "object" && (h = l[c], h && (h.ownKey = n));
        var s = [
          new b(E, [
            0
          ], void 0, r, this)
        ];
        return y(t, s), r;
      };
      J = function J2() {
        var t = this[c], e = t.target, r = arguments.length, n = new Array(r);
        for (var s = 0; s < r; s++)
          n[s] = g(arguments[s], s, t);
        var i = Reflect.apply(e.unshift, e, n);
        for (var s1 = 0, u = e.length, f; s1 < u; s1++)
          if (f = e[s1], f && typeof f == "object") {
            var a = f[c];
            a && (a.ownKey = s1);
          }
        var l = n.length, h = new Array(l);
        for (var s2 = 0; s2 < l; s2++)
          h[s2] = new b(m, [
            s2
          ], e[s2], void 0, this);
        return y(t, h), i;
      };
      F = function F2() {
        var t = this[c], e = t.target;
        var r, n, i;
        for (e.reverse(), r = 0, n = e.length; r < n; r++)
          if (i = e[r], i && typeof i == "object") {
            var h = i[c];
            h && (h.ownKey = r);
          }
        var l = [
          new b(T, [], void 0, void 0, this)
        ];
        return y(t, l), this;
      };
      P = function P2(t) {
        var e = this[c], r = e.target;
        var n, i, l;
        for (r.sort(t), n = 0, i = r.length; n < i; n++)
          if (l = r[n], l && typeof l == "object") {
            var s = l[c];
            s && (s.ownKey = n);
          }
        var h = [
          new b(K, [], void 0, void 0, this)
        ];
        return y(e, h), this;
      };
      L = function L2(t, e, r) {
        var n = this[c], i = n.target, l = [], h = i.length, s = i.slice(0);
        if (e = e === void 0 ? 0 : e < 0 ? Math.max(h + e, 0) : Math.min(e, h), r = r === void 0 ? h : r < 0 ? Math.max(h + r, 0) : Math.min(r, h), e < h && r > e) {
          i.fill(t, e, r);
          var u;
          for (var f = e, a, p; f < r; f++)
            a = i[f], i[f] = g(a, f, n), f in s ? (p = s[f], p && typeof p == "object" && (u = p[c], u && (p = u.detach())), l.push(new b(x, [
              f
            ], i[f], p, this))) : l.push(new b(m, [
              f
            ], i[f], void 0, this));
          y(n, l);
        }
        return this;
      };
      C = function C2(t, e, r) {
        var n = this[c], i = n.target, l = i.length;
        t = t < 0 ? Math.max(l + t, 0) : t, e = e === void 0 ? 0 : e < 0 ? Math.max(l + e, 0) : Math.min(e, l), r = r === void 0 ? l : r < 0 ? Math.max(l + r, 0) : Math.min(r, l);
        var h = Math.min(r - e, l - t);
        if (t < l && t !== e && h > 0) {
          var s = i.slice(0), u = [];
          i.copyWithin(t, e, r);
          for (var f = t, a, p, O; f < t + h; f++)
            a = i[f], a && typeof a == "object" && (a = g(a, f, n), i[f] = a), p = s[f], p && typeof p == "object" && (O = p[c], O && (p = O.detach())), !(typeof a != "object" && a === p) && u.push(new b(x, [
              f
            ], a, p, this));
          y(n, u);
        }
        return this;
      };
      Q = function Q2() {
        var t = this[c], e = t.target, r = arguments.length, n = new Array(r), i = e.length;
        for (var w = 0; w < r; w++)
          n[w] = g(arguments[w], w, t);
        var l = r === 0 ? 0 : n[0] < 0 ? i + n[0] : n[0], h = r < 2 ? i - l : n[1], s = Math.max(r - 2, 0), u = Reflect.apply(e.splice, e, n), f = e.length;
        var a;
        for (var w1 = 0, A; w1 < f; w1++)
          A = e[w1], A && typeof A == "object" && (a = A[c], a && (a.ownKey = w1));
        var p, O, j;
        for (p = 0, O = u.length; p < O; p++)
          j = u[p], j && typeof j == "object" && (a = j[c], a && (u[p] = a.detach()));
        var M = [];
        var d;
        for (d = 0; d < h; d++)
          d < s ? M.push(new b(x, [
            l + d
          ], e[l + d], u[d], this)) : M.push(new b(E, [
            l + d
          ], void 0, u[d], this));
        for (; d < s; d++)
          M.push(new b(m, [
            l + d
          ], e[l + d], void 0, this));
        return y(t, M), u;
      };
      X = function X2(t, e) {
        var r = this[c], n = r.target, i = t.length, l = n.slice(0);
        e = e || 0, n.set(t, e);
        var h = new Array(i);
        for (var s = e; s < i + e; s++)
          h[s - e] = new b(x, [
            s
          ], n[s], l[s], this);
        y(r, h);
      };
      Z = {
        pop: q,
        push: H,
        shift: G,
        unshift: J,
        reverse: F,
        sort: P,
        fill: L,
        copyWithin: C,
        splice: Q
      };
      _ = {
        reverse: F,
        sort: P,
        fill: L,
        copyWithin: C,
        set: X
      };
      b = function b2(t, e, r, n, i) {
        "use strict";
        _class_call_check(this, b2);
        this.type = t, this.path = e, this.value = r, this.oldValue = n, this.object = i;
      };
      S = /* @__PURE__ */ function() {
        "use strict";
        function S2(t, e) {
          _class_call_check(this, S2);
          var { target: r, parent: n, ownKey: i, visited: l = /* @__PURE__ */ new Set() } = t;
          n && i !== void 0 ? (this.parent = n, this.ownKey = i) : (this.parent = null, this.ownKey = null), l.add(r);
          var h = e(r, this, l);
          l.delete(r), this.observers = [], this.revocable = Proxy.revocable(h, this), this.proxy = this.revocable.proxy, this.target = h, this.options = this.processOptions(t.options), this.options.async && (this.batches = []);
        }
        _create_class(S2, [
          {
            key: "processOptions",
            value: function processOptions(t) {
              if (t) {
                if (typeof t != "object")
                  throw new Error(`Observable options if/when provided, MAY only be an object, got '${t}'`);
                var e = Object.keys(t).filter((r) => !(r in $));
                if (e.length)
                  throw new Error(`'${e.join(", ")}' is/are not a valid Observable option/s`);
                return Object.assign({}, t);
              } else
                return {};
            }
          },
          {
            key: "detach",
            value: function detach() {
              return this.parent = null, this.target;
            }
          },
          {
            key: "set",
            value: function set(t, e, r) {
              var n = t[e];
              if (r !== n) {
                var i = g(r, e, this);
                if (t[e] = i, n && typeof n == "object") {
                  var h = n[c];
                  h && (n = h.detach());
                }
                var l = n === void 0 ? [
                  new b(m, [
                    e
                  ], i, void 0, this.proxy)
                ] : [
                  new b(x, [
                    e
                  ], i, n, this.proxy)
                ];
                y(this, l);
              }
              return true;
            }
          },
          {
            key: "deleteProperty",
            value: function deleteProperty(t, e) {
              var r = t[e];
              if (delete t[e], r && typeof r == "object") {
                var i = r[c];
                i && (r = i.detach());
              }
              var n = [
                new b(E, [
                  e
                ], void 0, r, this.proxy)
              ];
              return y(this, n), true;
            }
          }
        ]);
        return S2;
      }();
      V = /* @__PURE__ */ function(S2) {
        "use strict";
        _inherits(V2, S2);
        function V2(t) {
          _class_call_check(this, V2);
          return _call_super(this, V2, [
            t,
            Y
          ]);
        }
        return V2;
      }(S);
      U = /* @__PURE__ */ function(S2) {
        "use strict";
        _inherits(U2, S2);
        function U2(t) {
          _class_call_check(this, U2);
          return _call_super(this, U2, [
            t,
            I
          ]);
        }
        _create_class(U2, [
          {
            key: "get",
            value: function get(t, e) {
              return Z[e] || t[e];
            }
          }
        ]);
        return U2;
      }(S);
      W = /* @__PURE__ */ function(S2) {
        "use strict";
        _inherits(W2, S2);
        function W2(t) {
          _class_call_check(this, W2);
          return _call_super(this, W2, [
            t,
            B
          ]);
        }
        _create_class(W2, [
          {
            key: "get",
            value: function get(t, e) {
              return _[e] || t[e];
            }
          }
        ]);
        return W2;
      }(S);
      v = Object.freeze({
        from: (o, t) => {
          if (!o || typeof o != "object")
            throw new Error("observable MAY ONLY be created from a non-null object");
          if (o[c])
            return o;
          if (Array.isArray(o))
            return new U({
              target: o,
              ownKey: null,
              parent: null,
              options: t
            }).proxy;
          if (ArrayBuffer.isView(o))
            return new W({
              target: o,
              ownKey: null,
              parent: null,
              options: t
            }).proxy;
          if (o instanceof Date)
            throw new Error(`${o} found to be one of a non-observable types`);
          return new V({
            target: o,
            ownKey: null,
            parent: null,
            options: t
          }).proxy;
        },
        isObservable: (o) => !!(o && o[c]),
        observe: (o, t, e) => {
          if (!v.isObservable(o))
            throw new Error("invalid observable parameter");
          if (typeof t != "function")
            throw new Error(`observer MUST be a function, got '${t}'`);
          var r = o[c].observers;
          r.some((n) => n[0] === t) ? console.warn("observer may be bound to an observable only once; will NOT rebind") : r.push([
            t,
            N(e)
          ]);
        },
        unobserve: (o, ...t) => {
          if (!v.isObservable(o))
            throw new Error("invalid observable parameter");
          var e = o[c].observers;
          var r = e.length;
          if (r) {
            if (!t.length) {
              e.splice(0);
              return;
            }
            for (; r; )
              t.indexOf(e[--r][0]) >= 0 && e.splice(r, 1);
          }
        }
      });
    }
  });

  // src/lib/api/storage/index.ts
  var storage_exports = {};
  __export(storage_exports, {
    awaitStorage: () => awaitStorage2,
    createStorage: () => createStorage2,
    createStorageAndCallback: () => createStorageAndCallback,
    createStorageAsync: () => createStorageAsync,
    getPreloadedStorage: () => getPreloadedStorage,
    preloadStorageIfExists: () => preloadStorageIfExists,
    purgeStorage: () => purgeStorage2,
    updateStorage: () => updateStorage,
    useObservable: () => useObservable
  });
  function createFileBackend2(filePath) {
    var write = debounce((data) => {
      writeFile(filePath, JSON.stringify(data));
    }, 500);
    return {
      get: () => _async_to_generator(function* () {
        try {
          return JSON.parse(yield readFile(filePath));
        } catch (e) {
          throw new Error(`Failed to parse storage from '${filePath}'`, {
            cause: e
          });
        }
      })(),
      set: (data) => _async_to_generator(function* () {
        if (!data || typeof data !== "object") {
          throw new Error("data needs to be an object");
        }
        write(data);
      })(),
      exists: () => _async_to_generator(function* () {
        return yield fileExists(filePath);
      })()
    };
  }
  function useObservable(observables, opts) {
    if (observables.some((o) => o?.[storageInitErrorSymbol]))
      throw new Error("An error occured while initializing the storage");
    if (observables.some((o) => !v.isObservable(o))) {
      throw new Error("Argument passed isn't an Observable");
    }
    var [, forceUpdate] = React.useReducer((n) => ~n, 0);
    React.useEffect(() => {
      var listener = () => forceUpdate();
      observables.forEach((o) => v.observe(o, listener, opts));
      return () => {
        observables.forEach((o) => v.unobserve(o, listener));
      };
    }, []);
  }
  function updateStorage(path, value) {
    return _async_to_generator(function* () {
      _loadedStorage[path] = value;
      createFileBackend2(path).set(value);
    })();
  }
  function createStorageAndCallback(path, cb, { dflt = {}, nullIfEmpty = false } = {}) {
    var emitter;
    var callback = (data) => {
      var proxy = new Proxy(v.from(data), {
        get(target, prop, receiver) {
          if (prop === Symbol.for("vendetta.storage.emitter")) {
            if (emitter)
              return emitter;
            emitter = new Emitter();
            v.observe(target, (changes) => {
              for (var change of changes) {
                emitter.emit(change.type !== "delete" ? "SET" : "DEL", {
                  path: change.path,
                  value: change.value
                });
              }
            });
            return emitter;
          }
          return Reflect.get(target, prop, receiver);
        }
      });
      var handler = () => backend.set(proxy);
      v.observe(proxy, handler);
      cb(proxy);
    };
    var backend = createFileBackend2(path);
    if (_loadedStorage[path]) {
      callback(_loadedStorage[path]);
    } else {
      backend.exists().then((exists) => _async_to_generator(function* () {
        if (!exists) {
          if (nullIfEmpty) {
            callback(_loadedStorage[path] = null);
          } else {
            _loadedStorage[path] = dflt;
            yield backend.set(dflt);
            callback(dflt);
          }
        } else {
          callback(_loadedStorage[path] = yield backend.get());
        }
      })());
    }
  }
  function createStorageAsync(_0) {
    return _async_to_generator(function* (path, opts = {}) {
      return new Promise((r) => createStorageAndCallback(path, r, opts));
    }).apply(this, arguments);
  }
  function preloadStorageIfExists(path) {
    return _async_to_generator(function* () {
      if (_loadedStorage[path])
        return true;
      var backend = createFileBackend2(path);
      if (yield backend.exists()) {
        _loadedStorage[path] = yield backend.get();
        return true;
      }
      return false;
    })();
  }
  function purgeStorage2(path) {
    return _async_to_generator(function* () {
      yield removeFile(path);
      delete _loadedStorage[path];
    })();
  }
  function awaitStorage2(...proxies) {
    return Promise.all(proxies.map((proxy) => proxy[storagePromiseSymbol]));
  }
  function getPreloadedStorage(path) {
    return _loadedStorage[path];
  }
  var storageInitErrorSymbol, storagePromiseSymbol, _loadedStorage, createStorage2;
  var init_storage2 = __esm({
    "src/lib/api/storage/index.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_async_to_generator();
      init_Emitter();
      init_object_observer_min();
      init_fs();
      init_dist();
      storageInitErrorSymbol = Symbol.for("bunny.storage.initError");
      storagePromiseSymbol = Symbol.for("bunny.storage.promise");
      _loadedStorage = {};
      createStorage2 = (path, opts = {}) => {
        var promise = new Promise((r) => resolvePromise = r);
        var awaited, resolved, error, resolvePromise;
        createStorageAndCallback(path, (proxy) => {
          awaited = proxy;
          resolved = true;
          resolvePromise();
        }, opts);
        var check = () => {
          if (resolved)
            return true;
          throw new Error(`Attempted to access storage without initializing: ${path}`);
        };
        return new Proxy({}, {
          ...Object.fromEntries(Object.getOwnPropertyNames(Reflect).map((k) => [
            k,
            (t, ...a) => {
              return check() && Reflect[k](awaited, ...a);
            }
          ])),
          get(target, prop, recv) {
            if (prop === storageInitErrorSymbol)
              return error;
            if (prop === storagePromiseSymbol)
              return promise;
            return check() && Reflect.get(awaited ?? target, prop, recv);
          }
        });
      };
    }
  });

  // src/lib/utils/constants.ts
  var constants_exports = {};
  __export(constants_exports, {
    BUNNY_PROXY_PREFIX: () => BUNNY_PROXY_PREFIX,
    DISCORD_SERVER: () => DISCORD_SERVER,
    GITHUB: () => GITHUB,
    HTTP_REGEX: () => HTTP_REGEX,
    HTTP_REGEX_MULTI: () => HTTP_REGEX_MULTI,
    OFFICIAL_PLUGINS_REPO_URL: () => OFFICIAL_PLUGINS_REPO_URL,
    VD_DISCORD_SERVER_ID: () => VD_DISCORD_SERVER_ID,
    VD_PLUGINS_CHANNEL_ID: () => VD_PLUGINS_CHANNEL_ID,
    VD_PROXY_PREFIX: () => VD_PROXY_PREFIX,
    VD_THEMES_CHANNEL_ID: () => VD_THEMES_CHANNEL_ID
  });
  var DISCORD_SERVER, GITHUB, HTTP_REGEX, HTTP_REGEX_MULTI, BUNNY_PROXY_PREFIX, OFFICIAL_PLUGINS_REPO_URL, VD_PROXY_PREFIX, VD_DISCORD_SERVER_ID, VD_PLUGINS_CHANNEL_ID, VD_THEMES_CHANNEL_ID;
  var init_constants = __esm({
    "src/lib/utils/constants.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      DISCORD_SERVER = "https://discord.com/invite/ddcQf3s2Uq";
      GITHUB = "https://github.com/revenge-mod";
      HTTP_REGEX = /^https?:\/\/(?:www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_+.~#?&/=]*)$/;
      HTTP_REGEX_MULTI = /https?:\/\/(?:www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_+.~#?&//=]*)/g;
      BUNNY_PROXY_PREFIX = "https://bn-plugins.github.io/vd-proxy";
      OFFICIAL_PLUGINS_REPO_URL = "https://bn-plugins.github.io/dist/repo.json";
      VD_PROXY_PREFIX = "https://vd-plugins.github.io/proxy";
      VD_DISCORD_SERVER_ID = "1015931589865246730";
      VD_PLUGINS_CHANNEL_ID = "1091880384561684561";
      VD_THEMES_CHANNEL_ID = "1091880434939482202";
    }
  });

  // src/lib/utils/cyrb64.ts
  function cyrb64(str, seed = 0) {
    var h1 = 3735928559 ^ seed, h2 = 1103547991 ^ seed;
    for (var i = 0, ch; i < str.length; i++) {
      ch = str.charCodeAt(i);
      h1 = Math.imul(h1 ^ ch, 2654435761);
      h2 = Math.imul(h2 ^ ch, 1597334677);
    }
    h1 = Math.imul(h1 ^ h1 >>> 16, 2246822507);
    h1 ^= Math.imul(h2 ^ h2 >>> 13, 3266489909);
    h2 = Math.imul(h2 ^ h2 >>> 16, 2246822507);
    h2 ^= Math.imul(h1 ^ h1 >>> 13, 3266489909);
    return [
      h2 >>> 0,
      h1 >>> 0
    ];
  }
  function cyrb64Hash(str, seed = 0) {
    var [h2, h1] = cyrb64(str, seed);
    return h2.toString(36).padStart(7, "0") + h1.toString(36).padStart(7, "0");
  }
  var init_cyrb64 = __esm({
    "src/lib/utils/cyrb64.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
    }
  });

  // src/lib/utils/findInReactTree.ts
  function findInReactTree(tree, filter) {
    return findInTree(tree, filter, {
      walkable: [
        "props",
        "children",
        "child",
        "sibling"
      ]
    });
  }
  var init_findInReactTree = __esm({
    "src/lib/utils/findInReactTree.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_utils();
    }
  });

  // src/lib/utils/findInTree.ts
  function treeSearch(tree, filter, opts, depth) {
    if (depth > opts.maxDepth)
      return;
    if (!tree)
      return;
    try {
      if (filter(tree))
        return tree;
    } catch (unused) {
    }
    if (Array.isArray(tree)) {
      for (var item of tree) {
        if (typeof item !== "object" || item === null)
          continue;
        try {
          var found = treeSearch(item, filter, opts, depth + 1);
          if (found)
            return found;
        } catch (unused) {
        }
      }
    } else if (typeof tree === "object") {
      for (var key of Object.keys(tree)) {
        if (typeof tree[key] !== "object" || tree[key] === null)
          continue;
        if (opts.walkable.length && !opts.walkable.includes(key))
          continue;
        if (opts.ignore.includes(key))
          continue;
        try {
          var found1 = treeSearch(tree[key], filter, opts, depth + 1);
          if (found1)
            return found1;
        } catch (unused) {
        }
      }
    }
  }
  function findInTree(tree, filter, { walkable = [], ignore = [], maxDepth = 100 } = {}) {
    return treeSearch(tree, filter, {
      walkable,
      ignore,
      maxDepth
    }, 0);
  }
  var init_findInTree = __esm({
    "src/lib/utils/findInTree.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
    }
  });

  // src/lib/utils/hookDefineProperty.ts
  function hookDefineProperty(target, property, cb) {
    var targetAsAny = target;
    if (property in target) {
      return void cb(targetAsAny[property]);
    }
    var value;
    Object.defineProperty(targetAsAny, property, {
      get: () => value,
      set(v2) {
        value = cb(v2) ?? v2;
      },
      configurable: true,
      enumerable: false
    });
    return () => {
      delete targetAsAny[property];
      targetAsAny[property] = value;
    };
  }
  var init_hookDefineProperty = __esm({
    "src/lib/utils/hookDefineProperty.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
    }
  });

  // src/lib/utils/invariant.ts
  function invariant(condition, message) {
    if (condition)
      return;
    var resolvedMessage = typeof message === "function" ? message() : message;
    var prefix = "[Invariant Violation]";
    var value = resolvedMessage ? `${prefix}: ${resolvedMessage}` : prefix;
    throw new Error(value);
  }
  var init_invariant = __esm({
    "src/lib/utils/invariant.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
    }
  });

  // src/lib/utils/logger.ts
  var logger_exports = {};
  __export(logger_exports, {
    LoggerClass: () => LoggerClass,
    logger: () => logger
  });
  var LoggerClass, logger;
  var init_logger = __esm({
    "src/lib/utils/logger.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_wrappers();
      LoggerClass = findByNameLazy("Logger");
      logger = new LoggerClass("YumiCord");
    }
  });

  // src/lib/utils/safeFetch.ts
  function safeFetch(input, options, timeout = 1e4) {
    return _async_to_generator(function* () {
      var req = yield fetch(input, {
        signal: timeoutSignal(timeout),
        ...options
      });
      if (!req.ok)
        throw new Error(`Request returned non-ok: ${req.status} ${req.statusText}`);
      return req;
    })();
  }
  function timeoutSignal(ms) {
    var controller = new AbortController();
    setTimeout(() => controller.abort(`Timed out after ${ms}ms`), ms);
    return controller.signal;
  }
  var init_safeFetch = __esm({
    "src/lib/utils/safeFetch.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_async_to_generator();
    }
  });

  // src/lib/utils/index.ts
  var utils_exports = {};
  __export(utils_exports, {
    constants: () => constants_exports,
    cyrb64: () => cyrb64,
    findInReactTree: () => findInReactTree,
    findInTree: () => findInTree,
    hookDefineProperty: () => hookDefineProperty,
    invariant: () => invariant,
    lazy: () => lazy_exports,
    logger: () => logger_exports,
    safeFetch: () => safeFetch
  });
  var init_utils = __esm({
    "src/lib/utils/index.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_constants();
      init_cyrb64();
      init_findInReactTree();
      init_findInTree();
      init_hookDefineProperty();
      init_invariant();
      init_lazy();
      init_logger();
      init_safeFetch();
    }
  });

  // shims/jsxRuntime.ts
  var jsxRuntime_exports = {};
  __export(jsxRuntime_exports, {
    Fragment: () => Fragment,
    jsx: () => jsx,
    jsxs: () => jsxs
  });
  function unproxyFirstArg(args) {
    if (!args[0]) {
      throw new Error("The first argument (Component) is falsy. Ensure that you are passing a valid component.");
    }
    var factory = getProxyFactory(args[0]);
    if (factory)
      args[0] = factory();
    return args;
  }
  var jsxRuntime, Fragment, jsx, jsxs;
  var init_jsxRuntime = __esm({
    "shims/jsxRuntime.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_lazy();
      init_wrappers();
      jsxRuntime = findByPropsLazy("jsx", "jsxs", "Fragment");
      Fragment = Symbol.for("react.fragment");
      jsx = (...args) => jsxRuntime.jsx(...unproxyFirstArg(args));
      jsxs = (...args) => jsxRuntime.jsxs(...unproxyFirstArg(args));
    }
  });

  // src/lib/addons/themes/colors/preferences.ts
  var colorsPref;
  var init_preferences = __esm({
    "src/lib/addons/themes/colors/preferences.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_storage2();
      colorsPref = createStorage2("themes/colors/preferences.json", {
        dflt: {
          selected: null,
          customBackground: null
        }
      });
    }
  });

  // src/metro/common/components.ts
  var components_exports = {};
  __export(components_exports, {
    ActionSheet: () => ActionSheet,
    ActionSheetRow: () => ActionSheetRow,
    AlertActionButton: () => AlertActionButton,
    AlertActions: () => AlertActions,
    AlertModal: () => AlertModal,
    Avatar: () => Avatar,
    AvatarPile: () => AvatarPile,
    BottomSheetTitleHeader: () => BottomSheetTitleHeader,
    Button: () => Button,
    Card: () => Card,
    CompatButton: () => CompatButton,
    CompatSegmentedControl: () => CompatSegmentedControl,
    ContextMenu: () => ContextMenu,
    FlashList: () => FlashList,
    FloatingActionButton: () => FloatingActionButton,
    FormCheckbox: () => FormCheckbox,
    FormRadio: () => FormRadio,
    FormSwitch: () => FormSwitch,
    Forms: () => Forms,
    HelpMessage: () => HelpMessage,
    IconButton: () => IconButton,
    LegacyAlert: () => LegacyAlert,
    LegacyForm: () => LegacyForm,
    LegacyFormArrow: () => LegacyFormArrow,
    LegacyFormCTA: () => LegacyFormCTA,
    LegacyFormCTAButton: () => LegacyFormCTAButton,
    LegacyFormCardSection: () => LegacyFormCardSection,
    LegacyFormCheckbox: () => LegacyFormCheckbox,
    LegacyFormCheckboxRow: () => LegacyFormCheckboxRow,
    LegacyFormCheckmark: () => LegacyFormCheckmark,
    LegacyFormDivider: () => LegacyFormDivider,
    LegacyFormHint: () => LegacyFormHint,
    LegacyFormIcon: () => LegacyFormIcon,
    LegacyFormInput: () => LegacyFormInput,
    LegacyFormLabel: () => LegacyFormLabel,
    LegacyFormRadio: () => LegacyFormRadio,
    LegacyFormRadioGroup: () => LegacyFormRadioGroup,
    LegacyFormRadioRow: () => LegacyFormRadioRow,
    LegacyFormRow: () => LegacyFormRow,
    LegacyFormSection: () => LegacyFormSection,
    LegacyFormSelect: () => LegacyFormSelect,
    LegacyFormSliderRow: () => LegacyFormSliderRow,
    LegacyFormSubLabel: () => LegacyFormSubLabel,
    LegacyFormSwitch: () => LegacyFormSwitch,
    LegacyFormSwitchRow: () => LegacyFormSwitchRow,
    LegacyFormTernaryCheckBox: () => LegacyFormTernaryCheckBox,
    LegacyFormText: () => LegacyFormText,
    LegacyFormTitle: () => LegacyFormTitle,
    PressableScale: () => PressableScale,
    RedesignCompat: () => RedesignCompat,
    RowButton: () => RowButton,
    SafeAreaProvider: () => SafeAreaProvider,
    SafeAreaView: () => SafeAreaView,
    SegmentedControl: () => SegmentedControl,
    SegmentedControlPages: () => SegmentedControlPages,
    Stack: () => Stack,
    TableCheckbox: () => TableCheckbox,
    TableCheckboxRow: () => TableCheckboxRow,
    TableRadio: () => TableRadio,
    TableRadioGroup: () => TableRadioGroup,
    TableRadioRow: () => TableRadioRow,
    TableRow: () => TableRow,
    TableRowGroup: () => TableRowGroup,
    TableRowIcon: () => TableRowIcon,
    TableRowTrailingText: () => TableRowTrailingText,
    TableSwitch: () => TableSwitch,
    TableSwitchRow: () => TableSwitchRow,
    Text: () => Text,
    TextArea: () => TextArea,
    TextInput: () => TextInput,
    TwinButtons: () => TwinButtons,
    useSafeAreaInsets: () => useSafeAreaInsets,
    useSegmentedControlState: () => useSegmentedControlState
  });
  var bySingularProp, findSingular, findProp, LegacyAlert, CompatButton, HelpMessage, SafeAreaView, SafeAreaProvider, useSafeAreaInsets, ActionSheetRow, Button, TwinButtons, IconButton, RowButton, PressableScale, TableRow, TableRowIcon, TableRowTrailingText, TableRowGroup, TableRadioGroup, TableRadioRow, TableSwitchRow, TableCheckboxRow, TableSwitch, TableRadio, TableCheckbox, FormSwitch, FormRadio, FormCheckbox, Card, RedesignCompat, AlertModal, AlertActionButton, AlertActions, AvatarPile, ContextMenu, Stack, Avatar, TextInput, TextArea, SegmentedControl, SegmentedControlPages, useSegmentedControlState, CompatSegmentedControl, FloatingActionButton, ActionSheet, BottomSheetTitleHeader, textsModule, Text, Forms, LegacyForm, LegacyFormArrow, LegacyFormCTA, LegacyFormCTAButton, LegacyFormCardSection, LegacyFormCheckbox, LegacyFormCheckboxRow, LegacyFormCheckmark, LegacyFormDivider, LegacyFormHint, LegacyFormIcon, LegacyFormInput, LegacyFormLabel, LegacyFormRadio, LegacyFormRadioGroup, LegacyFormRadioRow, LegacyFormRow, LegacyFormSection, LegacyFormSelect, LegacyFormSliderRow, LegacyFormSubLabel, LegacyFormSwitch, LegacyFormSwitchRow, LegacyFormTernaryCheckBox, LegacyFormText, LegacyFormTitle, FlashList;
  var init_components = __esm({
    "src/metro/common/components.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_lazy();
      init_factories();
      init_finders();
      init_wrappers();
      bySingularProp = createFilterDefinition(([prop], m2) => m2[prop] && Object.keys(m2).length === 1, (prop) => `bunny.metro.common.components.bySingularProp(${prop})`);
      findSingular = (prop) => proxyLazy(() => findExports(bySingularProp(prop))?.[prop]);
      findProp = (...props) => proxyLazy(() => findByProps(...props)[props[0]]);
      LegacyAlert = findByDisplayNameLazy("FluxContainer(Alert)");
      CompatButton = findByPropsLazy("Looks", "Colors", "Sizes");
      HelpMessage = findByNameLazy("HelpMessage");
      ({ SafeAreaView, SafeAreaProvider, useSafeAreaInsets } = lazyDestructure(() => findByProps("useSafeAreaInsets")));
      ActionSheetRow = findProp("ActionSheetRow");
      Button = findSingular("Button");
      TwinButtons = findProp("TwinButtons");
      IconButton = findSingular("IconButton");
      RowButton = findProp("RowButton");
      PressableScale = findProp("PressableScale");
      TableRow = findProp("TableRow");
      TableRowIcon = findProp("TableRowIcon");
      TableRowTrailingText = findProp("TableRowTrailingText");
      TableRowGroup = findProp("TableRowGroup");
      TableRadioGroup = findProp("TableRadioGroup");
      TableRadioRow = findProp("TableRadioRow");
      TableSwitchRow = findProp("TableSwitchRow");
      TableCheckboxRow = findProp("TableCheckboxRow");
      TableSwitch = findSingular("FormSwitch");
      TableRadio = findSingular("FormRadio");
      TableCheckbox = findSingular("FormCheckbox");
      FormSwitch = findSingular("FormSwitch");
      FormRadio = findSingular("FormRadio");
      FormCheckbox = findSingular("FormCheckbox");
      Card = findProp("Card");
      RedesignCompat = proxyLazy(() => findByProps("RedesignCompat").RedesignCompat);
      AlertModal = findProp("AlertModal");
      AlertActionButton = findProp("AlertActionButton");
      AlertActions = findProp("AlertActions");
      AvatarPile = findSingular("AvatarPile");
      ContextMenu = findProp("ContextMenu");
      Stack = findProp("Stack");
      Avatar = findProp("default", "AvatarSizes", "getStatusSize");
      TextInput = findSingular("TextInput");
      TextArea = findSingular("TextArea");
      SegmentedControl = findProp("SegmentedControl");
      SegmentedControlPages = findProp("SegmentedControlPages");
      useSegmentedControlState = findSingular("useSegmentedControlState");
      CompatSegmentedControl = findProp("CompatSegmentedControl");
      FloatingActionButton = findProp("FloatingActionButton");
      ActionSheet = findProp("ActionSheet");
      BottomSheetTitleHeader = findProp("BottomSheetTitleHeader");
      textsModule = findByPropsLazy("Text", "LegacyText");
      Text = proxyLazy(() => textsModule.Text);
      Forms = findByPropsLazy("Form", "FormSection");
      ({ Form: LegacyForm, FormArrow: LegacyFormArrow, FormCTA: LegacyFormCTA, FormCTAButton: LegacyFormCTAButton, FormCardSection: LegacyFormCardSection, FormCheckbox: LegacyFormCheckbox, FormCheckboxRow: LegacyFormCheckboxRow, FormCheckmark: LegacyFormCheckmark, FormDivider: LegacyFormDivider, FormHint: LegacyFormHint, FormIcon: LegacyFormIcon, FormInput: LegacyFormInput, FormLabel: LegacyFormLabel, FormRadio: LegacyFormRadio, FormRadioGroup: LegacyFormRadioGroup, FormRadioRow: LegacyFormRadioRow, FormRow: LegacyFormRow, FormSection: LegacyFormSection, FormSelect: LegacyFormSelect, FormSliderRow: LegacyFormSliderRow, FormSubLabel: LegacyFormSubLabel, FormSwitch: LegacyFormSwitch, FormSwitchRow: LegacyFormSwitchRow, FormTernaryCheckBox: LegacyFormTernaryCheckBox, FormText: LegacyFormText, FormTitle: LegacyFormTitle } = lazyDestructure(() => Forms));
      FlashList = findProp("FlashList");
    }
  });

  // src/metro/common/index.ts
  var common_exports = {};
  __export(common_exports, {
    Flux: () => Flux,
    FluxDispatcher: () => FluxDispatcher,
    FluxUtils: () => FluxUtils,
    NavigationNative: () => NavigationNative,
    React: () => React2,
    ReactNative: () => ReactNative,
    assets: () => assets,
    channels: () => channels,
    clipboard: () => clipboard,
    commands: () => commands,
    components: () => components_exports,
    constants: () => constants,
    i18n: () => i18n,
    invites: () => invites,
    messageUtil: () => messageUtil,
    navigation: () => navigation,
    navigationStack: () => navigationStack,
    semver: () => semver,
    toasts: () => toasts,
    tokens: () => tokens,
    url: () => url,
    useToken: () => useToken
  });
  var import_react_native2, constants, channels, i18n, openURL, url, clipboard, assets, invites, commands, navigation, toasts, messageUtil, navigationStack, NavigationNative, semver, tokens, useToken, Flux, FluxDispatcher, FluxUtils, React2, ReactNative;
  var init_common = __esm({
    "src/metro/common/index.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_lazy();
      init_wrappers();
      import_react_native2 = __toESM(require_react_native());
      init_components();
      constants = findByPropsLazy("Fonts", "Permissions");
      channels = findByPropsLazy("getVoiceChannelId");
      i18n = findByPropsLazy("Messages");
      openURL = (url2) => import_react_native2.Linking.openURL(url2);
      url = nativeModuleProxy.NativeLinkingModule || nativeModuleProxy.DCDLinkingManager ? {
        openURL,
        openDeeplink: openURL,
        handleSupportedURL: openURL,
        isDiscordConnectOauth2Deeplink: () => {
          console.warn("url.isDiscordConnectOauth2Deeplink is not implemented and will always return false");
          return false;
        },
        showLongPressUrlActionSheet: () => console.warn("url.showLongPressUrlActionSheet is not implemented"),
        handleMessageLinking: findByFilePathLazy("modules/links/native/handleContentLinking.tsx", true)
      } : findByPropsLazy("openURL", "openDeeplink");
      clipboard = findByPropsLazy("setString", "getString", "hasString");
      assets = findByPropsLazy("registerAsset");
      invites = findByPropsLazy("acceptInviteAndTransitionToInviteChannel");
      commands = findByPropsLazy("getBuiltInCommands");
      navigation = findByPropsLazy("pushLazy");
      toasts = findByFilePathLazy("modules/toast/native/ToastActionCreators.tsx", true);
      messageUtil = findByPropsLazy("sendBotMessage");
      navigationStack = findByPropsLazy("createStackNavigator");
      NavigationNative = findByPropsLazy("NavigationContainer");
      semver = findByPropsLazy("parse", "clean");
      tokens = findByPropsLazy("unsafe_rawColors", "colors");
      ({ useToken } = lazyDestructure(() => findByProps("useToken")));
      Flux = findByPropsLazy("connectStores");
      FluxDispatcher = findByProps("_interceptors");
      FluxUtils = findByProps("useStateFromStores");
      React2 = globalThis.React = findByPropsLazy("createElement");
      ReactNative = globalThis.ReactNative = findByPropsLazy("AppRegistry");
    }
  });

  // src/metro/index.ts
  var metro_exports = {};
  __export(metro_exports, {
    common: () => common_exports,
    factories: () => factories_exports,
    filters: () => filters_exports,
    findAllExports: () => findAllExports,
    findAllModule: () => findAllModule,
    findAllModuleId: () => findAllModuleId,
    findByDisplayName: () => findByDisplayName,
    findByDisplayNameAll: () => findByDisplayNameAll,
    findByDisplayNameLazy: () => findByDisplayNameLazy,
    findByFilePath: () => findByFilePath,
    findByFilePathLazy: () => findByFilePathLazy,
    findByName: () => findByName,
    findByNameAll: () => findByNameAll,
    findByNameLazy: () => findByNameLazy,
    findByProps: () => findByProps,
    findByPropsAll: () => findByPropsAll,
    findByPropsLazy: () => findByPropsLazy,
    findByStoreName: () => findByStoreName,
    findByStoreNameLazy: () => findByStoreNameLazy,
    findByTypeName: () => findByTypeName,
    findByTypeNameAll: () => findByTypeNameAll,
    findByTypeNameLazy: () => findByTypeNameLazy,
    findExports: () => findExports,
    findModule: () => findModule,
    findModuleId: () => findModuleId,
    lazy: () => lazy_exports2
  });
  var init_metro = __esm({
    "src/metro/index.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_common();
      init_factories();
      init_filters();
      init_finders();
      init_lazy2();
      init_wrappers();
    }
  });

  // globals:chroma-js
  var require_chroma_js = __commonJS({
    "globals:chroma-js"(exports, module) {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      module.exports = require_depsModule()["chroma-js"];
    }
  });

  // src/lib/addons/themes/colors/parser.ts
  function parseColorManifest(manifest) {
    var resolveType = (type2 = "dark") => (colorsPref.type ?? type2) === "dark" ? "darker" : "light";
    if (manifest.spec === 3) {
      var semanticColorDefinitions = {};
      for (var [semanticColorKey, semanticColorValue] of Object.entries(manifest.main.semantic ?? {})) {
        if (typeof semanticColorValue === "object") {
          var { type, value, opacity: semanticColorOpacity } = semanticColorValue;
          if (type === "raw") {
            semanticColorDefinitions[semanticColorKey] = {
              value,
              opacity: semanticColorOpacity ?? 1
            };
          } else {
            var rawColorValue = tokenRef.RawColor[value];
            semanticColorDefinitions[semanticColorKey] = {
              value: rawColorValue,
              opacity: semanticColorOpacity ?? 1
            };
          }
        } else if (typeof semanticColorValue === "string") {
          if (semanticColorValue.startsWith("#")) {
            semanticColorDefinitions[semanticColorKey] = {
              value: import_chroma_js.default.hex(semanticColorValue).hex(),
              opacity: 1
            };
          } else {
            semanticColorDefinitions[semanticColorKey] = {
              value: tokenRef.RawColor[semanticColorValue],
              opacity: 1
            };
          }
        } else {
          throw new Error(`Invalid semantic definitions: ${semanticColorValue}`);
        }
      }
      if (import_react_native3.Platform.OS === "android")
        applyAndroidAlphaKeys(manifest.main.raw);
      return {
        spec: 3,
        reference: resolveType(manifest.type),
        semantic: semanticColorDefinitions,
        raw: manifest.main.raw ?? {},
        background: manifest.main.background
      };
    }
    if (manifest.spec === 2) {
      var semanticDefinitions = {};
      var background = manifest.background ? {
        ...omit(manifest.background, [
          "alpha"
        ]),
        opacity: manifest.background.alpha
      } : void 0;
      if (manifest.semanticColors) {
        for (var key in manifest.semanticColors) {
          var values = manifest.semanticColors[key].map((c2) => c2 || void 0).slice(0, 2);
          if (!values[0])
            continue;
          semanticDefinitions[key] = {
            value: normalizeToHex(values[resolveType() === "light" ? 1 : 0]),
            opacity: 1
          };
        }
      }
      if (manifest.rawColors) {
        var draft = {};
        for (var key1 in manifest.rawColors) {
          var value1 = manifest.rawColors[key1];
          if (!value1)
            continue;
          draft[key1] = normalizeToHex(value1);
        }
        if (import_react_native3.Platform.OS === "android")
          applyAndroidAlphaKeys(draft);
        manifest.rawColors = draft;
      }
      return {
        spec: 2,
        reference: resolveType(),
        semantic: semanticDefinitions,
        raw: manifest.rawColors ?? {},
        background
      };
    }
    throw new Error("Invalid theme spec");
  }
  function applyAndroidAlphaKeys(rawColors2) {
    if (!rawColors2)
      return;
    var alphaMap = {
      "BLACK_ALPHA_60": [
        "BLACK",
        0.6
      ],
      "BRAND_NEW_360_ALPHA_20": [
        "BRAND_360",
        0.2
      ],
      "BRAND_NEW_360_ALPHA_25": [
        "BRAND_360",
        0.25
      ],
      "BRAND_NEW_500_ALPHA_20": [
        "BRAND_500",
        0.2
      ],
      "PRIMARY_DARK_500_ALPHA_20": [
        "PRIMARY_500",
        0.2
      ],
      "PRIMARY_DARK_700_ALPHA_60": [
        "PRIMARY_700",
        0.6
      ],
      "STATUS_GREEN_500_ALPHA_20": [
        "GREEN_500",
        0.2
      ],
      "STATUS_RED_500_ALPHA_20": [
        "RED_500",
        0.2
      ]
    };
    for (var key in alphaMap) {
      var [colorKey, alpha] = alphaMap[key];
      if (!rawColors2[colorKey])
        continue;
      rawColors2[key] = (0, import_chroma_js.default)(rawColors2[colorKey]).alpha(alpha).hex();
    }
    return rawColors2;
  }
  function normalizeToHex(colorString) {
    if (colorString === void 0)
      return void 0;
    if (import_chroma_js.default.valid(colorString))
      return (0, import_chroma_js.default)(colorString).hex();
    var color2 = Number((0, import_react_native3.processColor)(colorString));
    return import_chroma_js.default.rgb(
      color2 >> 16 & 255,
      color2 >> 8 & 255,
      color2 & 255,
      color2 >> 24 & 255
      // alpha
    ).hex();
  }
  var import_chroma_js, import_react_native3, tokenRef;
  var init_parser = __esm({
    "src/lib/addons/themes/colors/parser.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_metro();
      import_chroma_js = __toESM(require_chroma_js());
      init_dist();
      import_react_native3 = __toESM(require_react_native());
      init_preferences();
      tokenRef = findByProps("SemanticColor");
    }
  });

  // src/lib/addons/themes/colors/updater.ts
  function updateBunnyColor(colorManifest, { update = true }) {
    if (settings.safeMode?.enabled)
      return;
    var internalDef = colorManifest ? parseColorManifest(colorManifest) : null;
    var ref = Object.assign(_colorRef, {
      current: internalDef,
      key: `bn-theme-${++_inc}`,
      lastSetDiscordTheme: !ThemeStore.theme.startsWith("bn-theme-") ? ThemeStore.theme : _colorRef.lastSetDiscordTheme
    });
    if (internalDef != null) {
      tokenRef2.Theme[ref.key.toUpperCase()] = ref.key;
      FormDivider.DIVIDER_COLORS[ref.key] = FormDivider.DIVIDER_COLORS[ref.current.reference];
      Object.keys(tokenRef2.Shadow).forEach((k) => tokenRef2.Shadow[k][ref.key] = tokenRef2.Shadow[k][ref.current.reference]);
      Object.keys(tokenRef2.SemanticColor).forEach((k) => {
        tokenRef2.SemanticColor[k][ref.key] = {
          ...tokenRef2.SemanticColor[k][ref.current.reference]
        };
      });
    }
    if (update) {
      AppearanceManager.setShouldSyncAppearanceSettings(false);
      AppearanceManager.updateTheme(internalDef != null ? ref.key : ref.lastSetDiscordTheme);
    }
  }
  var tokenRef2, origRawColor, AppearanceManager, ThemeStore, FormDivider, _inc, _colorRef;
  var init_updater = __esm({
    "src/lib/addons/themes/colors/updater.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_settings();
      init_metro();
      init_parser();
      tokenRef2 = findByProps("SemanticColor");
      origRawColor = {
        ...tokenRef2.RawColor
      };
      AppearanceManager = findByPropsLazy("updateTheme");
      ThemeStore = findByStoreNameLazy("ThemeStore");
      FormDivider = findByPropsLazy("DIVIDER_COLORS");
      _inc = 1;
      _colorRef = {
        current: null,
        key: `bn-theme-${_inc}`,
        origRaw: origRawColor,
        lastSetDiscordTheme: "darker"
      };
    }
  });

  // src/lib/addons/themes/colors/patches/background.tsx
  function ThemeBackground({ children }) {
    useObservable([
      colorsPref
    ]);
    if (!_colorRef.current || colorsPref.customBackground === "hidden" || !_colorRef.current.background?.url || _colorRef.current.background?.blur && typeof _colorRef.current.background?.blur !== "number") {
      return children;
    }
    return /* @__PURE__ */ jsx(import_react_native4.ImageBackground, {
      style: {
        flex: 1,
        height: "100%"
      },
      source: {
        uri: _colorRef.current.background?.url
      },
      blurRadius: _colorRef.current.background?.blur,
      children
    });
  }
  function patchChatBackground() {
    try {
      var patch = (_2, ret) => {
        if (!_colorRef.current || !_colorRef.current.background?.url)
          return;
        var messagesComponent = findInReactTree(ret, (x2) => x2 && "HACK_fixModalInteraction" in x2.props && x2?.props?.style);
        if (messagesComponent) {
          var flattened = import_react_native4.StyleSheet.flatten(messagesComponent.props.style);
          var backgroundColor = (0, import_chroma_js2.default)(flattened.backgroundColor || "black").alpha(1 - (_colorRef.current.background?.opacity ?? 1)).hex();
          messagesComponent.props.style = import_react_native4.StyleSheet.flatten([
            messagesComponent.props.style,
            {
              backgroundColor
            }
          ]);
        }
        return /* @__PURE__ */ jsx(ThemeBackground, {
          children: ret
        });
      };
      var patches2 = [
        typeof MessagesModule.default === "function" ? after("default", MessagesModule, patch) : after("render", MessagesModule.default, patch)
      ];
      return () => patches2.forEach((x2) => x2());
    } catch (e) {
      logger.error("Failed to patch chat background.", e);
      return () => {
      };
    }
  }
  var import_chroma_js2, import_react_native4, MessagesModule;
  var init_background = __esm({
    "src/lib/addons/themes/colors/patches/background.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_jsxRuntime();
      init_preferences();
      init_updater();
      init_patcher();
      init_storage2();
      init_utils();
      init_metro();
      import_chroma_js2 = __toESM(require_chroma_js());
      import_react_native4 = __toESM(require_react_native());
      init_logger();
      MessagesModule = findByDisplayNameLazy("MessagesConnected", false);
    }
  });

  // src/lib/addons/themes/colors/patches/resolver.ts
  function patchDefinitionAndResolver() {
    var callback = ([theme]) => theme === _colorRef.key ? [
      _colorRef.current.reference
    ] : void 0;
    Object.keys(tokenReference.RawColor).forEach((key) => {
      Object.defineProperty(tokenReference.RawColor, key, {
        configurable: true,
        enumerable: true,
        get: () => {
          var ret = _colorRef.current?.raw[key];
          return ret || _colorRef.origRaw[key];
        }
      });
    });
    var unpatches = [
      before("isThemeDark", isThemeModule, callback),
      before("isThemeLight", isThemeModule, callback),
      before("updateTheme", NativeThemeModule, callback),
      instead("resolveSemanticColor", tokenReference.default.meta ?? tokenReference.default.internal, (args, orig) => {
        if (!_colorRef.current)
          return orig(...args);
        if (args[0] !== _colorRef.key)
          return orig(...args);
        args[0] = _colorRef.current.reference;
        var [name, colorDef] = extractInfo(_colorRef.current.reference, args[1]);
        var semanticDef = _colorRef.current.semantic[name];
        if (!semanticDef && _colorRef.current.spec === 2 && name in SEMANTIC_FALLBACK_MAP) {
          semanticDef = _colorRef.current.semantic[SEMANTIC_FALLBACK_MAP[name]];
        }
        if (semanticDef?.value) {
          if (semanticDef.opacity === 1)
            return semanticDef.value;
          return (0, import_chroma_js3.default)(semanticDef.value).alpha(semanticDef.opacity).hex();
        }
        var rawValue = _colorRef.current.raw[colorDef.raw];
        if (rawValue) {
          return colorDef.opacity === 1 ? rawValue : (0, import_chroma_js3.default)(rawValue).alpha(colorDef.opacity).hex();
        }
        return orig(...args);
      }),
      () => {
        Object.defineProperty(tokenReference, "RawColor", {
          configurable: true,
          writable: true,
          value: _colorRef.origRaw
        });
      }
    ];
    return () => unpatches.forEach((p) => p());
  }
  function extractInfo(themeName, colorObj) {
    var propName = colorObj[extractInfo._sym ??= Object.getOwnPropertySymbols(colorObj)[0]];
    var colorDef = tokenReference.SemanticColor[propName];
    return [
      propName,
      colorDef[themeName]
    ];
  }
  var import_chroma_js3, tokenReference, isThemeModule, SEMANTIC_FALLBACK_MAP;
  var init_resolver = __esm({
    "src/lib/addons/themes/colors/patches/resolver.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_updater();
      init_modules();
      init_patcher();
      init_metro();
      init_filters();
      init_lazy2();
      import_chroma_js3 = __toESM(require_chroma_js());
      tokenReference = findByProps("SemanticColor");
      isThemeModule = createLazyModule(byMutableProp("isThemeDark"));
      SEMANTIC_FALLBACK_MAP = {
        "BG_BACKDROP": "BACKGROUND_FLOATING",
        "BG_BASE_PRIMARY": "BACKGROUND_PRIMARY",
        "BG_BASE_SECONDARY": "BACKGROUND_SECONDARY",
        "BG_BASE_TERTIARY": "BACKGROUND_SECONDARY_ALT",
        "BG_MOD_FAINT": "BACKGROUND_MODIFIER_ACCENT",
        "BG_MOD_STRONG": "BACKGROUND_MODIFIER_ACCENT",
        "BG_MOD_SUBTLE": "BACKGROUND_MODIFIER_ACCENT",
        "BG_SURFACE_OVERLAY": "BACKGROUND_FLOATING",
        "BG_SURFACE_OVERLAY_TMP": "BACKGROUND_FLOATING",
        "BG_SURFACE_RAISED": "BACKGROUND_MOBILE_PRIMARY"
      };
    }
  });

  // src/lib/addons/themes/colors/patches/storage.ts
  function patchStorage() {
    var patchedKeys = /* @__PURE__ */ new Set([
      "ThemeStore",
      "SelectivelySyncedUserSettingsStore"
    ]);
    var patches2 = [
      after("get", mmkvStorage, ([key], ret) => {
        if (!_colorRef.current || !patchedKeys.has(key))
          return;
        var state = findInTree(ret._state, (s) => typeof s.theme === "string");
        if (state)
          state.theme = _colorRef.key;
      }),
      before("set", mmkvStorage, ([key, value]) => {
        if (!patchedKeys.has(key))
          return;
        var json = JSON.stringify(value);
        var lastSetDiscordTheme = _colorRef.lastSetDiscordTheme ?? "darker";
        var replaced = json.replace(/"theme":"bn-theme-\d+"/, `"theme":${JSON.stringify(lastSetDiscordTheme)}`);
        return [
          key,
          JSON.parse(replaced)
        ];
      })
    ];
    return () => patches2.forEach((p) => p());
  }
  var mmkvStorage;
  var init_storage3 = __esm({
    "src/lib/addons/themes/colors/patches/storage.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_updater();
      init_patcher();
      init_utils();
      init_lazy();
      init_metro();
      mmkvStorage = proxyLazy(() => {
        var newModule = findByProps("impl");
        if (typeof newModule?.impl === "object")
          return newModule.impl;
        return findByProps("storage");
      });
    }
  });

  // src/lib/addons/themes/colors/index.ts
  function initColors(manifest) {
    var patches2 = [
      patchStorage(),
      patchDefinitionAndResolver(),
      patchChatBackground()
    ];
    if (manifest)
      updateBunnyColor(manifest, {
        update: false
      });
    return () => patches2.forEach((p) => p());
  }
  var init_colors = __esm({
    "src/lib/addons/themes/colors/index.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_background();
      init_resolver();
      init_storage3();
      init_updater();
    }
  });

  // src/lib/addons/themes/index.ts
  var themes_exports = {};
  __export(themes_exports, {
    fetchTheme: () => fetchTheme,
    getCurrentTheme: () => getCurrentTheme,
    getThemeFromLoader: () => getThemeFromLoader,
    initThemes: () => initThemes,
    installTheme: () => installTheme,
    removeTheme: () => removeTheme,
    selectTheme: () => selectTheme,
    themes: () => themes,
    updateThemes: () => updateThemes,
    writeThemeToNative: () => writeThemeToNative
  });
  function writeThemeToNative(theme) {
    return _async_to_generator(function* () {
      if (typeof theme !== "object")
        throw new Error("Theme must be an object");
      yield createFileBackend(getThemeFilePath() || "theme.json").set(theme);
    })();
  }
  function processData(data) {
    if (data.semanticColors) {
      var { semanticColors: semanticColors2 } = data;
      for (var key in semanticColors2) {
        for (var index in semanticColors2[key]) {
          semanticColors2[key][index] &&= normalizeToHex(semanticColors2[key][index]) || false;
        }
      }
    }
    if (data.rawColors) {
      var { rawColors: rawColors2 } = data;
      for (var key1 in rawColors2) {
        var normalized = normalizeToHex(rawColors2[key1]);
        if (normalized)
          data.rawColors[key1] = normalized;
      }
      if (import_react_native5.Platform.OS === "android")
        applyAndroidAlphaKeys(rawColors2);
    }
    data.spec ??= 2;
    return data;
  }
  function validateTheme(themeJSON) {
    if (typeof themeJSON !== "object" || themeJSON === null)
      return false;
    if (themeJSON.spec !== 2 && themeJSON.spec !== 3)
      return false;
    if (themeJSON.spec === 3 && !themeJSON.main)
      return false;
    return true;
  }
  function fetchTheme(url2, selected = false) {
    return _async_to_generator(function* () {
      var themeJSON;
      try {
        themeJSON = yield (yield safeFetch(url2, {
          cache: "no-store"
        })).json();
      } catch (unused) {
        throw new Error(`Failed to fetch theme at ${url2}`);
      }
      if (!validateTheme(themeJSON))
        throw new Error(`Invalid theme at ${url2}`);
      themes[url2] = {
        id: url2,
        selected,
        data: processData(themeJSON)
      };
      if (selected) {
        writeThemeToNative(themes[url2]);
        updateBunnyColor(themes[url2].data, {
          update: true
        });
      }
    })();
  }
  function installTheme(url2) {
    return _async_to_generator(function* () {
      if (typeof url2 !== "string" || url2 in themes)
        throw new Error("Theme already installed");
      yield fetchTheme(url2);
    })();
  }
  function selectTheme(theme, write = true) {
    if (theme)
      theme.selected = true;
    Object.keys(themes).forEach((k) => themes[k].selected = themes[k].id === theme?.id);
    if (theme == null && write) {
      updateBunnyColor(null, {
        update: true
      });
      return writeThemeToNative({});
    } else if (theme) {
      updateBunnyColor(theme.data, {
        update: true
      });
      return writeThemeToNative(theme);
    }
  }
  function removeTheme(id) {
    return _async_to_generator(function* () {
      var theme = themes[id];
      if (theme.selected)
        yield selectTheme(null);
      delete themes[id];
      return theme.selected;
    })();
  }
  function updateThemes() {
    return _async_to_generator(function* () {
      yield awaitStorage(themes);
      var currentTheme = getThemeFromLoader();
      yield allSettled(Object.keys(themes).map((id) => fetchTheme(id, currentTheme?.id === id)));
    })();
  }
  function getCurrentTheme() {
    return Object.values(themes).find((t) => t.selected) ?? null;
  }
  function getThemeFromLoader() {
    return getStoredTheme();
  }
  function initThemes() {
    return _async_to_generator(function* () {
      if (!isThemeSupported())
        return;
      try {
        if (isPyonLoader()) {
          writeFile("../vendetta_theme.json", "null");
        }
        yield awaitStorage2(colorsPref);
        var currentTheme = getThemeFromLoader();
        initColors(currentTheme?.data ?? null);
        updateThemes().catch((e) => console.error("Failed to update themes", e));
      } catch (e) {
        console.error("Failed to initialize themes", e);
      }
    })();
  }
  var import_react_native5, themes;
  var init_themes = __esm({
    "src/lib/addons/themes/index.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_async_to_generator();
      init_storage();
      init_fs();
      init_loader();
      init_storage2();
      init_utils();
      import_react_native5 = __toESM(require_react_native());
      init_colors();
      init_parser();
      init_preferences();
      init_updater();
      themes = wrapSync(createStorage(createMMKVBackend("VENDETTA_THEMES")));
    }
  });

  // src/lib/api/native/loader.ts
  function isVendettaLoader() {
    return vendettaLoaderIdentity != null;
  }
  function isPyonLoader() {
    return pyonLoaderIdentity != null;
  }
  function polyfillVendettaLoaderIdentity() {
    if (!isPyonLoader() || isVendettaLoader())
      return null;
    var loader = {
      name: pyonLoaderIdentity.loaderName,
      features: {}
    };
    if (isLoaderConfigSupported())
      loader.features.loaderConfig = true;
    if (isSysColorsSupported()) {
      loader.features.syscolors = {
        prop: "__vendetta_syscolors"
      };
      Object.defineProperty(globalThis, "__vendetta_syscolors", {
        get: () => getSysColors(),
        configurable: true
      });
    }
    if (isThemeSupported()) {
      loader.features.themes = {
        prop: "__vendetta_theme"
      };
      Object.defineProperty(globalThis, "__vendetta_theme", {
        // get: () => getStoredTheme(),
        get: () => {
          var id = getStoredTheme()?.id;
          if (!id)
            return null;
          var { themes: themes2 } = (init_themes(), __toCommonJS(themes_exports));
          return themes2[id] ?? getStoredTheme() ?? null;
        },
        configurable: true
      });
    }
    Object.defineProperty(globalThis, "__vendetta_loader", {
      get: () => loader,
      configurable: true
    });
    return loader;
  }
  function getVendettaLoaderIdentity() {
    if (globalThis.__vendetta_loader)
      return globalThis.__vendetta_loader;
    return polyfillVendettaLoaderIdentity();
  }
  function getLoaderName() {
    if (isPyonLoader())
      return pyonLoaderIdentity.loaderName;
    else if (isVendettaLoader())
      return vendettaLoaderIdentity.name;
    return "Unknown";
  }
  function getLoaderVersion() {
    if (isPyonLoader())
      return pyonLoaderIdentity.loaderVersion;
    return null;
  }
  function isLoaderConfigSupported() {
    if (isPyonLoader()) {
      return true;
    } else if (isVendettaLoader()) {
      return vendettaLoaderIdentity.features.loaderConfig;
    }
    return false;
  }
  function isThemeSupported() {
    if (isPyonLoader()) {
      return pyonLoaderIdentity.hasThemeSupport;
    } else if (isVendettaLoader()) {
      return vendettaLoaderIdentity.features.themes != null;
    }
    return false;
  }
  function getStoredTheme() {
    if (isPyonLoader()) {
      return pyonLoaderIdentity.storedTheme;
    } else if (isVendettaLoader()) {
      var themeProp = vendettaLoaderIdentity.features.themes?.prop;
      if (!themeProp)
        return null;
      return globalThis[themeProp] || null;
    }
    return null;
  }
  function getThemeFilePath() {
    if (isPyonLoader()) {
      return "pyoncord/current-theme.json";
    } else if (isVendettaLoader()) {
      return "vendetta_theme.json";
    }
    return null;
  }
  function isReactDevToolsPreloaded() {
    if (isPyonLoader()) {
      return Boolean(globalThis.__REACT_DEVTOOLS__);
    }
    if (isVendettaLoader()) {
      return vendettaLoaderIdentity.features.devtools != null;
    }
    return false;
  }
  function getReactDevToolsProp() {
    if (!isReactDevToolsPreloaded())
      return null;
    if (isPyonLoader()) {
      globalThis.__pyoncord_rdt = globalThis.__REACT_DEVTOOLS__.exports;
      return "__pyoncord_rdt";
    }
    if (isVendettaLoader()) {
      return vendettaLoaderIdentity.features.devtools.prop;
    }
    return null;
  }
  function getReactDevToolsVersion() {
    if (!isReactDevToolsPreloaded())
      return null;
    if (isPyonLoader()) {
      return globalThis.__REACT_DEVTOOLS__.version || null;
    }
    if (isVendettaLoader()) {
      return vendettaLoaderIdentity.features.devtools.version;
    }
    return null;
  }
  function isSysColorsSupported() {
    if (isPyonLoader())
      return pyonLoaderIdentity.isSysColorsSupported;
    else if (isVendettaLoader()) {
      return vendettaLoaderIdentity.features.syscolors != null;
    }
    return false;
  }
  function getSysColors() {
    if (!isSysColorsSupported())
      return null;
    if (isPyonLoader()) {
      return pyonLoaderIdentity.sysColors;
    } else if (isVendettaLoader()) {
      return vendettaLoaderIdentity.features.syscolors.prop;
    }
    return null;
  }
  function getLoaderConfigPath() {
    if (isPyonLoader()) {
      return "pyoncord/loader.json";
    } else if (isVendettaLoader()) {
      return "vendetta_loader.json";
    }
    return "loader.json";
  }
  function isFontSupported() {
    if (isPyonLoader())
      return pyonLoaderIdentity.fontPatch === 2;
    return false;
  }
  var pyonLoaderIdentity, vendettaLoaderIdentity;
  var init_loader = __esm({
    "src/lib/api/native/loader.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_fs();
      pyonLoaderIdentity = globalThis.__PYON_LOADER__;
      vendettaLoaderIdentity = globalThis.__vendetta_loader;
      getVendettaLoaderIdentity();
    }
  });

  // src/lib/api/settings.ts
  var settings_exports = {};
  __export(settings_exports, {
    loaderConfig: () => loaderConfig,
    settings: () => settings
  });
  var settings, loaderConfig;
  var init_settings = __esm({
    "src/lib/api/settings.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_storage();
      init_loader();
      settings = wrapSync(createStorage(createMMKVBackend("VENDETTA_SETTINGS")));
      loaderConfig = wrapSync(createStorage(createFileBackend(getLoaderConfigPath(), {
        customLoadUrl: {
          enabled: false,
          url: "http://localhost:4040/revenge.js"
        }
      })));
    }
  });

  // src/metro/polyfills/redesign.ts
  var redesign_exports = {};
  __export(redesign_exports, {
    default: () => redesign_default
  });
  var redesignProps, _module, _source, cacher, actualExports, exportsKeysLength, prop, id, moduleExports, redesign_default;
  var init_redesign = __esm({
    "src/metro/polyfills/redesign.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_caches();
      redesignProps = /* @__PURE__ */ new Set([
        "AlertActionButton",
        "AlertModal",
        "AlertModalContainer",
        "AvatarDuoPile",
        "AvatarPile",
        "BACKDROP_OPAQUE_MAX_OPACITY",
        "Backdrop",
        "Button",
        "Card",
        "ContextMenu",
        "ContextMenuContainer",
        "FauxHeader",
        "FloatingActionButton",
        "GhostInput",
        "GuildIconPile",
        "HeaderActionButton",
        "HeaderButton",
        "HeaderSubmittingIndicator",
        "IconButton",
        "Input",
        "InputButton",
        "InputContainer",
        "LayerContext",
        "LayerScope",
        "Modal",
        "ModalActionButton",
        "ModalContent",
        "ModalDisclaimer",
        "ModalFloatingAction",
        "ModalFloatingActionSpacer",
        "ModalFooter",
        "ModalScreen",
        "ModalStepIndicator",
        "NAV_BAR_HEIGHT",
        "NAV_BAR_HEIGHT_MULTILINE",
        "Navigator",
        "NavigatorHeader",
        "NavigatorScreen",
        "Pile",
        "PileOverflow",
        "RedesignCompat",
        "RedesignCompatContext",
        "RowButton",
        "STATUS_BAR_HEIGHT",
        "SceneLoadingIndicator",
        "SearchField",
        "SegmentedControl",
        "SegmentedControlPages",
        "Slider",
        "Stack",
        "StepModal",
        "StickyContext",
        "StickyHeader",
        "StickyWrapper",
        "TABLE_ROW_CONTENT_HEIGHT",
        "TABLE_ROW_HEIGHT",
        "TableCheckboxRow",
        "TableRadioGroup",
        "TableRadioRow",
        "TableRow",
        "TableRowGroup",
        "TableRowGroupTitle",
        "TableRowIcon",
        "TableSwitchRow",
        "Tabs",
        "TextArea",
        "TextField",
        "TextInput",
        "Toast",
        "dismissAlerts",
        "getHeaderBackButton",
        "getHeaderCloseButton",
        "getHeaderConditionalBackButton",
        "getHeaderNoTitle",
        "getHeaderTextButton",
        "hideContextMenu",
        "navigatorShouldCrossfade",
        "openAlert",
        "useAccessibilityNativeStackOptions",
        "useAndroidNavScrim",
        "useCoachmark",
        "useFloatingActionButtonScroll",
        "useFloatingActionButtonState",
        "useNativeStackNavigation",
        "useNavigation",
        "useNavigationTheme",
        "useNavigatorBackPressHandler",
        "useNavigatorScreens",
        "useNavigatorShouldCrossfade",
        "useSegmentedControlState",
        "useStackNavigation",
        "useTabNavigation",
        "useTooltip"
      ]);
      _module = {};
      _source = {};
      cacher = getPolyfillModuleCacher("redesign_module");
      for ([id, moduleExports] of cacher.getModules()) {
        for (prop of redesignProps) {
          actualExports = void 0;
          if (moduleExports[prop]) {
            actualExports = moduleExports;
          } else if (moduleExports.default?.[prop]) {
            actualExports = moduleExports.default;
          } else {
            continue;
          }
          exportsKeysLength = Reflect.ownKeys(actualExports).length;
          if (_source[prop] && exportsKeysLength <= _source[prop]) {
            continue;
          }
          _module[prop] = actualExports[prop];
          _source[prop] = Reflect.ownKeys(actualExports).length;
          cacher.cacheId(id);
        }
      }
      cacher.finish();
      redesign_default = _module;
    }
  });

  // src/metro/internals/modules.ts
  var modules_exports2 = {};
  __export(modules_exports2, {
    getCachedPolyfillModules: () => getCachedPolyfillModules,
    getImportingModuleId: () => getImportingModuleId,
    getModules: () => getModules,
    metroModules: () => metroModules,
    requireModule: () => requireModule,
    subscribeModule: () => subscribeModule
  });
  function blacklistModule(id) {
    Object.defineProperty(metroModules, id, {
      enumerable: false
    });
    blacklistedIds.add(id);
    indexBlacklistFlag(Number(id));
  }
  function isBadExports(exports) {
    return !exports || exports === globalThis || exports["<!@ pylix was here :fuyusquish: !@>"] === null || exports.__proto__ === Object.prototype && Reflect.ownKeys(exports).length === 0 || exports.default?.[Symbol.toStringTag] === "IntlMessagesProxy";
  }
  function onModuleRequire(moduleExports, id) {
    indexExportsFlags(id, moduleExports);
    moduleExports.initSentry &&= () => void 0;
    if (moduleExports.default?.track && moduleExports.default.trackMaker)
      moduleExports.default.track = () => Promise.resolve();
    if (moduleExports.registerAsset) {
      (init_patches(), __toCommonJS(patches_exports)).patchAssets(moduleExports);
    }
    if (!patchedNativeComponentRegistry && [
      "customBubblingEventTypes",
      "customDirectEventTypes",
      "register",
      "get"
    ].every((x2) => moduleExports[x2])) {
      instead2("register", moduleExports, ([name, cb], origFunc) => {
        try {
          return origFunc(name, cb);
        } catch (unused) {
          return name;
        }
      });
      patchedNativeComponentRegistry = true;
    }
    if (moduleExports?.default?.constructor?.displayName === "DeveloperExperimentStore") {
      moduleExports.default = new Proxy(moduleExports.default, {
        get(target, property, receiver) {
          if (property === "isDeveloper") {
            var { settings: settings2 } = (init_settings(), __toCommonJS(settings_exports));
            return settings2.enableDiscordDeveloperSettings ?? false;
          }
          return Reflect.get(target, property, receiver);
        }
      });
    }
    if (!patchedImportTracker && moduleExports.fileFinishedImporting) {
      before2("fileFinishedImporting", moduleExports, ([filePath]) => {
        if (_importingModuleId === -1 || !filePath)
          return;
        metroModules[_importingModuleId].__filePath = filePath;
      });
      patchedImportTracker = true;
    }
    if (!patchedInspectSource && globalThis["__core-js_shared__"]) {
      var inspect2 = (f) => typeof f === "function" && functionToString.apply(f, []);
      globalThis["__core-js_shared__"].inspectSource = inspect2;
      patchedInspectSource = true;
    }
    if (moduleExports.findHostInstance_DEPRECATED) {
      var prevExports = metroModules[id - 1]?.publicModule.exports;
      var inc = prevExports.default?.reactProfilingEnabled ? 1 : -1;
      if (!metroModules[id + inc]?.isInitialized) {
        blacklistModule(id + inc);
      }
    }
    if (moduleExports.isMoment) {
      instead2("defineLocale", moduleExports, (args, orig) => {
        var origLocale = moduleExports.locale();
        orig(...args);
        moduleExports.locale(origLocale);
      });
    }
    var subs = moduleSubscriptions.get(Number(id));
    if (subs) {
      subs.forEach((s) => s());
      moduleSubscriptions.delete(Number(id));
    }
  }
  function getImportingModuleId() {
    return _importingModuleId;
  }
  function subscribeModule(id, cb) {
    var subs = moduleSubscriptions.get(id) ?? /* @__PURE__ */ new Set();
    subs.add(cb);
    moduleSubscriptions.set(id, subs);
    return () => subs.delete(cb);
  }
  function requireModule(id) {
    if (!metroModules[0]?.isInitialized)
      metroRequire(0);
    if (blacklistedIds.has(id))
      return void 0;
    if (Number(id) === -1)
      return init_redesign(), __toCommonJS(redesign_exports);
    if (metroModules[id]?.isInitialized && !metroModules[id]?.hasError) {
      return metroRequire(id);
    }
    var originalHandler = ErrorUtils.getGlobalHandler();
    ErrorUtils.setGlobalHandler(noopHandler);
    var moduleExports;
    try {
      moduleExports = metroRequire(id);
    } catch (unused) {
      blacklistModule(id);
      moduleExports = void 0;
    }
    ErrorUtils.setGlobalHandler(originalHandler);
    return moduleExports;
  }
  function* getModules(uniq, all = false) {
    yield [
      -1,
      (init_redesign(), __toCommonJS(redesign_exports))
    ];
    var cache = getMetroCache().findIndex[uniq];
    if (all && !cache?.[`_${ModulesMapInternal.FULL_LOOKUP}`])
      cache = void 0;
    if (cache?.[`_${ModulesMapInternal.NOT_FOUND}`])
      return;
    for (var id in cache) {
      if (id[0] === "_")
        continue;
      var exports = requireModule(Number(id));
      if (isBadExports(exports))
        continue;
      yield [
        id,
        exports
      ];
    }
    for (var id1 in metroModules) {
      var exports1 = requireModule(Number(id1));
      if (isBadExports(exports1))
        continue;
      yield [
        id1,
        exports1
      ];
    }
  }
  function* getCachedPolyfillModules(name) {
    var cache = getMetroCache().polyfillIndex[name];
    for (var id in cache) {
      var exports = requireModule(Number(id));
      if (isBadExports(exports))
        continue;
      yield [
        id,
        exports
      ];
    }
    if (!cache[`_${ModulesMapInternal.FULL_LOOKUP}`]) {
      for (var id1 in metroModules) {
        var exports1 = requireModule(Number(id1));
        if (isBadExports(exports1))
          continue;
        yield [
          id1,
          exports1
        ];
      }
    }
  }
  var _loop, before2, instead2, metroModules, metroRequire, moduleSubscriptions, blacklistedIds, noopHandler, functionToString, patchedInspectSource, patchedImportTracker, patchedNativeComponentRegistry, _importingModuleId, key;
  var init_modules2 = __esm({
    "src/metro/internals/modules.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_caches();
      init_enums();
      _loop = function(key) {
        var id = Number(key);
        var metroModule = metroModules[id];
        var cache = getMetroCache().flagsIndex[id];
        if (cache & ModuleFlags.BLACKLISTED) {
          blacklistModule(id);
          return "continue";
        }
        if (metroModule.factory) {
          instead2("factory", metroModule, (args, origFunc) => {
            var originalImportingId = _importingModuleId;
            _importingModuleId = id;
            var { 1: metroRequire2, 4: moduleObject } = args;
            args[
              2
              /* metroImportDefault */
            ] = (id2) => {
              var exps = metroRequire2(id2);
              return exps && exps.__esModule ? exps.default : exps;
            };
            args[
              3
              /* metroImportAll */
            ] = (id2) => {
              var exps = metroRequire2(id2);
              if (exps && exps.__esModule)
                return exps;
              var importAll = {};
              if (exps)
                Object.assign(importAll, exps);
              importAll.default = exps;
              return importAll;
            };
            origFunc(...args);
            if (!isBadExports(moduleObject.exports)) {
              onModuleRequire(moduleObject.exports, id);
            } else {
              blacklistModule(id);
            }
            _importingModuleId = originalImportingId;
          });
        }
      };
      ({ before: before2, instead: instead2 } = require_cjs());
      metroModules = globalThis.modules;
      metroRequire = (id) => globalThis.__r(+id);
      moduleSubscriptions = /* @__PURE__ */ new Map();
      blacklistedIds = /* @__PURE__ */ new Set();
      noopHandler = () => void 0;
      functionToString = Function.prototype.toString;
      patchedInspectSource = false;
      patchedImportTracker = false;
      patchedNativeComponentRegistry = false;
      _importingModuleId = -1;
      for (key in metroModules)
        _loop(key);
    }
  });

  // src/metro/internals/caches.ts
  var caches_exports = {};
  __export(caches_exports, {
    getCacherForUniq: () => getCacherForUniq,
    getMetroCache: () => getMetroCache,
    getPolyfillModuleCacher: () => getPolyfillModuleCacher,
    indexAssetModuleFlag: () => indexAssetModuleFlag,
    indexBlacklistFlag: () => indexBlacklistFlag,
    indexExportsFlags: () => indexExportsFlags,
    initMetroCache: () => initMetroCache
  });
  function buildInitCache() {
    var cache = {
      _v: CACHE_VERSION,
      _buildNumber: NativeClientInfoModule.getConstants().Build,
      _modulesCount: Object.keys(globalThis.modules).length,
      flagsIndex: {},
      findIndex: {},
      polyfillIndex: {}
    };
    setTimeout(() => {
      for (var id in globalThis.modules) {
        (init_modules2(), __toCommonJS(modules_exports2)).requireModule(id);
      }
    }, 100);
    _metroCache = cache;
    return cache;
  }
  function initMetroCache() {
    return _async_to_generator(function* () {
      if (!(yield fileExists(BUNNY_METRO_CACHE_PATH)))
        return void buildInitCache();
      var rawCache = yield readFile(BUNNY_METRO_CACHE_PATH);
      try {
        _metroCache = JSON.parse(rawCache);
        if (_metroCache._v !== CACHE_VERSION) {
          _metroCache = null;
          throw "cache invalidated; cache version outdated";
        }
        if (_metroCache._buildNumber !== NativeClientInfoModule.getConstants().Build) {
          _metroCache = null;
          throw "cache invalidated; version mismatch";
        }
        if (_metroCache._modulesCount !== Object.keys(globalThis.modules).length) {
          _metroCache = null;
          throw "cache invalidated; modules count mismatch";
        }
      } catch (unused) {
        buildInitCache();
      }
    })();
  }
  function extractExportsFlags(moduleExports) {
    if (!moduleExports)
      return void 0;
    var bit = ModuleFlags.EXISTS;
    return bit;
  }
  function indexExportsFlags(moduleId, moduleExports) {
    var flags = extractExportsFlags(moduleExports);
    if (flags && flags !== ModuleFlags.EXISTS) {
      _metroCache.flagsIndex[moduleId] = flags;
    }
  }
  function indexBlacklistFlag(id) {
    _metroCache.flagsIndex[id] |= ModuleFlags.BLACKLISTED;
  }
  function indexAssetModuleFlag(id) {
    _metroCache.flagsIndex[id] |= ModuleFlags.ASSET;
  }
  function getCacherForUniq(uniq, allFind) {
    var indexObject = _metroCache.findIndex[uniq] ??= {};
    return {
      cacheId(moduleId, exports) {
        indexObject[moduleId] ??= extractExportsFlags(exports);
        saveCache();
      },
      // Finish may not be called by single find
      finish(notFound) {
        if (allFind)
          indexObject[`_${ModulesMapInternal.FULL_LOOKUP}`] = 1;
        if (notFound)
          indexObject[`_${ModulesMapInternal.NOT_FOUND}`] = 1;
        saveCache();
      }
    };
  }
  function getPolyfillModuleCacher(name) {
    var indexObject = _metroCache.polyfillIndex[name] ??= {};
    return {
      getModules() {
        return (init_modules2(), __toCommonJS(modules_exports2)).getCachedPolyfillModules(name);
      },
      cacheId(moduleId) {
        indexObject[moduleId] = 1;
        saveCache();
      },
      finish() {
        indexObject[`_${ModulesMapInternal.FULL_LOOKUP}`] = 1;
        saveCache();
      }
    };
  }
  var CACHE_VERSION, BUNNY_METRO_CACHE_PATH, _metroCache, getMetroCache, saveCache;
  var init_caches = __esm({
    "src/metro/internals/caches.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_async_to_generator();
      init_fs();
      init_modules();
      init_dist();
      init_enums();
      CACHE_VERSION = 102;
      BUNNY_METRO_CACHE_PATH = "caches/metro_modules.json";
      _metroCache = null;
      getMetroCache = () => _metroCache;
      saveCache = debounce(() => {
        writeFile(BUNNY_METRO_CACHE_PATH, JSON.stringify(_metroCache));
      }, 1e3);
    }
  });

  // src/core/ui/reporter/utils/isStack.tsx
  function isComponentStack(error) {
    return "componentStack" in error && typeof error.componentStack === "string";
  }
  function hasStack(error) {
    return !!error.stack;
  }
  var init_isStack = __esm({
    "src/core/ui/reporter/utils/isStack.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
    }
  });

  // node_modules/@revenge-mod/devtools-shared/dist/constants.js
  var LogLevel, MessageType, MCPCommand, DEFAULT_SETTINGS, PROTOCOL_VERSION;
  var init_constants2 = __esm({
    "node_modules/@revenge-mod/devtools-shared/dist/constants.js"() {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      LogLevel = {
        Debug: 0,
        Default: 1,
        Warn: 2,
        Error: 3
      };
      MessageType = {
        Hello: 1,
        Hi: 2,
        Log: 3,
        Run: 4,
        MCPRun: 5,
        MCPResult: 6
      };
      MCPCommand = {
        GetModules: "get_modules",
        LookupModules: "lookup_modules",
        RequireModule: "require_module",
        SaveVar: "save_var",
        PatchMethod: "patch_method",
        UnpatchMethod: "unpatch_method",
        Eval: "eval",
        DiscordReload: "discord_reload",
        DiscordFluxListen: "discord_flux_listen",
        DiscordFluxPatch: "discord_flux_patch",
        DiscordFluxUnpatch: "discord_flux_unpatch",
        GetLogs: "get_logs",
        ReactTreeGetRoot: "react_tree_get_root",
        ReactTreeMatch: "react_tree_match",
        ReactTreeTraverseStructure: "react_tree_traverse_structure",
        ReactTreeHooks: "react_tree_hooks"
      };
      DEFAULT_SETTINGS = {
        client: {
          log: {
            level: LogLevel.Default,
            inspectDepth: 2,
            interceptConsole: true
          }
        },
        server: {
          watch: {
            command: false
          },
          mcp: {
            commandTimeout: 3e4
          }
        }
      };
      PROTOCOL_VERSION = 5;
    }
  });

  // node_modules/chalk/source/vendor/ansi-styles/index.js
  function assembleStyles() {
    var codes = /* @__PURE__ */ new Map();
    for (var [groupName, group] of Object.entries(styles)) {
      for (var [styleName, style] of Object.entries(group)) {
        styles[styleName] = {
          open: `\x1B[${style[0]}m`,
          close: `\x1B[${style[1]}m`
        };
        group[styleName] = styles[styleName];
        codes.set(style[0], style[1]);
      }
      Object.defineProperty(styles, groupName, {
        value: group,
        enumerable: false
      });
    }
    Object.defineProperty(styles, "codes", {
      value: codes,
      enumerable: false
    });
    styles.color.close = "\x1B[39m";
    styles.bgColor.close = "\x1B[49m";
    styles.color.ansi = wrapAnsi16();
    styles.color.ansi256 = wrapAnsi256();
    styles.color.ansi16m = wrapAnsi16m();
    styles.bgColor.ansi = wrapAnsi16(ANSI_BACKGROUND_OFFSET);
    styles.bgColor.ansi256 = wrapAnsi256(ANSI_BACKGROUND_OFFSET);
    styles.bgColor.ansi16m = wrapAnsi16m(ANSI_BACKGROUND_OFFSET);
    Object.defineProperties(styles, {
      rgbToAnsi256: {
        value(red, green, blue) {
          if (red === green && green === blue) {
            if (red < 8) {
              return 16;
            }
            if (red > 248) {
              return 231;
            }
            return Math.round((red - 8) / 247 * 24) + 232;
          }
          return 16 + 36 * Math.round(red / 255 * 5) + 6 * Math.round(green / 255 * 5) + Math.round(blue / 255 * 5);
        },
        enumerable: false
      },
      hexToRgb: {
        value(hex) {
          var matches = /[a-f\d]{6}|[a-f\d]{3}/i.exec(hex.toString(16));
          if (!matches) {
            return [
              0,
              0,
              0
            ];
          }
          var [colorString] = matches;
          if (colorString.length === 3) {
            colorString = [
              ...colorString
            ].map((character) => character + character).join("");
          }
          var integer = Number.parseInt(colorString, 16);
          return [
            /* eslint-disable no-bitwise */
            integer >> 16 & 255,
            integer >> 8 & 255,
            integer & 255
          ];
        },
        enumerable: false
      },
      hexToAnsi256: {
        value: (hex) => styles.rgbToAnsi256(...styles.hexToRgb(hex)),
        enumerable: false
      },
      ansi256ToAnsi: {
        value(code) {
          if (code < 8) {
            return 30 + code;
          }
          if (code < 16) {
            return 90 + (code - 8);
          }
          var red;
          var green;
          var blue;
          if (code >= 232) {
            red = ((code - 232) * 10 + 8) / 255;
            green = red;
            blue = red;
          } else {
            code -= 16;
            var remainder = code % 36;
            red = Math.floor(code / 36) / 5;
            green = Math.floor(remainder / 6) / 5;
            blue = remainder % 6 / 5;
          }
          var value = Math.max(red, green, blue) * 2;
          if (value === 0) {
            return 30;
          }
          var result = 30 + (Math.round(blue) << 2 | Math.round(green) << 1 | Math.round(red));
          if (value === 2) {
            result += 60;
          }
          return result;
        },
        enumerable: false
      },
      rgbToAnsi: {
        value: (red, green, blue) => styles.ansi256ToAnsi(styles.rgbToAnsi256(red, green, blue)),
        enumerable: false
      },
      hexToAnsi: {
        value: (hex) => styles.ansi256ToAnsi(styles.hexToAnsi256(hex)),
        enumerable: false
      }
    });
    return styles;
  }
  var ANSI_BACKGROUND_OFFSET, wrapAnsi16, wrapAnsi256, wrapAnsi16m, styles, modifierNames, foregroundColorNames, backgroundColorNames, colorNames, ansiStyles, ansi_styles_default;
  var init_ansi_styles = __esm({
    "node_modules/chalk/source/vendor/ansi-styles/index.js"() {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      ANSI_BACKGROUND_OFFSET = 10;
      wrapAnsi16 = (offset = 0) => (code) => `\x1B[${code + offset}m`;
      wrapAnsi256 = (offset = 0) => (code) => `\x1B[${38 + offset};5;${code}m`;
      wrapAnsi16m = (offset = 0) => (red, green, blue) => `\x1B[${38 + offset};2;${red};${green};${blue}m`;
      styles = {
        modifier: {
          reset: [
            0,
            0
          ],
          // 21 isn't widely supported and 22 does the same thing
          bold: [
            1,
            22
          ],
          dim: [
            2,
            22
          ],
          italic: [
            3,
            23
          ],
          underline: [
            4,
            24
          ],
          overline: [
            53,
            55
          ],
          inverse: [
            7,
            27
          ],
          hidden: [
            8,
            28
          ],
          strikethrough: [
            9,
            29
          ]
        },
        color: {
          black: [
            30,
            39
          ],
          red: [
            31,
            39
          ],
          green: [
            32,
            39
          ],
          yellow: [
            33,
            39
          ],
          blue: [
            34,
            39
          ],
          magenta: [
            35,
            39
          ],
          cyan: [
            36,
            39
          ],
          white: [
            37,
            39
          ],
          // Bright color
          blackBright: [
            90,
            39
          ],
          gray: [
            90,
            39
          ],
          grey: [
            90,
            39
          ],
          redBright: [
            91,
            39
          ],
          greenBright: [
            92,
            39
          ],
          yellowBright: [
            93,
            39
          ],
          blueBright: [
            94,
            39
          ],
          magentaBright: [
            95,
            39
          ],
          cyanBright: [
            96,
            39
          ],
          whiteBright: [
            97,
            39
          ]
        },
        bgColor: {
          bgBlack: [
            40,
            49
          ],
          bgRed: [
            41,
            49
          ],
          bgGreen: [
            42,
            49
          ],
          bgYellow: [
            43,
            49
          ],
          bgBlue: [
            44,
            49
          ],
          bgMagenta: [
            45,
            49
          ],
          bgCyan: [
            46,
            49
          ],
          bgWhite: [
            47,
            49
          ],
          // Bright color
          bgBlackBright: [
            100,
            49
          ],
          bgGray: [
            100,
            49
          ],
          bgGrey: [
            100,
            49
          ],
          bgRedBright: [
            101,
            49
          ],
          bgGreenBright: [
            102,
            49
          ],
          bgYellowBright: [
            103,
            49
          ],
          bgBlueBright: [
            104,
            49
          ],
          bgMagentaBright: [
            105,
            49
          ],
          bgCyanBright: [
            106,
            49
          ],
          bgWhiteBright: [
            107,
            49
          ]
        }
      };
      modifierNames = Object.keys(styles.modifier);
      foregroundColorNames = Object.keys(styles.color);
      backgroundColorNames = Object.keys(styles.bgColor);
      colorNames = [
        ...foregroundColorNames,
        ...backgroundColorNames
      ];
      ansiStyles = assembleStyles();
      ansi_styles_default = ansiStyles;
    }
  });

  // node_modules/chalk/source/vendor/supports-color/browser.js
  var level, colorSupport, supportsColor, browser_default;
  var init_browser = __esm({
    "node_modules/chalk/source/vendor/supports-color/browser.js"() {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      level = (() => {
        if (!("navigator" in globalThis)) {
          return 0;
        }
        if (globalThis.navigator.userAgentData) {
          var brand = navigator.userAgentData.brands.find(({ brand: brand2 }) => brand2 === "Chromium");
          if (brand && brand.version > 93) {
            return 3;
          }
        }
        if (/\b(Chrome|Chromium)\//.test(globalThis.navigator.userAgent)) {
          return 1;
        }
        return 0;
      })();
      colorSupport = level !== 0 && {
        level,
        hasBasic: true,
        has256: level >= 2,
        has16m: level >= 3
      };
      supportsColor = {
        stdout: colorSupport,
        stderr: colorSupport
      };
      browser_default = supportsColor;
    }
  });

  // node_modules/chalk/source/utilities.js
  function stringReplaceAll(string, substring, replacer) {
    var index = string.indexOf(substring);
    if (index === -1) {
      return string;
    }
    var substringLength = substring.length;
    var endIndex = 0;
    var returnValue = "";
    do {
      returnValue += string.slice(endIndex, index) + substring + replacer;
      endIndex = index + substringLength;
      index = string.indexOf(substring, endIndex);
    } while (index !== -1);
    returnValue += string.slice(endIndex);
    return returnValue;
  }
  function stringEncaseCRLFWithFirstIndex(string, prefix, postfix, index) {
    var endIndex = 0;
    var returnValue = "";
    do {
      var gotCR = string[index - 1] === "\r";
      returnValue += string.slice(endIndex, gotCR ? index - 1 : index) + prefix + (gotCR ? "\r\n" : "\n") + postfix;
      endIndex = index + 1;
      index = string.indexOf("\n", endIndex);
    } while (index !== -1);
    returnValue += string.slice(endIndex);
    return returnValue;
  }
  var init_utilities = __esm({
    "node_modules/chalk/source/utilities.js"() {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
    }
  });

  // node_modules/chalk/source/index.js
  function createChalk(options) {
    return chalkFactory(options);
  }
  var _loop2, _loop1, stdoutColor, stderrColor, GENERATOR, STYLER, IS_EMPTY, levelMapping, styles2, applyOptions, chalkFactory, styleName, style, getModelAnsi, usedModels, model, proto, createStyler, createBuilder, applyStyle, chalk, chalkStderr, source_default;
  var init_source = __esm({
    "node_modules/chalk/source/index.js"() {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_ansi_styles();
      init_browser();
      init_utilities();
      _loop2 = function(styleName, style) {
        styles2[styleName] = {
          get() {
            var builder = createBuilder(this, createStyler(style.open, style.close, this[STYLER]), this[IS_EMPTY]);
            Object.defineProperty(this, styleName, {
              value: builder
            });
            return builder;
          }
        };
      };
      _loop1 = function(model) {
        styles2[model] = {
          get() {
            var { level: level2 } = this;
            return function(...arguments_) {
              var styler = createStyler(getModelAnsi(model, levelMapping[level2], "color", ...arguments_), ansi_styles_default.color.close, this[STYLER]);
              return createBuilder(this, styler, this[IS_EMPTY]);
            };
          }
        };
        var bgModel = "bg" + model[0].toUpperCase() + model.slice(1);
        styles2[bgModel] = {
          get() {
            var { level: level2 } = this;
            return function(...arguments_) {
              var styler = createStyler(getModelAnsi(model, levelMapping[level2], "bgColor", ...arguments_), ansi_styles_default.bgColor.close, this[STYLER]);
              return createBuilder(this, styler, this[IS_EMPTY]);
            };
          }
        };
      };
      ({ stdout: stdoutColor, stderr: stderrColor } = browser_default);
      GENERATOR = Symbol("GENERATOR");
      STYLER = Symbol("STYLER");
      IS_EMPTY = Symbol("IS_EMPTY");
      levelMapping = [
        "ansi",
        "ansi",
        "ansi256",
        "ansi16m"
      ];
      styles2 = /* @__PURE__ */ Object.create(null);
      applyOptions = (object, options = {}) => {
        if (options.level && !(Number.isInteger(options.level) && options.level >= 0 && options.level <= 3)) {
          throw new Error("The `level` option should be an integer from 0 to 3");
        }
        var colorLevel = stdoutColor ? stdoutColor.level : 0;
        object.level = options.level === void 0 ? colorLevel : options.level;
      };
      chalkFactory = (options) => {
        var chalk2 = (...strings) => strings.join(" ");
        applyOptions(chalk2, options);
        Object.setPrototypeOf(chalk2, createChalk.prototype);
        return chalk2;
      };
      Object.setPrototypeOf(createChalk.prototype, Function.prototype);
      for ([styleName, style] of Object.entries(ansi_styles_default))
        _loop2(styleName, style);
      styles2.visible = {
        get() {
          var builder = createBuilder(this, this[STYLER], true);
          Object.defineProperty(this, "visible", {
            value: builder
          });
          return builder;
        }
      };
      getModelAnsi = (model, level2, type, ...arguments_) => {
        if (model === "rgb") {
          if (level2 === "ansi16m") {
            return ansi_styles_default[type].ansi16m(...arguments_);
          }
          if (level2 === "ansi256") {
            return ansi_styles_default[type].ansi256(ansi_styles_default.rgbToAnsi256(...arguments_));
          }
          return ansi_styles_default[type].ansi(ansi_styles_default.rgbToAnsi(...arguments_));
        }
        if (model === "hex") {
          return getModelAnsi("rgb", level2, type, ...ansi_styles_default.hexToRgb(...arguments_));
        }
        return ansi_styles_default[type][model](...arguments_);
      };
      usedModels = [
        "rgb",
        "hex",
        "ansi256"
      ];
      for (model of usedModels)
        _loop1(model);
      proto = Object.defineProperties(() => {
      }, {
        ...styles2,
        level: {
          enumerable: true,
          get() {
            return this[GENERATOR].level;
          },
          set(level2) {
            this[GENERATOR].level = level2;
          }
        }
      });
      createStyler = (open, close, parent) => {
        var openAll;
        var closeAll;
        if (parent === void 0) {
          openAll = open;
          closeAll = close;
        } else {
          openAll = parent.openAll + open;
          closeAll = close + parent.closeAll;
        }
        return {
          open,
          close,
          openAll,
          closeAll,
          parent
        };
      };
      createBuilder = (self, _styler, _isEmpty) => {
        var builder = (...arguments_) => applyStyle(builder, arguments_.length === 1 ? "" + arguments_[0] : arguments_.join(" "));
        Object.setPrototypeOf(builder, proto);
        builder[GENERATOR] = self;
        builder[STYLER] = _styler;
        builder[IS_EMPTY] = _isEmpty;
        return builder;
      };
      applyStyle = (self, string) => {
        if (self.level <= 0 || !string) {
          return self[IS_EMPTY] ? "" : string;
        }
        var styler = self[STYLER];
        if (styler === void 0) {
          return string;
        }
        var { openAll, closeAll } = styler;
        if (string.includes("\x1B")) {
          while (styler !== void 0) {
            string = stringReplaceAll(string, styler.close, styler.open);
            styler = styler.parent;
          }
        }
        var lfIndex = string.indexOf("\n");
        if (lfIndex !== -1) {
          string = stringEncaseCRLFWithFirstIndex(string, closeAll, openAll, lfIndex);
        }
        return openAll + string + closeAll;
      };
      Object.defineProperties(createChalk.prototype, styles2);
      chalk = createChalk();
      chalkStderr = createChalk({
        level: stderrColor ? stderrColor.level : 0
      });
      source_default = chalk;
    }
  });

  // node_modules/devalue/src/constants.js
  var UNDEFINED, HOLE, NAN, POSITIVE_INFINITY, NEGATIVE_INFINITY, NEGATIVE_ZERO, SPARSE, MAX_ARRAY_LEN, MAX_ARRAY_INDEX;
  var init_constants3 = __esm({
    "node_modules/devalue/src/constants.js"() {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      UNDEFINED = -1;
      HOLE = -2;
      NAN = -3;
      POSITIVE_INFINITY = -4;
      NEGATIVE_INFINITY = -5;
      NEGATIVE_ZERO = -6;
      SPARSE = -7;
      MAX_ARRAY_LEN = 2 ** 32 - 1;
      MAX_ARRAY_INDEX = MAX_ARRAY_LEN - 1;
    }
  });

  // node_modules/devalue/src/utils.js
  function is_primitive(thing) {
    return thing === null || typeof thing !== "object" && typeof thing !== "function";
  }
  function is_plain_object(thing) {
    var proto2 = Object.getPrototypeOf(thing);
    return proto2 === Object.prototype || proto2 === null || Object.getPrototypeOf(proto2) === null || Object.getOwnPropertyNames(proto2).sort().join("\0") === object_proto_names;
  }
  function get_type(thing) {
    return Object.prototype.toString.call(thing).slice(8, -1);
  }
  function get_escaped_char(char) {
    switch (char) {
      case '"':
        return '\\"';
      case "<":
        return "\\u003C";
      case "\\":
        return "\\\\";
      case "\n":
        return "\\n";
      case "\r":
        return "\\r";
      case "	":
        return "\\t";
      case "\b":
        return "\\b";
      case "\f":
        return "\\f";
      case "\u2028":
        return "\\u2028";
      case "\u2029":
        return "\\u2029";
      default:
        return char < " " ? `\\u${char.charCodeAt(0).toString(16).padStart(4, "0")}` : "";
    }
  }
  function stringify_string(str) {
    var result = "";
    var last_pos = 0;
    var len = str.length;
    for (var i = 0; i < len; i += 1) {
      var char = str[i];
      var replacement = get_escaped_char(char);
      if (replacement) {
        result += str.slice(last_pos, i) + replacement;
        last_pos = i + 1;
      }
    }
    return `"${last_pos === 0 ? str : result + str.slice(last_pos)}"`;
  }
  function enumerable_symbols(object) {
    return Object.getOwnPropertySymbols(object).filter((symbol) => Object.getOwnPropertyDescriptor(object, symbol).enumerable);
  }
  function stringify_key(key) {
    return is_identifier.test(key) ? "." + key : "[" + JSON.stringify(key) + "]";
  }
  function is_valid_array_index(n) {
    if (!Number.isInteger(n))
      return false;
    if (n < 0)
      return false;
    if (n > MAX_ARRAY_INDEX)
      return false;
    return true;
  }
  function is_valid_array_len(n) {
    if (!Number.isInteger(n))
      return false;
    if (n < 0)
      return false;
    if (n > MAX_ARRAY_LEN)
      return false;
    return true;
  }
  function is_valid_array_index_string(s) {
    if (s.length === 0)
      return false;
    if (s.length > 1 && s.charCodeAt(0) === 48)
      return false;
    for (var i = 0; i < s.length; i++) {
      var c2 = s.charCodeAt(i);
      if (c2 < 48 || c2 > 57)
        return false;
    }
    return is_valid_array_index(+s);
  }
  function valid_array_indices(array) {
    var keys = Object.keys(array);
    for (var i = keys.length - 1; i >= 0; i--) {
      if (is_valid_array_index_string(keys[i])) {
        break;
      }
    }
    keys.length = i + 1;
    return keys;
  }
  var DevalueError, object_proto_names, is_identifier;
  var init_utils2 = __esm({
    "node_modules/devalue/src/utils.js"() {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_call_super();
      init_class_call_check();
      init_inherits();
      init_wrap_native_super();
      init_constants3();
      DevalueError = /* @__PURE__ */ function(Error1) {
        "use strict";
        _inherits(DevalueError2, Error1);
        function DevalueError2(message, keys, value, root) {
          _class_call_check(this, DevalueError2);
          var _this;
          _this = _call_super(this, DevalueError2, [
            message
          ]);
          _this.name = "DevalueError";
          _this.path = keys.join("");
          _this.value = value;
          _this.root = root;
          return _this;
        }
        return DevalueError2;
      }(_wrap_native_super(Error));
      object_proto_names = /* @__PURE__ */ Object.getOwnPropertyNames(Object.prototype).sort().join("\0");
      is_identifier = /^[a-zA-Z_$][a-zA-Z_$0-9]*$/;
    }
  });

  // node_modules/devalue/src/base64.js
  function encode_native(array_buffer) {
    return new Uint8Array(array_buffer).toBase64();
  }
  function decode_native(base64) {
    return Uint8Array.fromBase64(base64).buffer;
  }
  function encode_buffer(array_buffer) {
    return Buffer.from(array_buffer).toString("base64");
  }
  function decode_buffer(base64) {
    return Uint8Array.from(Buffer.from(base64, "base64")).buffer;
  }
  function encode_legacy(array_buffer) {
    var array = new Uint8Array(array_buffer);
    var binary = "";
    var chunk_size = 32768;
    for (var i = 0; i < array.length; i += chunk_size) {
      var chunk = array.subarray(i, i + chunk_size);
      binary += String.fromCharCode.apply(null, chunk);
    }
    return btoa(binary);
  }
  function decode_legacy(base64) {
    var binary_string = atob(base64);
    var len = binary_string.length;
    var array = new Uint8Array(len);
    for (var i = 0; i < len; i++) {
      array[i] = binary_string.charCodeAt(i);
    }
    return array.buffer;
  }
  var native, buffer, encode64, decode64;
  var init_base64 = __esm({
    "node_modules/devalue/src/base64.js"() {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      native = typeof Uint8Array.fromBase64 === "function";
      buffer = typeof process === "object" && process.versions?.node !== void 0;
      encode64 = native ? encode_native : buffer ? encode_buffer : encode_legacy;
      decode64 = native ? decode_native : buffer ? decode_buffer : decode_legacy;
    }
  });

  // node_modules/devalue/src/parse.js
  function parse(serialized, revivers2) {
    return unflatten(JSON.parse(serialized), revivers2);
  }
  function unflatten(parsed, revivers2) {
    if (typeof parsed === "number")
      return hydrate(parsed, true);
    if (!Array.isArray(parsed) || parsed.length === 0) {
      throw new Error("Invalid input");
    }
    var values = (
      /** @type {any[]} */
      parsed
    );
    var hydrated = Array(values.length);
    var hydrating = null;
    function hydrate(index, standalone = false) {
      if (index === UNDEFINED)
        return void 0;
      if (index === NAN)
        return NaN;
      if (index === POSITIVE_INFINITY)
        return Infinity;
      if (index === NEGATIVE_INFINITY)
        return -Infinity;
      if (index === NEGATIVE_ZERO)
        return -0;
      if (standalone || typeof index !== "number") {
        throw new Error(`Invalid input`);
      }
      if (index in hydrated)
        return hydrated[index];
      var value = values[index];
      if (!value || typeof value !== "object") {
        hydrated[index] = value;
      } else if (Array.isArray(value)) {
        if (typeof value[0] === "string") {
          var type = value[0];
          var reviver = revivers2 && Object.hasOwn(revivers2, type) ? revivers2[type] : void 0;
          if (reviver) {
            var i = value[1];
            if (typeof i !== "number") {
              i = values.push(value[1]) - 1;
            }
            hydrating ??= /* @__PURE__ */ new Set();
            if (hydrating.has(i)) {
              throw new Error("Invalid circular reference");
            }
            hydrating.add(i);
            hydrated[index] = reviver(hydrate(i));
            hydrating.delete(i);
            return hydrated[index];
          }
          switch (type) {
            case "Date":
              hydrated[index] = new Date(value[1]);
              break;
            case "Set":
              var set = /* @__PURE__ */ new Set();
              hydrated[index] = set;
              for (var i1 = 1; i1 < value.length; i1 += 1) {
                set.add(hydrate(value[i1]));
              }
              break;
            case "Map":
              var map = /* @__PURE__ */ new Map();
              hydrated[index] = map;
              for (var i2 = 1; i2 < value.length; i2 += 2) {
                map.set(hydrate(value[i2]), hydrate(value[i2 + 1]));
              }
              break;
            case "RegExp":
              hydrated[index] = new RegExp(value[1], value[2]);
              break;
            case "Object": {
              var wrapped_index = value[1];
              if (typeof values[wrapped_index] === "object" && values[wrapped_index][0] !== "BigInt") {
                throw new Error("Invalid input");
              }
              hydrated[index] = Object(hydrate(wrapped_index));
              break;
            }
            case "BigInt":
              hydrated[index] = BigInt(value[1]);
              break;
            case "null":
              var obj = /* @__PURE__ */ Object.create(null);
              hydrated[index] = obj;
              for (var i3 = 1; i3 < value.length; i3 += 2) {
                if (value[i3] === "__proto__") {
                  throw new Error("Cannot parse an object with a `__proto__` property");
                }
                obj[value[i3]] = hydrate(value[i3 + 1]);
              }
              break;
            case "Int8Array":
            case "Uint8Array":
            case "Uint8ClampedArray":
            case "Int16Array":
            case "Uint16Array":
            case "Float16Array":
            case "Int32Array":
            case "Uint32Array":
            case "Float32Array":
            case "Float64Array":
            case "BigInt64Array":
            case "BigUint64Array":
            case "DataView": {
              if (values[value[1]][0] !== "ArrayBuffer") {
                throw new Error("Invalid data");
              }
              var TypedArrayConstructor = globalThis[type];
              var buffer2 = hydrate(value[1]);
              hydrated[index] = value[2] !== void 0 ? new TypedArrayConstructor(buffer2, value[2], value[3]) : new TypedArrayConstructor(buffer2);
              break;
            }
            case "ArrayBuffer": {
              var base64 = value[1];
              if (typeof base64 !== "string") {
                throw new Error("Invalid ArrayBuffer encoding");
              }
              var arraybuffer = decode64(base64);
              hydrated[index] = arraybuffer;
              break;
            }
            case "Temporal.Duration":
            case "Temporal.Instant":
            case "Temporal.PlainDate":
            case "Temporal.PlainTime":
            case "Temporal.PlainDateTime":
            case "Temporal.PlainMonthDay":
            case "Temporal.PlainYearMonth":
            case "Temporal.ZonedDateTime": {
              var temporalName = type.slice(9);
              hydrated[index] = Temporal[temporalName].from(value[1]);
              break;
            }
            case "URL": {
              var url2 = new URL(value[1]);
              hydrated[index] = url2;
              break;
            }
            case "URLSearchParams": {
              var url1 = new URLSearchParams(value[1]);
              hydrated[index] = url1;
              break;
            }
            default:
              throw new Error(`Unknown type ${type}`);
          }
        } else if (value[0] === SPARSE) {
          var len = value[1];
          if (!is_valid_array_len(len)) {
            throw new Error("Invalid input");
          }
          var array = [];
          hydrated[index] = array;
          array[MAX_ARRAY_INDEX] = void 0;
          delete array[MAX_ARRAY_INDEX];
          for (var i4 = 2; i4 < value.length; i4 += 2) {
            var idx = value[i4];
            if (!is_valid_array_index(idx) || idx >= len) {
              throw new Error("Invalid input");
            }
            array[idx] = hydrate(value[i4 + 1]);
          }
          array.length = len;
        } else {
          var array1 = new Array(value.length);
          hydrated[index] = array1;
          for (var i5 = 0; i5 < value.length; i5 += 1) {
            var n = value[i5];
            if (n === HOLE)
              continue;
            array1[i5] = hydrate(n);
          }
        }
      } else {
        var object = {};
        hydrated[index] = object;
        for (var key of Object.keys(value)) {
          if (key === "__proto__") {
            throw new Error("Cannot parse an object with a `__proto__` property");
          }
          var n1 = value[key];
          object[key] = hydrate(n1);
        }
      }
      return hydrated[index];
    }
    return hydrate(0);
  }
  var init_parse = __esm({
    "node_modules/devalue/src/parse.js"() {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_base64();
      init_constants3();
      init_utils2();
    }
  });

  // node_modules/devalue/src/stringify.js
  function stringify(value, reducers2) {
    var stringified = run(false, value, reducers2);
    return typeof stringified === "string" ? stringified : `[${stringified.join(",")}]`;
  }
  function run(async, value, reducers2) {
    var stringified = [];
    var indexes = /* @__PURE__ */ new Map();
    var custom = [];
    if (reducers2) {
      for (var key of Object.getOwnPropertyNames(reducers2)) {
        custom.push({
          key,
          fn: reducers2[key]
        });
      }
    }
    var keys = [];
    var p = 0;
    function flatten(thing, index2) {
      if (thing === void 0)
        return UNDEFINED;
      if (Number.isNaN(thing))
        return NAN;
      if (thing === Infinity)
        return POSITIVE_INFINITY;
      if (thing === -Infinity)
        return NEGATIVE_INFINITY;
      if (thing === 0 && 1 / thing < 0)
        return NEGATIVE_ZERO;
      if (indexes.has(thing))
        return (
          /** @type {number} */
          indexes.get(thing)
        );
      index2 ??= p++;
      indexes.set(thing, index2);
      for (var { key: key2, fn } of custom) {
        var _$value = fn(thing);
        if (_$value) {
          stringified[index2] = `["${key2}",${flatten(_$value)}]`;
          return index2;
        }
      }
      if (typeof thing === "function") {
        throw new DevalueError(`Cannot stringify a function`, keys, thing, value);
      } else if (typeof thing === "symbol") {
        throw new DevalueError(`Cannot stringify a Symbol primitive`, keys, thing, value);
      }
      var str = "";
      if (is_primitive(thing)) {
        str = stringify_primitive(thing);
      } else if (typeof thing.then === "function") {
        if (!async) {
          throw new DevalueError(`Cannot stringify a Promise or thenable \u2014 use stringifyAsync instead`, keys, thing, value);
        }
        str = Promise.resolve(thing).then((value2) => {
          var i2 = flatten(value2, index2);
          if (i2 < 0)
            stringified[index2] = i2;
        });
      } else {
        var type = get_type(thing);
        switch (type) {
          case "Number":
          case "String":
          case "Boolean":
          case "BigInt":
            str = `["Object",${flatten(thing.valueOf())}]`;
            break;
          case "Date":
            var valid = !isNaN(thing.getDate());
            str = `["Date","${valid ? thing.toISOString() : ""}"]`;
            break;
          case "URL":
            str = `["URL",${stringify_string(thing.toString())}]`;
            break;
          case "URLSearchParams":
            str = `["URLSearchParams",${stringify_string(thing.toString())}]`;
            break;
          case "RegExp":
            var { source, flags } = thing;
            str = flags ? `["RegExp",${stringify_string(source)},"${flags}"]` : `["RegExp",${stringify_string(source)}]`;
            break;
          case "Array": {
            var mostly_dense = false;
            str = "[";
            for (var i = 0; i < thing.length; i += 1) {
              if (i > 0)
                str += ",";
              if (Object.hasOwn(thing, i)) {
                keys.push(`[${i}]`);
                str += flatten(thing[i]);
                keys.pop();
              } else if (mostly_dense) {
                str += HOLE;
              } else {
                var populated_keys = valid_array_indices(
                  /** @type {any[]} */
                  thing
                );
                var population = populated_keys.length;
                var d = String(thing.length).length;
                var hole_cost = (thing.length - population) * 3;
                var sparse_cost = 4 + d + population * (d + 1);
                if (hole_cost > sparse_cost) {
                  str = "[" + SPARSE + "," + thing.length;
                  for (var j = 0; j < populated_keys.length; j++) {
                    var key1 = populated_keys[j];
                    keys.push(`[${key1}]`);
                    str += "," + key1 + "," + flatten(thing[key1]);
                    keys.pop();
                  }
                  break;
                } else {
                  mostly_dense = true;
                  str += HOLE;
                }
              }
            }
            str += "]";
            break;
          }
          case "Set":
            str = '["Set"';
            for (var _$value1 of thing) {
              str += `,${flatten(_$value1)}`;
            }
            str += "]";
            break;
          case "Map":
            str = '["Map"';
            for (var [key22, _$value2] of thing) {
              keys.push(`.get(${is_primitive(key22) ? stringify_primitive(key22) : "..."})`);
              str += `,${flatten(key22)},${flatten(_$value2)}`;
              keys.pop();
            }
            str += "]";
            break;
          case "Int8Array":
          case "Uint8Array":
          case "Uint8ClampedArray":
          case "Int16Array":
          case "Uint16Array":
          case "Float16Array":
          case "Int32Array":
          case "Uint32Array":
          case "Float32Array":
          case "Float64Array":
          case "BigInt64Array":
          case "BigUint64Array":
          case "DataView": {
            var typedArray = thing;
            str = '["' + type + '",' + flatten(typedArray.buffer);
            if (typedArray.byteLength !== typedArray.buffer.byteLength) {
              str += `,${typedArray.byteOffset},${typedArray.length}`;
            }
            str += "]";
            break;
          }
          case "ArrayBuffer": {
            var arraybuffer = thing;
            var base64 = encode64(arraybuffer);
            str = `["ArrayBuffer","${base64}"]`;
            break;
          }
          case "Temporal.Duration":
          case "Temporal.Instant":
          case "Temporal.PlainDate":
          case "Temporal.PlainTime":
          case "Temporal.PlainDateTime":
          case "Temporal.PlainMonthDay":
          case "Temporal.PlainYearMonth":
          case "Temporal.ZonedDateTime":
            str = `["${type}",${stringify_string(thing.toString())}]`;
            break;
          default:
            if (!is_plain_object(thing)) {
              throw new DevalueError(`Cannot stringify arbitrary non-POJOs`, keys, thing, value);
            }
            if (enumerable_symbols(thing).length > 0) {
              throw new DevalueError(`Cannot stringify POJOs with symbolic keys`, keys, thing, value);
            }
            if (Object.getPrototypeOf(thing) === null) {
              str = '["null"';
              for (var key3 of Object.keys(thing)) {
                if (key3 === "__proto__") {
                  throw new DevalueError(`Cannot stringify objects with __proto__ keys`, keys, thing, value);
                }
                keys.push(stringify_key(key3));
                str += `,${stringify_string(key3)},${flatten(thing[key3])}`;
                keys.pop();
              }
              str += "]";
            } else {
              str = "{";
              var started = false;
              for (var key4 of Object.keys(thing)) {
                if (key4 === "__proto__") {
                  throw new DevalueError(`Cannot stringify objects with __proto__ keys`, keys, thing, value);
                }
                if (started)
                  str += ",";
                started = true;
                keys.push(stringify_key(key4));
                str += `${stringify_string(key4)}:${flatten(thing[key4])}`;
                keys.pop();
              }
              str += "}";
            }
        }
      }
      stringified[index2] = str;
      return index2;
    }
    var index = flatten(value);
    if (index < 0)
      return `${index}`;
    return stringified;
  }
  function stringify_primitive(thing) {
    var type = typeof thing;
    if (type === "string")
      return stringify_string(thing);
    if (thing === void 0)
      return UNDEFINED.toString();
    if (thing === 0 && 1 / thing < 0)
      return NEGATIVE_ZERO.toString();
    if (type === "bigint")
      return `["BigInt","${thing}"]`;
    return String(thing);
  }
  var init_stringify = __esm({
    "node_modules/devalue/src/stringify.js"() {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_utils2();
      init_constants3();
      init_base64();
    }
  });

  // node_modules/devalue/index.js
  var init_devalue = __esm({
    "node_modules/devalue/index.js"() {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_parse();
      init_stringify();
    }
  });

  // node_modules/@revenge-mod/devtools-shared/dist/serializer.js
  function isPlaceholder(value) {
    return value instanceof MaxDepthObject || value instanceof MaxDepthFunction || value instanceof MaxDepthGetter || value instanceof MaxDepthSetter || value instanceof MaxDepthGetterSetter || value instanceof TaggedObject;
  }
  function isTagged(value) {
    try {
      return value.constructor !== Object && Symbol.toStringTag in value && !(value instanceof Map) && !(value instanceof Set);
    } catch (unused) {
      return false;
    }
  }
  function symbolKeyName(key, copy) {
    var base = `[Symbol(${key.description ?? ""})]`;
    var name = base;
    var index = 1;
    while (name in copy)
      name = `${base}#${index++}`;
    return name;
  }
  function functionName(fn) {
    try {
      var displayName = fn.displayName;
      if (typeof displayName === "string" && displayName)
        return displayName;
    } catch (unused) {
    }
    try {
      if (fn.name)
        return fn.name;
    } catch (unused) {
    }
    return "anonymous";
  }
  function previewAtCap(value) {
    try {
      if (Array.isArray(value))
        return new MaxDepthObject(`[Array(${value.length})]`);
      if (value instanceof Map)
        return new MaxDepthObject(`[Map(${value.size})]`);
      if (value instanceof Set)
        return new MaxDepthObject(`[Set(${value.size})]`);
      var keys = Reflect.ownKeys(value).filter((k) => typeof k === "string");
      if (!keys.length)
        return new MaxDepthObject();
      var shown = keys.slice(0, 6);
      var ellipsis = keys.length > shown.length ? ", \u2026" : "";
      return new MaxDepthObject(`[Object {${shown.join(", ")}${ellipsis}}]`);
    } catch (unused) {
      return new MaxDepthObject();
    }
  }
  function snapshot(value, maxDepth = 2) {
    return snap(value, maxDepth, 0, /* @__PURE__ */ new WeakMap());
  }
  function snap(value, maxDepth, depth, seen) {
    if (value == null)
      return value;
    if (typeof value === "function")
      return new MaxDepthFunction(functionName(value));
    if (typeof value !== "object")
      return value;
    if (isPlaceholder(value))
      return value;
    if (value instanceof Date || value instanceof RegExp || value instanceof URL)
      return value;
    if (seen.has(value))
      return seen.get(value);
    if (depth >= maxDepth)
      return previewAtCap(value);
    if (value instanceof Map) {
      var copy$1 = /* @__PURE__ */ new Map();
      seen.set(value, copy$1);
      for (var [k, v2] of value)
        copy$1.set(snap(k, maxDepth, depth + 1, seen), snap(v2, maxDepth, depth + 1, seen));
      return copy$1;
    }
    if (value instanceof Set) {
      var copy$11 = /* @__PURE__ */ new Set();
      seen.set(value, copy$11);
      for (var v1 of value)
        copy$11.add(snap(v1, maxDepth, depth + 1, seen));
      return copy$11;
    }
    if (Array.isArray(value)) {
      var copy$12 = [];
      seen.set(value, copy$12);
      for (var i = 0; i < value.length; i++)
        try {
          copy$12[i] = snap(value[i], maxDepth, depth + 1, seen);
        } catch (unused) {
          copy$12[i] = new MaxDepthObject();
        }
      return copy$12;
    }
    if (isTagged(value))
      return new TaggedObject(Object.prototype.toString.call(value));
    var copy = {};
    seen.set(value, copy);
    for (var key of Reflect.ownKeys(value)) {
      var descriptor = void 0;
      try {
        descriptor = Object.getOwnPropertyDescriptor(value, key);
      } catch (unused) {
        continue;
      }
      if (!descriptor)
        continue;
      var child = void 0;
      if ("value" in descriptor)
        try {
          child = snap(descriptor.value, maxDepth, depth + 1, seen);
        } catch (unused) {
          child = new MaxDepthObject();
        }
      else {
        var hasGetter = typeof descriptor.get === "function";
        var hasSetter = typeof descriptor.set === "function";
        if (depth + 1 >= maxDepth)
          child = hasGetter && hasSetter ? new MaxDepthGetterSetter(String(key)) : hasGetter ? new MaxDepthGetter(String(key)) : new MaxDepthSetter(String(key));
        else if (hasGetter)
          try {
            child = snap(descriptor.get.call(value), maxDepth, depth + 1, seen);
          } catch (unused) {
            child = new MaxDepthGetter(String(key));
          }
        else
          child = new MaxDepthSetter(String(key));
      }
      var name = typeof key === "symbol" ? symbolKeyName(key, copy) : key;
      copy[name] = child;
    }
    return copy;
  }
  function serialize(value) {
    return stringify(value, reducers);
  }
  function deserialize(json) {
    return parse(json, revivers);
  }
  var inspect, MaxDepthObject, MaxDepthFunction, MaxDepthGetter, MaxDepthSetter, MaxDepthGetterSetter, TaggedObject, reducers, revivers;
  var init_serializer = __esm({
    "node_modules/@revenge-mod/devtools-shared/dist/serializer.js"() {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_class_call_check();
      init_create_class();
      init_source();
      init_devalue();
      inspect = Symbol.for("nodejs.util.inspect.custom");
      MaxDepthObject = /* @__PURE__ */ function() {
        "use strict";
        function MaxDepthObject2(preview) {
          _class_call_check(this, MaxDepthObject2);
          this.preview = preview;
        }
        _create_class(MaxDepthObject2, [
          {
            key: inspect,
            value: function value() {
              return source_default.cyan(this.preview ?? "[Object]");
            }
          },
          {
            key: "toString",
            value: function toString() {
              return this.preview ?? "[Object]";
            }
          }
        ]);
        return MaxDepthObject2;
      }();
      MaxDepthFunction = /* @__PURE__ */ function() {
        "use strict";
        function MaxDepthFunction2(name = "anonymous") {
          _class_call_check(this, MaxDepthFunction2);
          this.name = name;
        }
        _create_class(MaxDepthFunction2, [
          {
            key: inspect,
            value: function value() {
              return source_default.cyan(`[Function: ${this.name}]`);
            }
          },
          {
            key: "toString",
            value: function toString() {
              return `[Function: ${this.name}]`;
            }
          }
        ]);
        return MaxDepthFunction2;
      }();
      MaxDepthGetter = /* @__PURE__ */ function() {
        "use strict";
        function MaxDepthGetter2(name) {
          _class_call_check(this, MaxDepthGetter2);
          this.name = name;
        }
        _create_class(MaxDepthGetter2, [
          {
            key: inspect,
            value: function value() {
              return source_default.cyan("[Getter]");
            }
          },
          {
            key: "toString",
            value: function toString() {
              return "[Getter]";
            }
          }
        ]);
        return MaxDepthGetter2;
      }();
      MaxDepthSetter = /* @__PURE__ */ function() {
        "use strict";
        function MaxDepthSetter2(name) {
          _class_call_check(this, MaxDepthSetter2);
          this.name = name;
        }
        _create_class(MaxDepthSetter2, [
          {
            key: inspect,
            value: function value() {
              return source_default.cyan("[Setter]");
            }
          },
          {
            key: "toString",
            value: function toString() {
              return "[Setter]";
            }
          }
        ]);
        return MaxDepthSetter2;
      }();
      MaxDepthGetterSetter = /* @__PURE__ */ function() {
        "use strict";
        function MaxDepthGetterSetter2(name) {
          _class_call_check(this, MaxDepthGetterSetter2);
          this.name = name;
        }
        _create_class(MaxDepthGetterSetter2, [
          {
            key: inspect,
            value: function value() {
              return source_default.cyan("[Getter/Setter]");
            }
          },
          {
            key: "toString",
            value: function toString() {
              return "[Getter/Setter]";
            }
          }
        ]);
        return MaxDepthGetterSetter2;
      }();
      TaggedObject = /* @__PURE__ */ function() {
        "use strict";
        function TaggedObject2(tag) {
          _class_call_check(this, TaggedObject2);
          this.tag = tag;
        }
        _create_class(TaggedObject2, [
          {
            key: inspect,
            value: function value() {
              return source_default.cyan(this.tag);
            }
          },
          {
            key: "toString",
            value: function toString() {
              return this.tag;
            }
          }
        ]);
        return TaggedObject2;
      }();
      reducers = {
        MaxDepthObject: (v2) => v2 instanceof MaxDepthObject && [
          v2.preview ?? null
        ],
        MaxDepthFunction: (v2) => v2 instanceof MaxDepthFunction && [
          v2.name
        ],
        MaxDepthGetter: (v2) => v2 instanceof MaxDepthGetter && [
          v2.name
        ],
        MaxDepthSetter: (v2) => v2 instanceof MaxDepthSetter && [
          v2.name
        ],
        MaxDepthGetterSetter: (v2) => v2 instanceof MaxDepthGetterSetter && [
          v2.name
        ],
        TaggedObject: (v2) => v2 instanceof TaggedObject && [
          v2.tag
        ],
        URL: (v2) => typeof URL !== "undefined" && v2 instanceof URL && [
          v2.href
        ],
        symbol: (v2) => typeof v2 === "symbol" && [
          v2.description ?? ""
        ],
        function: (v2) => typeof v2 === "function" && [
          functionName(v2)
        ],
        instance: (v2) => {
          if (v2 === null || typeof v2 !== "object")
            return false;
          var proto2;
          try {
            proto2 = Object.getPrototypeOf(v2);
          } catch (unused) {
            return [
              {}
            ];
          }
          if (proto2 === Object.prototype || proto2 === Array.prototype || proto2 === null)
            return false;
          if (v2 instanceof Date || v2 instanceof RegExp || v2 instanceof Map || v2 instanceof Set)
            return false;
          return [
            {
              ...v2
            }
          ];
        }
      };
      revivers = {
        MaxDepthObject: ([preview]) => new MaxDepthObject(preview ?? void 0),
        MaxDepthFunction: ([name]) => new MaxDepthFunction(name),
        MaxDepthGetter: ([name]) => new MaxDepthGetter(name),
        MaxDepthSetter: ([name]) => new MaxDepthSetter(name),
        MaxDepthGetterSetter: ([name]) => new MaxDepthGetterSetter(name),
        TaggedObject: ([tag]) => new TaggedObject(tag),
        URL: ([href]) => new URL(href),
        symbol: ([description]) => Symbol(description),
        function: ([name]) => new MaxDepthFunction(name),
        instance: ([props]) => props
      };
    }
  });

  // node_modules/bippy/dist/src-DnJsD_Sy.js
  function traverseFiber(fiber, selector, ascending = false) {
    var isAsync = fiber && selector(fiber) instanceof Promise;
    if (isAsync)
      return traverseFiberAsync(fiber, selector, ascending);
    return traverseFiberSync(fiber, selector, ascending);
  }
  var version, BIPPY_INSTRUMENTATION_STRING, objectDefineProperty, objectHasOwnProperty, NO_OP, checkDCE, isRealReactDevtools, isReactRefreshOverride, injectFnStr, isReactRefresh, onActiveListeners, _renderers, installRDTHook, patchRDTHook, hasRDTHook, getRDTHook, isClientEnvironment, safelyInstallRDTHook, FunctionComponentTag, ClassComponentTag, HostRootTag, HostComponentTag, HostTextTag, FragmentTag, ContextConsumerTag, ForwardRefTag, SuspenseComponentTag, MemoComponentTag, SimpleMemoComponentTag, LazyComponentTag, DehydratedSuspenseComponentTag, SuspenseListComponentTag, OffscreenComponentTag, LegacyHiddenComponentTag, HostHoistableTag, HostSingletonTag, ActivityComponentTag, ViewTransitionComponentTag, CONCURRENT_MODE_NUMBER, ELEMENT_TYPE_SYMBOL_STRING, TRANSITIONAL_ELEMENT_TYPE_SYMBOL_STRING, CONCURRENT_MODE_SYMBOL_STRING, DEPRECATED_ASYNC_MODE_SYMBOL_STRING, PerformedWork, Placement, Hydrating, Update, Cloned, ChildDeletion, ContentReset, Snapshot, Visibility, MutationMask, isValidElement, isValidFiber, isHostFiber, isCompositeFiber, areFiberEqual, traverseContexts, traverseState, traverseProps, didFiberRender, didFiberCommit, getMutatedHostFibers, getFiberStack, shouldFilterFiber, getNearestHostFiber, getNearestHostFibers, traverseFiberSync, traverseFiberAsync, getTimings, hasMemoCache, getType, getDisplayName, detectReactBuildType, isInstrumentationActive, getLatestFiber, fiberId, fiberIdMap, setFiberId, getFiberId, mountFiberRecursively, updateFiberRecursively, unmountFiber, unmountFiberChildrenRecursively, commitId, rootInstanceMap, traverseRenderedFibers, createFiberVisitor, _overrideProps, _overrideHookState, _overrideContext, injectOverrideMethods, isPOJO, buildPathsFromValue, overrideProps, overrideHookState, overrideContext, instrument, getFiberFromHostInstance, INSTALL_ERROR, _fiberRoots, secure, onCommitFiberRoot;
  var init_src_DnJsD_Sy = __esm({
    "node_modules/bippy/dist/src-DnJsD_Sy.js"() {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_async_to_generator();
      version = "0.3.34";
      BIPPY_INSTRUMENTATION_STRING = `bippy-${version}`;
      objectDefineProperty = Object.defineProperty;
      objectHasOwnProperty = Object.prototype.hasOwnProperty;
      NO_OP = () => {
      };
      checkDCE = (fn) => {
        try {
          var code = Function.prototype.toString.call(fn);
          if (code.indexOf("^_^") > -1)
            setTimeout(() => {
              throw new Error("React is running in production mode, but dead code elimination has not been applied. Read how to correctly configure React for production: https://reactjs.org/link/perf-use-production-build");
            });
        } catch (unused) {
        }
      };
      isRealReactDevtools = (rdtHook = getRDTHook()) => {
        return "getFiberRoots" in rdtHook;
      };
      isReactRefreshOverride = false;
      injectFnStr = void 0;
      isReactRefresh = (rdtHook = getRDTHook()) => {
        if (isReactRefreshOverride)
          return true;
        if (typeof rdtHook.inject === "function")
          injectFnStr = rdtHook.inject.toString();
        return Boolean(injectFnStr?.includes("(injected)"));
      };
      onActiveListeners = /* @__PURE__ */ new Set();
      _renderers = /* @__PURE__ */ new Set();
      installRDTHook = (onActive) => {
        var renderers = /* @__PURE__ */ new Map();
        var i = 0;
        var rdtHook = {
          _instrumentationIsActive: false,
          _instrumentationSource: BIPPY_INSTRUMENTATION_STRING,
          checkDCE,
          hasUnsupportedRendererAttached: false,
          inject(renderer) {
            var nextID = ++i;
            renderers.set(nextID, renderer);
            _renderers.add(renderer);
            if (!rdtHook._instrumentationIsActive) {
              rdtHook._instrumentationIsActive = true;
              onActiveListeners.forEach((listener) => listener());
            }
            return nextID;
          },
          on: NO_OP,
          onCommitFiberRoot: NO_OP,
          onCommitFiberUnmount: NO_OP,
          onPostCommitFiberRoot: NO_OP,
          renderers,
          supportsFiber: true,
          supportsFlight: true
        };
        try {
          objectDefineProperty(globalThis, "__REACT_DEVTOOLS_GLOBAL_HOOK__", {
            configurable: true,
            enumerable: true,
            get() {
              return rdtHook;
            },
            set(newHook) {
              if (newHook && typeof newHook === "object") {
                var ourRenderers = rdtHook.renderers;
                rdtHook = newHook;
                if (ourRenderers.size > 0) {
                  ourRenderers.forEach((renderer, id) => {
                    _renderers.add(renderer);
                    newHook.renderers.set(id, renderer);
                  });
                  patchRDTHook(onActive);
                }
              }
            }
          });
          var originalWindowHasOwnProperty = globalThis.hasOwnProperty;
          var hasRanHack = false;
          objectDefineProperty(globalThis, "hasOwnProperty", {
            configurable: true,
            value: function value(...args) {
              try {
                if (!hasRanHack && args[0] === "__REACT_DEVTOOLS_GLOBAL_HOOK__") {
                  globalThis.__REACT_DEVTOOLS_GLOBAL_HOOK__ = void 0;
                  hasRanHack = true;
                  return -0;
                }
              } catch (unused) {
              }
              return originalWindowHasOwnProperty.apply(this, args);
            },
            writable: true
          });
        } catch (unused) {
          patchRDTHook(onActive);
        }
        return rdtHook;
      };
      patchRDTHook = (onActive) => {
        if (onActive)
          onActiveListeners.add(onActive);
        try {
          var rdtHook = globalThis.__REACT_DEVTOOLS_GLOBAL_HOOK__;
          if (!rdtHook)
            return;
          if (!rdtHook._instrumentationSource) {
            var isReactDevtools = isRealReactDevtools();
            rdtHook.checkDCE = checkDCE;
            rdtHook.supportsFiber = true;
            rdtHook.supportsFlight = true;
            rdtHook.hasUnsupportedRendererAttached = false;
            rdtHook._instrumentationSource = BIPPY_INSTRUMENTATION_STRING;
            rdtHook._instrumentationIsActive = false;
            if (!isReactDevtools)
              rdtHook.on = NO_OP;
            if (rdtHook.renderers.size) {
              rdtHook._instrumentationIsActive = true;
              onActiveListeners.forEach((listener) => listener());
              return;
            }
            var prevInject = rdtHook.inject;
            if (isReactRefresh(rdtHook) && !isReactDevtools) {
              isReactRefreshOverride = true;
              var nextID = rdtHook.inject({
                scheduleRefresh() {
                }
              });
              if (nextID)
                rdtHook._instrumentationIsActive = true;
            }
            rdtHook.inject = (renderer) => {
              var id = prevInject(renderer);
              _renderers.add(renderer);
              rdtHook._instrumentationIsActive = true;
              onActiveListeners.forEach((listener) => listener());
              return id;
            };
          }
          if (rdtHook.renderers.size || rdtHook._instrumentationIsActive || isReactRefresh())
            onActive?.();
        } catch (unused) {
        }
      };
      hasRDTHook = () => {
        return objectHasOwnProperty.call(globalThis, "__REACT_DEVTOOLS_GLOBAL_HOOK__");
      };
      getRDTHook = (onActive) => {
        if (!hasRDTHook())
          return installRDTHook(onActive);
        patchRDTHook(onActive);
        return globalThis.__REACT_DEVTOOLS_GLOBAL_HOOK__;
      };
      isClientEnvironment = () => {
        return Boolean(typeof globalThis !== "undefined" && (globalThis.document?.createElement || globalThis.navigator?.product === "ReactNative"));
      };
      safelyInstallRDTHook = () => {
        try {
          if (isClientEnvironment())
            getRDTHook();
        } catch (unused) {
        }
      };
      FunctionComponentTag = 0;
      ClassComponentTag = 1;
      HostRootTag = 3;
      HostComponentTag = 5;
      HostTextTag = 6;
      FragmentTag = 7;
      ContextConsumerTag = 9;
      ForwardRefTag = 11;
      SuspenseComponentTag = 13;
      MemoComponentTag = 14;
      SimpleMemoComponentTag = 15;
      LazyComponentTag = 16;
      DehydratedSuspenseComponentTag = 18;
      SuspenseListComponentTag = 19;
      OffscreenComponentTag = 22;
      LegacyHiddenComponentTag = 23;
      HostHoistableTag = 26;
      HostSingletonTag = 27;
      ActivityComponentTag = 28;
      ViewTransitionComponentTag = 30;
      CONCURRENT_MODE_NUMBER = 60111;
      ELEMENT_TYPE_SYMBOL_STRING = "Symbol(react.element)";
      TRANSITIONAL_ELEMENT_TYPE_SYMBOL_STRING = "Symbol(react.transitional.element)";
      CONCURRENT_MODE_SYMBOL_STRING = "Symbol(react.concurrent_mode)";
      DEPRECATED_ASYNC_MODE_SYMBOL_STRING = "Symbol(react.async_mode)";
      PerformedWork = 1;
      Placement = 2;
      Hydrating = 4096;
      Update = 4;
      Cloned = 8;
      ChildDeletion = 16;
      ContentReset = 32;
      Snapshot = 1024;
      Visibility = 8192;
      MutationMask = Placement | Update | ChildDeletion | ContentReset | Hydrating | Visibility | Snapshot;
      isValidElement = (element) => typeof element === "object" && element != null && "$$typeof" in element && [
        ELEMENT_TYPE_SYMBOL_STRING,
        TRANSITIONAL_ELEMENT_TYPE_SYMBOL_STRING
      ].includes(String(element.$$typeof));
      isValidFiber = (fiber) => typeof fiber === "object" && fiber != null && "tag" in fiber && "stateNode" in fiber && "return" in fiber && "child" in fiber && "sibling" in fiber && "flags" in fiber;
      isHostFiber = (fiber) => {
        switch (fiber.tag) {
          case HostComponentTag:
          case HostHoistableTag:
          case HostSingletonTag:
            return true;
          default:
            return typeof fiber.type === "string";
        }
      };
      isCompositeFiber = (fiber) => {
        switch (fiber.tag) {
          case ClassComponentTag:
          case ForwardRefTag:
          case FunctionComponentTag:
          case MemoComponentTag:
          case SimpleMemoComponentTag:
            return true;
          default:
            return false;
        }
      };
      areFiberEqual = (fiberA, fiberB) => {
        return fiberA === fiberB || fiberA.alternate === fiberB || fiberB.alternate === fiberA;
      };
      traverseContexts = (fiber, selector) => {
        try {
          var nextDependencies = fiber.dependencies;
          var prevDependencies = fiber.alternate?.dependencies;
          if (!nextDependencies || !prevDependencies)
            return false;
          if (typeof nextDependencies !== "object" || !("firstContext" in nextDependencies) || typeof prevDependencies !== "object" || !("firstContext" in prevDependencies))
            return false;
          var nextContext = nextDependencies.firstContext;
          var prevContext = prevDependencies.firstContext;
          while (nextContext && typeof nextContext === "object" && "memoizedValue" in nextContext || prevContext && typeof prevContext === "object" && "memoizedValue" in prevContext) {
            if (selector(nextContext, prevContext) === true)
              return true;
            nextContext = nextContext?.next;
            prevContext = prevContext?.next;
          }
        } catch (unused) {
        }
        return false;
      };
      traverseState = (fiber, selector) => {
        try {
          var nextState = fiber.memoizedState;
          var prevState = fiber.alternate?.memoizedState;
          while (nextState || prevState) {
            if (selector(nextState, prevState) === true)
              return true;
            nextState = nextState?.next;
            prevState = prevState?.next;
          }
        } catch (unused) {
        }
        return false;
      };
      traverseProps = (fiber, selector) => {
        try {
          var nextProps = fiber.memoizedProps;
          var prevProps = fiber.alternate?.memoizedProps || {};
          var allKeys = /* @__PURE__ */ new Set([
            ...Object.keys(nextProps),
            ...Object.keys(prevProps)
          ]);
          for (var propName of allKeys) {
            var prevValue = prevProps?.[propName];
            var nextValue = nextProps?.[propName];
            if (selector(propName, nextValue, prevValue) === true)
              return true;
          }
        } catch (unused) {
        }
        return false;
      };
      didFiberRender = (fiber) => {
        var nextProps = fiber.memoizedProps;
        var prevProps = fiber.alternate?.memoizedProps || {};
        var flags = fiber.flags ?? fiber.effectTag ?? 0;
        switch (fiber.tag) {
          case ClassComponentTag:
          case ContextConsumerTag:
          case ForwardRefTag:
          case FunctionComponentTag:
          case MemoComponentTag:
          case SimpleMemoComponentTag:
            return (flags & PerformedWork) === PerformedWork;
          default:
            if (!fiber.alternate)
              return true;
            return prevProps !== nextProps || fiber.alternate.memoizedState !== fiber.memoizedState || fiber.alternate.ref !== fiber.ref;
        }
      };
      didFiberCommit = (fiber) => {
        return Boolean((fiber.flags & (MutationMask | Cloned)) !== 0 || (fiber.subtreeFlags & (MutationMask | Cloned)) !== 0);
      };
      getMutatedHostFibers = (fiber) => {
        var mutations = [];
        var stack = [
          fiber
        ];
        while (stack.length) {
          var node = stack.pop();
          if (!node)
            continue;
          if (isHostFiber(node) && didFiberCommit(node) && didFiberRender(node))
            mutations.push(node);
          if (node.child)
            stack.push(node.child);
          if (node.sibling)
            stack.push(node.sibling);
        }
        return mutations;
      };
      getFiberStack = (fiber) => {
        var stack = [];
        var currentFiber = fiber;
        while (currentFiber.return) {
          stack.push(currentFiber);
          currentFiber = currentFiber.return;
        }
        return stack;
      };
      shouldFilterFiber = (fiber) => {
        switch (fiber.tag) {
          case DehydratedSuspenseComponentTag:
            return true;
          case FragmentTag:
          case HostTextTag:
          case LegacyHiddenComponentTag:
          case OffscreenComponentTag:
            return true;
          case HostRootTag:
            return false;
          default: {
            var symbolOrNumber = typeof fiber.type === "object" && fiber.type !== null ? fiber.type.$$typeof : fiber.type;
            var typeSymbol = typeof symbolOrNumber === "symbol" ? symbolOrNumber.toString() : symbolOrNumber;
            switch (typeSymbol) {
              case CONCURRENT_MODE_NUMBER:
              case CONCURRENT_MODE_SYMBOL_STRING:
              case DEPRECATED_ASYNC_MODE_SYMBOL_STRING:
                return true;
              default:
                return false;
            }
          }
        }
      };
      getNearestHostFiber = (fiber, ascending = false) => {
        var hostFiber = traverseFiber(fiber, isHostFiber, ascending);
        if (!hostFiber)
          hostFiber = traverseFiber(fiber, isHostFiber, !ascending);
        return hostFiber;
      };
      getNearestHostFibers = (fiber) => {
        var hostFibers = [];
        var stack = [];
        if (isHostFiber(fiber))
          hostFibers.push(fiber);
        else if (fiber.child)
          stack.push(fiber.child);
        while (stack.length) {
          var currentNode = stack.pop();
          if (!currentNode)
            break;
          if (isHostFiber(currentNode))
            hostFibers.push(currentNode);
          else if (currentNode.child)
            stack.push(currentNode.child);
          if (currentNode.sibling)
            stack.push(currentNode.sibling);
        }
        return hostFibers;
      };
      traverseFiberSync = (fiber, selector, ascending = false) => {
        if (!fiber)
          return null;
        if (selector(fiber) === true)
          return fiber;
        var child = ascending ? fiber.return : fiber.child;
        while (child) {
          var match = traverseFiberSync(child, selector, ascending);
          if (match)
            return match;
          child = ascending ? null : child.sibling;
        }
        return null;
      };
      traverseFiberAsync = (fiber, selector, ascending = false) => _async_to_generator(function* () {
        if (!fiber)
          return null;
        if ((yield selector(fiber)) === true)
          return fiber;
        var child = ascending ? fiber.return : fiber.child;
        while (child) {
          var match = yield traverseFiberAsync(child, selector, ascending);
          if (match)
            return match;
          child = ascending ? null : child.sibling;
        }
        return null;
      })();
      getTimings = (fiber) => {
        var totalTime = fiber?.actualDuration ?? 0;
        var selfTime = totalTime;
        var child = fiber?.child ?? null;
        while (totalTime > 0 && child != null) {
          selfTime -= child.actualDuration ?? 0;
          child = child.sibling;
        }
        return {
          selfTime,
          totalTime
        };
      };
      hasMemoCache = (fiber) => {
        return Boolean(fiber.updateQueue?.memoCache);
      };
      getType = (type) => {
        var currentType = type;
        if (typeof currentType === "function")
          return currentType;
        if (typeof currentType === "object" && currentType)
          return getType(currentType.type || currentType.render);
        return null;
      };
      getDisplayName = (type) => {
        var currentType = type;
        if (typeof currentType === "string")
          return currentType;
        if (typeof currentType !== "function" && !(typeof currentType === "object" && currentType))
          return null;
        var name = currentType.displayName || currentType.name || null;
        if (name)
          return name;
        var unwrappedType = getType(currentType);
        if (!unwrappedType)
          return null;
        return unwrappedType.displayName || unwrappedType.name || null;
      };
      detectReactBuildType = (renderer) => {
        try {
          if (typeof renderer.version === "string" && renderer.bundleType > 0)
            return "development";
        } catch (unused) {
        }
        return "production";
      };
      isInstrumentationActive = () => {
        var rdtHook = getRDTHook();
        return Boolean(rdtHook._instrumentationIsActive) || isRealReactDevtools() || isReactRefresh();
      };
      getLatestFiber = (fiber) => {
        var alternate = fiber.alternate;
        if (!alternate)
          return fiber;
        if (alternate.actualStartTime && fiber.actualStartTime)
          return alternate.actualStartTime > fiber.actualStartTime ? alternate : fiber;
        for (var root of _fiberRoots) {
          var latestFiber = traverseFiber(root.current, (innerFiber) => {
            if (innerFiber === fiber)
              return true;
          });
          if (latestFiber)
            return latestFiber;
        }
        return fiber;
      };
      fiberId = 0;
      fiberIdMap = /* @__PURE__ */ new WeakMap();
      setFiberId = (fiber, id = fiberId++) => {
        fiberIdMap.set(fiber, id);
      };
      getFiberId = (fiber) => {
        var id = fiberIdMap.get(fiber);
        if (!id && fiber.alternate)
          id = fiberIdMap.get(fiber.alternate);
        if (!id) {
          id = fiberId++;
          setFiberId(fiber, id);
        }
        return id;
      };
      mountFiberRecursively = (onRender, firstChild, traverseSiblings) => {
        var fiber = firstChild;
        while (fiber != null) {
          if (!fiberIdMap.has(fiber))
            getFiberId(fiber);
          var shouldIncludeInTree = !shouldFilterFiber(fiber);
          if (shouldIncludeInTree && didFiberRender(fiber))
            onRender(fiber, "mount");
          if (fiber.tag === SuspenseComponentTag) {
            var isTimedOut = fiber.memoizedState !== null;
            if (isTimedOut) {
              var primaryChildFragment = fiber.child;
              var fallbackChildFragment = primaryChildFragment ? primaryChildFragment.sibling : null;
              if (fallbackChildFragment) {
                var fallbackChild = fallbackChildFragment.child;
                if (fallbackChild !== null)
                  mountFiberRecursively(onRender, fallbackChild, false);
              }
            } else {
              var primaryChild = null;
              var areSuspenseChildrenConditionallyWrapped = OffscreenComponentTag === -1;
              if (areSuspenseChildrenConditionallyWrapped)
                primaryChild = fiber.child;
              else if (fiber.child !== null)
                primaryChild = fiber.child.child;
              if (primaryChild !== null)
                mountFiberRecursively(onRender, primaryChild, false);
            }
          } else if (fiber.child != null)
            mountFiberRecursively(onRender, fiber.child, true);
          fiber = traverseSiblings ? fiber.sibling : null;
        }
      };
      updateFiberRecursively = (onRender, nextFiber, prevFiber, parentFiber) => {
        if (!fiberIdMap.has(nextFiber))
          getFiberId(nextFiber);
        if (!prevFiber)
          return;
        if (!fiberIdMap.has(prevFiber))
          getFiberId(prevFiber);
        var isSuspense = nextFiber.tag === SuspenseComponentTag;
        var shouldIncludeInTree = !shouldFilterFiber(nextFiber);
        if (shouldIncludeInTree && didFiberRender(nextFiber))
          onRender(nextFiber, "update");
        var prevDidTimeout = isSuspense && prevFiber.memoizedState !== null;
        var nextDidTimeOut = isSuspense && nextFiber.memoizedState !== null;
        if (prevDidTimeout && nextDidTimeOut) {
          var nextFallbackChildSet = nextFiber.child?.sibling ?? null;
          var prevFallbackChildSet = prevFiber.child?.sibling ?? null;
          if (nextFallbackChildSet !== null && prevFallbackChildSet !== null)
            updateFiberRecursively(onRender, nextFallbackChildSet, prevFallbackChildSet, nextFiber);
        } else if (prevDidTimeout && !nextDidTimeOut) {
          var nextPrimaryChildSet = nextFiber.child;
          if (nextPrimaryChildSet !== null)
            mountFiberRecursively(onRender, nextPrimaryChildSet, true);
        } else if (!prevDidTimeout && nextDidTimeOut) {
          unmountFiberChildrenRecursively(onRender, prevFiber);
          var nextFallbackChildSet1 = nextFiber.child?.sibling ?? null;
          if (nextFallbackChildSet1 !== null)
            mountFiberRecursively(onRender, nextFallbackChildSet1, true);
        } else if (nextFiber.child !== prevFiber.child) {
          var nextChild = nextFiber.child;
          while (nextChild) {
            if (nextChild.alternate) {
              var prevChild = nextChild.alternate;
              updateFiberRecursively(onRender, nextChild, prevChild, shouldIncludeInTree ? nextFiber : parentFiber);
            } else
              mountFiberRecursively(onRender, nextChild, false);
            nextChild = nextChild.sibling;
          }
        }
      };
      unmountFiber = (onRender, fiber) => {
        var isRoot = fiber.tag === HostRootTag;
        if (isRoot || !shouldFilterFiber(fiber))
          onRender(fiber, "unmount");
      };
      unmountFiberChildrenRecursively = (onRender, fiber) => {
        var isTimedOutSuspense = fiber.tag === SuspenseComponentTag && fiber.memoizedState !== null;
        var child = fiber.child;
        if (isTimedOutSuspense) {
          var primaryChildFragment = fiber.child;
          var fallbackChildFragment = primaryChildFragment?.sibling ?? null;
          child = fallbackChildFragment?.child ?? null;
        }
        while (child !== null) {
          if (child.return !== null) {
            unmountFiber(onRender, child);
            unmountFiberChildrenRecursively(onRender, child);
          }
          child = child.sibling;
        }
      };
      commitId = 0;
      rootInstanceMap = /* @__PURE__ */ new WeakMap();
      traverseRenderedFibers = (root, onRender) => {
        var fiber = "current" in root ? root.current : root;
        var rootInstance = rootInstanceMap.get(root);
        if (!rootInstance) {
          rootInstance = {
            id: commitId++,
            prevFiber: null
          };
          rootInstanceMap.set(root, rootInstance);
        }
        var { prevFiber } = rootInstance;
        if (!fiber)
          unmountFiber(onRender, fiber);
        else if (prevFiber !== null) {
          var wasMounted = prevFiber && prevFiber.memoizedState != null && prevFiber.memoizedState.element != null && prevFiber.memoizedState.isDehydrated !== true;
          var isMounted = fiber.memoizedState != null && fiber.memoizedState.element != null && fiber.memoizedState.isDehydrated !== true;
          if (!wasMounted && isMounted)
            mountFiberRecursively(onRender, fiber, false);
          else if (wasMounted && isMounted)
            updateFiberRecursively(onRender, fiber, fiber.alternate, null);
          else if (wasMounted && !isMounted)
            unmountFiber(onRender, fiber);
        } else
          mountFiberRecursively(onRender, fiber, true);
        rootInstance.prevFiber = fiber;
      };
      createFiberVisitor = ({ onRender }) => {
        return (_rendererID, root, _state) => {
          traverseRenderedFibers(root, onRender);
        };
      };
      _overrideProps = null;
      _overrideHookState = null;
      _overrideContext = null;
      injectOverrideMethods = () => {
        var _loop3 = function(_3, renderer2) {
          try {
            if (_overrideHookState) {
              var prevOverrideHookState = _overrideHookState;
              _overrideHookState = (fiber, id, path, value) => {
                var current = fiber.memoizedState;
                for (var i = 0; i < Number(id); i++) {
                  if (!current?.next)
                    break;
                  current = current.next;
                }
                if (current?.queue) {
                  var queue = current.queue;
                  if (isPOJO(queue) && "dispatch" in queue) {
                    var dispatch = queue.dispatch;
                    dispatch(value);
                    return;
                  }
                }
                prevOverrideHookState(fiber, id, path, value);
                renderer2.overrideHookState?.(fiber, id, path, value);
              };
            } else if (renderer2.overrideHookState)
              _overrideHookState = renderer2.overrideHookState;
            if (_overrideProps) {
              var prevOverrideProps = _overrideProps;
              _overrideProps = (fiber, path, value) => {
                prevOverrideProps(fiber, path, value);
                renderer2.overrideProps?.(fiber, path, value);
              };
            } else if (renderer2.overrideProps)
              _overrideProps = renderer2.overrideProps;
            _overrideContext = (fiber, contextType, path, value) => {
              var current = fiber;
              while (current) {
                var type = current.type;
                if (type === contextType || type?.Provider === contextType) {
                  if (_overrideProps) {
                    _overrideProps(current, [
                      "value",
                      ...path
                    ], value);
                    if (current.alternate)
                      _overrideProps(current.alternate, [
                        "value",
                        ...path
                      ], value);
                  }
                  break;
                }
                current = current.return;
              }
            };
          } catch (unused) {
          }
        };
        if (!hasRDTHook())
          return null;
        var rdtHook = getRDTHook();
        if (!rdtHook?.renderers)
          return null;
        if (_overrideProps || _overrideHookState || _overrideContext)
          return {
            overrideContext: _overrideContext,
            overrideHookState: _overrideHookState,
            overrideProps: _overrideProps
          };
        for (var [_2, renderer] of Array.from(rdtHook.renderers))
          _loop3(_2, renderer);
      };
      isPOJO = (maybePOJO) => {
        return Object.prototype.toString.call(maybePOJO) === "[object Object]" && (Object.getPrototypeOf(maybePOJO) === Object.prototype || Object.getPrototypeOf(maybePOJO) === null);
      };
      buildPathsFromValue = (maybePOJO, basePath = []) => {
        if (!isPOJO(maybePOJO))
          return [
            {
              path: basePath,
              value: maybePOJO
            }
          ];
        var paths = [];
        for (var key in maybePOJO) {
          var value = maybePOJO[key];
          var path = basePath.concat(key);
          if (isPOJO(value))
            paths.push(...buildPathsFromValue(value, path));
          else
            paths.push({
              path,
              value
            });
        }
        return paths;
      };
      overrideProps = (fiber, partialValue) => {
        injectOverrideMethods();
        var paths = buildPathsFromValue(partialValue);
        for (var { path, value } of paths)
          try {
            _overrideProps?.(fiber, path, value);
          } catch (unused) {
          }
      };
      overrideHookState = (fiber, id, partialValue) => {
        injectOverrideMethods();
        var hookId = String(id);
        if (isPOJO(partialValue)) {
          var paths = buildPathsFromValue(partialValue);
          for (var { path, value } of paths)
            try {
              _overrideHookState?.(fiber, hookId, path, value);
            } catch (unused) {
            }
        } else
          try {
            _overrideHookState?.(fiber, hookId, [], partialValue);
          } catch (unused) {
          }
      };
      overrideContext = (fiber, contextType, partialValue) => {
        injectOverrideMethods();
        if (isPOJO(partialValue)) {
          var paths = buildPathsFromValue(partialValue);
          for (var { path, value } of paths)
            try {
              _overrideContext?.(fiber, contextType, path, value);
            } catch (unused) {
            }
        } else
          try {
            _overrideContext?.(fiber, contextType, [], partialValue);
          } catch (unused) {
          }
      };
      instrument = (options) => {
        var rdtHook = getRDTHook(options.onActive);
        rdtHook._instrumentationSource = options.name ?? BIPPY_INSTRUMENTATION_STRING;
        var prevOnCommitFiberRoot = rdtHook.onCommitFiberRoot;
        if (options.onCommitFiberRoot) {
          var handler = (rendererID, root, priority) => {
            if (rdtHook.onCommitFiberRoot !== handler)
              return;
            prevOnCommitFiberRoot?.(rendererID, root, priority);
            options.onCommitFiberRoot?.(rendererID, root, priority);
          };
          rdtHook.onCommitFiberRoot = handler;
        }
        var prevOnCommitFiberUnmount = rdtHook.onCommitFiberUnmount;
        if (options.onCommitFiberUnmount) {
          var handler1 = (rendererID, root) => {
            if (rdtHook.onCommitFiberUnmount !== handler1)
              return;
            prevOnCommitFiberUnmount?.(rendererID, root);
            options.onCommitFiberUnmount?.(rendererID, root);
          };
          rdtHook.onCommitFiberUnmount = handler1;
        }
        var prevOnPostCommitFiberRoot = rdtHook.onPostCommitFiberRoot;
        if (options.onPostCommitFiberRoot) {
          var handler2 = (rendererID, root) => {
            if (rdtHook.onPostCommitFiberRoot !== handler2)
              return;
            prevOnPostCommitFiberRoot?.(rendererID, root);
            options.onPostCommitFiberRoot?.(rendererID, root);
          };
          rdtHook.onPostCommitFiberRoot = handler2;
        }
        return rdtHook;
      };
      getFiberFromHostInstance = (hostInstance) => {
        var rdtHook = getRDTHook();
        for (var renderer of rdtHook.renderers.values())
          try {
            var fiber = renderer.findFiberByHostInstance?.(hostInstance);
            if (fiber)
              return fiber;
          } catch (unused) {
          }
        if (typeof hostInstance === "object" && hostInstance != null) {
          if ("_reactRootContainer" in hostInstance)
            return hostInstance._reactRootContainer?._internalRoot?.current?.child;
          for (var key in hostInstance)
            if (key.startsWith("__reactContainer$") || key.startsWith("__reactInternalInstance$") || key.startsWith("__reactFiber"))
              return hostInstance[key] || null;
        }
        return null;
      };
      INSTALL_ERROR = new Error();
      _fiberRoots = /* @__PURE__ */ new Set();
      secure = (options, secureOptions = {}) => {
        var onActive = options.onActive;
        var isRDTHookInstalled = hasRDTHook();
        var isUsingRealReactDevtools = isRealReactDevtools();
        var isUsingReactRefresh = isReactRefresh();
        var timeout;
        var isDevelopment = !secureOptions.isProduction;
        options.onActive = () => {
          clearTimeout(timeout);
          var isSecure = true;
          try {
            var rdtHook = getRDTHook();
            for (var renderer of rdtHook.renderers.values()) {
              var [majorVersion] = renderer.version.split(".");
              if (Number(majorVersion) < (secureOptions.minReactMajorVersion ?? 17))
                isSecure = false;
              var buildType = detectReactBuildType(renderer);
              if (buildType === "development")
                isDevelopment = true;
              else if (!secureOptions.dangerouslyRunInProduction)
                isSecure = false;
            }
          } catch (err) {
            secureOptions.onError?.(err);
          }
          if (!isSecure) {
            options.onCommitFiberRoot = void 0;
            options.onCommitFiberUnmount = void 0;
            options.onPostCommitFiberRoot = void 0;
            options.onActive = void 0;
            return;
          }
          onActive?.();
          try {
            var onCommitFiberRoot$1 = options.onCommitFiberRoot;
            if (onCommitFiberRoot$1)
              options.onCommitFiberRoot = (rendererID, root, priority) => {
                if (!_fiberRoots.has(root))
                  _fiberRoots.add(root);
                try {
                  onCommitFiberRoot$1(rendererID, root, priority);
                } catch (err) {
                  secureOptions.onError?.(err);
                }
              };
            var onCommitFiberUnmount = options.onCommitFiberUnmount;
            if (onCommitFiberUnmount)
              options.onCommitFiberUnmount = (rendererID, root) => {
                try {
                  onCommitFiberUnmount(rendererID, root);
                } catch (err) {
                  secureOptions.onError?.(err);
                }
              };
            var onPostCommitFiberRoot = options.onPostCommitFiberRoot;
            if (onPostCommitFiberRoot)
              options.onPostCommitFiberRoot = (rendererID, root) => {
                try {
                  onPostCommitFiberRoot(rendererID, root);
                } catch (err) {
                  secureOptions.onError?.(err);
                }
              };
          } catch (err) {
            secureOptions.onError?.(err);
          }
        };
        if (!isRDTHookInstalled && !isUsingRealReactDevtools && !isUsingReactRefresh)
          timeout = setTimeout(() => {
            if (isDevelopment)
              secureOptions.onError?.(INSTALL_ERROR);
            stop();
          }, secureOptions.installCheckTimeout ?? 100);
        return options;
      };
      onCommitFiberRoot = (handler) => {
        return instrument(secure({
          onCommitFiberRoot: (_2, root) => {
            handler(root);
          }
        }));
      };
      safelyInstallRDTHook();
    }
  });

  // node_modules/bippy/dist/index.js
  var dist_exports = {};
  __export(dist_exports, {
    ActivityComponentTag: () => ActivityComponentTag,
    BIPPY_INSTRUMENTATION_STRING: () => BIPPY_INSTRUMENTATION_STRING,
    CONCURRENT_MODE_NUMBER: () => CONCURRENT_MODE_NUMBER,
    CONCURRENT_MODE_SYMBOL_STRING: () => CONCURRENT_MODE_SYMBOL_STRING,
    ClassComponentTag: () => ClassComponentTag,
    ContextConsumerTag: () => ContextConsumerTag,
    DEPRECATED_ASYNC_MODE_SYMBOL_STRING: () => DEPRECATED_ASYNC_MODE_SYMBOL_STRING,
    DehydratedSuspenseComponentTag: () => DehydratedSuspenseComponentTag,
    ELEMENT_TYPE_SYMBOL_STRING: () => ELEMENT_TYPE_SYMBOL_STRING,
    ForwardRefTag: () => ForwardRefTag,
    FragmentTag: () => FragmentTag,
    FunctionComponentTag: () => FunctionComponentTag,
    HostComponentTag: () => HostComponentTag,
    HostHoistableTag: () => HostHoistableTag,
    HostRootTag: () => HostRootTag,
    HostSingletonTag: () => HostSingletonTag,
    HostTextTag: () => HostTextTag,
    INSTALL_ERROR: () => INSTALL_ERROR,
    LazyComponentTag: () => LazyComponentTag,
    LegacyHiddenComponentTag: () => LegacyHiddenComponentTag,
    MemoComponentTag: () => MemoComponentTag,
    OffscreenComponentTag: () => OffscreenComponentTag,
    SimpleMemoComponentTag: () => SimpleMemoComponentTag,
    SuspenseComponentTag: () => SuspenseComponentTag,
    SuspenseListComponentTag: () => SuspenseListComponentTag,
    TRANSITIONAL_ELEMENT_TYPE_SYMBOL_STRING: () => TRANSITIONAL_ELEMENT_TYPE_SYMBOL_STRING,
    ViewTransitionComponentTag: () => ViewTransitionComponentTag,
    _fiberRoots: () => _fiberRoots,
    _renderers: () => _renderers,
    areFiberEqual: () => areFiberEqual,
    createFiberVisitor: () => createFiberVisitor,
    detectReactBuildType: () => detectReactBuildType,
    didFiberCommit: () => didFiberCommit,
    didFiberRender: () => didFiberRender,
    fiberIdMap: () => fiberIdMap,
    getDisplayName: () => getDisplayName,
    getFiberFromHostInstance: () => getFiberFromHostInstance,
    getFiberId: () => getFiberId,
    getFiberStack: () => getFiberStack,
    getLatestFiber: () => getLatestFiber,
    getMutatedHostFibers: () => getMutatedHostFibers,
    getNearestHostFiber: () => getNearestHostFiber,
    getNearestHostFibers: () => getNearestHostFibers,
    getRDTHook: () => getRDTHook,
    getTimings: () => getTimings,
    getType: () => getType,
    hasMemoCache: () => hasMemoCache,
    hasRDTHook: () => hasRDTHook,
    injectOverrideMethods: () => injectOverrideMethods,
    installRDTHook: () => installRDTHook,
    instrument: () => instrument,
    isClientEnvironment: () => isClientEnvironment,
    isCompositeFiber: () => isCompositeFiber,
    isHostFiber: () => isHostFiber,
    isInstrumentationActive: () => isInstrumentationActive,
    isReactRefresh: () => isReactRefresh,
    isRealReactDevtools: () => isRealReactDevtools,
    isValidElement: () => isValidElement,
    isValidFiber: () => isValidFiber,
    mountFiberRecursively: () => mountFiberRecursively,
    onCommitFiberRoot: () => onCommitFiberRoot,
    overrideContext: () => overrideContext,
    overrideHookState: () => overrideHookState,
    overrideProps: () => overrideProps,
    patchRDTHook: () => patchRDTHook,
    safelyInstallRDTHook: () => safelyInstallRDTHook,
    secure: () => secure,
    setFiberId: () => setFiberId,
    shouldFilterFiber: () => shouldFilterFiber,
    traverseContexts: () => traverseContexts,
    traverseFiber: () => traverseFiber,
    traverseFiberAsync: () => traverseFiberAsync,
    traverseFiberSync: () => traverseFiberSync,
    traverseProps: () => traverseProps,
    traverseRenderedFibers: () => traverseRenderedFibers,
    traverseState: () => traverseState,
    unmountFiber: () => unmountFiber,
    unmountFiberChildrenRecursively: () => unmountFiberChildrenRecursively,
    updateFiberRecursively: () => updateFiberRecursively,
    version: () => version
  });
  var init_dist2 = __esm({
    "node_modules/bippy/dist/index.js"() {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_src_DnJsD_Sy();
    }
  });

  // node_modules/@revenge-mod/devtools-client/dist/index.js
  function loadBippy() {
    bippyModule ??= Promise.resolve().then(() => (init_dist2(), dist_exports));
    return bippyModule;
  }
  var _class, bippyModule, LOG_BUFFER_CAPACITY, DevToolsClient;
  var init_dist3 = __esm({
    "node_modules/@revenge-mod/devtools-client/dist/index.js"() {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_async_to_generator();
      init_class_call_check();
      init_create_class();
      init_define_property();
      init_constants2();
      init_serializer();
      bippyModule = null;
      LOG_BUFFER_CAPACITY = 1e3;
      DevToolsClient = (_class = /* @__PURE__ */ function() {
        "use strict";
        function _class2() {
          _class_call_check(this, _class2);
          _define_property(this, "ws", null);
          _define_property(this, "settings", DEFAULT_SETTINGS.client);
          _define_property(this, "scope", {
            devTools: this,
            vars: {
              mcp: {}
            }
          });
          _define_property(this, "connected", false);
          _define_property(this, "authenticated", false);
          _define_property(this, "handlers", /* @__PURE__ */ new Map());
          _define_property(this, "alias", void 0);
          _define_property(this, "logs", []);
          _define_property(this, "reactRoot", null);
          _define_property(this, "reactCommitHooked", false);
          _define_property(this, "patches", /* @__PURE__ */ new Map());
          _define_property(this, "patchIdCounter", 0);
        }
        _create_class(_class2, [
          {
            /**
            * Connect to the developer tools server.
            *
            * @param url - WebSocket server URL (e.g., "ws://localhost:7864")
            * @param info - Optional information string to identify this client
            * @param alias - Optional alias (alphanumeric, `-`, `_`) for targeting this client in MCP commands
            *
            * @example
            * ```ts
            * client.connect("ws://localhost:7864", "My React Native App")
            * ```
            */
            key: "connect",
            value: function connect(url2, info, alias) {
              if (this.ws?.readyState === WebSocket.OPEN)
                return;
              this.alias = alias;
              try {
                this.ws = new WebSocket(url2);
                this.ws.onopen = () => {
                  this.connected = true;
                  this.sendHello(info);
                };
                this.ws.onmessage = (event) => {
                  try {
                    var msg = deserialize(event.data);
                    this.handleMessage(msg);
                  } catch (e) {
                    console.error("[DevTools] Parse error:", e);
                  }
                };
                this.ws.onerror = (error) => {
                  console.error("[DevTools] WebSocket error:", error);
                };
                this.ws.onclose = () => {
                  this.connected = false;
                  this.authenticated = false;
                  this.patches.clear();
                  this.patchIdCounter = 0;
                };
              } catch (e) {
                console.error("[DevTools] Connection error:", e);
              }
            }
          },
          {
            /**
            * Disconnect from the server and clean up the connection.
            */
            key: "disconnect",
            value: function disconnect() {
              if (this.ws) {
                this.ws.close();
                this.ws = null;
              }
              this.connected = false;
              this.authenticated = false;
            }
          },
          {
            /**
            * Clear all saved variables. Not the scope itself!
            */
            key: "clearVars",
            value: function clearVars() {
              this.scope.vars = {
                mcp: {}
              };
            }
          },
          {
            /**
            * Expose a variable to the server execution scope.
            *
            * @param key - Variable name to use in server scope
            * @param value - Value to expose (will be serialized when accessed)
            *
            * @example
            * ```ts
            * client.expose('user', { name: 'John', age: 30 })
            * client.expose('config', appConfig)
            *
            * // From server:
            * // > user.name
            * // "John"
            * ```
            */
            key: "expose",
            value: function expose(key, value) {
              this.scope[key] = value;
            }
          },
          {
            key: "sendHello",
            value: function sendHello(info) {
              var msg = {
                type: MessageType.Hello,
                data: {
                  version: PROTOCOL_VERSION,
                  info,
                  alias: this.alias
                }
              };
              this.send(msg);
            }
          },
          {
            key: "handleMessage",
            value: function handleMessage(msg) {
              switch (msg.type) {
                case MessageType.Hi:
                  this.handleHi(msg);
                  break;
                case MessageType.Run:
                  this.handleRun(msg);
                  break;
                case MessageType.MCPRun:
                  this.handleMCPRun(msg);
                  break;
              }
              var handlers = this.handlers.get(msg.type);
              if (handlers)
                for (var handler of handlers)
                  handler(msg);
            }
          },
          {
            key: "handleHi",
            value: function handleHi(msg) {
              if (!msg.data.supported) {
                console.error("[DevTools] Version not supported by server");
                this.disconnect();
                return;
              }
              if (this.authenticated)
                console.debug("[DevTools] Reloaded settings from server");
              this.authenticated = true;
              this.settings = msg.data.settings;
            }
          },
          {
            key: "handleRun",
            value: function handleRun(msg) {
              try {
                var mappings = msg.data.mappings || {};
                var scope = {
                  ...this.scope
                };
                for (var [key, mapping] of Object.entries(mappings))
                  scope[key] = this.resolveMapping(mapping);
                var result = this.evalInScope(msg.data.code, scope);
                this.log(LogLevel.Default, [
                  snapshot(result, this.settings.log.inspectDepth)
                ]);
              } catch (e) {
                this.log(LogLevel.Error, [
                  this.formatError(e)
                ]);
              }
            }
          },
          {
            key: "wrapCodeWithAutoReturn",
            value: function wrapCodeWithAutoReturn(code) {
              var trimmed = code.trim();
              if (trimmed.startsWith("return "))
                return code;
              if (!/[;{}]|^(let|const|var|if|for|while|function|class)\s/.test(trimmed))
                return `return (${trimmed})`;
              var lines = trimmed.split(/[;\n]+/).map((l) => l.trim()).filter(Boolean);
              if (!lines.length)
                return code;
              var lastLine = lines[lines.length - 1];
              var previousLines = lines.slice(0, -1);
              if (/^(let|const|var|if|for|while|function|class|return)\s/.test(lastLine))
                return code;
              var statementsCode = previousLines.join("\n");
              return statementsCode ? `${statementsCode}
return (${lastLine})` : `return (${lastLine})`;
            }
          },
          {
            key: "withScope",
            value: function withScope(scope, code) {
              return new Function(...Object.keys(scope), code);
            }
          },
          {
            key: "resolveMapping",
            value: function resolveMapping(path) {
              try {
                return this.withScope(this.scope, this.wrapCodeWithAutoReturn(path))(...Object.values(this.scope));
              } catch (unused) {
                return;
              }
            }
          },
          {
            /**
            * Evaluate a code string against a scope. The code is compiled as a single
            * expression first, then with the auto-return heuristic, then as a raw
            * function body (statements allowed, explicit `return` honored).
            */
            key: "evalInScope",
            value: function evalInScope(code, scope = this.scope) {
              var keys = Object.keys(scope);
              var func;
              var parseError;
              for (var body of [
                `return (${code})`,
                this.wrapCodeWithAutoReturn(code),
                code
              ])
                try {
                  func = new Function(...keys, body);
                  break;
                } catch (e) {
                  if (!(e instanceof SyntaxError))
                    throw e;
                  parseError ??= e;
                }
              if (!func)
                throw new SyntaxError(`${this.cleanParseError(parseError)} (code is evaluated as an expression first, then as a function body \u2014 use an explicit \`return\` for multi-statement code)`);
              return func(...Object.values(scope));
            }
          },
          {
            /** Strip wrapper-relative line/column positions from a parse error message. */
            key: "cleanParseError",
            value: function cleanParseError(e) {
              return (e?.message ?? (e == null ? "Invalid code" : String(e))).replace(/^\d+:\d+:?\s*/, "").replace(/\s*\(<anonymous>:\d+:\d+\)/g, "").replace(/<anonymous>:\d+:\d+:?\s*/g, "").trim();
            }
          },
          {
            /** Format an error with its stack trimmed to the first few frames. */
            key: "formatError",
            value: function formatError(e) {
              var stack = e?.stack;
              if (typeof stack !== "string")
                return e?.message ?? (e == null ? "Unknown error" : String(e));
              var lines = stack.split("\n");
              var firstFrame = lines.findIndex((line) => /^\s*at /.test(line));
              if (firstFrame === -1)
                return stack;
              var frames = lines.slice(firstFrame);
              if (frames.length <= 5)
                return stack;
              return [
                ...lines.slice(0, firstFrame),
                ...frames.slice(0, 5),
                `    \u2026 (${frames.length - 5} more frames)`
              ].join("\n");
            }
          },
          {
            /**
            * Evaluate a single expression in the client scope, always returning its value.
            */
            key: "evalExpression",
            value: function evalExpression(code) {
              return this.withScope(this.scope, `return (${code})`)(...Object.values(this.scope));
            }
          },
          {
            key: "revenge",
            get: function get() {
              return this.scope.revenge;
            }
          },
          {
            key: "revengeDiscord",
            get: function get() {
              var discord = this.revenge?.discord;
              if (!discord)
                throw new Error("YumiCord Discord API is not available in the client scope");
              return discord;
            }
          },
          {
            key: "revengeModulesFinders",
            get: function get() {
              var finders = this.revenge?.modules?.finders;
              if (!finders)
                throw new Error("YumiCord module finders are not available in the client scope");
              return finders;
            }
          },
          {
            key: "sendMCPResult",
            value: function sendMCPResult(id, ok, result, error) {
              var msg = {
                type: MessageType.MCPResult,
                data: {
                  id,
                  ok,
                  result,
                  error
                }
              };
              this.send(msg);
            }
          },
          {
            key: "handleMCPRun",
            value: function handleMCPRun(msg) {
              return _async_to_generator(function* () {
                var { id, command, args } = msg.data;
                try {
                  var result;
                  switch (command) {
                    case MCPCommand.GetModules:
                      result = yield this.mcpGetModules(args);
                      break;
                    case MCPCommand.LookupModules:
                      result = this.mcpLookupModules(args);
                      break;
                    case MCPCommand.RequireModule:
                      result = this.mcpRequireModule(args);
                      break;
                    case MCPCommand.SaveVar:
                      result = this.mcpSaveVar(args);
                      break;
                    case MCPCommand.PatchMethod:
                      result = this.mcpPatchMethod(args);
                      break;
                    case MCPCommand.UnpatchMethod:
                      result = this.mcpUnpatchMethod(args);
                      break;
                    case MCPCommand.Eval:
                      result = this.mcpEval(args);
                      break;
                    case MCPCommand.DiscordReload:
                      result = this.mcpDiscordReload();
                      break;
                    case MCPCommand.DiscordFluxListen:
                      result = yield this.mcpDiscordFluxListen(args);
                      break;
                    case MCPCommand.DiscordFluxPatch:
                      result = this.mcpDiscordFluxPatch(args);
                      break;
                    case MCPCommand.DiscordFluxUnpatch:
                      result = this.mcpDiscordFluxUnpatch(args);
                      break;
                    case MCPCommand.GetLogs:
                      result = this.mcpGetLogs(args);
                      break;
                    case MCPCommand.ReactTreeGetRoot:
                      result = yield this.mcpReactTreeGetRoot();
                      break;
                    case MCPCommand.ReactTreeMatch:
                      result = yield this.mcpReactTreeMatch(args);
                      break;
                    case MCPCommand.ReactTreeTraverseStructure:
                      result = yield this.mcpReactTreeTraverseStructure(args);
                      break;
                    case MCPCommand.ReactTreeHooks:
                      result = yield this.mcpReactTreeHooks(args);
                      break;
                    default:
                      throw new Error(`Unknown MCP command: ${command}`);
                  }
                  this.sendMCPResult(id, true, result);
                } catch (e) {
                  this.sendMCPResult(id, false, void 0, this.formatError(e));
                }
              }).call(this);
            }
          },
          {
            key: "mcpGetModules",
            value: function mcpGetModules(args) {
              var finders = this.revengeModulesFinders;
              var filterFactory = finders.filters[args.filter];
              if (typeof filterFactory !== "function")
                throw new Error(`Unknown filter "${args.filter}". Available: ${Object.keys(finders.filters).join(", ")}`);
              var filterArgs = this.evalInScope(args.args);
              if (!Array.isArray(filterArgs))
                throw new Error("`args` must evaluate to an array of filter arguments");
              var filter = filterFactory(...filterArgs);
              var max = args.max ?? 1;
              var timeout = args.timeout ?? 5e3;
              var depth = args.depth ?? this.settings.log.inspectDepth;
              return new Promise((resolve) => {
                var results = [];
                var unsub;
                var done = false;
                var finish = () => {
                  if (done)
                    return;
                  done = true;
                  clearTimeout(timer);
                  try {
                    unsub?.();
                  } catch (unused) {
                  }
                  resolve({
                    count: results.length,
                    modules: results
                  });
                };
                var timer = setTimeout(finish, timeout);
                unsub = finders.getModules(filter, (exports, moduleId) => {
                  results.push({
                    id: moduleId,
                    exports: snapshot(exports, depth)
                  });
                  if (results.length >= max)
                    finish();
                }, {
                  max
                });
                if (results.length >= max)
                  finish();
              });
            }
          },
          {
            key: "mcpLookupModules",
            value: function mcpLookupModules(args) {
              var finders = this.revengeModulesFinders;
              var filterFactory = finders.filters[args.filter];
              if (typeof filterFactory !== "function")
                throw new Error(`Unknown filter "${args.filter}". Available: ${Object.keys(finders.filters).join(", ")}`);
              var filterArgs = this.evalInScope(args.args);
              if (!Array.isArray(filterArgs))
                throw new Error("`args` must evaluate to an array of filter arguments");
              var filter = filterFactory(...filterArgs);
              var initialize = args.initialize ?? true;
              var depth = args.depth ?? this.settings.log.inspectDepth;
              var max = args.max ?? Infinity;
              var options = initialize ? void 0 : {
                initialize: false
              };
              var modules = [];
              for (var [exports, id] of finders.lookupModules(filter, options)) {
                modules.push({
                  id,
                  exports: exports === void 0 ? null : snapshot(exports, depth)
                });
                if (modules.length >= max)
                  break;
              }
              return {
                count: modules.length,
                modules
              };
            }
          },
          {
            key: "mcpRequireModule",
            value: function mcpRequireModule(args) {
              var depth = args.depth ?? this.settings.log.inspectDepth;
              var metroRequire2 = globalThis.__r;
              if (typeof metroRequire2 !== "function")
                throw new Error("Metro require function is not available");
              var exports = metroRequire2(args.id);
              return {
                id: args.id,
                exports: snapshot(exports, depth),
                source: "unavailable (Hermes bytecode)"
              };
            }
          },
          {
            key: "mcpSaveVar",
            value: function mcpSaveVar(args) {
              var value = this.evalInScope(args.expression);
              this.scope.vars[args.name] = value;
              return {
                name: args.name,
                value: snapshot(value, this.settings.log.inspectDepth)
              };
            }
          },
          {
            key: "mcpPatchMethod",
            value: function mcpPatchMethod(args) {
              var patcher = this.revenge?.patcher;
              if (!patcher)
                throw new Error("YumiCord patcher is not available in the client scope");
              var patchFn = patcher[args.method];
              if (typeof patchFn !== "function")
                throw new Error(`Unknown patch method: ${args.method}`);
              var target = this.evalInScope(args.target);
              if (target == null || typeof target !== "object" && typeof target !== "function")
                throw new Error("`target` must evaluate to an object or function");
              var hook = this.evalExpression(args.hook);
              if (typeof hook !== "function")
                throw new Error("`hook` must evaluate to a function");
              var unpatch = patchFn(target, args.key, hook);
              return {
                id: this.storePatch(unpatch)
              };
            }
          },
          {
            /** Allocate a patch ID and store its unpatch closure. */
            key: "storePatch",
            value: function storePatch(unpatch) {
              var id = ++this.patchIdCounter;
              this.patches.set(id, unpatch);
              return id;
            }
          },
          {
            /** Remove (and invoke) a stored patch by ID. */
            key: "removePatch",
            value: function removePatch(id) {
              var unpatch = this.patches.get(id);
              if (!unpatch)
                throw new Error(`Unknown patch ID: ${id}`);
              unpatch();
              this.patches.delete(id);
              return {
                unpatched: true
              };
            }
          },
          {
            key: "mcpUnpatchMethod",
            value: function mcpUnpatchMethod(args) {
              return this.removePatch(args.id);
            }
          },
          {
            key: "mcpEval",
            value: function mcpEval(args) {
              return snapshot(this.evalInScope(args.code), this.settings.log.inspectDepth);
            }
          },
          {
            key: "mcpDiscordReload",
            value: function mcpDiscordReload() {
              var manager = this.revengeDiscord.native?.BundleUpdaterManager;
              if (typeof manager?.reload !== "function")
                throw new Error("BundleUpdaterManager.reload is not available");
              setTimeout(() => {
                try {
                  manager.reload();
                } catch (e) {
                  console.error("[DevTools] Reload failed:", e);
                }
              }, 0);
              return {
                reloading: true
              };
            }
          },
          {
            key: "mcpDiscordFluxListen",
            value: function mcpDiscordFluxListen(args) {
              var flux = this.revengeDiscord.flux;
              if (!flux?.onAnyFluxEventDispatched || !flux.onFluxEventDispatched)
                throw new Error("YumiCord Discord Flux API is not available");
              var count = args.count ?? 25;
              var timeout = args.timeout ?? 5e3;
              var depth = args.depth ?? this.settings.log.inspectDepth;
              return new Promise((resolve) => {
                var events = [];
                var unsub;
                var done = false;
                var finish = () => {
                  if (done)
                    return;
                  done = true;
                  clearTimeout(timer);
                  try {
                    unsub?.();
                  } catch (unused) {
                  }
                  resolve({
                    count: events.length,
                    events
                  });
                };
                var timer = setTimeout(finish, timeout);
                var capture = (payload) => {
                  events.push(snapshot(payload, depth));
                  if (events.length >= count)
                    finish();
                  return payload;
                };
                unsub = args.event ? flux.onFluxEventDispatched(args.event, capture) : flux.onAnyFluxEventDispatched(capture);
              });
            }
          },
          {
            key: "mcpDiscordFluxPatch",
            value: function mcpDiscordFluxPatch(args) {
              var flux = this.revengeDiscord.flux;
              if (!flux?.onAnyFluxEventDispatched || !flux.onFluxEventDispatched)
                throw new Error("YumiCord Discord Flux API is not available");
              var hook = this.evalExpression(args.hook);
              if (typeof hook !== "function")
                throw new Error("`hook` must evaluate to a function");
              var unsub = args.event ? flux.onFluxEventDispatched(args.event, hook) : flux.onAnyFluxEventDispatched(hook);
              return {
                id: this.storePatch(unsub)
              };
            }
          },
          {
            key: "mcpDiscordFluxUnpatch",
            value: function mcpDiscordFluxUnpatch(args) {
              return this.removePatch(args.id);
            }
          },
          {
            key: "mcpGetLogs",
            value: function mcpGetLogs(args) {
              var minLevel = args.min_level ?? LogLevel.Debug;
              var depth = args.depth ?? this.settings.log.inspectDepth;
              var entries = this.logs.filter((entry) => entry.level >= minLevel);
              if (args.limit != null && entries.length > args.limit)
                entries = entries.slice(-args.limit);
              return {
                count: entries.length,
                logs: entries.map((entry) => ({
                  level: entry.level,
                  time: entry.time,
                  message: entry.message.map((item) => snapshot(item, depth))
                }))
              };
            }
          },
          {
            key: "ensureReactCommitHook",
            value: function ensureReactCommitHook(bippy) {
              if (this.reactCommitHooked)
                return;
              this.reactCommitHooked = true;
              try {
                bippy.onCommitFiberRoot((root) => {
                  this.reactRoot = root.current;
                });
              } catch (unused) {
              }
            }
          },
          {
            key: "getReactRootFiber",
            value: function getReactRootFiber(bippy) {
              this.ensureReactCommitHook(bippy);
              var hook = bippy.getRDTHook();
              if (typeof hook?.getFiberRoots === "function") {
                for (var id of hook.renderers.keys())
                  for (var root of hook.getFiberRoots(id))
                    if (root?.current)
                      return root.current;
              }
              if (this.reactRoot)
                return this.reactRoot;
              throw new Error("React root fiber is unavailable. No renderer has registered with the DevTools hook and no commit has been observed yet.");
            }
          },
          {
            key: "resolveReactFiber",
            value: function resolveReactFiber(bippy, from) {
              if (from != null) {
                var fiber = this.evalInScope(from);
                if (!bippy.isValidFiber(fiber))
                  throw new Error("`from` must evaluate to a React fiber");
                return fiber;
              }
              var stored = this.scope.vars.mcp?.reactFiber;
              if (stored != null) {
                if (!bippy.isValidFiber(stored))
                  throw new Error("`vars.mcp.reactFiber` is not a valid React fiber");
                return stored;
              }
              return this.getReactRootFiber(bippy);
            }
          },
          {
            key: "describeFiber",
            value: function describeFiber(bippy, fiber) {
              return {
                name: bippy.getDisplayName(fiber.type) ?? (typeof fiber.type === "string" ? fiber.type : `#${fiber.tag}`),
                tag: fiber.tag,
                key: fiber.key
              };
            }
          },
          {
            key: "mcpReactTreeGetRoot",
            value: function mcpReactTreeGetRoot() {
              return _async_to_generator(function* () {
                var bippy = yield loadBippy();
                var root = this.getReactRootFiber(bippy);
                this.scope.vars.mcp ??= {};
                this.scope.vars.mcp.reactFiber = root;
                return {
                  stored: "vars.mcp.reactFiber",
                  fiber: this.describeFiber(bippy, root)
                };
              }).call(this);
            }
          },
          {
            key: "mcpReactTreeMatch",
            value: function mcpReactTreeMatch(args) {
              return _async_to_generator(function* () {
                var bippy = yield loadBippy();
                var predicate = this.evalExpression(args.predicate);
                if (typeof predicate !== "function")
                  throw new Error("`predicate` must evaluate to a function");
                var start = this.resolveReactFiber(bippy, args.from);
                var maxVisits = args.depth ?? 100;
                var visited = 0;
                var exceeded = false;
                var found = bippy.traverseFiber(start, (fiber) => {
                  if (++visited > maxVisits) {
                    exceeded = true;
                    return true;
                  }
                  try {
                    return Boolean(predicate(fiber));
                  } catch (unused) {
                    return false;
                  }
                });
                if (!found || exceeded)
                  return {
                    matched: false,
                    visited: visited - 1
                  };
                this.scope.vars.mcp ??= {};
                this.scope.vars.mcp.reactFiber = found;
                return {
                  matched: true,
                  visited,
                  stored: "vars.mcp.reactFiber",
                  fiber: this.describeFiber(bippy, found)
                };
              }).call(this);
            }
          },
          {
            key: "summarizeProps",
            value: function summarizeProps(props) {
              if (props == null || typeof props !== "object")
                return "";
              var parts = [];
              for (var key of Object.keys(props)) {
                if (key === "children")
                  continue;
                if (parts.length >= 8) {
                  parts.push("\u2026");
                  break;
                }
                var value = props[key];
                var rendered = void 0;
                switch (typeof value) {
                  case "string":
                    rendered = JSON.stringify(value.length > 32 ? `${value.slice(0, 32)}\u2026` : value);
                    break;
                  case "function":
                    rendered = "fn";
                    break;
                  case "object":
                    rendered = value === null ? "null" : Array.isArray(value) ? `Array(${value.length})` : "{\u2026}";
                    break;
                  default:
                    rendered = String(value);
                }
                parts.push(`${key}=${rendered}`);
              }
              return parts.join(" ");
            }
          },
          {
            key: "mcpReactTreeTraverseStructure",
            value: function mcpReactTreeTraverseStructure(args) {
              return _async_to_generator(function* () {
                var bippy = yield loadBippy();
                var start = this.resolveReactFiber(bippy, args.from);
                var maxDepth = args.depth ?? 10;
                var showHost = args.showHostComponents ?? false;
                var maxLines = 2e3;
                var lines = [];
                var truncated = false;
                var formatLine = (fiber, depth) => {
                  var { name, key } = this.describeFiber(bippy, fiber);
                  var host = showHost && bippy.isHostFiber(fiber) ? " (host)" : "";
                  var keyPart = key != null ? ` key=${JSON.stringify(key)}` : "";
                  var props = this.summarizeProps(fiber.memoizedProps);
                  var propsPart = props ? ` ${props}` : "";
                  return `${"  ".repeat(depth)}<${name}${keyPart}${propsPart}>${host}`;
                };
                var walk = (node, depth) => {
                  for (var fiber = node; fiber; fiber = fiber.sibling) {
                    if (lines.length >= maxLines) {
                      truncated = true;
                      return;
                    }
                    if (!showHost && bippy.isHostFiber(fiber)) {
                      walk(fiber.child, depth);
                      continue;
                    }
                    lines.push(formatLine(fiber, depth));
                    if (depth < maxDepth)
                      walk(fiber.child, depth + 1);
                    else if (fiber.child)
                      truncated = true;
                  }
                };
                if (!showHost && bippy.isHostFiber(start))
                  walk(start.child, 0);
                else {
                  lines.push(formatLine(start, 0));
                  walk(start.child, 1);
                }
                return {
                  depth: maxDepth,
                  truncated,
                  hostComponentsHidden: !showHost,
                  structure: lines.join("\n")
                };
              }).call(this);
            }
          },
          {
            key: "mcpReactTreeHooks",
            value: function mcpReactTreeHooks(args) {
              return _async_to_generator(function* () {
                var bippy = yield loadBippy();
                var fiber = this.resolveReactFiber(bippy, args.from);
                var limit = args.limit ?? 50;
                var depth = args.depth ?? this.settings.log.inspectDepth;
                var first = fiber.memoizedState;
                var isHookNode = (node2) => node2 != null && typeof node2 === "object" && ("memoizedState" in node2 || "queue" in node2) && "next" in node2;
                if (!isHookNode(first))
                  return {
                    count: 0,
                    hooks: [],
                    truncated: false,
                    fiber: this.describeFiber(bippy, fiber),
                    note: "fiber has no hook chain (not a function component, or not mounted)"
                  };
                var hooks = [];
                var truncated = false;
                var index = 0;
                for (var node = first; isHookNode(node); node = node.next) {
                  if (hooks.length >= limit) {
                    truncated = true;
                    break;
                  }
                  hooks.push({
                    index: index++,
                    state: snapshot(node.memoizedState, depth),
                    hasQueue: node.queue != null
                  });
                }
                return {
                  count: hooks.length,
                  hooks,
                  truncated,
                  fiber: this.describeFiber(bippy, fiber)
                };
              }).call(this);
            }
          },
          {
            key: "send",
            value: function send(msg) {
              if (this.ws?.readyState === WebSocket.OPEN && this.ws)
                this.ws.send(serialize(msg));
            }
          },
          {
            /**
            * Send a log message to the server.
            *
            * @param level - Log level (Debug, Default, Warn, Error)
            * @param message - Array of values to log
            *
            * @example
            * ```ts
            * import { LogLevel } from '@revenge-mod/devtools-shared/constants'
            *
            * client.log(LogLevel.Debug, ["Debug info", { data: 123 }])
            * client.log(LogLevel.Error, ["Error:", error])
            * ```
            */
            key: "log",
            value: function log(level2, message) {
              var snapped = message.map((item) => snapshot(item, this.settings.log.inspectDepth));
              this.logs.push({
                level: level2,
                time: Date.now(),
                message: snapped
              });
              if (this.logs.length > LOG_BUFFER_CAPACITY)
                this.logs.shift();
              if (!this.authenticated)
                return;
              if (level2 < this.settings.log.level)
                return;
              var msg = {
                type: MessageType.Log,
                data: {
                  level: level2,
                  message: snapped
                }
              };
              this.send(msg);
            }
          },
          {
            /**
            * Register a handler for a specific message type.
            *
            * @param type - Message type to listen for
            * @param handler - Callback function to handle the message
            *
            * @example
            * ```ts
            * import { MessageType } from '@revenge-mod/devtools-shared/constants'
            *
            * client.on(MessageType.Hi, (msg) => {
            *   console.log('Server acknowledged connection')
            * })
            * ```
            */
            key: "on",
            value: function on(type, handler) {
              if (!this.handlers.has(type))
                this.handlers.set(type, /* @__PURE__ */ new Set());
              this.handlers.get(type).add(handler);
            }
          },
          {
            /**
            * Unregister a message handler.
            *
            * @param type - Message type
            * @param handler - Handler function to remove
            */
            key: "off",
            value: function off(type, handler) {
              var handlers = this.handlers.get(type);
              if (handlers)
                handlers.delete(handler);
            }
          },
          {
            /**
            * Check if the client is connected and authenticated with the server.
            *
            * @returns `true` if connected and authenticated, `false` otherwise
            */
            key: "isConnected",
            value: function isConnected() {
              return this.connected && this.authenticated;
            }
          }
        ]);
        return _class2;
      }(), /** Protocol version used by this client */
      _define_property(_class, "version", PROTOCOL_VERSION), _class);
    }
  });

  // src/core/i18n/default.json
  var default_default;
  var init_default = __esm({
    "src/core/i18n/default.json"() {
      default_default = {
        ABOUT: "About",
        ACTIONS: "Actions",
        ARE_YOU_SURE_TO_CLEAR_DATA: "Are you sure you wish to clear the data of {name}?",
        ARE_YOU_SURE_TO_DELETE_PLUGIN: "Are you sure you wish to delete {name}? This will clear all of the plugin's data.",
        ARE_YOU_SURE_TO_DELETE_THEME: "Are you sure you wish to delete {name}?",
        ASSET_BROWSER: "Asset Browser",
        BRAND: "Brand",
        BUNNY_URL: "YumiCord URL",
        BUNNY: "YumiCord",
        BYTECODE: "Bytecode",
        CANCEL: "Cancel",
        CLEAR_BUNDLE_DESC: "Clear the cached bundle. This will force a re-download of the bundle next app launch.",
        CLEAR_BUNDLE: "Clear JS Bundle",
        CLEAR_DATA_FAILED: "Failed to clear data for {name}",
        CLEAR_DATA_SUCCESSFUL: "Cleared data for {name}",
        CLEAR_DATA: "Clear Data",
        CLEAR: "Clear",
        CODENAME: "Codename",
        COMMAND_DEBUG_DESC: "Send debug information",
        COMMAND_DEBUG_OPT_EPHEMERALLY: "Send the message ephemerally",
        COMMAND_EVAL_DESC: "Evaluate JavaScript code",
        COMMAND_EVAL_OPT_ASYNC: "Whether to support 'await' in code, must explicitly return for result (default: false)",
        COMMAND_EVAL_OPT_CODE: "The code to evaluate",
        COMMAND_PLUGINS_DESC: "Send list of installed plugins",
        COMMAND_PLUGINS_OPT_EPHEMERALLY: "Send the message ephemerally",
        COMPONENT: "Component",
        CONFIRMATION_LINK_IS_A_TYPE: "This link is a **{urlType, select, plugin {Plugin} theme {Theme} other {Add-on}}**, would you like to install it?",
        CONNECT_TO_DEBUG_WEBSOCKET: "Connect to DevTools",
        CONNECT_TO_REACT_DEVTOOLS: "Connect to React DevTools",
        CONNECTED_TO_DEBUGGER: "Connected to DevTools",
        CONNECTED_TO_REACT_DEVTOOLS: "Connected to React DevTools",
        CONTINUE: "Continue",
        COPIED_TO_CLIPBOARD: "Copied to clipboard",
        COPY_URL: "Copy URL",
        DEBUG: "Debug",
        DEBUGGER_AUTOCONNECT_DESC: "Automatically connect to the DevTools during startup",
        DEBUGGER_AUTOCONNECT: "Auto-connect to DevTools",
        DEBUGGER_URL: "DevTools URL",
        DELETE: "Delete",
        DESC_EXTRACT_FONTS_FROM_THEME: 'Looks out for "fonts" field in your currently applied theme and install it.',
        DEVELOPER_SETTINGS: "Developer Settings",
        DEVELOPER: "Developer",
        DISABLE_THEME: "Disable Theme",
        DISABLE_UPDATES: "Disable Updates",
        DISCONNECT_FROM_DEBUG_WEBSOCKET: "Disconnect from DevTools",
        DISCONNECT_FROM_REACT_DEVTOOLS: "Disconnect from React DevTools",
        DISCORD_SERVER: "Discord Server",
        DONE: "Done",
        ENABLE_EVAL_COMMAND_DESC: "Evaluate JavaScript directly from a command. Be cautious when using this command as it may pose a security risk. Make sure to know what you are doing.",
        ENABLE_EVAL_COMMAND: "Enable /eval command",
        ENABLE_UPDATES: "Enable Updates",
        ERROR_BOUNDARY_TOOLS_LABEL: "ErrorBoundary Tools",
        EXTRACT: "Extract",
        FONT_NAME: "Font Name",
        FONTS: "Fonts",
        GENERAL: "General",
        GITHUB: "GitHub",
        HOLD_UP: "Hold Up",
        INFO: "Info",
        INSTALL_ADDON: "Install an add-on",
        INSTALL_FONT: "Install a font",
        INSTALL_PLUGIN: "Install a plugin",
        INSTALL_REACT_DEVTOOLS: "Install React DevTools",
        INSTALL_THEME: "Install a theme",
        INSTALL: "Install",
        LABEL_EXTRACT_FONTS_FROM_THEME: "Extract font from theme",
        LINKS: "Links",
        LOAD_FROM_CUSTOM_URL_DEC: "Load YumiCord from a custom endpoint",
        LOAD_FROM_CUSTOM_URL: "Load from custom URL",
        LOAD_REACT_DEVTOOLS: "Load React DevTools",
        LOADER: "Loader",
        MACHINE_ID: "Machine ID",
        MANUFACTURER: "Manufacturer",
        MESSAGE: "Message",
        MISCELLANEOUS: "Miscellaneous",
        MODAL_RELOAD_REQUIRED_DESC: "A reload is required to see the changes. Do you want to reload now?",
        MODAL_RELOAD_REQUIRED: "Reload app?",
        MODAL_THEME_REFETCHED_DESC: "A reload is required to see the changes. Do you want to reload now?",
        MODAL_THEME_REFETCHED: "Theme refetched",
        MODAL_UNPROXIED_PLUGIN_DESC: "The plugin you are trying to install has not been proxied/verified by staff. Are you sure you want to continue?",
        MODAL_UNPROXIED_PLUGIN_HEADER: "Unproxied Plugin",
        MODEL: "Model",
        OPEN_IN_BROWSER: "Open in Browser",
        OPERATING_SYSTEM: "Operating System",
        OVERFLOW_PLUGIN_SETTINGS: "Plugin Settings",
        PLATFORM: "Platform",
        PLUGIN_REFETCH_FAILED: "Failed to refetch plugin",
        PLUGIN_REFETCH_SUCCESSFUL: "Successfully refetched plugin",
        PLUGINS: "Plugins",
        REFETCH: "Refetch",
        RELOAD_DISCORD: "Reload Discord",
        RELOAD_IN_NORMAL_MODE_DESC: "Safe mode currently enabled, tap to reload in normal mode",
        RELOAD_IN_NORMAL_MODE: "Reload in Normal Mode",
        RELOAD_IN_SAFE_MODE_DESC: "Tap to reload Discord without loading addons",
        RELOAD_IN_SAFE_MODE: "Reload in Safe Mode",
        RELOAD: "Reload",
        REMOVE: "Remove",
        RESTART_REQUIRED_TO_TAKE_EFFECT: "Restart is required to take effect",
        RETRY_RENDER: "Retry Render",
        RETRY: "Retry",
        SAFE_MODE_NOTICE_FONTS: "You are in safe mode, meaning fonts have been temporarily disabled. {enabled, select, true {If a font appears to be causing the issue, you can press below to disable it persistently.} other {}}",
        SAFE_MODE_NOTICE_PLUGINS: "You are in safe mode, so plugins cannot be loaded. Disable any misbehaving plugins, then return to Normal Mode from the General settings page.",
        SAFE_MODE_NOTICE_THEMES: "You are in safe mode, meaning themes have been temporarily disabled. {enabled, select, true {If a theme appears to be causing the issue, you can press below to disable it persistently.} other {}}",
        SAFE_MODE: "Safe Mode",
        SEARCH: "Search",
        SEPARATOR: ", ",
        SETTINGS_ACTIVATE_DISCORD_EXPERIMENTS_DESC: "Warning: Messing with this feature may lead to account termination. We are not responsible for what you do with this feature.",
        SETTINGS_ACTIVATE_DISCORD_EXPERIMENTS: "Activate Discord Experiments",
        STACK_TRACE: "Stack Trace",
        SUCCESSFULLY_INSTALLED: "Successfully installed",
        THEME_EXTRACTOR_DESC: "This pack overrides the following: {fonts}",
        THEME_REFETCH_FAILED: "Failed to refetch theme",
        THEME_REFETCH_SUCCESSFUL: "Successfully refetched theme",
        THEMES_RELOAD_FOR_CHANGES: "Reload the app to fully apply changes",
        THEMES: "Themes",
        TOASTS_INSTALLED_PLUGIN: "Installed plugin",
        TOASTS_PLUGIN_UPDATE: "{update, select, true {Enabled} other {Disabled}} updates for {name}",
        UH_OH: "Uh Oh",
        UNINSTALL_TITLE: "Uninstall {title}",
        UNINSTALL: "Uninstall",
        URL_PLACEHOLDER: "https://",
        VERSION: "Version",
        VERSIONS: "Versions"
      };
    }
  });

  // src/core/i18n/index.ts
  function initFetchI18nStrings() {
    return () => {};
    var cb = ({ locale }) => {
      var languageMap = {
        "es-ES": "es",
        "es-419": "es_419",
        "zh-TW": "zh-Hant",
        "zh-CN": "zh-Hans",
        "pt-PT": "pt",
        "pt-BR": "pt_BR",
        "sv-SE": "sv"
      };
      var resolvedLocale = _lastSetLocale = languageMap[locale] ?? locale;
      if (resolvedLocale.startsWith("en-")) {
        _currentLocale = null;
        return;
      }
      if (!_loadedLocale.has(resolvedLocale)) {
        _loadedLocale.add(resolvedLocale);
        fetch(`https://raw.githubusercontent.com/pyoncord/i18n/main/resources/${resolvedLocale}/bunny.json`).then((r) => r.json()).then((strings) => _loadedStrings[resolvedLocale] = strings).then(() => resolvedLocale === _lastSetLocale && (_currentLocale = resolvedLocale)).catch((e) => console.error(`An error occured while fetching strings for ${resolvedLocale}: ${e}`));
      } else {
        _currentLocale = resolvedLocale;
      }
    };
    FluxDispatcher.subscribe("I18N_LOAD_SUCCESS", cb);
    return () => FluxDispatcher.unsubscribe("I18N_LOAD_SUCCESS", cb);
  }
  function formatString(key, val) {
    var str = Strings[key];
    return new IntlMessageFormat(str).format(val);
  }
  var IntlMessageFormat, _currentLocale, _lastSetLocale, _loadedLocale, _loadedStrings, Strings;
  var init_i18n = __esm({
    "src/core/i18n/index.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_common();
      init_wrappers();
      init_default();
      IntlMessageFormat = findByNameLazy("MessageFormat");
      _currentLocale = null;
      _lastSetLocale = null;
      _loadedLocale = /* @__PURE__ */ new Set();
      _loadedStrings = {};
      Strings = new Proxy({}, {
        get: (_t, prop) => {
          if (_currentLocale && _loadedStrings[_currentLocale]?.[prop]) {
            return _loadedStrings[_currentLocale]?.[prop];
          }
          return default_default[prop];
        }
      });
    }
  });

  // src/lib/api/assets/index.ts
  var assets_exports = {};
  __export(assets_exports, {
    filterAssets: () => filterAssets,
    findAsset: () => findAsset,
    findAssetId: () => findAssetId,
    iterateAssets: () => iterateAssets
  });
  function* iterateAssets() {
    var { flagsIndex } = getMetroCache();
    var yielded = /* @__PURE__ */ new Set();
    for (var id in flagsIndex) {
      if (flagsIndex[id] & ModuleFlags.ASSET) {
        var assetId = requireModule(Number(id));
        if (typeof assetId !== "number" || yielded.has(assetId))
          continue;
        yield getAssetById(assetId);
        yielded.add(assetId);
      }
    }
  }
  function getAssetById(id) {
    var asset = assetsModule.getAssetByID(id);
    if (!asset)
      return asset;
    return Object.assign(asset, {
      id
    });
  }
  function findAsset(param) {
    if (typeof param === "number")
      return getAssetById(param);
    if (typeof param === "string" && _nameToAssetCache[param]) {
      return _nameToAssetCache[param];
    }
    for (var asset of iterateAssets()) {
      if (typeof param === "string" && asset.name === param) {
        _nameToAssetCache[param] = asset;
        return asset;
      } else if (typeof param === "function" && param(asset)) {
        return asset;
      }
    }
  }
  function filterAssets(param) {
    var filteredAssets = [];
    for (var asset of iterateAssets()) {
      if (typeof param === "string" ? asset.name === param : param(asset)) {
        filteredAssets.push(asset);
      }
    }
    return filteredAssets;
  }
  function findAssetId(name) {
    return findAsset(name)?.id;
  }
  var _nameToAssetCache;
  var init_assets = __esm({
    "src/lib/api/assets/index.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_caches();
      init_enums();
      init_modules2();
      init_patches();
      _nameToAssetCache = {};
    }
  });

  // src/lib/ui/toasts.ts
  var toasts_exports = {};
  __export(toasts_exports, {
    showToast: () => showToast
  });
  var uuid4, showToast;
  var init_toasts = __esm({
    "src/lib/ui/toasts.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_i18n();
      init_assets();
      init_lazy();
      init_common();
      init_wrappers();
      ({ uuid4 } = lazyDestructure(() => findByProps("uuid4")));
      showToast = (content, asset) => toasts.open({
        // ? In build 182205/44707, Discord changed their toasts, source is no longer used, rather icon, and a key is needed.
        // TODO: We could probably have the developer specify a key themselves, but this works to fix toasts
        key: `vd-toast-${uuid4()}`,
        content,
        source: asset,
        icon: asset
      });
      showToast.showCopyToClipboard = (message = Strings.COPIED_TO_CLIPBOARD) => {
        showToast(message, findAssetId("LinkIcon"));
      };
    }
  });

  // src/lib/api/debug/devtools.ts
  function interceptLogging() {
    var _loop3 = function(key2, level3) {
      unpatches.push(instead(key2, console, (args, orig) => {
        if (dtConnected && dtClient)
          dtClient.log(level3, args);
        return Reflect.apply(orig, console, args);
      }));
    };
    if (intercepted)
      return;
    intercepted = true;
    var unpatches = [];
    for (var [key, level2] of [
      [
        "log",
        LogLevel.Default
      ],
      [
        "warn",
        LogLevel.Warn
      ],
      [
        "error",
        LogLevel.Error
      ],
      [
        "info",
        LogLevel.Default
      ],
      [
        "debug",
        LogLevel.Debug
      ]
    ])
      _loop3(key, level2);
    return () => {
      intercepted = false;
      for (var unpatch of unpatches)
        unpatch();
    };
  }
  function bump() {
    for (var x2 of changeHooks)
      x2(dtConnected);
  }
  function cleanup() {
    dtClient = null;
    dtConnected = false;
    bump();
  }
  function connectDt(url2, quiet) {
    if (dtClient)
      return;
    var info = getDebugInfo();
    var client = dtClient = new DevToolsClient();
    client.connect(`ws://${url2}`, `${info.discord.version} (${info.bunny.loader.name}-${info.bunny.loader.version})`);
    var ws = client.ws;
    ws.addEventListener("open", () => {
      if (!quiet)
        showToast("Connected to DevTools", findAssetId("CheckmarkSmallIcon"));
      if (client.settings.log.interceptConsole) {
        var unintercept = interceptLogging();
        ws.addEventListener("close", function self() {
          unintercept?.();
          ws.removeEventListener("close", self);
        });
      }
      dtConnected = true;
      bump();
    });
    ws.addEventListener("close", () => {
      cleanup();
    });
    ws.addEventListener("error", (e) => {
      cleanup();
      var err = e?.message ?? e?.stack ?? String(e);
      logger.error("DevTools error:", err);
      if (!quiet)
        showToast(err, findAssetId("CircleXIcon-primary"));
    });
  }
  function disconnectDt() {
    dtClient?.disconnect();
  }
  function useIsDtConnected() {
    var [connected, update] = React2.useState(dtConnected);
    React2.useEffect(() => {
      changeHooks.add(update);
      return () => void changeHooks.delete(update);
    });
    return connected;
  }
  var dtClient, dtConnected, changeHooks, intercepted;
  var init_devtools = __esm({
    "src/lib/api/debug/devtools.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_dist3();
      init_patcher();
      init_constants2();
      init_debug();
      init_common();
      init_logger();
      init_toasts();
      init_assets();
      dtClient = null;
      dtConnected = false;
      changeHooks = /* @__PURE__ */ new Set();
      intercepted = false;
    }
  });

  // src/lib/api/debug/react.ts
  function bump2() {
    for (var x2 of changeHooks2)
      x2(rdtConnected);
  }
  function cleanup2() {
    rdtClient = null;
    rdtConnected = false;
    bump2();
  }
  function connectRdt(url2, quiet) {
    if (!isReactDevToolsPreloaded() || rdtClient)
      return;
    var base = url2.split(":").slice(0, -1);
    var ws = rdtClient = new WebSocket(`ws://${base}:${rdtPort}`);
    ws.addEventListener("open", () => {
      if (!quiet)
        showToast("Connected to React DevTools", findAssetId("CheckmarkSmallIcon"));
      rdtConnected = true;
      bump2();
    });
    ws.addEventListener("close", () => {
      cleanup2();
    });
    ws.addEventListener("error", (e) => {
      cleanup2();
      var err = e?.message ?? e?.stack ?? String(e);
      logger.error("React DevTools error:", err);
      if (!quiet)
        showToast(err, findAssetId("CircleXIcon-primary"));
    });
    globalThis[getReactDevToolsProp() || "__vendetta_rdc"].connectToDevTools({
      websocket: ws
    });
  }
  function disconnectRdt() {
    rdtClient?.close();
  }
  function useIsRdtConnected() {
    var [connected, update] = React.useState(rdtConnected);
    React.useEffect(() => {
      changeHooks2.add(update);
      return () => void changeHooks2.delete(update);
    });
    return connected;
  }
  var rdtPort, rdtClient, rdtConnected, changeHooks2;
  var init_react = __esm({
    "src/lib/api/debug/react.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_logger();
      init_loader();
      init_toasts();
      init_assets();
      rdtPort = 8097;
      rdtClient = null;
      rdtConnected = false;
      changeHooks2 = /* @__PURE__ */ new Set();
    }
  });

  // src/lib/api/debug/index.ts
  var debug_exports = {};
  __export(debug_exports, {
    connectToDebugger: () => connectToDebugger,
    connectToReactDevTools: () => connectToReactDevTools,
    getDebugInfo: () => getDebugInfo,
    initDebugger: () => initDebugger,
    toggleSafeMode: () => toggleSafeMode,
    versionHash: () => versionHash
  });
  function toggleSafeMode() {
    return _async_to_generator(function* () {
      settings.safeMode = {
        ...settings.safeMode,
        enabled: !settings.safeMode?.enabled
      };
      if (isThemeSupported()) {
        if (getThemeFromLoader()?.id)
          settings.safeMode.currentThemeId = getThemeFromLoader().id;
        if (settings.safeMode?.enabled) {
          yield selectTheme(null);
        } else if (settings.safeMode?.currentThemeId) {
          yield selectTheme(themes[settings.safeMode?.currentThemeId]);
        }
      }
      setTimeout(BundleUpdaterManager.reload, 400);
    })();
  }
  function connectToDebugger(url2, quiet) {
    if (dtConnected)
      return;
    connectDt(url2, quiet);
  }
  function connectToReactDevTools(url2, quiet) {
    if (!isReactDevToolsPreloaded() || rdtConnected)
      return;
    connectRdt(url2, quiet);
  }
  function getDebugInfo() {
    var hermesProps = globalThis.HermesInternal.getRuntimeProperties();
    var hermesVer = hermesProps["OSS Release Version"];
    var padding = "for RN ";
    var PlatformConstants = import_react_native6.Platform.constants;
    var rnVer = PlatformConstants.reactNativeVersion;
    return {
      /**
       * @deprecated use `bunny` field
       * */
      vendetta: {
        version: versionHash.split("-")[0],
        loader: getLoaderName()
      },
      bunny: {
        version: versionHash,
        loader: {
          name: getLoaderName(),
          version: getLoaderVersion()
        }
      },
      discord: {
        version: NativeClientInfoModule.getConstants().Version,
        build: NativeClientInfoModule.getConstants().Build
      },
      react: {
        version: React.version,
        nativeVersion: hermesVer.startsWith(padding) ? hermesVer.substring(padding.length) : `${rnVer.major}.${rnVer.minor}.${rnVer.patch}`
      },
      hermes: {
        version: hermesVer,
        buildType: hermesProps.Build,
        bytecodeVersion: hermesProps["Bytecode Version"]
      },
      ...import_react_native6.Platform.select({
        android: {
          os: {
            name: "Android",
            version: PlatformConstants.Release,
            sdk: PlatformConstants.Version
          }
        },
        ios: {
          os: {
            name: PlatformConstants.systemName,
            version: PlatformConstants.osVersion
          }
        }
      }),
      ...import_react_native6.Platform.select({
        android: {
          device: {
            manufacturer: PlatformConstants.Manufacturer,
            brand: PlatformConstants.Brand,
            model: PlatformConstants.Model,
            codename: NativeDeviceModule.device
          }
        },
        ios: {
          device: {
            manufacturer: NativeDeviceModule.deviceManufacturer,
            brand: NativeDeviceModule.deviceBrand,
            model: NativeDeviceModule.deviceModel,
            codename: NativeDeviceModule.device
          }
        }
      })
    };
  }
  function initDebugger() {
    if (!settings.enableAutoDebugger || !settings.debuggerUrl)
      return;
    try {
      connectToDebugger(settings.debuggerUrl, true);
      connectToReactDevTools(settings.debuggerUrl, true);
    } catch (e) {
      logger.error("Failed to connect to DevTools during startup:", e);
    }
  }
  var import_react_native6, versionHash;
  var init_debug = __esm({
    "src/lib/api/debug/index.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_async_to_generator();
      init_themes();
      init_loader();
      init_modules();
      init_settings();
      import_react_native6 = __toESM(require_react_native());
      init_devtools();
      init_react();
      init_logger();
      versionHash = "v2.1";
    }
  });

  // src/lib/ui/components/wrappers/AlertModal.tsx
  function AlertModal2(props) {
    var forwardFailedModal = findByFilePath("modules/forwarding/native/ForwardFailedAlertModal.tsx");
    if (!forwardFailedModal && "extraContent" in props) {
      props.content = /* @__PURE__ */ jsxs(import_react_native7.View, {
        style: {
          gap: 16
        },
        children: [
          /* @__PURE__ */ jsx(Text, {
            variant: "text-md/medium",
            color: "text-muted",
            children: props.content
          }),
          /* @__PURE__ */ jsx(import_react_native7.View, {
            children: props.extraContent
          })
        ]
      });
      delete props.extraContent;
    }
    return /* @__PURE__ */ jsx(_AlertModal, {
      ...props
    });
  }
  var import_react_native7, _AlertModal, _AlertActionButton, AlertActionButton2;
  var init_AlertModal = __esm({
    "src/lib/ui/components/wrappers/AlertModal.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_jsxRuntime();
      init_lazy();
      init_metro();
      init_components();
      import_react_native7 = __toESM(require_react_native());
      ({ AlertModal: _AlertModal, AlertActionButton: _AlertActionButton } = lazyDestructure(() => findByProps("AlertModal", "AlertActions")));
      AlertActionButton2 = _AlertActionButton;
    }
  });

  // src/lib/ui/components/wrappers/index.ts
  var wrappers_exports = {};
  __export(wrappers_exports, {
    AlertActionButton: () => AlertActionButton2,
    AlertModal: () => AlertModal2
  });
  var init_wrappers2 = __esm({
    "src/lib/ui/components/wrappers/index.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_AlertModal();
    }
  });

  // src/lib/ui/color.ts
  function isSemanticColor(sym) {
    return colorResolver.isSemanticColor(sym);
  }
  function resolveSemanticColor(sym, theme = ThemeStore2.theme) {
    return colorResolver.resolveSemanticColor(theme, sym);
  }
  var color, semanticColors, rawColors, ThemeStore2, colorResolver;
  var init_color = __esm({
    "src/lib/ui/color.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_common();
      init_wrappers();
      color = findByProps("SemanticColor");
      semanticColors = color?.default?.colors ?? constants?.ThemeColorMap;
      rawColors = color?.default?.unsafe_rawColors ?? constants?.Colors;
      ThemeStore2 = findByStoreNameLazy("ThemeStore");
      colorResolver = color.default.meta ??= color.default.internal;
    }
  });

  // src/lib/ui/styles.ts
  var styles_exports = {};
  __export(styles_exports, {
    TextStyleSheet: () => TextStyleSheet,
    ThemeContext: () => ThemeContext,
    createLegacyClassComponentStyles: () => createLegacyClassComponentStyles,
    createStyles: () => createStyles,
    createThemedStyleSheet: () => createThemedStyleSheet
  });
  function createStyles(sheet) {
    return proxyLazy(() => Styles.createStyles(sheet));
  }
  function createLegacyClassComponentStyles(sheet) {
    return proxyLazy(() => Styles.createLegacyClassComponentStyles(sheet));
  }
  function createThemedStyleSheet(sheet) {
    for (var key in sheet) {
      sheet[key] = new Proxy(import_react_native8.StyleSheet.flatten(sheet[key]), {
        get(target, prop, receiver) {
          var res = Reflect.get(target, prop, receiver);
          return isSemanticColor(res) ? resolveSemanticColor(res) : res;
        }
      });
    }
    return sheet;
  }
  var import_react_native8, Styles, ThemeContext, TextStyleSheet;
  var init_styles = __esm({
    "src/lib/ui/styles.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_lazy();
      init_wrappers();
      init_color();
      import_react_native8 = __toESM(require_react_native());
      Styles = findByPropsLazy("createStyles");
      ({ ThemeContext } = lazyDestructure(() => findByProps("ThemeContext"), {
        hint: "object"
      }));
      ({ TextStyleSheet } = lazyDestructure(() => findByProps("TextStyleSheet")));
    }
  });

  // src/lib/ui/components/Codeblock.tsx
  function Codeblock({ selectable, style, children }) {
    if (!selectable)
      return /* @__PURE__ */ jsx(TextBasedCodeblock, {
        style,
        children
      });
    return import_react_native9.Platform.select({
      ios: /* @__PURE__ */ jsx(InputBasedCodeblock, {
        style,
        children
      }),
      default: /* @__PURE__ */ jsx(TextBasedCodeblock, {
        style,
        children,
        selectable: true
      })
    });
  }
  var import_react_native9, useStyles, InputBasedCodeblock, TextBasedCodeblock;
  var init_Codeblock = __esm({
    "src/lib/ui/components/Codeblock.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_jsxRuntime();
      init_common();
      init_color();
      init_styles();
      import_react_native9 = __toESM(require_react_native());
      useStyles = createStyles({
        codeBlock: {
          fontFamily: constants.Fonts.CODE_NORMAL,
          fontSize: 12,
          textAlignVertical: "center",
          backgroundColor: semanticColors.CARD_BACKGROUND_DEFAULT,
          color: semanticColors.TEXT_DEFAULT,
          borderWidth: 1,
          borderRadius: 12,
          borderColor: semanticColors.BORDER_SUBTLE,
          padding: 10
        }
      });
      InputBasedCodeblock = ({ style, children }) => /* @__PURE__ */ jsx(import_react_native9.TextInput, {
        editable: false,
        multiline: true,
        style: [
          useStyles().codeBlock,
          style && style
        ],
        value: children
      });
      TextBasedCodeblock = ({ selectable, style, children }) => /* @__PURE__ */ jsx(import_react_native9.Text, {
        selectable,
        style: [
          useStyles().codeBlock,
          style && style
        ],
        children
      });
    }
  });

  // src/lib/ui/sheets.ts
  var sheets_exports = {};
  __export(sheets_exports, {
    hideSheet: () => hideSheet,
    showSheet: () => showSheet
  });
  function showSheet(key, lazyImport, props) {
    if (!("then" in lazyImport))
      lazyImport = Promise.resolve({
        default: lazyImport
      });
    actionSheet.openLazy(lazyImport, key, props ?? {});
  }
  function hideSheet(key) {
    actionSheet.hideActionSheet(key);
  }
  var actionSheet;
  var init_sheets = __esm({
    "src/lib/ui/sheets.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_wrappers();
      actionSheet = findByPropsLazy("openLazy", "hideActionSheet");
    }
  });

  // src/core/ui/reporter/utils/parseComponentStack.tsx
  function parseComponentStack(componentStack) {
    return componentStack.split(/[\s|\n]+?in /).filter(Boolean);
  }
  var init_parseComponentStack = __esm({
    "src/core/ui/reporter/utils/parseComponentStack.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
    }
  });

  // globals:react
  var require_react = __commonJS({
    "globals:react"(exports, module) {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      module.exports = require_depsModule()["react"];
    }
  });

  // src/core/ui/reporter/components/ErrorComponentStackCard.tsx
  function ErrorComponentStackCard(props) {
    var [collapsed, setCollapsed] = (0, import_react2.useState)(true);
    var stack;
    try {
      stack = parseComponentStack(props.componentStack);
      stack = collapsed ? stack.slice(0, 4) : stack;
    } catch (unused) {
      return;
    }
    return /* @__PURE__ */ jsx(Card, {
      children: /* @__PURE__ */ jsxs(import_react_native10.View, {
        style: {
          gap: 8
        },
        children: [
          /* @__PURE__ */ jsx(Text, {
            variant: "heading-lg/bold",
            children: "Component Stack"
          }),
          /* @__PURE__ */ jsx(import_react_native10.View, {
            style: {
              gap: 4
            },
            children: stack.map((component) => /* @__PURE__ */ jsxs(import_react_native10.View, {
              style: {
                flexDirection: "row"
              },
              children: [
                /* @__PURE__ */ jsx(Text, {
                  variant: "text-md/bold",
                  color: "text-muted",
                  children: "<"
                }),
                /* @__PURE__ */ jsx(Text, {
                  variant: "text-md/bold",
                  children: component
                }),
                /* @__PURE__ */ jsx(Text, {
                  variant: "text-md/bold",
                  color: "text-muted",
                  children: "/>"
                })
              ]
            }))
          }),
          collapsed && /* @__PURE__ */ jsx(Text, {
            children: "..."
          }),
          /* @__PURE__ */ jsxs(import_react_native10.View, {
            style: {
              gap: 8,
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center"
            },
            children: [
              /* @__PURE__ */ jsx(Button, {
                variant: "secondary",
                text: `Show ${collapsed ? "more" : "less"}`,
                icon: findAssetId(collapsed ? "ChevronSmallUpIcon" : "ChevronSmallDownIcon"),
                onPress: () => setCollapsed((v2) => !v2)
              }),
              /* @__PURE__ */ jsx(Button, {
                variant: "secondary",
                text: "Copy",
                icon: findAssetId("CopyIcon"),
                onPress: () => clipboard.setString(props.componentStack)
              })
            ]
          })
        ]
      })
    });
  }
  var import_react2, import_react_native10;
  var init_ErrorComponentStackCard = __esm({
    "src/core/ui/reporter/components/ErrorComponentStackCard.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_jsxRuntime();
      init_parseComponentStack();
      init_assets();
      init_common();
      init_components();
      import_react2 = __toESM(require_react());
      import_react_native10 = __toESM(require_react_native());
    }
  });

  // src/core/ui/reporter/utils/parseErrorStack.ts
  function isInternalBytecodeSourceUrl(sourceUrl) {
    return sourceUrl === "InternalBytecode.js";
  }
  function parseLine(line) {
    var asFrame = line.match(RE_FRAME);
    if (asFrame) {
      return {
        type: "FRAME",
        functionName: asFrame[1],
        location: asFrame[2] === "native" ? {
          type: "NATIVE"
        } : asFrame[3] === "address at " ? isInternalBytecodeSourceUrl(asFrame[4]) ? {
          type: "INTERNAL_BYTECODE",
          sourceUrl: asFrame[4],
          line1Based: Number.parseInt(asFrame[5], 10),
          virtualOffset0Based: Number.parseInt(asFrame[6], 10)
        } : {
          type: "BYTECODE",
          sourceUrl: asFrame[4],
          line1Based: Number.parseInt(asFrame[5], 10),
          virtualOffset0Based: Number.parseInt(asFrame[6], 10)
        } : {
          type: "SOURCE",
          sourceUrl: asFrame[4],
          line1Based: Number.parseInt(asFrame[5], 10),
          column1Based: Number.parseInt(asFrame[6], 10)
        }
      };
    }
    var asSkipped = line.match(RE_SKIPPED);
    if (asSkipped) {
      return {
        type: "SKIPPED",
        count: Number.parseInt(asSkipped[1], 10)
      };
    }
  }
  function parseHermesStack(stack) {
    var lines = stack.split(/\n/);
    var entries = [];
    var lastMessageLine = -1;
    for (var i = 0; i < lines.length; ++i) {
      var line = lines[i];
      if (!line) {
        continue;
      }
      var entry = parseLine(line);
      if (entry) {
        entries.push(entry);
        continue;
      }
      if (RE_COMPONENT_NO_STACK.test(line)) {
        continue;
      }
      lastMessageLine = i;
      entries = [];
    }
    var message = lines.slice(0, lastMessageLine + 1).join("\n");
    return {
      message,
      entries
    };
  }
  function convertHermesStack(stack) {
    var frames = [];
    for (var entry of stack.entries) {
      if (entry.type !== "FRAME") {
        continue;
      }
      var { location, functionName: functionName2 } = entry;
      if (location.type === "NATIVE" || location.type === "INTERNAL_BYTECODE") {
        continue;
      }
      frames.push({
        methodName: functionName2,
        file: location.sourceUrl,
        lineNumber: location.line1Based,
        column: location.type === "SOURCE" ? location.column1Based - 1 : location.virtualOffset0Based
      });
    }
    return frames;
  }
  function parseErrorStack(errorStack) {
    if (errorStack == null) {
      return [];
    }
    var parsedStack = Array.isArray(errorStack) ? errorStack : convertHermesStack(parseHermesStack(errorStack));
    return parsedStack;
  }
  var RE_FRAME, RE_SKIPPED, RE_COMPONENT_NO_STACK;
  var init_parseErrorStack = __esm({
    "src/core/ui/reporter/utils/parseErrorStack.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      RE_FRAME = /^ {4}at (.+?)(?: \((native)\)?| \((address at )?(.*?):(\d+):(\d+)\))$/;
      RE_SKIPPED = /^ {4}... skipping (\d+) frames$/;
      RE_COMPONENT_NO_STACK = /^ {4}at .*$/;
    }
  });

  // src/core/ui/reporter/components/ErrorStackCard.tsx
  function ErrorStackCard(props) {
    var [collapsed, setCollapsed] = (0, import_react3.useState)(true);
    var stack;
    try {
      var parsedErrorStack = parseErrorStack(props.error.stack);
      stack = collapsed ? parsedErrorStack.slice(0, 4) : parsedErrorStack;
    } catch (unused) {
      return null;
    }
    return /* @__PURE__ */ jsx(Card, {
      children: /* @__PURE__ */ jsxs(import_react_native11.View, {
        style: {
          gap: 12
        },
        children: [
          /* @__PURE__ */ jsx(Text, {
            variant: "heading-lg/bold",
            children: "Call Stack"
          }),
          /* @__PURE__ */ jsx(import_react_native11.View, {
            style: {
              gap: 4
            },
            children: stack.map((f, id) => /* @__PURE__ */ jsx(Line, {
              id,
              frame: f
            }))
          }),
          collapsed && /* @__PURE__ */ jsx(Text, {
            children: "..."
          }),
          /* @__PURE__ */ jsxs(import_react_native11.View, {
            style: {
              gap: 8,
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center"
            },
            children: [
              /* @__PURE__ */ jsx(Button, {
                variant: "secondary",
                text: `Show ${collapsed ? "more" : "less"}`,
                icon: findAssetId(collapsed ? "ChevronSmallUpIcon" : "ChevronSmallDownIcon"),
                onPress: () => setCollapsed((v2) => !v2)
              }),
              /* @__PURE__ */ jsx(Button, {
                variant: "secondary",
                text: "Copy",
                icon: findAssetId("CopyIcon"),
                onPress: () => clipboard.setString(props.error.stack)
              })
            ]
          })
        ]
      })
    });
  }
  function Line(props) {
    var [collapsed, setCollapsed] = (0, import_react3.useState)(true);
    return /* @__PURE__ */ jsxs(import_react_native11.Pressable, {
      onPress: () => setCollapsed((v2) => !v2),
      children: [
        /* @__PURE__ */ jsx(Text, {
          style: {
            fontFamily: constants.Fonts.CODE_BOLD
          },
          children: props.frame.methodName
        }),
        /* @__PURE__ */ jsx(Text, {
          style: {
            fontFamily: constants.Fonts.CODE_NORMAL
          },
          ellipsizeMode: "middle",
          numberOfLines: collapsed ? 1 : void 0,
          children: /* @__PURE__ */ jsxs(Text, {
            color: "text-muted",
            children: [
              props.frame.file === INDEX_BUNDLE_FILE ? "jsbundle" : props.frame.file,
              ":",
              props.frame.lineNumber,
              ":",
              props.frame.column
            ]
          })
        })
      ]
    }, props.id);
  }
  var import_react3, import_react_native11;
  var init_ErrorStackCard = __esm({
    "src/core/ui/reporter/components/ErrorStackCard.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_jsxRuntime();
      init_parseErrorStack();
      init_assets();
      init_common();
      init_components();
      import_react3 = __toESM(require_react());
      import_react_native11 = __toESM(require_react_native());
      init_ErrorCard();
    }
  });

  // src/core/ui/reporter/components/ErrorDetailsActionSheet.tsx
  function ErrorDetailsActionSheet(props) {
    return /* @__PURE__ */ jsx(ActionSheet, {
      children: /* @__PURE__ */ jsxs(import_react_native12.View, {
        style: {
          gap: 12,
          paddingVertical: 12
        },
        children: [
          /* @__PURE__ */ jsx(Text, {
            variant: "heading-lg/extrabold",
            children: "Error"
          }),
          /* @__PURE__ */ jsx(Codeblock, {
            selectable: true,
            children: props.error.message
          }),
          hasStack(props.error) && /* @__PURE__ */ jsx(ErrorStackCard, {
            error: props.error
          }),
          isComponentStack(props.error) ? /* @__PURE__ */ jsx(ErrorComponentStackCard, {
            componentStack: props.error.componentStack
          }) : null
        ]
      })
    });
  }
  var import_react_native12;
  var init_ErrorDetailsActionSheet = __esm({
    "src/core/ui/reporter/components/ErrorDetailsActionSheet.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_jsxRuntime();
      init_isStack();
      init_components2();
      init_components();
      import_react_native12 = __toESM(require_react_native());
      init_ErrorComponentStackCard();
      init_ErrorStackCard();
    }
  });

  // src/core/ui/reporter/components/ErrorCard.tsx
  function ErrorCard(props) {
    return /* @__PURE__ */ jsx(Card, {
      children: /* @__PURE__ */ jsxs(Stack, {
        children: [
          props.header && typeof props.header !== "string" ? props.header : /* @__PURE__ */ jsx(Text, {
            variant: "heading-lg/bold",
            children: props.header ?? Strings.UH_OH
          }),
          /* @__PURE__ */ jsx(Codeblock, {
            selectable: true,
            children: String(props.error)
          }),
          /* @__PURE__ */ jsxs(TwinButtons, {
            children: [
              props.onRetryRender && /* @__PURE__ */ jsx(Button, {
                variant: "destructive",
                // icon={findAssetId("RetryIcon")}
                text: Strings.RETRY_RENDER,
                onPress: props.onRetryRender
              }),
              props.error instanceof Error ? /* @__PURE__ */ jsx(Button, {
                text: "Details",
                // icon={findAssetId("CircleInformationIcon-primary")}
                onPress: () => showSheet("BunnyErrorDetailsActionSheet", ErrorDetailsActionSheet, {
                  error: props.error
                })
              }) : null
            ]
          })
        ]
      })
    });
  }
  var INDEX_BUNDLE_FILE;
  var init_ErrorCard = __esm({
    "src/core/ui/reporter/components/ErrorCard.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_jsxRuntime();
      init_i18n();
      init_components2();
      init_sheets();
      init_components();
      init_ErrorDetailsActionSheet();
      INDEX_BUNDLE_FILE = globalThis.HermesInternal.getFunctionLocation(globalThis.__r).fileName;
    }
  });

  // src/lib/ui/components/ErrorBoundary.tsx
  var _React_Component, ErrorBoundary;
  var init_ErrorBoundary = __esm({
    "src/lib/ui/components/ErrorBoundary.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_call_super();
      init_class_call_check();
      init_create_class();
      init_define_property();
      init_inherits();
      init_jsxRuntime();
      init_ErrorCard();
      init_common();
      init_styles();
      ErrorBoundary = /* @__PURE__ */ function(_superClass) {
        "use strict";
        _inherits(ErrorBoundary2, _superClass);
        function ErrorBoundary2(props) {
          _class_call_check(this, ErrorBoundary2);
          var _this;
          _this = _call_super(this, ErrorBoundary2, [
            props
          ]);
          _this.state = {
            hasErr: false
          };
          return _this;
        }
        _create_class(ErrorBoundary2, [
          {
            key: "render",
            value: function render() {
              if (!this.state.hasErr)
                return this.props.children;
              return /* @__PURE__ */ jsx(ErrorCard, {
                error: this.state.error,
                onRetryRender: () => this.setState({
                  hasErr: false
                })
              });
            }
          }
        ]);
        return ErrorBoundary2;
      }(_React_Component = React2.Component);
      _define_property(ErrorBoundary, "contextType", ThemeContext);
      _define_property(ErrorBoundary, "getDerivedStateFromError", (error) => ({
        hasErr: true,
        error
      }));
    }
  });

  // src/lib/ui/components/Search.tsx
  function SearchIcon() {
    return /* @__PURE__ */ jsx(import_react_native13.Image, {
      style: {
        width: 16,
        height: 16
      },
      source: findAssetId("MagnifyingGlassIcon")
    });
  }
  var import_react_native13, Search_default;
  var init_Search = __esm({
    "src/lib/ui/components/Search.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_jsxRuntime();
      init_i18n();
      init_assets();
      init_components();
      init_ErrorBoundary();
      import_react_native13 = __toESM(require_react_native());
      Search_default = ({ onChangeText, placeholder, style, isRound }) => {
        var [query, setQuery] = React.useState("");
        var onChange = (value) => {
          setQuery(value);
          onChangeText?.(value);
        };
        return /* @__PURE__ */ jsx(ErrorBoundary, {
          children: /* @__PURE__ */ jsx(import_react_native13.View, {
            style,
            children: /* @__PURE__ */ jsx(TextInput, {
              grow: true,
              isClearable: true,
              leadingIcon: SearchIcon,
              placeholder: placeholder ?? Strings.SEARCH,
              onChange,
              returnKeyType: "search",
              size: "md",
              autoCapitalize: "none",
              autoCorrect: false,
              isRound,
              value: query
            })
          })
        });
      };
    }
  });

  // src/lib/ui/components/Summary.tsx
  function Summary({ label, icon, noPadding = false, noAnimation = false, children }) {
    var [hidden, setHidden] = React.useState(true);
    return /* @__PURE__ */ jsxs(Fragment, {
      children: [
        /* @__PURE__ */ jsx(TableRow, {
          label,
          icon: icon && /* @__PURE__ */ jsx(TableRow.Icon, {
            source: findAssetId(icon)
          }),
          trailing: /* @__PURE__ */ jsx(LegacyFormRow.Arrow, {
            style: {
              transform: [
                {
                  rotate: `${hidden ? 180 : 90}deg`
                }
              ]
            }
          }),
          onPress: () => {
            setHidden(!hidden);
            if (!noAnimation)
              import_react_native14.LayoutAnimation.configureNext(import_react_native14.LayoutAnimation.Presets.easeInEaseOut);
          }
        }),
        !hidden && /* @__PURE__ */ jsx(Fragment, {
          children: /* @__PURE__ */ jsx(import_react_native14.View, {
            style: !noPadding && {
              paddingHorizontal: 15
            },
            children
          })
        })
      ]
    });
  }
  var import_react_native14;
  var init_Summary = __esm({
    "src/lib/ui/components/Summary.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_jsxRuntime();
      init_assets();
      init_components();
      import_react_native14 = __toESM(require_react_native());
    }
  });

  // src/lib/ui/components/index.ts
  var components_exports2 = {};
  __export(components_exports2, {
    Codeblock: () => Codeblock,
    ErrorBoundary: () => ErrorBoundary,
    Search: () => Search_default,
    Summary: () => Summary,
    wrappers: () => wrappers_exports
  });
  var init_components2 = __esm({
    "src/lib/ui/components/index.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_wrappers2();
      init_Codeblock();
      init_ErrorBoundary();
      init_Search();
      init_Summary();
    }
  });

  // src/core/ui/reporter/components/ErrorBoundaryScreen.tsx
  function ErrorBoundaryScreen(props) {
    var styles3 = useStyles2();
    var debugInfo = getDebugInfo();
    return /* @__PURE__ */ jsx(ErrorBoundary, {
      children: /* @__PURE__ */ jsx(SafeAreaProvider, {
        children: /* @__PURE__ */ jsxs(SafeAreaView, {
          style: styles3.container,
          children: [
            /* @__PURE__ */ jsxs(import_react_native15.View, {
              style: {
                gap: 4
              },
              children: [
                /* @__PURE__ */ jsx(Text, {
                  variant: "display-lg",
                  children: "Uh oh."
                }),
                /* @__PURE__ */ jsx(Text, {
                  variant: "text-md/normal",
                  children: "A crash occurred while rendering a component. This could be caused by a plugin, YumiCord, or Discord itself."
                }),
                /* @__PURE__ */ jsxs(Text, {
                  variant: "text-sm/normal",
                  color: "text-muted",
                  children: [
                    debugInfo.os.name,
                    "; ",
                    debugInfo.discord.build,
                    " (",
                    debugInfo.discord.version,
                    "); ",
                    debugInfo.bunny.version
                  ]
                })
              ]
            }),
            /* @__PURE__ */ jsxs(import_react_native15.ScrollView, {
              fadingEdgeLength: 64,
              contentContainerStyle: {
                gap: 12
              },
              children: [
                /* @__PURE__ */ jsx(Codeblock, {
                  selectable: true,
                  children: props.error.message
                }),
                hasStack(props.error) && /* @__PURE__ */ jsx(ErrorStackCard, {
                  error: props.error
                }),
                isComponentStack(props.error) ? /* @__PURE__ */ jsx(ErrorComponentStackCard, {
                  componentStack: props.error.componentStack
                }) : null
              ]
            }),
            /* @__PURE__ */ jsxs(Card, {
              style: {
                gap: 6
              },
              children: [
                /* @__PURE__ */ jsx(Button, {
                  text: "Reload Discord",
                  onPress: () => BundleUpdaterManager.reload()
                }),
                !settings.safeMode?.enabled && /* @__PURE__ */ jsx(Button, {
                  text: "Reload in Safe Mode",
                  onPress: () => toggleSafeMode()
                }),
                /* @__PURE__ */ jsx(Button, {
                  variant: "destructive",
                  text: "Retry Render",
                  onPress: () => props.rerender()
                })
              ]
            })
          ]
        })
      })
    });
  }
  var import_react_native15, useStyles2;
  var init_ErrorBoundaryScreen = __esm({
    "src/core/ui/reporter/components/ErrorBoundaryScreen.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_jsxRuntime();
      init_isStack();
      init_debug();
      init_modules();
      init_settings();
      init_components2();
      init_styles();
      init_common();
      init_components();
      import_react_native15 = __toESM(require_react_native());
      init_ErrorComponentStackCard();
      init_ErrorStackCard();
      useStyles2 = createStyles({
        container: {
          flex: 1,
          backgroundColor: tokens.colors.BG_BASE_SECONDARY,
          paddingHorizontal: 16,
          height: "100%",
          gap: 12
        }
      });
    }
  });

  // src/core/debug/patches/patchErrorBoundary.tsx
  function getErrorBoundaryContext() {
    var ctxt = findByNameLazy("ErrorBoundary")[_lazyContextSymbol];
    return new Promise((resolve) => ctxt.getExports((exp) => resolve(exp.prototype)));
  }
  function patchErrorBoundary() {
    return after.await("render", getErrorBoundaryContext(), function() {
      if (!this.state.error)
        return;
      return /* @__PURE__ */ jsx(ErrorBoundaryScreen, {
        error: this.state.error,
        rerender: () => this.setState({
          info: null,
          error: null
        })
      });
    });
  }
  var init_patchErrorBoundary = __esm({
    "src/core/debug/patches/patchErrorBoundary.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_jsxRuntime();
      init_ErrorBoundaryScreen();
      init_patcher();
      init_lazy2();
      init_wrappers();
    }
  });

  // globals:moment
  var require_moment = __commonJS({
    "globals:moment"(exports, module) {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      module.exports = require_depsModule()["moment"];
    }
  });

  // src/core/fixes.ts
  function onDispatch({ locale }) {
    try {
      import_moment.default.locale(locale.toLowerCase());
    } catch (e) {
      logger.error("Failed to fix timestamps...", e);
    }
    FluxDispatcher.unsubscribe("I18N_LOAD_SUCCESS", onDispatch);
  }
  var import_moment, fixes_default;
  var init_fixes = __esm({
    "src/core/fixes.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_logger();
      init_common();
      import_moment = __toESM(require_moment());
      fixes_default = () => {
        FluxDispatcher.subscribe("I18N_LOAD_SUCCESS", onDispatch);
      };
    }
  });

  // src/assets/icons/revenge.png
  var revenge_default;
  var init_revenge = __esm({
    "src/assets/icons/revenge.png"() {
      revenge_default = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAABWI0lEQVR42q29ebwmRXU+/pyq7ne/6yzMwrAN+wAqiKhAXKK4gALKEMRExUTjhjFfjcZgnKgYEzVxjQuEaDSIzgQFJQIqiwgiAoKsAwwMA8x679z1ve/WXXV+f1QvVdV9B/P9fcfPFbjzLt1dVWd5znOeQ/i/+LN+40a5af16BpEGAGYWb56dfN6jvc6p84xT+1odobQ+aEDUjJQCAwDY/JMIDICIAAaInv372HwAyPsdg0EgJB/lvcm8nkDJG8lcAzsvsf5Qci3FFzARnu0yKXuL+znmCovX59wLOHuBSK+XAWaGJIEquFeB2B6K4PGWlLcfIsQvNi5ffqcg6rN5GLQeEJuI1P92Lel/9WpmwqZNAueeq0IAb5/bcfSvu9GfzGl9Rk+p4+J6LYgZQKyAOIZQynowyT1S9riRL4u3EN5KMpuHYq8PL3pDlD1QIu93yS1kG4bzBbCvJ/2rfHOSs5zsXQF5C73PTW1tJmb7Czm7VvuZsGZoQWAZAGEIQYSg0+GqEA+PBsFPjwkqP/jhsmV3DcxniA0APpEczP+3G4BZgkhJAOfufeZF92j9wek4PnPQbAXc7wO9HkhpnT5zEoLyp2wWgAFQ+oSYs5vVADhdYJB5TdmlMmcPh70bIPiLlW4YTqxOfspSq1BmDYS/KZPVZMuqILlef8eQ95n+U842GZUfCniWjtnaesycGj4GJKo1UL2GysICxkTw82OE+NxVK1b8PLLW6v/VBiAwCxCpr0xsW3WJxqcmtLqgV68Tz89DaMQETp8bpU+m3GhyfkTYWib2To7zIKjwdvfU5hsp3UyOSeeimc1OMbkWhchsUNelUH5UqeTkJl+SblrNbC04nPc5Zt8yE7zPhbBMmbNjWTOR1swBt1qoRDGWEm18fRD8/T8tX/4oNm6UWL9eg4j/rzcAs7lMScQv37lt/cPgL3bqtVWYnWUCNBMJcH7kiM2yZL7Mv0HrTpm54G6pcJbz45afCrYNS74OnPvg9KGR/ZAzE5t+LRUCDUpjk8IjyncJk+1i0utiJy5JY470s8iyTdbjyl6XnXTyXIltabJN77+XAWalmYmHh0WrH80eCvrIrWtWfTPOfd6im0As9hcbmAURMQN47vbHP/f7QGxsK70K0zMxMQggCTYfTZwGLWSOoDa+K7NxGoBm86MYrMyJIcsOkvPa9DMAVuazWJv3sQZIJa9R5u+hkieVfo/3OdDJ92n/9+7fc/Y+Mj+cBKrJtWSv1cg+jzg5/Tq9F/Nesp4FlPVd2fuSf2pAJO9jTYBOAlVms7g6/yHrM5z7AkkBIcTsXDw/GIw8GIbfOHrbM5cwcwgi3sC86DoHpYu/YYP4BJFm3tlct+PJb020WuvjqWklTIgbZIvmRdxgOKY9i9LZCpuYswzA8QrpJqBkn7Mb7WUfzYsYMCvSd7IL5oJfzU0GZTbDdVoMO0hIX5FaLSLLpjNZWYrr1qzLyXxMsmDZ2SAvnmHf1KcnldxgNA2a2HEgIghixXpuXj0zMvaOo57aefBNu3ef/TKi9gZmURYc0mJmn/fsaR4bdX+8s1l/GU9PRwQK2XJJ2U0k5ouYPNNOfq7jubTEfKU3418Mlwdp9saz3+UsirWg9hI6z5VS0+u+x2xQKwhz7pXzKD5zQZSluGxFi2WpI6VxBhE0XL/OlGQYzNn+se/CDj7J2mps+0L7zDBHPDIWjna6N13WXPn6l+1HC8kN8eIWwCy+YECv67a/u2uo9TJMTkcgCv24JLv5JJp3dnrmEKkkj09/n5hdkLvCSSCmrRPoJIyc32ua0uV+1A7g2PH1zJ6lYDcjsSMIY/o5CQrJSfTs0IW4JE6wNk6+1yg9KVkM4FjF5Ds5dfpZTGBFD4l1dIJU64uKXp5CMT0Vz4yMvey97R1XMfNradMmBWYnMCQ/1ZNE6jlbtvzrtpHWX/P0TARCmO1DRmmYRpklKCa42QNjtk6ua2xhmVDXsiwSDaHMFRRjnfLo2g7byMs82Lo2L9Gk1NSzk2WQB0yVxPB5sEhFhIszIIuzpIIXwUgIrsXifeAhFo4QYWxJuKY9e8n9hx/wl+qmmwK87GVxYQOsZ5abiNQrn9i2/v56uHEwNx8TOMjOBVm7jEtStBITjSQmy2MEzlFA+Baj6AJsc5tnEsXI3lychcCxv3xkpZnk+M1FljsPA+wNyyWhB7tgBHMpulUCDnGevJJ/wVSwYex/DhWwROfC0kOXHMBYtoaD46L+W35x2KrvYiNLnGtwApFEfWIToD+7e/eKh1T0lf5CV5PSgnVyEtMIuhDtwopQOXsN6/wnjfZNVpC4ijR61250nEfg7n+b6JxMlmFF88SUB2HZ9yav0wRKonHzk0TyzrVb0b33ezuTcF/jXrfm9Fq897EVDKbXxtZnMFkZEOXn23uNefb5PUBb2YrzOsozqWy9kt9riLjT1Y8pfOlTeztrsB46zQzMBli3jiQRf3e2/dlevbmf6PaZmQSYrAu10iIm7+RS/jvrhtOHwdqKlllkEb+5MWshUyyJRfI6ytJLtjeW85Csh19YgPw1wnqA5P3APCSQ5mxjpZtMJGmanbaR/93Jhss/m600MV8cSjd48nrm9H7Jer6UPY/sswFnDbJn7R2EfCMktiU5fAIkgijSnWp97MpdU5+RRPyJTZuMrVm/keWmc0mdt23H828e9H/bHwy0YBacOcg8zqUyfI9tQCEPkpjZxefZixUsE+ukgymAYqWUjh+0Akgiy5yz6xvJsczkpGRl2YwTuSWmM0ssUv9vJRqa3PqDZ3zTOLck0UP6WL0ilOXWqJjlFJ6E71PKMi5YoJkx1LpaqeKF1eCkKw9ddtf6jSwJzCIg0msfePSqPc3mmTQ/p4iE9P0RFYIrKgZjNhrHcKJ28jYILHSQnUXL38v7QATJ87XkeVffeZL1fzrZXCJBC1lzFnVnh7sUGUxjiRTRYwgLcnah6EWSfMpjERspZicltDYWEcrCyzI4JAsgOUcNndSXtVKtEbms37nqsWP2P1sxG3jhXVt2HnP1oPP7bhyRMDdNea6ZRNfs3YUXwDk701jSzFT6aZyTGtqWgJNv5WJw5heJCG4+bP8dE3n1O7cGkFonYSf82XWY32lwBpNSUuLILUcedAkvjYRVZyB7M9m4gAURk5UalsX0mTG08QdwAQ8g62GyVfb2niMzEWqVijpjtHHc11cNPxwQgDv6/fOj5pCQszMxCAF5py3LQ9k10faX6/SB6GT3sZebsnu6nZPpAN7pbZFTYxeFKox7Zzp7h0sOIC/3z9wIuW4ndTlEZamqtfmIQSwyO0PsZxYJ8mnliOlrqBSQElkdILMwlvnm1OVll2wjl0kKmW5oe52oFKMgAY6jWiu4c3ruLQR8VGjmyoyKz9K9Hogh0ijdCbI0OYGGCWSEeRBMWZRs4+nkRdJ5cIAEK7cCqCwISwMukQRi+d+xnSGk2YEm5zNsiJqsgKiQWST3ZK4zvR87C6D89zoPuIgBoc31iOw19j1SZinT688ieG0C4Ow77GAue21y/9oKLNkNSim7vvx+BBME2/ULOyg0G0Mk/4OG0J0uZiL1Os0c0HlP7Dzp5nb31oFWgbChRLJ8ciHJddHzHNK169h+FY4cHCEvC1vnjKkQY7BTZeQMvcvNsYXFEznBn3vd7KD1NoCVmlqyAR9mcKGe78LQBtK18XjOgjrX0CUBtEjjhRQ6Jo+AQhlzgstiBPsd5KDoBYAIXtBqww0agJQiPrVRPSXY1umfpsJ6IDptBSIJBgQlUXAKAGXmU3gYdZpi5VwZ21xmGILnx+3I1GbC+FE1c55d2MUU4yYSs6vzaL5YJ7B9PyWBnb0J2PGrECLbhC5liAoAThb4UX4tBppOi1825Jv8XiMrltul3XzBjG93ADCyOU2U8Q+cyBl+DYqszIoLmQZprVS1HjzZ7788mFJ8kiZtTAgXExs7MmfLn5UhguxF6XkFj90EkvPN4dLDyMHoyIGQk1JpCsFa7CAnO7Br8FYklLqFbGnYCnLT12ty06+yCN576IKtAo1F8cnCjjQnt6qi5C4pbJoTkVcsoyTCoDy3Z4vi5hfXUitow8kgD6oHgRVjQemTg1jTkYgUwBBZpKnhRazugrP1MAslu/SC2DpdZTi+FVQ6l0Ye9YrzHJy8wNTmCabm20FV02BPeyF19uBERrIiIZzANguq/NJ0xq8gjxqWL/Bi6Dw70bplmq3g2C72kIVvCC5Bo8nNxog8Oh2hgKkYCwCBKEYfdFgA0AGIlUlouEjJInZr3w6FynoC2WlNnQysqha75U3p+WGNJMjzTh9Z+H32AdqusHkPpcwsapQhBF76R4Bip+hEFoGTrNwaHjbgcPqsBbCviWyTSDn/UYj8AKSpW15Nz8u8VIr/kMOjo30xyop1AkIUgyUdHHQ1hUJbj55d9m1WuOGiFQAnUQGT89xTV8Hp0dWG0CBA6CqNruIkbQMkCDVBqAqT6ml2iR92Gkc2wsg+j5itlIkcF0A5dcotLJFdXrbugbwCPrtm283TyVoPziwEs4UzWNCgIJM19bXGAEBsWYa6INQlZSQgoiTqt6+HyTVmJeVC8igZdujO1iHsM4WBUtrL1938N+XBZafbA2w8WkaStnBm3jkJeSINdJTGYfUQzxmqYEVFghnY0VfYvBDhiU6MrtIYEgI1QVBsB3g5SCO49CxbVoPyIIMZIGEehBAmwk/+CZE5W2MkUjOp2WQdWps4Q+e/yxy0h4el66ytaEZQziEEAEkMxYSZvoYgYP+axBGtEAfUJCqCMK8Zv58b4IF2jCoBNUnQGk5W4cAlwqt5p7eaZEjC3gScIwyCObNASmkExDbI4/pespInG45le6OwB9hyXvUDMQIACzEwEgp87rBxvGF5A0OBS1HrKI375ge4cmcHP9rZxq6uxkhgEClmcou6/oO3Fg5EoDAApASHiaOJNRDFQK8P6vZB3Z7590EMxBGgDHuaZAAOQ6ASQtdrQKMGqteBSgWQyWdpBYoVOIrz+043FJmMxY8bpQktMBMzGgHhzP2aOG9VHSeNVTAeSuc59JXGNRM9fPyRWUz0FZoB5ZsziTGycrq2mNEpxV67TKgsk+CcQpZbkOR9K27flsU5ZDFdy6J3sjiX8Mx0VvBJTh4TQRIw0IyRQOCHz1mOY4YqADNii9krCJB56Ivt3RiXPDmPy56cRyfWGK0IxOwbYCswkxKohgBJIFYQ823QxF7Qrj2QOyeAPVOg6Tlgrm0WfzAAKQ1olZMVLAsDQeBKBahWgVYTPDoEXjYOrFgKvXoleL9l0KPD4CAAYgWKBiBtTBUJ4VhkKYCOZsQMnLmigQvXtvCckUp2dFVmqAzSJ5PaxBMLMc6+cwJ7+ho1KaDTOoWNVZCHDaTrK0pKECk0nyKJCXeCCaCVv96We0rO6nE5UdPb0XZ3guASjoTmPO0BY0Exfvi85XjJeA19pRAK4SPYBpxI3EYgjXV4YHaAv31gCrfs6WNJVUCnaY7WZtFrVSAIoNsLEE9th9i8BWLL0xA7d0PMzgP9gVngxNSzFIAgE/nn5Dwnncrza2P6WSmzUVQSSVZC6KEhYNUKqLUHgI86DHzgGohWE4gjcL+fWQUpgOmBxtqhEBevG8Wr9qslBomTWAA+DAQGEGlGVQrctreHN945hbpMCmgiDQjN4TIuwCa5U4IjuITG9FlruOlVZiVW3fY0F9g1ICe9snN/p5zqNHewEyQGYOyNNP589RC+sG4MA6URihK3QS6KxsxQAEIhoJjxmYdm8PmHZ9CSAkEtNCez14fYug10z4OgBx8Ddu4G9fuAlKBKAASBWy61oDE33nH6x6wqZP6wnJCPNThxAaSUcQ8rVkAfdwT4hOeCDzoAJCXQ62JPN8Z5B7XwueeOYbwiEGsTIQj7fjOzzM41xMn9f+C+GXx3WwdjVYHIzvrIb0wpKQuXtE45cUQK9q269RnOUhy2umm8Mm4hzGeUVwQZFk+WcNMLl2NtQ0JphhR2C07yRcrJ97I/KrMIhB/tGuAjD86js2sStfseBv/mbmDrNiCKQaEEhyEosyxUoHmnwKs53Dq5V51B2Bk5y+I/mCINORbRYf8SAK2BQQREA1CtDhx5OPTJL0B07Dp86Phl+KsDQuhYQxEhEFTceHZgmQWtBJ2Uqh+cjfCa2yYRCMoQQpD1/WSCzTybJa/oynm2YL83uRMGEAgWWbpGMAyYrMWJ2WmxIoeP5y9+3lwhCZiJGGetqOHQZoBIach0YwlhTGq3B9Qq4ECaa1YaJCwETDOCwARJJ3WnsO7qa/Hbn/0WYm4WOpBApQKuhqauz8gCJEBBsYJSEZSKoOMBVNwHxzFYRWAVA1rli29lC0SJmxABSEpQEECGdYigAhmEEKICQYGpTabNHGEIVCvm+dz/IPD7+zC09iAc/NevQ7zyxQhCCVYaWjOEIK/4QOBYgboDoFE1QYPWECAozThmtIIXjFdxy0Qfw6GAYgvcgcXKtrAGToG7tP8Cbo3Ddr/EAO3/yx1uzcNaeLBXT+diEQWWO0ixAkmM6QHjP48fx+tX1tGPNUICSApgzyz4zi1ALwLVK8CapcDhK81iKgWtgSCJjh9/fAe++Y1r8aOrf4PB7DyqzZpZfCvOYMRQrBBHPcSDLuJeG7rfNb6bCKhUIBotoNkEtVoQQ8OgZgtUrZmMIQjMfUZ9cK8H7vXB7TZ4fgbcngcvtMG9noknZABRqUPWGgjCBmRQQyAqyXUYy0KCwP0Is50BTnz+EfjAX52FV73mBABAFMWQQpiF7g2AR3YAO2eAbh+oVUAnHQaMt8BKI2KgGghc8vgCPnz/PJZWktSY4JSa3U5ScppZM+PiAbIOPHzATTvYqUOz1cULFyBi5pJKWw77pptCacZIQLjxlOVYVjG+XEgCDWLwtfcAnS5QCROHp4FWDfy8Q8CrlyAAMDe7gK997Rp8+9s/x9RUG8MjTQhBJjc3cBGU7mMQdRB15hB35sEqgmg0IJevgFhzIOSag0CrV0PstwJiZAyi3oSo18BhJcMEyHuAhneowXEM6vfB3QXE09PQk3vA27cj2roF+snHoSd2gXt9iEoNQWMYldoQwqAOUJCYYYIQQLvdgYoUXvPak/Cxj70Jaw9dhRgAPTUBumcr0O4BgQQFEtyPgJEG6LTngqWA0oxQEh6ciXH6rdOQxIv4dLc/MauUkkuDYKczxaLnHXDDzqwiQVxOq2YbZk0rXGkVTFuNk8yQAOYijZcvq+IHJy1FPzbmX4QC2LwduHsLUKtY/WAE3Y+MjzzpCPzkoW34p4uvwCObn8LwSBNhGEDrlBLCUGoB8wvTiBfmELICxsYhj1gHecyxCI88CsGKVcDQMCADQGsTrKkYpLXJILQu2eTwHh6BSRjQSEqwDMym0QqYm0W0/WlEDz+I+N7fAY9vRmd2Fqg1MDa6HGF12HTPsc7M7fT0PJaOD+MjH3szLjj1GODOLYgjBVGvuMhqZwA65SjwIcuhI5O4xQycfusUHp2LUU9xAasK5Jesmbw40I4B0r+3uZMH/GIX+3hzGQHN2YA2PsAW8AYD/Ez2ND565DA+fFQL3YFGKAGSBPrFfcDkHFAJsshFaY1wqIGp6Tn8/RU3YtOdj6JWCVGvh1BKJ3RTDRV3sLAwjamZGSwfbaBx9Dp0T3oFWseug166H4SUIBWD4gGgTYCnGYiSODPiHMNwKmMWwMJJD54gA0KFCZAlMqYQgaUEhxWwDCHiPua2bsOq+34J3H4rfv/wk2g0ahgZXYIgGIKgCjRrSEmII4W59gJe+5xD8C9vfTWWLxlF1O5BpkgRAehFwAHLgJccDY41IgXUAoH33j2HK5/uYKwiEHtr47d9Oi1p5GkvkNNyYYLAjHqNvMTqFzXIZvNYBSK20kROmCcERoUI61qh6YpN0bJOH5jrmpq7Nh+lGAibddy+eRv++r9+gS07pzA2VIMRGTEnVesOFhb2YnpqGuPjTbzjHWfjA+/7E4i1a3HurfOYbXdR7y0ki0zoayBOrqseEJZWBZbVBJbXJZbXJMaqhJGAUJECFWkeVqQZfcWYjRh7+woTPY1dHYU9XY3pvkYvuY+KIFRZQ8ZdSHQwGxMOPuJgbLrweIzMvQPf/d61+MbXNuLBB5/A0FADrdYSyKAFrUMISRgfa+GnD23Do1+4El+94NU4ce3+iOa7+SYQApheMAorQoCVeeCHNqUJabR1UCkvdrEFFxO7KKmgYk+knfnSwT/fw1nXa2nzJVwip13mtaxDVgBKkKarX7wERwxJDLRGUJMQO2cgbrwfCGTGeJGtGr5z8+/w0StuBAC06lXEyrxfqR76/RlMTk5geKiJ889/LS78q/Nx2GFrsi++a08Pf3LrLNqRRlUQltUEjhgOcOxoiHVjAdYOh1hVFxitiJK+/33/UcyY7its72g8OhvhwZkYD0zHeHQ2TjYF48ChAJteOoaDWwRFASQB8/MdXHrJlfjKl67A9md2YnzpElRro5CyAYARSIHOIIYA41//9JU455TnIp5dMMSXpAzPZxwPPdxA1FeoBwI/frqP99w5i5HQWAC2NYiIFm+UJrdmknB6cjYTAXTI9RPMKQ8+I3NSgfzAbNlP9kqdljWINLC8JnH1yeMYDU05S9YkxKM7IW59BLpmQBpZD/Hpq2/BF667C0PVEFIkrB1oqKiN6endiKIYrz/zpbjoonfguOccZvDyfpz4PkKtIvA/z/Rw+8QAr1xZwbrREEtrsliHZ5PWlhQSHYJN+vQEDIxdbOhjPLOgcN9UhF/sGODNa2s4YWkV/UgbR6U1giCAlMBTT+/GxZ+8BJf/1/8gkITh0aUIwhEIkiAoxEpjYRDjU+tfjne9/PmI5roGEo9i4DXPg145gqinUBMCd05GePNtswiFsZoOJ4fYIaDYzY52C14hCEwtxtrrJpg1O+acUFzYHCzKTb5N3kjpWx3FOHq0gk0vGgURQxJD1iXkvU8Bv30MaFYhKwE+fOWNuOTGe7C0VUPKaVV6gF5vCpN79uDIIw7Gp/7xQpx99svAABYWYggiCCmQZlIMRiCdq4XWxvfn2EfOqnUc4LO0kOasK7bqPpT16acvipMV0WzwC61Nla1WCxBI4JprfoUP/80XseWxbVi6dBxhZQRS1rIAcardwUWv/yN86DUnI253IQYxcNpxUActRdxTCEhg65zCObfMoq+TjeYErRZHgXzeAGXWgq16B1GKCzAEKYs9m7F+kTFmKVO4YJDK2bLEufIFq5TRa5i6I5IQEpJyZvIgIwXWgJQS/+eKn+GSm+7F8qFGVv+P4wXMz+7E9N4p/MU71uOmW76Ns89+GWbnY8zNKwPUSEIgGWFg3KUkgynFWiNOwBYigkw2iGn88OhopYvPXr9ZQv9OKnxSEKRIBK00I1bm+5RmSAKkJATSbBADIkp0ugqz8zHOOONU3HjzZTj3vNdgcnIK3c4EVNxJOIoa4606Lv7JrfjidbchqFWgBlbtgc2/ViWhSgStLPURkLtGhZ+UzcxWj6C1zspUiIKshGiheU4tgD2eQMbcEbB197IGDw00hMhKo2mlFgxUayH+4Zpf4T9uewDLmjXEyQ6J4zam9u5Co17DNy/9B7ztbaej3QX2TkeQgUQoDdgmpV2SykuwRUqMtagEuBFtWapDbocKFdQsLMZv4h68ligiswmkICgFDJigNGHvdIShkVF8578+hec+9yh8YsNXEce70WyOQwZDEACWNKv4hx/fgvF6DW858VgMvJZzCRgWlQZIkKdIlhABvC7lHJchxxoIrwFG2I2Lwuawa1ic9Jwjn+440nlzp3D+TiBF5ZOUG1HMqI428Y0b7sKXbrgby5p1qEQDR8VtTE7swKpVy3HVNV/D2952OiamIvR6CmEo0agRGnVKTP0+BE642Puf8xnJ7slapKGOvBajfb3WLZzllURjNYIAaNQJ1QoQhhK9nsLUdIwPfeh8fOd7n0UYVjE3uwcqboNB0KwxWq/hI1ffgpsffByVoSaiOGEppaVwXewSztbHb161ehvytTMwP7G7jsL54HRxk38Xym9usP9p3ie0KHTmap1TuwYxYzgk/OKhJ7Dh2tswVqtAaQNyKLWAPXuewRFHHIIf//TrOOHEo7BzzwBEEvUqYahBqARwew8Kxel8sXMeHperJyymL+Q7fp/6xU4ZyK2K2Toz3kdWQkKzTqhWBEgI7J4c4HWvPwU/uPKLGBkdx9zsJKJoNqmfECQz3rPx59g6NYNaAMSxsbCRYsRx3jRCmkDK6lz22tfTQ0xJwwix3TziNscIaAKU1XOvCSL5Sb8IVldKliWoVBsA+U5TBMmEhb7JBpRmBBWJbU9N4f9s+A+EFQmwhoaGUh1M7d2NQw89CBt/9GWsOXAVJvcOUKkEGG4Rmo1UzNHv/rRF1wrAtCua5EN9/n+XVTTtQkv6icS53/WZv7RYE0rCCxRAqw606oQwDDAxMcDJJx+Lyzf+C5qtBtpzk2A9gGaBakDYPTuH//PRSxH1tCn+MKPdY/QjTmKsvEsp1Tygkm4os+B5Gz6sjiJb7yGzALm0mS+uIIrWwDYtyrogDQQaaPc1+spcXCAJF110GZ55ag+q9YqxDHqA6amdWLFiGS7f+EWsWLkMM9MDtBoBxoYJlTARlICvE+MyIalkNamsVcbBRdlh+Dp0YipX9c2LJ764sRU4F4LMXLKG2ZCWhltAvRZgYnKAE19wFL526T+CRIhuZwaaB4iVxthoCzfdcBf+7atXYXREIo4Y032NQQRIR6OAXHOvyArSE6EMZQd+wmrDszYJtP1BblRJyjI5nj9xXEaq3acIkoGpToyphQFGhiV+8uM78dNrbsXoaAMqNqJ+nc4siBhfu+STOPyI1ZiZ6WNkOMBIK2XUugJJ5SiH35Pg92/ZvfHsLjKxJSLtnV6npytXMWNbHq5UuAf7iFHMPUlBGBkiNJsB9uzp4zWvPRGf+8JFmJ+fR783ZQAopTE80sDXv/ZD3Hf/btTqArvaEQYRm1K93yPI5Pl+JBadswwNTqaQWAOVsrUzn5LvIH/B7UDRbArKzYn1WtZAhYHdC4QJUUWv3cfnP/cd1Gu1hABOGAzmMD09gc989m/xkpc/B5OTAywdr6DVSDkIfgceiq1ahdPGJbo8PjiyyOcWmv/I6+1OgRNePB5kHy6Fm1qSy+MebgJjIyH2Tg7wZ299FS5455uwd3ISrPtgCFTCKqanZ3DxJy9BrU54pFtNYoBUioeToN0N+mCtj1nPsoOcB+/QBDr6ezPs9+iRw+svEkCo0A2UVKaUBgcB4m4Xxz70S/Qeux93//5BBIkaDUmB3Tu34o3rX43/+M+LMTMTYXRYolY1FGgqTcXIbTZw+pwWA3TYFXT4g8Bf75Vuxch9DZfp3LNbiiv8zhWRJAG0FzRmFxhSaJx79nvxu7sfxJIl+0OpAZgVRFDHC59/HHatPgZ7n/NSSNIW16+4ebOGU3KLQxmJhDwUEQxad/ks5xSwnPufWkwNl+vnizxTstO11iApobo9RN/9KnpPPAGuVtFs1KDiAWLVRaczj6GmxC9++V20RobQrGrUa5Q3nfjgjH+s2ep6IFp00Z8V5St5PbvddMXMgFDkP9KzZBU2+8e/nmQTzMzFEGGIu3+7Geec9T40GkMIgyaCsA4hJdoLC6jEA4TPfQHkOW9HkM5fIHLJb46SqMsZzKp/FhcgvQ0BZWvXuoGdMR8EihNzk+jyGleRiCEpBlEAEdZBI2PgO34F/eQTaCwdR7NegYpjEEmE4TBGR/dHP6rjyk03Y2zI5MmsiwobBeZDodpBfoXKaR/jRS2C93r7HGU6A1ySYnr+nJwuufI0k8viA3dDaw2MDkkEpPGDK25Ba2h/NFsrEVZaCawdY6jZQGVsCdS9t4Mfuhc8sgQkqwaIU9pKv8kVprJzfc4zOkpiAiRrGAjlWT32OnzswnKu1WGuXkigVoOenYLe9RS410Xv/tvAIRDNTxjalKwkFiKClMD8fBfNuqFNx3HSc8H+SUcx+k85b1Z3b9ZJabNYma3mSiumWHSaw2JpptNDVmg2L7gFeNf8bIBSQvFWmlGrEFj30J6fR71mCLRCBEnM1EGsIoAi4I4bIISAqNVBKw4GmkOgXifvI/ObZm02D5NXJUysyLGXzXGxkTDl+HmU6vRsaQ0KK1D9DqJfXY/4/t+C2rMQmsGVABASg0Ebve4MBEnUamMIK1Xs3TuLt/zZy/GvX3w3lDItUovRt8stuZ/Hk/PQGVw+p6DUEzD2zadGiU9HiSqD77nYc0+8iFtJfLI2PMKFhR7OOvMTePihbWgNNdHv99DrTQPQqNfHIcOqgXGjgWE7jYxDnnAqgue/AoI1SJt6SaHT2usp9BlCdNylc+54BrYrfv6pZMNardRA8zNoX/FlxE8/AapVQUEFIhEXAzOECKFUD3Nzz4BZIYoIzzluHX567T+jWgszH+iYVqs5pfCMF5PyXGSBeV/ziBYNIveFEu472CzELOzSrOwY1rcsWmnIQOLhh5/Ga171N+j15hGrDmq1MTSby0AkwAniw8kB1FEPYtBDcMyL0DzrnQkXUzlkHmc8TarrRG7WLMjD9+Hp4juIX8yQCNDuLGDbt/8JOx/9HaJaAJKBOX86znyo1gbSHRpeAyGqiKMFfP5f/hL1RtUEjKLMtMIxn2TLzvj69AVswF1Eon1gwUT7xvbLwobF6gdMJc0x5IhAZ7lVGWTMDCEFoijGUUetwUf/7lzsntiORmMEzeZ+SYk5Mk9AM1jFhm8oJdoBYedvr8f2qy5FV4aQ6Xql1V3lzlagTPiScq0jRwUzCfCEskWUzO9kItQ0V2ni+Pt/gw2tOj74vBcgntuB6dlnoFWc8OV1TilnRhAEiKIQH/7IBTjh+UcZarSUKFX7snJN8lIoKk27SlwCL1Ko8SI0Bu8jWsvLoKZvj4sNMT6KmCGJCdDksmlKAlq3w1VKgThWeOe73oBz3ngGlGqBRE7RN6SdhOsY9zAx8zSWxm1seP4p+HBnNw565G7MV4cgk8OaikdBExAna8vkrqsmBFAWb0y70u9244ECIRYhPrb1frxVMPCclwJBiFOb4zjnth+iPb8TwyNrnH60NF4Qsg4Sw564gp8382JDg0p8Zz4WxlVioKLfpX1V9riEF+DFalSmDF2GB3ARVSRPTKEsFsiUzpOemSiGDIaSw2ThGawSPkKEqbkdWN0YwrUvOQ/7jy4DOMa7OxP4ysRWXNpahWEVpf7VJfCqYlIj8pPvugAbPYIGeizxT888hLdu3wwFhcGgg978DF5+4Dq89fATMd1vY9CbApGE1pzsWIZSGs1GFd+7/AZMTs4hCGROJaeSHoNCylRWt7dy3kKqtajtdn5Hi1V0qMxF+NdIKFdp8HkEVAzCUJ4WKqUhhMAdv30EN994D1pDdSitTSOoZQX6vRl0VISPHv1i7D+yFN3OLAaDHqoE/M1T9+LCqW2YpyoCpU2K7ugUG4q0LTknstw+q+hZIs4aCDRjTlbx7j1bccbEExisWgpaswRBq4ZACmiOcd6BR6AuQ/T681AqcmZoMDMqlQCTk/O45Zf3JRmkLi5wGahiq2iXAD3kz53hosZ/AbMtDO3zSCaLlgsthKwQL+5zUGC2cd1BWQx/NA0AXH/9vQkFxHOLBCg1QLs/j4NaIzhj9SHgqIsKSQTjDej9lyAaaeHCyYfxyvm9mEMSE2if4UWOYLbIsGOnyJAHDF0KcGx/Hu+efgxq/2WQy4aAVhUYaxiOXhzjmNY4DmgNoxsPoOKu0aN0XDRBa43bbnvQy5f908eLRu1Z147m8hSOLAIIL4L7MbDowEBvxiHYN91U4vdd4ml2jVbcwc6ACSqtIjEM20lrxt13b0EYyiwD43ziIlTcRU9FeO7YCoxVm1CsQYEAxlqgWgW0chw8XMdH99yPJVpBQWRFIVjK6LCqviLjjWnXNEABQjEGHODtux5HpS6gx4eMuILVhxZrjWa1hSNGlqOvYmg18Ha4CV7CMMCjj+5IqmKifGKiF4EzGCpWpltWCAgpIaQAa0DF8b4svJs9OCrNXjcy2e0ylsDaIqzgwuJp4+aIKL9GIaCUhlZcbhu4yEsgEpiYmMXTT0+gWgkNi9n7Wq0HiLXCsWPLgSBw5JuJGUJrxEvHsFp0cfbcTsxTBVK7cv6U6DqIlDcgrDTQ0IZMtUkw0CeJQ7vz+OP2TugloxA6Ia5LAQyMwgYTgCDAIUPjiJmhVd8KPPIGkjCU2L17Gu12t6CkUeYOtDYPNQgDSCkxNzeP7dt3YmpqGkIKBGEIIUTiTnJz4xb+2FMg3Bduj5JNSYuniQCUUuZaggDMjD27J7Fj+y70uj1DDw8ktGKLzcTOrEDfSuzaOY35uS5kIPPaDMzmYK2g1ACCJA4bGs9dnGbTSCJN0EhSgMeGcebkVoyoGIpELivrzCwwmyFIIUK7ZA4Y0eCuCHDq3G7UQ4WoUYVMT75mcLvvjGZbWWsaAqi2ixX5DLwgEGjPdzEzvYChoYY3jdOt8mmtIaVEHMf4wfd/jE2bfoLHt2xFp9NBpVLF2rUH48wzT8Nb3rYe1WrVLIQQKEddFqsxsFdJs9vdyEoDywElpRSCIMAzz+zEN7/xHdx886+xa9cElGIMDzVw/PHH4S/e8Wa8+OTnQyduwUVrOZ9jnGzeiYlZ9PsRqtUwoc3l8aTWCkrHqMgAK1vDeWqsGFgYAEN1Q9XVDG7WsZZ347j+HH5TG0VTx16XN2eFoSCbJOfEU+a8BAyc3J0EmnXTHBkrw8Ve6JtWL5HSixnDIoAgkREDyZKVTbuF+oMYCwu9Qn9aHjRTtviPb9mKd77zb3DjTTcACBHKClrNFmQg8fQz23Hddb/A9753Fb7zX1/BmjUrs03ApUVgepY0zJNWcuYkMOCMzDDIXRAEuPrq6/C+93wMz+zYAkIN9XoTzWYdU1N78cijT2Djxh/jrz7wDlz86Y9kgS9RXnkkD8Ba6PSgFXtcQ+TCFgyEQqIVhK5I1XwPPN4CQmMFVBhA1CRO6OzFLbVxtDKtgFzJnLJBH9YEyrSyJBiIQVgy6OOIeB6oVEDKyu0n25l8Whql1iqVBLJkcEmgTERQsUKvFzlES7JAnnTxt259Cmec8RbceNPNOHf9Obju2h/gv6+8DGsOWAWlFIaHh7Bi5Qrc/pu7cfaZb8fU3ulk8IP2xq09Wxm4mMMzChr3DlKZwrbX/OQXeMPZFwCI8Y1vfAXXXfd9vPpVL0W320Oz0cTY2DBaQw185jNfxgfe/3FIKTMxCl8dNV3LXjeCZl2IXInzcFAACO1SpCBDwJxum82QSuWFEsf19qKSjuZL2cSwlNo1Icj17nORByJGBIGVcQdLdAQdhUbpGgK8ew7U7uf+h31kzQN77GkarLMbZLhza1Mz2O8P8I6/+BA2P/IQPv2pv8fffewD2Wt27dqDC993EWr1GgaDAZYsHcU99/weH/vYP+NrX/8nU3pOP9UZ9+0CRFw6Hs6VlSnbNFob2Hbnzt1473s+gjVrVuO667+PI488FABw1NGH4YUnvQ6DQT9TW1uxYhm+8tV/x/HHH4u3XnAuVBxDmBKo9Z2UCEio8uuyC/jwhlykm2CqDVQkaKxlMCDFOChewKiO0IcwbCK/BG76AlIomDNdf9IMDYFVcR8CGnqhD0zMgp+aBiYX8khLiGQVCd1BlJh6UXoDpvlVIJDSLj1lC6OVOf2X/fvluOHGn+ENZ52Jv/vYB6CUQrfbQxzHWLZsKYSQWZwRDSIsXTqOjT/4MR5+6DHIIDCm1pE4o0LfAJXi+YyC6SqcVGOtvvqVb+GpZx7HZz/7cRx55KHo9XpQSmFsdBRLlyxBNIhAyWgapTRGRobx6Yu/hKm9MxBSgjMcxF3ssOKK6BaYCWQk42I7Tc2KdwLYNQfeMQPaPg10IoxzhPF4AMUi6d2wBlqlGQHZ8lFs040J43pgTnekgYm2UbQQ5AE0JoVq6zjz9fkzJ2tWECMMJGr1SqGAwwzIQKLT6eKyy36AStjCe957QRJUGq2gIAjwm9vvglJxJvLMDAgpMTs7i40bf5yDTFQsAjFxObjDKJnbl2APsLF4IAgCLCx0cOWV12LtIUfhtaf/cdYQSkTYsWMXdu7aiTAMM4umNaNeq+PJbU/h+1f8yLhCrd3vT/406hWHe2hrMBAJCCEQs0Y7igr0tQzfnO0Asx0wCdSUQiuKoLVRCM2npuWbQAjkxSDBObecmdBUccI6sTpGdVEdHALYPehafDXyWUlgZlRrIYZaddcscOK7iXDbbXfioQc3Y/WqlTjqqMNM5KsUwjDEzp17sHHjT9AaakIrZTWDaoRhBbfffhcAJL7WxwLIH8qeK5DaTZTkIobkNJ0a13X/fQ/jsS2P4fDDD0ar1YRWGnFsAtBNm67B9PQswjBw7IdmjUolxFVXX29wEPsaLcRyaKgBKZPSbwkBVpBApBUmF9rIR8en1b60B89qkmGNqlbORJaM+ZUgwILT8iDgzPADA0LpvB85KzXCEpJK8mytsX1hFgIMIumDtAmKpdFq1TE0XPcqspydll/e/GsorTEYGLMvpUStVkW7vYB3/MWHsGfPXlQqFcMetsxypRJi+zO7sdDuJOkgW+6S7dkji/r6XLW7rG5E2TU+vHkLmBl7J2dNNhAGqNWq+OXNv8YXvnAJRkdHECtlM2ugtUatVsPDDz2K7dt3mWvMNfCzmHXp0iFUqkGObTjidBJEEkprPN2ZRToHLlt4e+RNWgJmNriO09zjzhwUTo+ZJ/vShcwbR9OI35pnD2ZIImgd48n5aaMCKsJs99mBYaw0liwZRrNZS3yg3Yxj4obHHnsSlUqI+fY8PvI3n8Ytv7wdV1zxI7z6VefjxhtuxfBwy6BunoWRUqDdnke7vWCZTCoBm/z/LLqKZ2MQT0/NIJQVbN78KD74wU/g1l/dgc997ms477z3QCsFIXyU2HxiEEjMzMxiy2NbjWtwSt/mNeNLhtBsVhNpHBvFNLqBUoQgAE8szCa9Cl7cYmWQxhoIDFhmNHK7K0gk2V5gSoTeYDU2bUizsuo1TLh5C8PAn3v6HTzdmUdFBiARZHh4mpKRAKI4xv5rliTqHxrCavYUwqSPu3dPgAA06g1cedU1+J+f/jxptgwwMjoEFSt3MoilTialTHgGltwNOVwjy+eXwLse05jL7QGUiqF0jGZrHF/80jfx9a99CyQkGo268f2ai+RmNhpJ0WCAvXunrKzHbWFbsmQY4+NDmJ1pI2hU3eIRGf3CgAQemt8LVhFkmvFQEV4WYPSFxAKHBsBLD7gNuApKcQAXKiRNCDVjF9WN7/HGoKV1AM0MFhIPTk9gT28BVWnEFDkbpWTqAGCD6R922P7uzVvwLTMjSoIbIYGzznwVDjhwfwwNtdBsNk1XURnLlghKK7SGmmgNNbPNwU4qT27RqIwI4pNCnbGtuWVYtWolpAjBWuHsM1+DQ9YehFargTCQ5lTvq1OICINBBLePmTPp9mo1xAEHLMMgih3OS1paJ1FBTUo8NjeJXYMFE0ssUlsAGLNUxSyqCDW7k8dSi2+kiOz28LxiVFUKO1DDjKyaIVKLFDVIEG7YvQ0DFUHKAEIE/tiwpJgDHLPugAJpj5LIXQiBJeNL0O5M4YzTX4kfXfVtnHHGKzE9PefyPPypJslDPeywQ1CrGVjYVqJ1AjveF0vU1cH1KQGUQM3HHXcUCMC6dUfih1d9C+98559iamoGQohybogFRAopMTI6XEotS4PMY9YdiCiKEqjYTgQ1SBCqQQW7Ogu4Y3I7WAZ5PGQdUG2mdWObbGIOodkAOi8EURLziYwQYvmGND2osMaErOHB6igY2pu8kvh/IdAbdHH9jq2oCwkZ1BN/ng9sYNYYDAYYG23i2GMPzky+ff/pzR908GpIUcVdd92Hi/7uM7j+upvRajWglCp/qGQ+K44VTjvtpR7XACX6AIxy0WNapHXcGjqVEDOOOHItjjn2cDzwwMP427/9NH7w/R9jaKhlUruyDnbkwxlazQYOO+zgzPw6sUfyn887fi0Cmcr35uaZWUGIAFJWwGBcvX1LzjMskJ+MEsRd4VJELM0wT0/TIQ32BemkS9RafGJAatMZ/PNwTeLL2SFVxswQlSqu3fE47p/ejUYYQsh6Jsacmn8ioNvp4PAjVmHV6qVJlc8jbSR3/6rTXopA1vDU09vx+c99HTt2uDm1b30ECXS7PRx88AF44zmn56Vmq7iklMo2WKGf2OYseNiBUioJxnJSZxzHqFQqeNsFb8Luib346le+hYcefhTVasX4fiov+Qoh0Ol2cexxR+OQQw7KKp35xkRSRwGOP+FQLFs+in5/kJl+TjqvTCxRQysIcd3Ox/HkwiRkEJoTL/JmFSkYA1HBL+UKNFTsDKm0hSQEp6RQe/GTHaKZ0Ioj3BTshyeq4wgRI0rl3FmbnDTu43Ob70AIhhA1CBGCWVkERg0ijX6/jz/+4+dlAaDTzAHOyrqnvfqlOPXUk7DQ7mLlyv2sxacCoTMFRuZm5/Dxj/81xsdHjfkXwtlcRrVLenL4udshi3JlW4cgCBAEgaXibQJNrTUuePuf4NSTTwIYGB4ectVSPbuf8gT63T4uvPDPIaWAVrrogARBKYVly0ZxwgmHYWGha6D95FkiwROEDFGRIfZ22/jcw3dAhFWoNF8w/E8IDHBt5QA8TsOos84mrLpqIiaFFBlfLOsORtYlHGigrwUubjwXXVlFNZCQQiAUAYJGDRfddzPu3rsDzSCADJvZosP6iaIIY2NNvP71JyenwaN7pUMgtUYYSHzxi5/AfsuXY9euCUgpEIQSUgpIKSCkgJQyYRpH2LV7Dy666AP40z87B3Ec56ffOto/u/6XeHTzlizTsItOvV4vz0IS15HCvVdfdR2u/emNOXch+T1rRrPZwGX/8S9YvXoF9uyeNNcZyCQTEcmPuU6lFHbs2on3vu8CnHX2q6Hi2AhDllDg0o101lkvgtLKYQKn/04QIFnDSFjFt5/4Pf77yd+j2hqBJAEpAlQl4XG5BF8PD0cjjqEzGZ9UTSShhCtAKDK9gTZHjBJUibSxAg0d4wGM48LKMfj1nm2YFTEe60zjfb+5Bl9+5G6MhCFk2DK+iVWimq2gWYEkMDszj1e/+gU4ZO0qxLHKHiiTm7iKIIAiwrpjj8C1N12Bl77iFMzNL2ByzxRmZ+cxN9fG/FwbU1Mz2Lt3GmNjw7j00s/jkxd/GCq2+QAGaiUh8N+brsGrXv0GnH/+hYiiGMyMwWAAKSU2b34cJzzvtTjzdW9Dvz+AkNL8Uwjc9/uHcc4578L5570Hjz221ViodECzFFBK4bDDD8HPfvF9vO51p2FhoYfJvdOYmZlDe34Bc7NtTE/NYHJiCtV6FZ/53AZ84cufMmNb0mEWukhfMmwnxqtedSKOPGJ/dBa6CTScs3U1KwRhHTKookKMd/72p/jXe27Crn4b06qNH03uwvsrz0c7DhFo5SqHKZiqruKstzPjA1BWEyEneGEIDKseHqkfiPOeeBrNX1+Naa0w3etgpFKDCJsIq0PI5MM4R/biKEa9UcGF7z/Hymk9neF04XoRxMwC4u4AR44sw3XfvxQ33/U73HT7XXj0occwt3calWoV+61Yghe96Pk4/fRXYOmyJQkPgByKePr9Cws9NGpj2LJlK7512ffxznf9KaSUePTRrXjTee/BU09vx5YtT+C9774IX/7KJ9Fo1sHM+Od//jdUKiGGR0ZQrVQKYJEQAipWOPDA/fHfP7wUv/nN73D99Tfj0c2PY2pqGmEQYL8DVuH5Jx6H1556MtasWg29bdK4+2YNGGtmswHcsV+EKFJotmp4z3vPxLvf9QU0mhXEcTLwhXK6bVgbAZHAIFrAR+65Dl/dcjdEPAd11Ntw4IEjqPXb0EI62o9O/2fqJV/x/h6T3Vdh5+mUDk/RkLKK/txTePz6v4caTCMMKtBk0j4HdEkaQ4JAYMeOCWzYcAH+9qNvThpChNULkYxuW+gDdzwO3rYX6PazhkkKAsjVS4HDVgCHLwdkMQ6M4zgDf5z2/aTfbnJyCi9+4euxe/cEGo0aXvPaV6DVauKnP/0FJvZMGQk2GUDFMY455gi8+OQX4KEHN+POu+7H3qm9eOc73oxvXvLZpIQr3BoGcaZL6LCR0j9TPeChncATuxBNzRnNQkFm4YfroOPWAMetyWsrlKbMScQugD8591P4+c/uwLLlo4gGsdP6TTDDLXTcB1ijN+igPnoIDn/F58EiBLMZPGFniGSRjDMU5JXv7XE2scTv04SNpmmE1QZmnvw1dtz+RZCQgJBgTlO0lBhpfOzu3TN40/kvx6WXfiThvJMzdg9EwFwX/MO7gLkOUAlBktKPMmJSsQL3Y9BIA/THRwMHLzeTP5AIN9rjVjyAJ6VsXX/9L3H+ee/C/HwHkYoBaAgKMNRq4DP/fBHuvecBXHLpf0GKAEoPIBACBJxy8om48kf/jvHx0Xy0bAFJTFRCNZsAjZKg8oaHoO9/yjTFVEKISuAy25UCBjHoxLXAqUcgUcfIeIIqBoQk7N49hbPO/Ds88sjTWLJkOMkGOFE1F2ASpg8jWoCsDGHNyR9HdeQg6KifjLzJMc18wLarl0uv/Msek/Da28jlyGSnVmsgaGBh9z3Yde+/YzD/DEgESCfmRbFGrzeAkMDb3346Lv70OzPzJu0NwABLAb7uPtBD24GhWkJG4WQmMbuD9wYxIAXoTS8CD9fzIY5YrHOUM3BFSokHHtiMS775Pdx7730AM9atOwpv//PzcOILngtmjcsvvwpXbroGeyYm0GoN4ZWv/CO8+z1vQbPZgE4zC1u1xBHlt3iSUgB3PgHc9BAwVMtJMzY6mXLBJAHdAejsE4H9xwGVN4EwE2KlUa1IbN8+ife9919x8033QMoA1ZrMOBWsI7DWaCw7Fvsd95eoDR8AVt2kIOd2uZGPFaTI72nv7HJK2WJarE82n6TFWkOEDcT9Wczu+DXmd9yBuLMbYGDJmMBzn3MI/vTPXoNTTj0a3a6haElJ+XxFW7niv34NmuuYqRnMDs3ZuQMpjZb+iw8DnXCwOUGC8IfIxaSbwAacUpMdJ24pRfmiKM5KuaZrV2V/t89+c2tD8ndvA+a7CW/Cf+KW9ZAC6AyAlx1t3EGswIKSYdkMzYQ41ghDoxfw46t+hf/edCM2P7oT820FISWqwwdiaOXJGF5xkqnBqH6++OkgbW/Ki+8O6FV/0WVHTMmmy9s3Zk0SYVZGFSSoAlAQ3MFcO8an/6qJPzqhgt4A6PUUglRDV+aTWimv3gC3PgL89nHDaFWOKrW7XdNhCqc/D1i73PQmiMV6DItWQWuVFYxSkIdgoNkULCIhIJNoXysNIYXXx4jFRaYtgib/5HfAY7vNECiLUJIrlCUUroEyG3/9C8BjrcQN5NPSU9HrKDIWoVITqIXAN3+wgH//YRfjI1VQMGQ2atRN0lThdDyRLXvjm/7EEgek7XY4zhWlkU8DZVttWwOABLSCVgsmrZNVkKih2w/Q7ih0u4xqVVisX6vKRglrSGvQC9aCp9rAY7tBFWmaHYQ10yaZ8EmRAtatAQ5ZliiTeJSulGnLZE24IwtoktliMNKNkBM/ZBBkJVoCMl5+aU8il8jUkFXYetGh4J3ToIW+0YyVwtxT+jalgV4MDgPQHx0JjLeMRaO8o5ot9RshCHEMzMzEaDYIE1NVVCshJDHi3kJWpyC7astcKESQ01SdpwUBNAojpsm6sezftf+RqVQMg6BACpjcKxKTygXFlyyotNRdOJTA654HbN4FPL4b2DsP6sfZ6Fk0QtB4CzhiFXD4yhIRHo/nVxCVoAI7nLCYuBQ8iLpMOMLvZfAgba2BpcOgN70YuO9p4KlJYKEPigyHkUIJNOvAqjHQMWuAJWZCmD3py28J5CQmCqSAUsDEZISA2bB5sjUo749NrTh5i2FfvrEAdq2EvM5b5JNA7GDGnWlv+gN27EqGM6R1EaYcxbJOStYsqxPLctQq4KhV4O4A1OmbmbyBBBpVcL1iXq85y4VtNTlYY24c6RVY7sZv4nQ2Rh5HuBwA8uRefHEHKi33QmtgqA4++XBjDdp9UG9grrkWgptVY/oBM5qWyKlL2GkaWxaBCOj0gKlpIEhavfdllLJTz26pgz0XG9hj37JBApnyNTmNMn5qmD0GbS5q2zMKg4GESIJfsggbWa5Zpp+UPAiqh0DdBV4oLYKQ37NBXgOwrRLM2ahpKmvh9heR/CYQr5TM6TAmfpbWsXwTUCoUPFw3P1ZXDiypN4ZLSM7JvoZvoZMDJQPC3j0aU3vNCN507lJhoe3ZwZbsfxkRSjAQCL+d3iapJHw1spVT4cu4ml9VJGPnLoWpWcb4iOGSiuxQplMrE1gpGcuCdJZ9alW0h1L4DZ3wBlkWeH5cQu+yds+zCkwuoldILgmNfTTTn69jKYMSs6VB6I1wQ5GmwAkQlDXYpEMjAmDrNo1OW6PVEskovRJLZE04c8Ad9urUyeWKbLZ41keekwzJ06YlS4o8pxeb14cSmJ0xF1mpUDYrwCBbVvu0ReZ0dr/9IITN6GFPW4E96XZ4vH+L8cv70Bn2mha4ZIbgoqccXuPLIhoBXOgGp/IXJJG/Hahn1Eud79uHN6uE0cPemthkj7zal3E5ldsinknFZkKRjIw3LuxyoaNOnXQO212mFs9cMKBj4He/Z6TZSHoDOY+UsxtiXkTAA1buSuy6XS59zH6fdQkbqOi3bcJlpgXs6BQViSK5ybUAoTxac7QAXCIaOf6cbaqXT3RyrIB5bkIAs3PAQ5sVqgGDY4aj7eStE7x/Eud9AE6QoRkB2VPAbBINu74kHTeWBWNeAy4roBYwfndPjL17AzQaWWqbHCgLTLK0FLVtMYvZi3u4kuvKFssmfZIv8pCuv9eB7EvNJzdiB4B5kMtFwizgdRXnQ6moEBpwGZe2oC1tbwzNlGAAJgaIFVCvE+75fYzt2zWaDWNdc+3LxBqkApHsudDUavt6WcmtCaR14nTPZjuHrRPPWetYuqMEw+k0YcWoBsCeXQq//k2MatXkrxmbXFM2uk0ndAHtnAbyXISb1haYO/sS7ABbMnFcLkXLblRP5TJEPiBeDPyZHR0ohsXi8aN7UHHxLYuotVl8pRMgKLUCGrjxxigfmu2IenB+yrW23AJnVj1LlG0XkTxcIdjSj7FEIilZncwt6NxV2NMohG1elBmMcP3PIszPGwRQWSNkXHcAzxw6o3e8E1L8Kfp+l/5ng4S+1q+7y+wKX5m6jDVU07ITuYRLvs/8eyrVq0q6de3XmoU3E1bS8cZKA1EE1GqE++9XuOfeGM06Gf1/R+nDlpH33IC244J882QuwcwLsIKFNLCz/T+z90POLhLWSDJONsC2rQo//1mMVjO3As4m0PYmSAZGWmbQAUO8DuKyTZOFhZ5DzU05uTlWRqakQlM4leoKsUPRzvoiLIyMF5c3Sq6T8vvVdo9N0kSqrWejcyxFKeBHPxrkZt4+xbC6gZJF5+TBipQJlFgCoZMftiwGc44DlNUrymX6rCYLO+2wfFmjQbj6xwOc+AKJ5csJgwFDBsniiRzJFSKBX50ysSfV76F4XN4H4ehB+/0exRez54gX+Uyn6YZdsm/ZAAsUPjaDwdmKCfxNnAbH6QFRbE7/0DDhf66J8MD9MYaGCBZoaFX6uEwHs9Dc7GBinF+PsEeOwWoeFJZ8LNutaipJ6yxFMVbpzktAIQEstDUuu7Sfta2p2OxmpfIdrhQlQU9uBp0sIT01yGFRLJZBsBOQF+IHLl2u4jNb1OWwew1ePFWI3u183umqs0y8Tny9Sv5bKTOhPhoAtTphyxaNjd/voVGDEZxKGzzYGhXjmXhh6S6kpzz98tyK51pBgpwec8ueZdJsbEmNccYmdRx5FiCaL2DFaNaB++6NcPl3IjSbhFjlN53dsDajV7MUsZA6cvYgtZUr22hZ4TRhkZqIvzn2FVuUbLL8MXH2vSikbOQMyzSe1Zj8NKiz79E8A3KeSRQDMgTm5xnf+EoPgy4jEDmjN+3WzoI/bSG5djbH5Sm73QUmTDHIyrkzrfkUTGEP9nAVxZ2IOUmF0oemYsZQC7j2Jz0sXUJ43RsCzM0wIK0pM5Y7SF1yxhuwAbwkgk17/HNeBpcggGVpPIGAZ7EB5RV/u8/ECRjLzL03dzAPbCmbh+RbhHTesNbJ1HhpJo9+7UtdPPVkjNZQkvYlffiUikaTHd2T0z3ld7rbJWnfOwSF9CnziS62bouZ+NBlUe7XoHBaM5pNjcv/swMSDZx+ZoC5WZNCSmkiVBYJ2EG5ZnHKwchjg7wQRcg3QkYydbB8r/5dmv2zFzRwaUeQ9uVYkgIWl8YIeYRv6xK4eX7O+cvibpUovcVAEBpL+fUvdHDf7yIMDQuo2M5WLaUDtmFfzvL9vFZDbvbLXJxtSYzAHhZlb4J0Grj7zHLAI3smzLAn7tjj99Lct1ZlXH5ZD71ODa87J0C/xxgMTLlccC46wiJnUQkvMKQU5CCXtWyYL1ws53LOgSvli5QEezYQVMD/rGZR9rIA+7hkmUJqBbTlkjRK44EoAqp1YKHN+OaXerj/3ghDw2QW31JTopKWM7LJAw5TrSiAXWhcYqQiUYkoIRWbL/N35CEolU544Wz4UyaDlkH7hHpdY9PlPezaUcWbLghRrzO6nYQzkTCG7IXXFoMoozGRX5zxuW6W8AORmwISyit+drdQVkUspgTMbrqYP9e0Tz8fN+uc+lRawQZ80hggOf2NIcITjypc9m9dbH9aYXjILD75ZBPrYAkHHHU3ge0GHJpdwXUzArKMIznSLeypU7m6APDHs6Ruo8Doyk/sUItx2009PL01wnkXVHHksRL9LqPfR04ds7iDKe0vixMsNQ3ylUAp1/W3S8BUaur9lNGTnnfsgQVfp4Ub67/ZSodLoHY3QE02QZoNVWqmL/Pn1/Rx1Q+66PeAVtPEAFRWmdT5PdscCOLFdC/YK5mnBG6r6fWNr55lWA+7vOjFRQ4OUUFiHxZv0LkFy40ICfS6DCEJLzutile+LsTYUkK/y9DKEEilLDv9JfiNRXC0taLtwJC8xDm9dmbss5ebbQ4gu0QKP720LYlmLqSTqQVQSSYUhIAICFsfU/jJxh4euDdGo2Hu2wBArjsm8pBFWlzB2IazGSVKp86wNQadd8Y8R7HprqEC7akESEkejMM7cAa1UYGe4ZgvJOPuNWOhzVi2IsAfv7aCk04NMDJGiAeMeGDiDSGQ9ROklySEJ+9A7gYgz0nmLoLc4g47Ot7WoOry4VFsZUbpLWv2kWUqgD1p6gsAYcXcy9PbNH75swF+e9sAg55GvZGPnmHPYpcPJvf4CORmPYTiPRY4rMyQgQC95ey5dqdDTSGU80FkUZVsAkGWHpJP4vWVtVxwJVUEzSqCYAhBiAaMfo+w3yqBF5wS4vkvDrFyfwEpgWhgmiTSdZE+tRzllsIu5JEz+WOxIU9UrOD5M6DgFXU88qbv39OhWEFIkAHQ7QBPPBbjt7dEuO93MRbmNeqNRNxTF60uO2ad8gJt2SxKOPu6OF7Z8v05vZ/QGEJEb1s/v6UzL9eC+vl4ZL9uYnP2HWmXEu1dTxOfrZCTLCaMbZpIAIM+YzBgDA0JHHZ0iGOPD3DokRJLlwtUqub1cWw2hNacLUS6sYhcXAGeZfBNJDspKzvubDEZeofvqD0SS4JhSGkkbpiBToexe7vGw/crPHRvjKeeiBFFjFrdTFXXOo9twB7zqTCqOOnbsEfAEHuyBm6JlOB0t9uHjwWq1BxRjwdBwJsFBWtZ9zQTpBs6lswJdgKpfQn2EzjJpNNdyOTKyWbkTgWEIVCrElTMuO/OAe69o4/WiMDK1QIHHxZgzcECK1ZLjIwLVOuESoBMZIGZoZUx00p7vrlIDPaMQFlvv3WahGeGk01GYR4DKW3g2/lZjakJjZ3PKGzdovHMNo3JnQq9LiMIgGoVqFYSrp9mW0kurzXwYiQ1r4pZoKVxCYud3NSWU8UxaEmBrATR5mC4Gt+5ADpdaxg6dwY0FD/Q4xlYkXbOkyF4jaUWqFRGlrA7V7U2/X51o3yOqM94fHOMRx6IISTQaAgMj0qMLiGMjxPGlwuMLyO0hgWaLUK9AVSqhDAkBKGZrygEJbGEm1mUNSHptKJmY/aKs6h9MAB6HUa3w2jPa8xOM6YmNaYnGVMTCjPTjIV5Rq+XSL+GhDAAWi2/KdP9Zjv2KMUqCY5QleN2LR5HrkKeuFqrU9tHSUVAaDRwZ7B8dXDDzp2djzNDErO128lKcby0hLnE17PL0GByqlBUwrX0XTAluXjqEwUBtVqqzwOwYkztjjGxw2yWNKCU0kTWlQoQVAhhBQirQKVCqFQEKhVCGDBkYCJtkWUZCXafuBSlTdEqjhhxTIgiRhQZ1zToMaKBOelxBMQDjUywNDP/ZtM1mzknP91M5MvPF2vdFgeS3HXQ7NEac+5GaSZjjdUhzuX601+whiDq8OrV4mZi5upbTp++dzCoHgnqahAJIpdVYavqsw9KUHm7nB1E8h8gwOg3R6DsfTYQ5QSqFuKWPnSLaZR1w1g8PF81O8uprdRCeKOIKNlwQphpCJnQUxYbcHHksAOrk4dA27iFhy7aUz95keYVcAmSucgU8yx/Zi24Lqr13ub/+NHY8wIi6r//vKmfTk3Xj4x0VxPnCDAvVjQt2XyUpEFudMqw5dCxePueJ0qRWx0iN3llh1uXtz6ni5drRZSIwdIiQyLLPW6Bl8AWZVdnNHbr80v8NxcYRYWrcuC67PFpLqCe+65nebQ3djkMVoFMh0FdNFu9nxJRTwDA4UdUvitFW7E2Mgy+UDmxV/y2PpCcAReehjD7PDSbj8YlD4WzaIKIiyRMn9SY3Rw7E8/Y08NNy9WsrJ9MxojgyBolf5+OzGXNzr3aP+7v2eII5nX4MpSOS4kEcGjsLiq7GPnAvoYSGnxBV1EDGpKordYeWfkuAIgNYPH+T7XurdcHN4c0RMSs2DpmVMK68al3/hCuzOSCfejJi8Y5L2hYN5QJsxFZ35UIWIOM2gbltqVgY9gNLskblUBugd9dWGdTkSWb4tXbS2xJ9n77n155drH3Op/rFW8I+zABlnvzF925F8MbVKEYonoruvmDH2/dC7AQ69ab7qu1h8l/DAKVqUq5tHrOW42pZLAmlWyI7OYpKzQ5i2ntbmaf87/YiU8+K9vxJQ2P2bQtdjaaX/XMSZJl7FOr9uD1I5CFxTuT/xYxzf5GcDR7re1LHv2ZvONS+mz8v00ZP36KnhayNEGKCAcdHH5aa2D9+uTcbgCLT0nSf/mGvVfPz4y8PtbTymjAlAd2pdH8YoyKMralFUwW2vFocfe2r1FA5RxBdzR92Sly55DyIrGPj7RRnumQlzKzH6z5uv/CKTETLc4v3FcLDMp6KKhIos3jM6VCMSabIzM//MZ/L3vjBmbxCZA2yPoGQCum418oPxgEnTZ0xeQe3lgS+4d9znOht7no3tlh1pbEE0C5z/Nq2M41FXqwChwu983OtdnRTnnKW5wj4YEv7FqEYinBH0/jujr7IOR6gOW9TP5DI4ufUShmOi5cM3GFKtXu/PNOCT8MZsIG7/PXr2e5aROpj/75xF/ufGbsG91oJiZCUDh6hLJiMHxVISoZD8+ltdgiZEfWacRiRqQAlLhDoXzDuYjcdaZYxiWtH+UWKa8WFl9LRbSUXJaQfTcF/IRtWp4Pr+fwN0oLRF5qaYuaaESN+li44qDZv/j0V8cuS9e68Exf8pKbglt+9bL4vefsuXxueun5fbU3IlDoYqEWRERUsMEOgOT1r5ZvAB9AKECNLq5QSPBcP7RYzsyLNXdmuBwXAkmbd2fX1rmEWU5E+7DPRfPEZYAYCp1nZZkyFkH/HW6CBcJFtXBJODQ+9Z//9v0lb3vjG/PFL1ydwaA2iZ0719c++b7Z6+dmmidHejoSlIyq8B3i4sfROceL0gyeDRtC0XpSCT7tD6H06VNcVgiw2TPe65wHTz6WYLODbMELyiPubB6xhwcsFrNQuU8vLbI50bn9bNlDFAFmHVfEeDA0tnDjv20cfi0RIgM05smp8G6PN2xYzytX0sK5F/TPaQ0tPBDSaMjgyC3v8j6QCXbPHPOi52GxdGixphRaxKc4o2/LgkeUsXoJriwaedMF4VTT2NPvsTOCgjm2TYSNPHp08zIVGgJKmhioEFuRg3AWYWVmHYViLKjV27esf0/vTCLqb9jwD7AXf1G3un79Rrlp07nqZ9+bWPXDKytXtWebJw7UdEwCMsPTynri2asjsF+e8ohOnFO2nN5PwuLiX6XWppzZZXPqSodVl2QwiyDblngGWVVxduwd9hHR8z7MeCEM8ievkg3Is9fF5O0m1sxMqhYuCVoj7RvedH7/7FPOWja/YQOLT3yC9LMeNH8T7N69u/XJ99e+1Z5pndPrz4KEUpkYHfkVrn0tUF4htP01ZXVuFPSXGEXtheKcT95nFkVl711kNbisXFzm3Mg37CU0mJKaD+EP7UzwnBGVbVCv5m1+G7MOglqliZHR7qVf+v7U+4kO7i22+PvcAACQvlEGwIfeNv03u56W/xDH1Uas5pTpCiVhp2DkRaic4O/MVFwQv6ECRcYxL3K1TuzE2McqlqRHfo2E8L/6U9iQ/L977x+U7S+GsZAfP2XAlWIGVYIxEVZ7s/utxgc/c0nrssRFkG/2/+ANkJzSBJEl/eVP7n7O5vtqn12Yq5w2iDQUFpiMOoCglItDrmRbORxD+3wQxOWpvY+tcOnBWYQ5WQKQlG3cZw3gs3Ks32fD+y7Y0L42ALt0LnjWg0o2Hye9wBpBIIcQyBgjo9h4winx37/1wpFH12Oj3Mjr9b4W/w/aAD5OIEPg4vfNvXHbU/qDCwvyRTqqQakuGAMAUDmET2UBex4jsG1E6Q86PvvMHjhPr9w4oKwFnBzdQp82y5z3vBEIpQDB/yadedb0h8sm13qqaJx3wTNJSVUEsg7INloj4fUHrKZ/+dsv1H8Oztfqf3NJf9Af4xJMDBpWgE/+9dwfbX9y8Gedtjgt6tMBGnUz6ULHYI5Bgp2GjUV78J3db7UeObkdFbu5qLj4ttknP3G3pV3YZtTsC3alcg2oIpe03A+VoFmZ6yIusWZcTGOZQBRAitBMN0GbK2HwyNBQ8D9rDq9c8eF/rNytFQCw2LABWMzf///eAL41SP9769bp0Su+rF84MSFOXejqFw4GWMuK948GJLUqvfPCw+GylyHfBOkQyjIrzz4EXcJOJnJT9NK824vCXbU6ciO7Er3ogmwNLRaekEWgY/f97DZzBKFAWOGBDLGjEtKDraa4Y/mqyk0fvLh+FxH1kk8W69eD/tBTb//5/wBO2rUWSt/S3AAAAABJRU5ErkJggg==";
    }
  });

  // src/lib/ui/settings/patches/shared.tsx
  function wrapOnPress(onPress, navigation2, renderPromise, screenOptions, props) {
    return () => _async_to_generator(function* () {
      if (onPress)
        return void onPress();
      var Component = yield renderPromise().then((m2) => m2.default);
      if (typeof screenOptions === "string") {
        screenOptions = {
          title: screenOptions
        };
      }
      navigation2 ??= tabsNavigationRef.getRootNavigationRef();
      navigation2.navigate("BUNNY_CUSTOM_PAGE", {
        ...screenOptions,
        render: () => /* @__PURE__ */ jsx(Component, {
          ...props
        })
      });
    })();
  }
  var tabsNavigationRef, CustomPageRenderer;
  var init_shared = __esm({
    "src/lib/ui/settings/patches/shared.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_async_to_generator();
      init_jsxRuntime();
      init_common();
      init_wrappers();
      init_components2();
      tabsNavigationRef = findByPropsLazy("getRootNavigationRef");
      CustomPageRenderer = React.memo(() => {
        var navigation2 = NavigationNative.useNavigation();
        var route = NavigationNative.useRoute();
        var { render: PageComponent, ...args } = route.params;
        React.useEffect(() => void navigation2.setOptions({
          ...args
        }), []);
        return /* @__PURE__ */ jsx(ErrorBoundary, {
          children: /* @__PURE__ */ jsx(PageComponent, {})
        });
      });
    }
  });

  // src/lib/ui/settings/patches/tabs.tsx
  function useIsFirstRender() {
    var firstRender = false;
    React.useEffect(() => void (firstRender = true), []);
    return firstRender;
  }
  function patchTabsUI(unpatches) {
    var getRows = () => Object.values(registeredSections).flatMap((sect) => sect.map((row) => ({
      [row.key]: {
        type: "pressable",
        // title was renamed to useTitle, both are here for compatibility (thanks kmiioo) https://codeberg.org/raincord/rain/pulls/52
        useTitle: row.title,
        title: row.title,
        icon: row.icon,
        IconComponent: () => /* @__PURE__ */ jsx(TableRow.Icon, {
          source: row.icon
        }),
        usePredicate: row.usePredicate,
        useTrailing: row.useTrailing,
        onPress: wrapOnPress(row.onPress, null, row.render, row.title()),
        withArrow: true,
        ...row.rawTabsConfig
      }
    }))).reduce((a, c2) => Object.assign(a, c2));
    var origRendererConfig = settingConstants.SETTING_RENDERER_CONFIG;
    var rendererConfigValue = settingConstants.SETTING_RENDERER_CONFIG;
    Object.defineProperty(settingConstants, "SETTING_RENDERER_CONFIG", {
      enumerable: true,
      configurable: true,
      get: () => ({
        ...rendererConfigValue,
        VendettaCustomPage: {
          type: "route",
          useTitle: () => Strings.BUNNY,
          title: () => Strings.BUNNY,
          screen: {
            route: "VendettaCustomPage",
            getComponent: () => CustomPageRenderer
          }
        },
        BUNNY_CUSTOM_PAGE: {
          type: "route",
          useTitle: () => Strings.BUNNY,
          title: () => Strings.BUNNY,
          screen: {
            route: "BUNNY_CUSTOM_PAGE",
            getComponent: () => CustomPageRenderer
          }
        },
        ...getRows()
      }),
      set: (v2) => rendererConfigValue = v2
    });
    unpatches.push(() => {
      Object.defineProperty(settingConstants, "SETTING_RENDERER_CONFIG", {
        value: origRendererConfig,
        writable: true,
        get: void 0,
        set: void 0
      });
    });
    try {
      unpatches.push(after("createList", createListModule, function(args, ret) {
        var [config] = args;
        if (config?.sections && Array.isArray(config.sections)) {
          var sections = config.sections;
          var accountSectionIndex = sections.findIndex((i) => i.settings?.includes("ACCOUNT"));
          if (accountSectionIndex !== -1) {
            var index = accountSectionIndex + 1;
            Object.keys(registeredSections).filter((s) => registeredSections[s].length > 0).forEach((sect) => {
              var alreadyExists = sections.some((s) => s.label === sect);
              if (!alreadyExists) {
                sections.splice(index++, 0, {
                  label: (sect === "Bunny" || sect === "Vendetta") ? "Plugin Settings" : sect,
                  title: (sect === "Bunny" || sect === "Vendetta") ? "Plugin Settings" : sect,
                  settings: registeredSections[sect].map((a) => a.key)
                });
              }
            });
          }
        }
        return ret;
      }));
    } catch (unused) {
      unpatches.push(after("default", SettingsOverviewScreen, (_2, ret) => {
        if (useIsFirstRender())
          return;
        var { sections } = findInReactTree(ret, (i) => i.props?.sections).props;
        var index = -~sections.findIndex((i) => i.settings.includes("ACCOUNT")) || 1;
        Object.keys(registeredSections).filter((s) => registeredSections[s].length > 0).forEach((sect) => {
          sections.splice(index++, 0, {
            label: (sect === "Bunny" || sect === "Vendetta") ? "Plugin Settings" : sect,
            title: (sect === "Bunny" || sect === "Vendetta") ? "Plugin Settings" : sect,
            settings: registeredSections[sect].map((a) => a.key)
          });
        });
      }));
    }
  }
  var settingConstants, createListModule, SettingsOverviewScreen;
  var init_tabs = __esm({
    "src/lib/ui/settings/patches/tabs.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_jsxRuntime();
      init_patcher();
      init_components();
      init_wrappers();
      init_settings2();
      init_i18n();
      init_shared();
      init_utils();
      settingConstants = findByPropsLazy("SETTING_RENDERER_CONFIG");
      createListModule = findByPropsLazy("createList");
      SettingsOverviewScreen = findByNameLazy("SettingsOverviewScreen", false);
    }
  });

  // src/lib/ui/settings/index.tsx
  var settings_exports2 = {};
  __export(settings_exports2, {
    patchSettings: () => patchSettings,
    registerSection: () => registerSection,
    registeredSections: () => registeredSections
  });
  function registerSection(section) {
    registeredSections[section.name] = section.items;
    return () => delete registeredSections[section.name];
  }
  function patchSettings() {
    var unpatches = new Array();
    patchTabsUI(unpatches);
    return () => unpatches.forEach((u) => u());
  }
  var registeredSections;
  var init_settings2 = __esm({
    "src/lib/ui/settings/index.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_tabs();
      registeredSections = {};
    }
  });

  // src/core/debug/safeMode.ts
  function isSafeMode() {
    return settings.safeMode?.enabled === true;
  }
  function toggleSafeMode2() {
    return _async_to_generator(function* ({ to = !isSafeMode(), reload = true } = {}) {
      var enabled = (settings.safeMode ??= {
        enabled: to
      }).enabled = to;
      var currentColor = getCurrentTheme();
      yield writeThemeToNative(enabled ? {} : currentColor?.data ?? {});
      if (reload)
        setTimeout(() => BundleUpdaterManager.reload(), 500);
    }).apply(this, arguments);
  }
  var init_safeMode = __esm({
    "src/core/debug/safeMode.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_async_to_generator();
      init_themes();
      init_modules();
      init_settings();
    }
  });

  // src/core/ui/settings/pages/General/Version.tsx
  function Version({ label, version: version2, icon }) {
    return /* @__PURE__ */ jsx(TableRow, {
      label,
      trailing: /* @__PURE__ */ jsx(TableRowTrailingText, {
        text: version2
      }),
      icon: /* @__PURE__ */ jsx(TableRow.Icon, {
        source: typeof icon === "string" ? findAssetId(icon) : icon
      }),
      onPress: () => {
        clipboard.setString(`${label} - ${version2}`);
        showToast.showCopyToClipboard();
      }
    });
  }
  var init_Version = __esm({
    "src/core/ui/settings/pages/General/Version.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_jsxRuntime();
      init_assets();
      init_common();
      init_components();
      init_toasts();
    }
  });

  // src/core/ui/settings/pages/General/About.tsx
  function About() {
    var debugInfo = getDebugInfo();
    useProxy(settings);
    var versions = [
      {
        label: Strings.BUNNY,
        version: debugInfo.bunny.version,
        icon: {
          uri: revenge_default
        }
      },
      {
        label: "Discord",
        version: `${debugInfo.discord.version} (${debugInfo.discord.build})`,
        icon: "ClydeIcon"
      },
      {
        label: "React",
        version: debugInfo.react.version,
        icon: "ScienceIcon"
      },
      {
        label: "React Native",
        version: debugInfo.react.nativeVersion,
        icon: "MobilePhoneIcon"
      },
      {
        label: Strings.BYTECODE,
        version: debugInfo.hermes.bytecodeVersion,
        icon: "TopicsIcon"
      }
    ];
    var platformInfo = [
      {
        label: Strings.LOADER,
        version: `${debugInfo.bunny.loader.name} (${debugInfo.bunny.loader.version})`,
        icon: "DownloadIcon"
      },
      {
        label: Strings.OPERATING_SYSTEM,
        version: `${debugInfo.os.name} ${debugInfo.os.version}`,
        icon: "ScreenIcon"
      },
      ...debugInfo.os.sdk ? [
        {
          label: "SDK",
          version: debugInfo.os.sdk,
          icon: "StaffBadgeIcon"
        }
      ] : [],
      {
        label: Strings.MANUFACTURER,
        version: debugInfo.device.manufacturer,
        icon: "WrenchIcon"
      },
      {
        label: Strings.BRAND,
        version: debugInfo.device.brand,
        icon: "PencilSparkleIcon"
      },
      {
        label: Strings.MODEL,
        version: debugInfo.device.model,
        icon: "MobilePhoneIcon"
      },
      {
        label: import_react_native16.Platform.select({
          android: Strings.CODENAME,
          ios: Strings.MACHINE_ID
        }),
        version: debugInfo.device.codename,
        icon: "TagIcon"
      }
    ];
    return /* @__PURE__ */ jsx(import_react_native16.ScrollView, {
      style: {
        flex: 1
      },
      contentContainerStyle: {
        paddingBottom: 38
      },
      children: /* @__PURE__ */ jsxs(Stack, {
        style: {
          paddingVertical: 24,
          paddingHorizontal: 12
        },
        spacing: 24,
        children: [
          /* @__PURE__ */ jsx(TableRowGroup, {
            title: Strings.VERSIONS,
            children: versions.map((v2) => /* @__PURE__ */ jsx(Version, {
              label: v2.label,
              version: v2.version,
              icon: v2.icon
            }))
          }),
          /* @__PURE__ */ jsx(TableRowGroup, {
            title: Strings.PLATFORM,
            children: platformInfo.map((p) => /* @__PURE__ */ jsx(Version, {
              label: p.label,
              version: p.version,
              icon: p.icon
            }))
          })
        ]
      })
    });
  }
  var import_react_native16;
  var init_About = __esm({
    "src/core/ui/settings/pages/General/About.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_jsxRuntime();
      init_i18n();
      init_settings3();
      init_Version();
      init_storage();
      init_debug();
      init_settings();
      init_components();
      import_react_native16 = __toESM(require_react_native());
    }
  });

  // src/lib/ui/alerts.ts
  var alerts_exports = {};
  __export(alerts_exports, {
    dismissAlert: () => dismissAlert,
    openAlert: () => openAlert
  });
  var openAlert, dismissAlert;
  var init_alerts = __esm({
    "src/lib/ui/alerts.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_lazy();
      init_metro();
      ({ openAlert, dismissAlert } = lazyDestructure(() => findByProps("openAlert", "dismissAlert")));
    }
  });

  // src/core/ui/settings/pages/General/index.tsx
  var General_exports = {};
  __export(General_exports, {
    default: () => General
  });
  function General() {
    useProxy(settings);
    var debugInfo = getDebugInfo();
    var navigation2 = NavigationNative.useNavigation();
    return /* @__PURE__ */ jsx(import_react_native17.ScrollView, {
      style: {
        flex: 1
      },
      contentContainerStyle: {
        paddingBottom: 38
      },
      children: /* @__PURE__ */ jsxs(Stack, {
        style: {
          paddingVertical: 24,
          paddingHorizontal: 12
        },
        spacing: 24,
        children: [
          /* @__PURE__ */ jsxs(TableRowGroup, {
            title: Strings.INFO,
            children: [
              /* @__PURE__ */ jsx(TableRow, {
                label: Strings.BUNNY,
                icon: /* @__PURE__ */ jsx(TableRow.Icon, {
                  source: {
                    uri: revenge_default
                  }
                }),
                trailing: /* @__PURE__ */ jsx(TableRow.TrailingText, {
                  text: debugInfo.bunny.version
                })
              }),
              /* @__PURE__ */ jsx(TableRow, {
                label: "Discord",
                icon: /* @__PURE__ */ jsx(TableRow.Icon, {
                  source: findAssetId("ClydeIcon")
                }),
                trailing: /* @__PURE__ */ jsx(TableRow.TrailingText, {
                  text: `${debugInfo.discord.version} (${debugInfo.discord.build})`
                })
              }),
              /* @__PURE__ */ jsx(TableRow, {
                arrow: true,
                label: Strings.ABOUT,
                icon: /* @__PURE__ */ jsx(TableRow.Icon, {
                  source: findAssetId("CircleInformationIcon-primary")
                }),
                onPress: () => navigation2.push("BUNNY_CUSTOM_PAGE", {
                  title: Strings.ABOUT,
                  render: () => /* @__PURE__ */ jsx(About, {})
                })
              })
            ]
          }),
          null,
          /* @__PURE__ */ jsxs(TableRowGroup, {
            title: Strings.ACTIONS,
            children: [
              /* @__PURE__ */ jsx(TableRow, {
                label: Strings.RELOAD_DISCORD,
                icon: /* @__PURE__ */ jsx(TableRow.Icon, {
                  source: findAssetId("RetryIcon")
                }),
                onPress: () => BundleUpdaterManager.reload()
              }),
              /* @__PURE__ */ jsx(TableSwitchRow, {
                label: Strings.SAFE_MODE,
                subLabel: settings.safeMode?.enabled ? Strings.RELOAD_IN_NORMAL_MODE_DESC : Strings.RELOAD_IN_SAFE_MODE_DESC,
                icon: /* @__PURE__ */ jsx(TableRow.Icon, {
                  source: findAssetId("ShieldIcon")
                }),
                value: isSafeMode(),
                onValueChange: (to) => {
                  toggleSafeMode2({
                    to,
                    reload: false
                  });
                  openAlert("bunny-reload-safe-mode", /* @__PURE__ */ jsx(AlertModal, {
                    title: "Reload now?",
                    content: !to ? "All add-ons will load normally." : "All add-ons will be temporarily disabled upon reload.",
                    actions: /* @__PURE__ */ jsxs(AlertActions, {
                      children: [
                        /* @__PURE__ */ jsx(AlertActionButton, {
                          text: "Reload Now",
                          variant: "destructive",
                          onPress: () => BundleUpdaterManager.reload()
                        }),
                        /* @__PURE__ */ jsx(AlertActionButton, {
                          text: "Later",
                          variant: "secondary"
                        })
                      ]
                    })
                  }));
                }
              }),
              /* @__PURE__ */ jsx(TableSwitchRow, {
                label: Strings.DEVELOPER_SETTINGS,
                icon: /* @__PURE__ */ jsx(TableRow.Icon, {
                  source: findAssetId("WrenchIcon")
                }),
                value: settings.developerSettings,
                onValueChange: (v2) => {
                  settings.developerSettings = v2;
                }
              })
            ]
          }),
          /* @__PURE__ */ jsx(TableRowGroup, {
            title: Strings.MISCELLANEOUS,
            children: /* @__PURE__ */ jsx(TableSwitchRow, {
              label: Strings.SETTINGS_ACTIVATE_DISCORD_EXPERIMENTS,
              subLabel: Strings.SETTINGS_ACTIVATE_DISCORD_EXPERIMENTS_DESC,
              icon: /* @__PURE__ */ jsx(TableRow.Icon, {
                source: findAssetId("WrenchIcon")
              }),
              value: settings.enableDiscordDeveloperSettings,
              onValueChange: (v2) => {
                settings.enableDiscordDeveloperSettings = v2;
              }
            })
          })
        ]
      })
    });
  }
  var import_react_native17;
  var init_General = __esm({
    "src/core/ui/settings/pages/General/index.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_jsxRuntime();
      init_safeMode();
      init_i18n();
      init_settings3();
      init_About();
      init_storage();
      init_assets();
      init_debug();
      init_modules();
      init_settings();
      init_alerts();
      init_constants();
      init_common();
      init_components();
      import_react_native17 = __toESM(require_react_native());
    }
  });

  // src/lib/utils/isValidHttpUrl.ts
  function isValidHttpUrl(input) {
    var url2;
    try {
      url2 = new URL(input);
    } catch (unused) {
      return false;
    }
    return url2.protocol === "http:" || url2.protocol === "https:";
  }
  var init_isValidHttpUrl = __esm({
    "src/lib/utils/isValidHttpUrl.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
    }
  });

  // node_modules/fuzzysort/fuzzysort.js
  var require_fuzzysort = __commonJS({
    "node_modules/fuzzysort/fuzzysort.js"(exports, module) {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_call_super();
      init_class_call_check();
      init_create_class();
      init_inherits();
      init_wrap_native_super();
      ((root, UMD) => {
        if (typeof define === "function" && define.amd)
          define([], UMD);
        else if (typeof module === "object" && module.exports)
          module.exports = UMD();
        else
          root["fuzzysort"] = UMD();
      })(exports, (_2) => {
        "use strict";
        var single = (search, target) => {
          if (!search || !target)
            return NULL;
          var preparedSearch = getPreparedSearch(search);
          if (!isPrepared(target))
            target = getPrepared(target);
          var searchBitflags = preparedSearch.bitflags;
          if ((searchBitflags & target._bitflags) !== searchBitflags)
            return NULL;
          return algorithm(preparedSearch, target);
        };
        var go = (search, targets, options) => {
          if (!search)
            return options?.all ? all(targets, options) : noResults;
          var preparedSearch = getPreparedSearch(search);
          var searchBitflags = preparedSearch.bitflags;
          var containsSpace = preparedSearch.containsSpace;
          var threshold = denormalizeScore(options?.threshold || 0);
          var limit = options?.limit || INFINITY;
          var resultsLen = 0;
          var limitedCount = 0;
          var targetsLen = targets.length;
          function push_result(result2) {
            if (resultsLen < limit) {
              q3.add(result2);
              ++resultsLen;
            } else {
              ++limitedCount;
              if (result2._score > q3.peek()._score)
                q3.replaceTop(result2);
            }
          }
          if (options?.key) {
            var key = options.key;
            for (var i = 0; i < targetsLen; ++i) {
              var obj = targets[i];
              var target = getValue(obj, key);
              if (!target)
                continue;
              if (!isPrepared(target))
                target = getPrepared(target);
              if ((searchBitflags & target._bitflags) !== searchBitflags)
                continue;
              var result = algorithm(preparedSearch, target);
              if (result === NULL)
                continue;
              if (result._score < threshold)
                continue;
              result.obj = obj;
              push_result(result);
            }
          } else if (options?.keys) {
            var keys = options.keys;
            var keysLen = keys.length;
            outer:
              for (var i = 0; i < targetsLen; ++i) {
                var obj = targets[i];
                {
                  var keysBitflags = 0;
                  for (var keyI = 0; keyI < keysLen; ++keyI) {
                    var key = keys[keyI];
                    var target = getValue(obj, key);
                    if (!target) {
                      tmpTargets[keyI] = noTarget;
                      continue;
                    }
                    if (!isPrepared(target))
                      target = getPrepared(target);
                    tmpTargets[keyI] = target;
                    keysBitflags |= target._bitflags;
                  }
                  if ((searchBitflags & keysBitflags) !== searchBitflags)
                    continue;
                }
                if (containsSpace)
                  for (var i1 = 0; i1 < preparedSearch.spaceSearches.length; i1++)
                    keysSpacesBestScores[i1] = NEGATIVE_INFINITY2;
                for (var keyI = 0; keyI < keysLen; ++keyI) {
                  target = tmpTargets[keyI];
                  if (target === noTarget) {
                    tmpResults[keyI] = noTarget;
                    continue;
                  }
                  tmpResults[keyI] = algorithm(
                    preparedSearch,
                    target,
                    /*allowSpaces=*/
                    false,
                    /*allowPartialMatch=*/
                    containsSpace
                  );
                  if (tmpResults[keyI] === NULL) {
                    tmpResults[keyI] = noTarget;
                    continue;
                  }
                  if (containsSpace)
                    for (var i2 = 0; i2 < preparedSearch.spaceSearches.length; i2++) {
                      if (allowPartialMatchScores[i2] > -1e3) {
                        if (keysSpacesBestScores[i2] > NEGATIVE_INFINITY2) {
                          var tmp = (keysSpacesBestScores[i2] + allowPartialMatchScores[i2]) / 4;
                          if (tmp > keysSpacesBestScores[i2])
                            keysSpacesBestScores[i2] = tmp;
                        }
                      }
                      if (allowPartialMatchScores[i2] > keysSpacesBestScores[i2])
                        keysSpacesBestScores[i2] = allowPartialMatchScores[i2];
                    }
                }
                if (containsSpace) {
                  for (var i3 = 0; i3 < preparedSearch.spaceSearches.length; i3++) {
                    if (keysSpacesBestScores[i3] === NEGATIVE_INFINITY2)
                      continue outer;
                  }
                } else {
                  var hasAtLeast1Match = false;
                  for (var i4 = 0; i4 < keysLen; i4++) {
                    if (tmpResults[i4]._score !== NEGATIVE_INFINITY2) {
                      hasAtLeast1Match = true;
                      break;
                    }
                  }
                  if (!hasAtLeast1Match)
                    continue;
                }
                var objResults = new KeysResult(keysLen);
                for (var i5 = 0; i5 < keysLen; i5++) {
                  objResults[i5] = tmpResults[i5];
                }
                if (containsSpace) {
                  var score = 0;
                  for (var i6 = 0; i6 < preparedSearch.spaceSearches.length; i6++)
                    score += keysSpacesBestScores[i6];
                } else {
                  var score = NEGATIVE_INFINITY2;
                  for (var i7 = 0; i7 < keysLen; i7++) {
                    var result = objResults[i7];
                    if (result._score > -1e3) {
                      if (score > NEGATIVE_INFINITY2) {
                        var tmp = (score + result._score) / 4;
                        if (tmp > score)
                          score = tmp;
                      }
                    }
                    if (result._score > score)
                      score = result._score;
                  }
                }
                objResults.obj = obj;
                objResults._score = score;
                if (options?.scoreFn) {
                  score = options.scoreFn(objResults);
                  if (!score)
                    continue;
                  score = denormalizeScore(score);
                  objResults._score = score;
                }
                if (score < threshold)
                  continue;
                push_result(objResults);
              }
          } else {
            for (var i = 0; i < targetsLen; ++i) {
              var target = targets[i];
              if (!target)
                continue;
              if (!isPrepared(target))
                target = getPrepared(target);
              if ((searchBitflags & target._bitflags) !== searchBitflags)
                continue;
              var result = algorithm(preparedSearch, target);
              if (result === NULL)
                continue;
              if (result._score < threshold)
                continue;
              push_result(result);
            }
          }
          if (resultsLen === 0)
            return noResults;
          var results = new Array(resultsLen);
          for (var i = resultsLen - 1; i >= 0; --i)
            results[i] = q3.poll();
          results.total = resultsLen + limitedCount;
          return results;
        };
        var highlight = (result, open = "<b>", close = "</b>") => {
          var callback = typeof open === "function" ? open : void 0;
          var target = result.target;
          var targetLen = target.length;
          var indexes = result.indexes;
          var highlighted = "";
          var matchI = 0;
          var indexesI = 0;
          var opened = false;
          var parts = [];
          for (var i = 0; i < targetLen; ++i) {
            var char = target[i];
            if (indexes[indexesI] === i) {
              ++indexesI;
              if (!opened) {
                opened = true;
                if (callback) {
                  parts.push(highlighted);
                  highlighted = "";
                } else {
                  highlighted += open;
                }
              }
              if (indexesI === indexes.length) {
                if (callback) {
                  highlighted += char;
                  parts.push(callback(highlighted, matchI++));
                  highlighted = "";
                  parts.push(target.substr(i + 1));
                } else {
                  highlighted += char + close + target.substr(i + 1);
                }
                break;
              }
            } else {
              if (opened) {
                opened = false;
                if (callback) {
                  parts.push(callback(highlighted, matchI++));
                  highlighted = "";
                } else {
                  highlighted += close;
                }
              }
            }
            highlighted += char;
          }
          return callback ? parts : highlighted;
        };
        var prepare = (target) => {
          if (typeof target === "number")
            target = "" + target;
          else if (typeof target !== "string")
            target = "";
          var info = prepareLowerInfo(target);
          return new_result(target, {
            _targetLower: info._lower,
            _targetLowerCodes: info.lowerCodes,
            _bitflags: info.bitflags
          });
        };
        var cleanup3 = () => {
          preparedCache.clear();
          preparedSearchCache.clear();
        };
        var Result = /* @__PURE__ */ function() {
          function Result2() {
            _class_call_check(this, Result2);
          }
          _create_class(Result2, [
            {
              key: "indexes",
              get: function get() {
                return this._indexes.slice(0, this._indexes.len).sort((a, b3) => a - b3);
              }
            },
            {
              key: "indexes",
              set: function set(indexes) {
                return this._indexes = indexes;
              }
            },
            {
              key: "highlight",
              value: function value(open, close) {
                return highlight(this, open, close);
              }
            },
            {
              key: "score",
              get: function get() {
                return normalizeScore(this._score);
              }
            },
            {
              key: "score",
              set: function set(score) {
                this._score = denormalizeScore(score);
              }
            }
          ]);
          return Result2;
        }();
        var KeysResult = /* @__PURE__ */ function(Array1) {
          _inherits(KeysResult2, Array1);
          function KeysResult2() {
            _class_call_check(this, KeysResult2);
            return _call_super(this, KeysResult2, arguments);
          }
          _create_class(KeysResult2, [
            {
              key: "score",
              get: function get() {
                return normalizeScore(this._score);
              }
            },
            {
              key: "score",
              set: function set(score) {
                this._score = denormalizeScore(score);
              }
            }
          ]);
          return KeysResult2;
        }(_wrap_native_super(Array));
        var new_result = (target, options) => {
          var result = new Result();
          result["target"] = target;
          result["obj"] = options.obj ?? NULL;
          result._score = options._score ?? NEGATIVE_INFINITY2;
          result._indexes = options._indexes ?? [];
          result._targetLower = options._targetLower ?? "";
          result._targetLowerCodes = options._targetLowerCodes ?? NULL;
          result._nextBeginningIndexes = options._nextBeginningIndexes ?? NULL;
          result._bitflags = options._bitflags ?? 0;
          return result;
        };
        var normalizeScore = (score) => {
          if (score === NEGATIVE_INFINITY2)
            return 0;
          if (score > 1)
            return score;
          return Math.E ** (((-score + 1) ** 0.04307 - 1) * -2);
        };
        var denormalizeScore = (normalizedScore) => {
          if (normalizedScore === 0)
            return NEGATIVE_INFINITY2;
          if (normalizedScore > 1)
            return normalizedScore;
          return 1 - Math.pow(Math.log(normalizedScore) / -2 + 1, 1 / 0.04307);
        };
        var prepareSearch = (search) => {
          if (typeof search === "number")
            search = "" + search;
          else if (typeof search !== "string")
            search = "";
          search = search.trim();
          var info = prepareLowerInfo(search);
          var spaceSearches = [];
          if (info.containsSpace) {
            var searches = search.split(/\s+/);
            searches = [
              ...new Set(searches)
            ];
            for (var i = 0; i < searches.length; i++) {
              if (searches[i] === "")
                continue;
              var _info = prepareLowerInfo(searches[i]);
              spaceSearches.push({
                lowerCodes: _info.lowerCodes,
                _lower: searches[i].toLowerCase(),
                containsSpace: false
              });
            }
          }
          return {
            lowerCodes: info.lowerCodes,
            _lower: info._lower,
            containsSpace: info.containsSpace,
            bitflags: info.bitflags,
            spaceSearches
          };
        };
        var getPrepared = (target) => {
          if (target.length > 999)
            return prepare(target);
          var targetPrepared = preparedCache.get(target);
          if (targetPrepared !== void 0)
            return targetPrepared;
          targetPrepared = prepare(target);
          preparedCache.set(target, targetPrepared);
          return targetPrepared;
        };
        var getPreparedSearch = (search) => {
          if (search.length > 999)
            return prepareSearch(search);
          var searchPrepared = preparedSearchCache.get(search);
          if (searchPrepared !== void 0)
            return searchPrepared;
          searchPrepared = prepareSearch(search);
          preparedSearchCache.set(search, searchPrepared);
          return searchPrepared;
        };
        var all = (targets, options) => {
          var results = [];
          results.total = targets.length;
          var limit = options?.limit || INFINITY;
          if (options?.key) {
            for (var i = 0; i < targets.length; i++) {
              var obj = targets[i];
              var target = getValue(obj, options.key);
              if (target == NULL)
                continue;
              if (!isPrepared(target))
                target = getPrepared(target);
              var result = new_result(target.target, {
                _score: target._score,
                obj
              });
              results.push(result);
              if (results.length >= limit)
                return results;
            }
          } else if (options?.keys) {
            for (var i = 0; i < targets.length; i++) {
              var obj = targets[i];
              var objResults = new KeysResult(options.keys.length);
              for (var keyI = options.keys.length - 1; keyI >= 0; --keyI) {
                var target = getValue(obj, options.keys[keyI]);
                if (!target) {
                  objResults[keyI] = noTarget;
                  continue;
                }
                if (!isPrepared(target))
                  target = getPrepared(target);
                target._score = NEGATIVE_INFINITY2;
                target._indexes.len = 0;
                objResults[keyI] = target;
              }
              objResults.obj = obj;
              objResults._score = NEGATIVE_INFINITY2;
              results.push(objResults);
              if (results.length >= limit)
                return results;
            }
          } else {
            for (var i = 0; i < targets.length; i++) {
              var target = targets[i];
              if (target == NULL)
                continue;
              if (!isPrepared(target))
                target = getPrepared(target);
              target._score = NEGATIVE_INFINITY2;
              target._indexes.len = 0;
              results.push(target);
              if (results.length >= limit)
                return results;
            }
          }
          return results;
        };
        var algorithm = (preparedSearch, prepared, allowSpaces = false, allowPartialMatch = false) => {
          if (allowSpaces === false && preparedSearch.containsSpace)
            return algorithmSpaces(preparedSearch, prepared, allowPartialMatch);
          var searchLower = preparedSearch._lower;
          var searchLowerCodes = preparedSearch.lowerCodes;
          var searchLowerCode = searchLowerCodes[0];
          var targetLowerCodes = prepared._targetLowerCodes;
          var searchLen = searchLowerCodes.length;
          var targetLen = targetLowerCodes.length;
          var searchI = 0;
          var targetI = 0;
          var matchesSimpleLen = 0;
          for (; ; ) {
            var isMatch = searchLowerCode === targetLowerCodes[targetI];
            if (isMatch) {
              matchesSimple[matchesSimpleLen++] = targetI;
              ++searchI;
              if (searchI === searchLen)
                break;
              searchLowerCode = searchLowerCodes[searchI];
            }
            ++targetI;
            if (targetI >= targetLen)
              return NULL;
          }
          var searchI = 0;
          var successStrict = false;
          var matchesStrictLen = 0;
          var nextBeginningIndexes = prepared._nextBeginningIndexes;
          if (nextBeginningIndexes === NULL)
            nextBeginningIndexes = prepared._nextBeginningIndexes = prepareNextBeginningIndexes(prepared.target);
          targetI = matchesSimple[0] === 0 ? 0 : nextBeginningIndexes[matchesSimple[0] - 1];
          var backtrackCount = 0;
          if (targetI !== targetLen)
            for (; ; ) {
              if (targetI >= targetLen) {
                if (searchI <= 0)
                  break;
                ++backtrackCount;
                if (backtrackCount > 200)
                  break;
                --searchI;
                var lastMatch = matchesStrict[--matchesStrictLen];
                targetI = nextBeginningIndexes[lastMatch];
              } else {
                var isMatch = searchLowerCodes[searchI] === targetLowerCodes[targetI];
                if (isMatch) {
                  matchesStrict[matchesStrictLen++] = targetI;
                  ++searchI;
                  if (searchI === searchLen) {
                    successStrict = true;
                    break;
                  }
                  ++targetI;
                } else {
                  targetI = nextBeginningIndexes[targetI];
                }
              }
            }
          var substringIndex = searchLen <= 1 ? -1 : prepared._targetLower.indexOf(searchLower, matchesSimple[0]);
          var isSubstring = !!~substringIndex;
          var isSubstringBeginning = !isSubstring ? false : substringIndex === 0 || prepared._nextBeginningIndexes[substringIndex - 1] === substringIndex;
          if (isSubstring && !isSubstringBeginning) {
            for (var i = 0; i < nextBeginningIndexes.length; i = nextBeginningIndexes[i]) {
              if (i <= substringIndex)
                continue;
              for (var s = 0; s < searchLen; s++)
                if (searchLowerCodes[s] !== prepared._targetLowerCodes[i + s])
                  break;
              if (s === searchLen) {
                substringIndex = i;
                isSubstringBeginning = true;
                break;
              }
            }
          }
          var calculateScore = (matches) => {
            var score2 = 0;
            var extraMatchGroupCount = 0;
            for (var i2 = 1; i2 < searchLen; ++i2) {
              if (matches[i2] - matches[i2 - 1] !== 1) {
                score2 -= matches[i2];
                ++extraMatchGroupCount;
              }
            }
            var unmatchedDistance = matches[searchLen - 1] - matches[0] - (searchLen - 1);
            score2 -= (12 + unmatchedDistance) * extraMatchGroupCount;
            if (matches[0] !== 0)
              score2 -= matches[0] * matches[0] * 0.2;
            if (!successStrict) {
              score2 *= 1e3;
            } else {
              var uniqueBeginningIndexes = 1;
              for (var i2 = nextBeginningIndexes[0]; i2 < targetLen; i2 = nextBeginningIndexes[i2])
                ++uniqueBeginningIndexes;
              if (uniqueBeginningIndexes > 24)
                score2 *= (uniqueBeginningIndexes - 24) * 10;
            }
            score2 -= (targetLen - searchLen) / 2;
            if (isSubstring)
              score2 /= 1 + searchLen * searchLen * 1;
            if (isSubstringBeginning)
              score2 /= 1 + searchLen * searchLen * 1;
            score2 -= (targetLen - searchLen) / 2;
            return score2;
          };
          if (!successStrict) {
            if (isSubstring)
              for (var i = 0; i < searchLen; ++i)
                matchesSimple[i] = substringIndex + i;
            var matchesBest = matchesSimple;
            var score = calculateScore(matchesBest);
          } else {
            if (isSubstringBeginning) {
              for (var i = 0; i < searchLen; ++i)
                matchesSimple[i] = substringIndex + i;
              var matchesBest = matchesSimple;
              var score = calculateScore(matchesSimple);
            } else {
              var matchesBest = matchesStrict;
              var score = calculateScore(matchesStrict);
            }
          }
          prepared._score = score;
          for (var i = 0; i < searchLen; ++i)
            prepared._indexes[i] = matchesBest[i];
          prepared._indexes.len = searchLen;
          var result = new Result();
          result.target = prepared.target;
          result._score = prepared._score;
          result._indexes = prepared._indexes;
          return result;
        };
        var algorithmSpaces = (preparedSearch, target, allowPartialMatch) => {
          var seen_indexes = /* @__PURE__ */ new Set();
          var score = 0;
          var result = NULL;
          var first_seen_index_last_search = 0;
          var searches = preparedSearch.spaceSearches;
          var searchesLen = searches.length;
          var changeslen = 0;
          var resetNextBeginningIndexes = () => {
            for (var i3 = changeslen - 1; i3 >= 0; i3--)
              target._nextBeginningIndexes[nextBeginningIndexesChanges[i3 * 2 + 0]] = nextBeginningIndexesChanges[i3 * 2 + 1];
          };
          var hasAtLeast1Match = false;
          for (var i = 0; i < searchesLen; ++i) {
            allowPartialMatchScores[i] = NEGATIVE_INFINITY2;
            var search = searches[i];
            result = algorithm(search, target);
            if (allowPartialMatch) {
              if (result === NULL)
                continue;
              hasAtLeast1Match = true;
            } else {
              if (result === NULL) {
                resetNextBeginningIndexes();
                return NULL;
              }
            }
            var isTheLastSearch = i === searchesLen - 1;
            if (!isTheLastSearch) {
              var indexes = result._indexes;
              var indexesIsConsecutiveSubstring = true;
              for (var i1 = 0; i1 < indexes.len - 1; i1++) {
                if (indexes[i1 + 1] - indexes[i1] !== 1) {
                  indexesIsConsecutiveSubstring = false;
                  break;
                }
              }
              if (indexesIsConsecutiveSubstring) {
                var newBeginningIndex = indexes[indexes.len - 1] + 1;
                var toReplace = target._nextBeginningIndexes[newBeginningIndex - 1];
                for (var i2 = newBeginningIndex - 1; i2 >= 0; i2--) {
                  if (toReplace !== target._nextBeginningIndexes[i2])
                    break;
                  target._nextBeginningIndexes[i2] = newBeginningIndex;
                  nextBeginningIndexesChanges[changeslen * 2 + 0] = i2;
                  nextBeginningIndexesChanges[changeslen * 2 + 1] = toReplace;
                  changeslen++;
                }
              }
            }
            score += result._score / searchesLen;
            allowPartialMatchScores[i] = result._score / searchesLen;
            if (result._indexes[0] < first_seen_index_last_search) {
              score -= (first_seen_index_last_search - result._indexes[0]) * 2;
            }
            first_seen_index_last_search = result._indexes[0];
            for (var j = 0; j < result._indexes.len; ++j)
              seen_indexes.add(result._indexes[j]);
          }
          if (allowPartialMatch && !hasAtLeast1Match)
            return NULL;
          resetNextBeginningIndexes();
          var allowSpacesResult = algorithm(
            preparedSearch,
            target,
            /*allowSpaces=*/
            true
          );
          if (allowSpacesResult !== NULL && allowSpacesResult._score > score) {
            if (allowPartialMatch) {
              for (var i = 0; i < searchesLen; ++i) {
                allowPartialMatchScores[i] = allowSpacesResult._score / searchesLen;
              }
            }
            return allowSpacesResult;
          }
          if (allowPartialMatch)
            result = target;
          result._score = score;
          var i = 0;
          for (var index of seen_indexes)
            result._indexes[i++] = index;
          result._indexes.len = i;
          return result;
        };
        var remove_accents = (str) => str.replace(RegExp("[\\u0041-\\u005A\\u0061-\\u007A\\u00AA\\u00BA\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02B8\\u02E0-\\u02E4\\u1D00-\\u1D25\\u1D2C-\\u1D5C\\u1D62-\\u1D65\\u1D6B-\\u1D77\\u1D79-\\u1DBE\\u1E00-\\u1EFF\\u2071\\u207F\\u2090-\\u209C\\u212A-\\u212B\\u2132\\u214E\\u2160-\\u2188\\u2C60-\\u2C7F\\uA722-\\uA787\\uA78B-\\uA7DC\\uA7F1-\\uA7FF\\uAB30-\\uAB5A\\uAB5C-\\uAB64\\uAB66-\\uAB69\\uFB00-\\uFB06\\uFF21-\\uFF3A\\uFF41-\\uFF5A\\u{10780}-\\u{10785}\\u{10787}-\\u{107B0}\\u{107B2}-\\u{107BA}\\u{1DF00}-\\u{1DF1E}\\u{1DF25}-\\u{1DF2A}]+", "gu"), (match) => match.normalize("NFD")).replace(/[\u0300-\u036f]/g, "");
        var prepareLowerInfo = (str) => {
          str = remove_accents(str);
          var strLen = str.length;
          var lower = str.toLowerCase();
          var lowerCodes = [];
          var bitflags = 0;
          var containsSpace = false;
          for (var i = 0; i < strLen; ++i) {
            var lowerCode = lowerCodes[i] = lower.charCodeAt(i);
            if (lowerCode === 32) {
              containsSpace = true;
              continue;
            }
            var bit = lowerCode >= 97 && lowerCode <= 122 ? lowerCode - 97 : lowerCode >= 48 && lowerCode <= 57 ? 26 : lowerCode <= 127 ? 30 : 31;
            bitflags |= 1 << bit;
          }
          return {
            lowerCodes,
            bitflags,
            containsSpace,
            _lower: lower
          };
        };
        var prepareBeginningIndexes = (target) => {
          var targetLen = target.length;
          var beginningIndexes = [];
          var beginningIndexesLen = 0;
          var wasUpper = false;
          var wasAlphanum = false;
          for (var i = 0; i < targetLen; ++i) {
            var targetCode = target.charCodeAt(i);
            var isUpper = targetCode >= 65 && targetCode <= 90;
            var isAlphanum = isUpper || targetCode >= 97 && targetCode <= 122 || targetCode >= 48 && targetCode <= 57;
            var isBeginning = isUpper && !wasUpper || !wasAlphanum || !isAlphanum;
            wasUpper = isUpper;
            wasAlphanum = isAlphanum;
            if (isBeginning)
              beginningIndexes[beginningIndexesLen++] = i;
          }
          return beginningIndexes;
        };
        var prepareNextBeginningIndexes = (target) => {
          target = remove_accents(target);
          var targetLen = target.length;
          var beginningIndexes = prepareBeginningIndexes(target);
          var nextBeginningIndexes = [];
          var lastIsBeginning = beginningIndexes[0];
          var lastIsBeginningI = 0;
          for (var i = 0; i < targetLen; ++i) {
            if (lastIsBeginning > i) {
              nextBeginningIndexes[i] = lastIsBeginning;
            } else {
              lastIsBeginning = beginningIndexes[++lastIsBeginningI];
              nextBeginningIndexes[i] = lastIsBeginning === void 0 ? targetLen : lastIsBeginning;
            }
          }
          return nextBeginningIndexes;
        };
        var preparedCache = /* @__PURE__ */ new Map();
        var preparedSearchCache = /* @__PURE__ */ new Map();
        var matchesSimple = [];
        var matchesStrict = [];
        var nextBeginningIndexesChanges = [];
        var keysSpacesBestScores = [];
        var allowPartialMatchScores = [];
        var tmpTargets = [];
        var tmpResults = [];
        var getValue = (obj, prop) => {
          var tmp = obj[prop];
          if (tmp !== void 0)
            return tmp;
          if (typeof prop === "function")
            return prop(obj);
          var segs = prop;
          if (!Array.isArray(prop))
            segs = prop.split(".");
          var len = segs.length;
          var i = -1;
          while (obj && ++i < len)
            obj = obj[segs[i]];
          return obj;
        };
        var isPrepared = (x2) => {
          return typeof x2 === "object" && typeof x2._bitflags === "number";
        };
        var INFINITY = Infinity;
        var NEGATIVE_INFINITY2 = -INFINITY;
        var noResults = [];
        noResults.total = 0;
        var NULL = null;
        var noTarget = prepare("");
        var fastpriorityqueue = (r) => {
          var e = [], o = 0, a = {}, v2 = (r2) => {
            for (var a2 = 0, v3 = e[a2], c2 = 1; c2 < o; ) {
              var s = c2 + 1;
              a2 = c2, s < o && e[s]._score < e[c2]._score && (a2 = s), e[a2 - 1 >> 1] = e[a2], c2 = 1 + (a2 << 1);
            }
            for (var f = a2 - 1 >> 1; a2 > 0 && v3._score < e[f]._score; f = (a2 = f) - 1 >> 1)
              e[a2] = e[f];
            e[a2] = v3;
          };
          return a.add = (r2) => {
            var a2 = o;
            e[o++] = r2;
            for (var v3 = a2 - 1 >> 1; a2 > 0 && r2._score < e[v3]._score; v3 = (a2 = v3) - 1 >> 1)
              e[a2] = e[v3];
            e[a2] = r2;
          }, a.poll = (r2) => {
            if (0 !== o) {
              var a2 = e[0];
              return e[0] = e[--o], v2(), a2;
            }
          }, a.peek = (r2) => {
            if (0 !== o)
              return e[0];
          }, a.replaceTop = (r2) => {
            e[0] = r2, v2();
          }, a;
        };
        var q3 = fastpriorityqueue();
        return {
          "single": single,
          "go": go,
          "prepare": prepare,
          "cleanup": cleanup3
        };
      });
    }
  });

  // src/core/ui/components/AddonPage.tsx
  function InputAlert(props) {
    var [value, setValue] = React.useState("");
    var [error, setError] = React.useState("");
    var [isFetching, setIsFetching] = React.useState(false);
    function onConfirmWrapper() {
      setIsFetching(true);
      props.fetchFn(value).then(() => dismissAlert("AddonInputAlert")).catch((e) => e instanceof Error ? setError(e.message) : String(e)).finally(() => setIsFetching(false));
    }
    return /* @__PURE__ */ jsx(AlertModal, {
      title: props.label,
      content: "Type in the source URL you want to install from:",
      extraContent: /* @__PURE__ */ jsxs(Stack, {
        style: {
          marginTop: -12
        },
        children: [
          /* @__PURE__ */ jsx(TextInput, {
            autoFocus: true,
            isClearable: true,
            value,
            onChange: (v2) => {
              setValue(v2);
              if (error)
                setError("");
            },
            returnKeyType: "done",
            onSubmitEditing: onConfirmWrapper,
            state: error ? "error" : void 0,
            errorMessage: error || void 0
          }),
          /* @__PURE__ */ jsx(import_react_native18.ScrollView, {
            horizontal: true,
            showsHorizontalScrollIndicator: false,
            style: {
              gap: 8
            },
            children: /* @__PURE__ */ jsx(Button, {
              size: "sm",
              variant: "tertiary",
              text: "Import from clipboard",
              icon: findAssetId("ClipboardListIcon"),
              onPress: () => clipboard.getString().then((str) => setValue(str))
            })
          })
        ]
      }),
      actions: /* @__PURE__ */ jsxs(Stack, {
        children: [
          /* @__PURE__ */ jsx(Button, {
            loading: isFetching,
            text: "Install",
            variant: "primary",
            disabled: !value || !isValidHttpUrl(value),
            onPress: onConfirmWrapper
          }),
          /* @__PURE__ */ jsx(AlertActionButton, {
            disabled: isFetching,
            text: "Cancel",
            variant: "secondary"
          })
        ]
      })
    });
  }
  function AddonPage({ CardComponent, ...props }) {
    var [search, setSearch] = React.useState("");
    var [sortFn, setSortFn] = React.useState(() => null);
    var { bottom: bottomInset } = useSafeAreaInsets();
    var navigation2 = NavigationNative.useNavigation();
    (0, import_react4.useEffect)(() => {
      if (props.OptionsActionSheetComponent) {
        navigation2.setOptions({
          headerRight: () => /* @__PURE__ */ jsx(IconButton, {
            size: "sm",
            variant: "secondary",
            icon: findAssetId("MoreHorizontalIcon"),
            onPress: () => showSheet("AddonMoreSheet", props.OptionsActionSheetComponent)
          })
        });
      }
    }, [
      navigation2
    ]);
    var results = (0, import_react4.useMemo)(() => {
      var values = props.items;
      if (props.resolveItem)
        values = values.map(props.resolveItem).filter(isNotNil);
      var items = values.filter((i) => isNotNil(i) && typeof i === "object");
      if (!search && sortFn)
        items.sort(sortFn);
      return import_fuzzysort.default.go(search, items, {
        keys: props.searchKeywords,
        all: true
      });
    }, [
      props.items,
      sortFn,
      search
    ]);
    var onInstallPress = (0, import_react4.useCallback)(() => {
      if (!props.installAction)
        return () => {
        };
      var { label, onPress, fetchFn } = props.installAction;
      if (fetchFn) {
        openAlert("AddonInputAlert", /* @__PURE__ */ jsx(InputAlert, {
          label: label ?? "Install",
          fetchFn
        }));
      } else {
        onPress?.();
      }
    }, []);
    if (results.length === 0 && !search) {
      return /* @__PURE__ */ jsxs(import_react_native18.View, {
        style: {
          gap: 32,
          flexGrow: 1,
          justifyContent: "center",
          alignItems: "center"
        },
        children: [
          /* @__PURE__ */ jsxs(import_react_native18.View, {
            style: {
              gap: 8,
              alignItems: "center"
            },
            children: [
              /* @__PURE__ */ jsx(import_react_native18.Image, {
                source: findAssetId("empty_quick_switcher")
              }),
              /* @__PURE__ */ jsx(Text, {
                variant: "text-lg/semibold",
                children: "Oops! Nothing to see here\u2026 yet!"
              })
            ]
          }),
          /* @__PURE__ */ jsx(Button, {
            size: "lg",
            icon: findAssetId("DownloadIcon"),
            text: props.installAction?.label ?? "Install",
            onPress: onInstallPress
          })
        ]
      });
    }
    var headerElement = /* @__PURE__ */ jsxs(import_react_native18.View, {
      style: {
        paddingBottom: 8
      },
      children: [
        settings.safeMode?.enabled && /* @__PURE__ */ jsxs(import_react_native18.View, {
          style: {
            marginBottom: 10
          },
          children: [
            /* @__PURE__ */ jsx(HelpMessage, {
              messageType: 0,
              children: props.safeModeHint?.message
            }),
            props.safeModeHint?.footer
          ]
        }),
        /* @__PURE__ */ jsxs(import_react_native18.View, {
          style: {
            flexDirection: "row",
            gap: 8
          },
          children: [
            /* @__PURE__ */ jsx(Search_default, {
              style: {
                flexGrow: 1
              },
              isRound: !!props.sortOptions,
              onChangeText: (v2) => setSearch(v2)
            }),
            props.sortOptions && /* @__PURE__ */ jsx(IconButton, {
              icon: findAssetId("ArrowsUpDownIcon"),
              variant: "tertiary",
              disabled: !!search,
              onPress: () => showSimpleActionSheet({
                key: "AddonListSortOptions",
                header: {
                  title: "Sort Options",
                  onClose: () => hideActionSheet("AddonListSortOptions")
                },
                options: Object.entries(props.sortOptions).map(([name, fn]) => ({
                  label: name,
                  onPress: () => setSortFn(() => fn)
                }))
              })
            })
          ]
        }),
        props.ListHeaderComponent && /* @__PURE__ */ jsx(props.ListHeaderComponent, {})
      ]
    });
    return /* @__PURE__ */ jsxs(ErrorBoundary, {
      children: [
        /* @__PURE__ */ jsx(FlashList, {
          data: results,
          extraData: search,
          estimatedItemSize: 136,
          ListHeaderComponent: headerElement,
          ListEmptyComponent: () => /* @__PURE__ */ jsxs(import_react_native18.View, {
            style: {
              gap: 12,
              padding: 12,
              alignItems: "center"
            },
            children: [
              /* @__PURE__ */ jsx(import_react_native18.Image, {
                source: findAssetId("devices_not_found")
              }),
              /* @__PURE__ */ jsx(Text, {
                variant: "text-lg/semibold",
                children: "Hmmm... could not find that!"
              })
            ]
          }),
          contentContainerStyle: {
            padding: 8,
            paddingHorizontal: 12,
            paddingBottom: 90
          },
          ItemSeparatorComponent: () => /* @__PURE__ */ jsx(import_react_native18.View, {
            style: {
              height: 8
            }
          }),
          ListFooterComponent: props.ListFooterComponent,
          renderItem: ({ item }) => /* @__PURE__ */ jsx(CardComponent, {
            item: item.obj,
            result: item
          })
        }),
        props.installAction && /* @__PURE__ */ jsx(FloatingActionButton, {
          positionBottom: bottomInset + 8,
          icon: findAssetId("PlusLargeIcon"),
          onPress: onInstallPress
        })
      ]
    });
  }
  var import_fuzzysort, import_react4, import_react_native18, showSimpleActionSheet, hideActionSheet;
  var init_AddonPage = __esm({
    "src/core/ui/components/AddonPage.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_jsxRuntime();
      init_assets();
      init_settings();
      init_alerts();
      init_sheets();
      init_isValidHttpUrl();
      init_lazy();
      init_metro();
      init_common();
      init_components();
      init_components2();
      init_dist();
      import_fuzzysort = __toESM(require_fuzzysort());
      import_react4 = __toESM(require_react());
      import_react_native18 = __toESM(require_react_native());
      ({ showSimpleActionSheet, hideActionSheet } = lazyDestructure(() => findByProps("showSimpleActionSheet")));
    }
  });

  // src/core/ui/settings/pages/Plugins/usePluginCardStyles.ts
  var usePluginCardStyles;
  var init_usePluginCardStyles = __esm({
    "src/core/ui/settings/pages/Plugins/usePluginCardStyles.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_common();
      init_styles();
      usePluginCardStyles = createStyles({
        smallIcon: {
          tintColor: tokens.colors.LOGO_PRIMARY,
          height: 18,
          width: 18
        },
        badgeIcon: {
          tintColor: tokens.colors.LOGO_PRIMARY,
          height: 12,
          width: 12
        },
        badgesContainer: {
          flexWrap: "wrap",
          flexDirection: "row",
          gap: 6,
          borderRadius: 6,
          padding: 4
        }
      });
    }
  });

  // src/core/ui/settings/pages/Plugins/components/PluginCard.tsx
  function getHighlightColor() {
    return (0, import_chroma_js4.default)(tokens.unsafe_rawColors.YELLOW_300).alpha(0.3).hex();
  }
  function Title() {
    var styles3 = usePluginCardStyles();
    var { plugin, result } = useCardContext();
    var highlightedNode = result[0].highlight((m2, i) => /* @__PURE__ */ jsx(Text, {
      style: {
        backgroundColor: getHighlightColor()
      },
      children: m2
    }, i));
    var icon = plugin.icon && findAssetId(plugin.icon);
    var textNode = /* @__PURE__ */ jsx(Text, {
      numberOfLines: 1,
      variant: "heading-lg/semibold",
      children: highlightedNode.length ? highlightedNode : plugin.name
    });
    return /* @__PURE__ */ jsxs(import_react_native19.View, {
      style: {
        flexDirection: "row",
        alignItems: "center",
        gap: 6
      },
      children: [
        icon && /* @__PURE__ */ jsx(import_react_native19.Image, {
          style: styles3.smallIcon,
          source: icon
        }),
        textNode
      ]
    });
  }
  function Authors() {
    var { plugin, result } = useCardContext();
    var styles3 = usePluginCardStyles();
    if (!plugin.authors)
      return null;
    var highlightedNode = result[2].highlight((m2, i) => /* @__PURE__ */ jsx(Text, {
      style: {
        backgroundColor: getHighlightColor()
      },
      children: m2
    }, i));
    var badges = plugin.getBadges();
    var authorText = highlightedNode.length > 0 ? highlightedNode : plugin.authors.map((a) => a.name).join(", ");
    return /* @__PURE__ */ jsxs(import_react_native19.View, {
      style: {
        flexDirection: "row",
        flexWrap: "wrap",
        flexShrink: 1,
        gap: 4
      },
      children: [
        /* @__PURE__ */ jsxs(Text, {
          variant: "text-sm/semibold",
          color: "text-muted",
          children: [
            "by ",
            authorText
          ]
        }),
        badges.length > 0 && /* @__PURE__ */ jsx(import_react_native19.View, {
          style: styles3.badgesContainer,
          children: badges.map((b3, i) => /* @__PURE__ */ jsx(import_react_native19.Image, {
            source: b3.source,
            style: styles3.badgeIcon
          }, i))
        })
      ]
    });
  }
  function Description() {
    var { plugin, result } = useCardContext();
    var highlightedNode = result[1].highlight((m2, i) => /* @__PURE__ */ jsx(Text, {
      style: {
        backgroundColor: getHighlightColor()
      },
      children: m2
    }, i));
    return /* @__PURE__ */ jsx(Text, {
      variant: "text-md/medium",
      children: highlightedNode.length ? highlightedNode : plugin.description
    });
  }
  function PluginCard({ result, item: plugin }) {
    plugin.usePluginState();
    var [, forceUpdate] = React.useReducer(() => ({}), 0);
    var cardContextValue = (0, import_react5.useMemo)(() => ({
      plugin,
      result
    }), [
      plugin,
      result
    ]);
    return /* @__PURE__ */ jsx(CardContext.Provider, {
      value: cardContextValue,
      children: /* @__PURE__ */ jsx(Card, {
        children: /* @__PURE__ */ jsxs(Stack, {
          spacing: 16,
          children: [
            /* @__PURE__ */ jsxs(import_react_native19.View, {
              style: {
                flexDirection: "row",
                justifyContent: "space-between"
              },
              children: [
                /* @__PURE__ */ jsxs(import_react_native19.View, {
                  style: {
                    flexShrink: 1
                  },
                  children: [
                    /* @__PURE__ */ jsx(Title, {}),
                    /* @__PURE__ */ jsx(Authors, {})
                  ]
                }),
                /* @__PURE__ */ jsx(import_react_native19.View, {
                  children: /* @__PURE__ */ jsxs(Stack, {
                    spacing: 12,
                    direction: "horizontal",
                    children: [
                      /* @__PURE__ */ jsx(Actions, {}),
                      /* @__PURE__ */ jsx(TableSwitch, {
                        value: plugin.isEnabled(),
                        onValueChange: (v2) => {
                          plugin.toggle(v2);
                          forceUpdate();
                        }
                      })
                    ]
                  })
                })
              ]
            }),
            /* @__PURE__ */ jsx(Description, {})
          ]
        })
      })
    });
  }
  var import_chroma_js4, import_react5, import_react_native19, CardContext, useCardContext, Actions;
  var init_PluginCard = __esm({
    "src/core/ui/settings/pages/Plugins/components/PluginCard.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_jsxRuntime();
      init_usePluginCardStyles();
      init_assets();
      init_common();
      init_components();
      init_sheets();
      import_chroma_js4 = __toESM(require_chroma_js());
      import_react5 = __toESM(require_react());
      import_react_native19 = __toESM(require_react_native());
      CardContext = /* @__PURE__ */ (0, import_react5.createContext)(null);
      useCardContext = () => (0, import_react5.useContext)(CardContext);
      Actions = () => {
        var { plugin } = useCardContext();
        var navigation2 = NavigationNative.useNavigation();
        return /* @__PURE__ */ jsxs(import_react_native19.View, {
          style: {
            flexDirection: "row",
            gap: 6
          },
          children: [
            /* @__PURE__ */ jsx(IconButton, {
              size: "sm",
              variant: "secondary",
              icon: findAssetId("WrenchIcon"),
              disabled: !plugin.getPluginSettingsComponent(),
              onPress: () => navigation2.push("BUNNY_CUSTOM_PAGE", {
                title: plugin.name,
                render: plugin.getPluginSettingsComponent()
              })
            }),
            /* @__PURE__ */ jsx(IconButton, {
              size: "sm",
              variant: "secondary",
              icon: findAssetId("CircleInformationIcon-primary"),
              onPress: () => void showSheet("PluginInfoActionSheet", plugin.resolveSheetComponent(), {
                plugin,
                navigation: navigation2
              })
            })
          ]
        });
      };
    }
  });

  // src/core/vendetta/plugins.ts
  var plugins, pluginInstance, VdPluginManager;
  var init_plugins = __esm({
    "src/core/vendetta/plugins.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_async_to_generator();
      init_storage();
      init_settings();
      init_utils();
      init_constants();
      init_logger();
      plugins = wrapSync(createStorage(createMMKVBackend("VENDETTA_PLUGINS")));
      pluginInstance = {};
      VdPluginManager = {
        plugins,
        pluginFetch(url2) {
          return _async_to_generator(function* () {
            if (url2.startsWith(VD_PROXY_PREFIX)) {
              url2 = url2.replace("https://bunny-mod.github.io/plugins-proxy", BUNNY_PROXY_PREFIX).replace(VD_PROXY_PREFIX, BUNNY_PROXY_PREFIX);
            }
            return yield safeFetch(url2, {
              cache: "no-store"
            });
          })();
        },
        fetchPlugin(id) {
          return _async_to_generator(function* () {
            if (!id.endsWith("/"))
              id += "/";
            var existingPlugin = plugins[id];
            var pluginManifest;
            try {
              pluginManifest = yield (yield this.pluginFetch(id + "manifest.json")).json();
            } catch (unused) {
              throw new Error(`Failed to fetch manifest for ${id}`);
            }
            if (existingPlugin && existingPlugin.js && existingPlugin.manifest?.hash === pluginManifest.hash)
              return;
            var pluginJs;
            if (existingPlugin?.manifest.hash !== pluginManifest.hash) {
              try {
                pluginJs = yield (yield this.pluginFetch(id + (pluginManifest.main || "index.js"))).text();
              } catch (unused) {
              }
            }
            if (!pluginJs && !existingPlugin)
              throw new Error(`Failed to fetch JS for ${id}`);
            plugins[id] = {
              id,
              manifest: pluginManifest,
              enabled: existingPlugin?.enabled ?? false,
              update: existingPlugin?.update ?? true,
              js: pluginJs ?? existingPlugin.js
            };
          }).call(this);
        },
        installPlugin(id, enabled = true) {
          return _async_to_generator(function* () {
            if (!id.endsWith("/"))
              id += "/";
            if (typeof id !== "string" || id in plugins)
              throw new Error("Plugin already installed");
            yield this.fetchPlugin(id);
            if (enabled)
              yield this.startPlugin(id);
          }).call(this);
        },
        /**
         * @internal
         */
        evalPlugin(plugin) {
          return _async_to_generator(function* () {
            var vendettaForPlugins = {
              ...globalThis.vendetta,
              plugin: {
                id: plugin.id,
                manifest: plugin.manifest,
                // Wrapping this with wrapSync is NOT an option.
                storage: yield createStorage(createMMKVBackend(plugin.id))
              },
              logger: new LoggerClass(`YumiCord \xBB ${plugin.manifest.name}`)
            };
            var pluginString = `vendetta=>{return ${plugin.js}}
//# sourceURL=${plugin.id}`;
            var raw = (0, eval)(pluginString)(vendettaForPlugins);
            var ret = typeof raw === "function" ? raw() : raw;
            return ret?.default ?? ret ?? {};
          })();
        },
        startPlugin(id) {
          return _async_to_generator(function* () {
            if (!id.endsWith("/"))
              id += "/";
            var plugin = plugins[id];
            if (!plugin)
              throw new Error("Attempted to start non-existent plugin");
            try {
              if (!settings.safeMode?.enabled) {
                var pluginRet = yield this.evalPlugin(plugin);
                pluginInstance[id] = pluginRet;
                pluginRet.onLoad?.();
              }
              plugin.enabled = true;
            } catch (e) {
              logger.error(`Plugin ${plugin.id} errored whilst loading, and will be unloaded`, e);
              try {
                pluginInstance[plugin.id]?.onUnload?.();
              } catch (e2) {
                logger.error(`Plugin ${plugin.id} errored whilst unloading`, e2);
              }
              delete pluginInstance[id];
              plugin.enabled = false;
            }
          }).call(this);
        },
        stopPlugin(id, disable = true) {
          if (!id.endsWith("/"))
            id += "/";
          var plugin = plugins[id];
          var pluginRet = pluginInstance[id];
          if (!plugin)
            throw new Error("Attempted to stop non-existent plugin");
          if (!settings.safeMode?.enabled) {
            try {
              pluginRet?.onUnload?.();
            } catch (e) {
              logger.error(`Plugin ${plugin.id} errored whilst unloading`, e);
            }
            delete pluginInstance[id];
          }
          if (disable)
            plugin.enabled = false;
        },
        removePlugin(id) {
          return _async_to_generator(function* () {
            if (!id.endsWith("/"))
              id += "/";
            var plugin = plugins[id];
            if (plugin.enabled)
              this.stopPlugin(id);
            delete plugins[id];
            yield purgeStorage(id);
          }).call(this);
        },
        /**
         * @internal
         */
        initPlugins() {
          return _async_to_generator(function* () {
            yield awaitStorage(settings, plugins);
            var allIds = Object.keys(plugins);
            if (!settings.safeMode?.enabled) {
              yield allSettled(allIds.filter((pl) => plugins[pl].enabled).map((pl) => _async_to_generator(function* () {
                return plugins[pl].update && (yield this.fetchPlugin(pl).catch((e) => logger.error(e.message))), yield this.startPlugin(pl);
              }).call(this)));
              setTimeout(() => {
                try {
                  Object.keys(plugins).filter((pl) => plugins[pl] && !plugins[pl].enabled && plugins[pl].update).forEach((pl) => this.fetchPlugin(pl).catch(() => {
                  }));
                } catch (e) {
                }
              }, 3e4);
            }
            return () => this.stopAllPlugins();
          }).call(this);
        },
        stopAllPlugins() {
          return Object.keys(pluginInstance).forEach((p) => this.stopPlugin(p, false));
        },
        getSettings: (id) => pluginInstance[id]?.settings
      };
    }
  });

  // src/core/plugins/quickinstall/forumPost.tsx
  function useExtractThreadContent(thread, _firstMessage = null, actionSheet3 = false) {
    if (thread.guild_id !== VD_DISCORD_SERVER_ID)
      return;
    var postType;
    if (thread.parent_id === VD_PLUGINS_CHANNEL_ID) {
      postType = "Plugin";
    } else if (thread.parent_id === VD_THEMES_CHANNEL_ID && isThemeSupported()) {
      postType = "Theme";
    } else
      return;
    var { firstMessage } = actionSheet3 ? useFirstForumPostMessage(thread) : {
      firstMessage: _firstMessage
    };
    var urls = firstMessage?.content?.match(HTTP_REGEX_MULTI)?.filter(postMap[postType].urlsFilter);
    if (!urls || !urls[0])
      return;
    if (postType === "Plugin" && !urls[0].endsWith("/"))
      urls[0] += "/";
    return [
      postType,
      urls[0]
    ];
  }
  function useInstaller(thread, firstMessage = null, actionSheet3 = false) {
    var [postType, url2] = useExtractThreadContent(thread, firstMessage, actionSheet3) ?? [];
    useProxy(VdPluginManager.plugins);
    useProxy(themes);
    var [isInstalling, setIsInstalling] = React.useState(false);
    if (!postType || !url2)
      return [
        true
      ];
    var isInstalled = Boolean(postMap[postType].storage[url2]);
    var installOrRemove = () => _async_to_generator(function* () {
      setIsInstalling(true);
      try {
        yield postMap[postType].installOrRemove(url2);
      } catch (e) {
        showToast(e.message, findAssetId("XSmallIcon"));
      } finally {
        setIsInstalling(false);
      }
    })();
    return [
      false,
      postType,
      isInstalled,
      isInstalling,
      installOrRemove
    ];
  }
  var useFirstForumPostMessage, forumReactions, postMap, installButtonPatch, forumPost_default;
  var init_forumPost = __esm({
    "src/core/plugins/quickinstall/forumPost.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_async_to_generator();
      init_jsxRuntime();
      init_i18n();
      init_plugins();
      init_storage();
      init_themes();
      init_assets();
      init_loader();
      init_patcher();
      init_constants();
      init_lazy();
      init_components();
      init_wrappers();
      init_components2();
      init_toasts();
      ({ useFirstForumPostMessage } = lazyDestructure(() => findByProps("useFirstForumPostMessage")));
      forumReactions = findByPropsLazy("MostCommonForumPostReaction");
      postMap = {
        Plugin: {
          storage: VdPluginManager.plugins,
          urlsFilter: (url2) => url2.startsWith(VD_PROXY_PREFIX),
          installOrRemove: (url2) => {
            var isInstalled = postMap.Plugin.storage[url2];
            return isInstalled ? VdPluginManager.removePlugin(url2) : VdPluginManager.installPlugin(url2);
          }
        },
        Theme: {
          storage: themes,
          urlsFilter: (url2) => url2.endsWith(".json"),
          installOrRemove: (url2) => {
            var isInstalled = postMap.Theme.storage[url2];
            return isInstalled ? removeTheme(url2) : installTheme(url2);
          }
        }
      };
      installButtonPatch = () => after("MostCommonForumPostReaction", forumReactions, ([{ thread, firstMessage }], res) => {
        var [shouldReturn, _2, installed, loading, installOrRemove] = useInstaller(thread, firstMessage, true);
        if (shouldReturn)
          return;
        return /* @__PURE__ */ jsxs(Fragment, {
          children: [
            res,
            /* @__PURE__ */ jsx(ErrorBoundary, {
              children: /* @__PURE__ */ jsx(Button, {
                size: "sm",
                loading,
                disabled: loading,
                // variant={installed ? "destructive" : "primary"} crashes older version because "destructive" was renamed from "danger" and there's no sane way for compat check horror
                variant: installed ? "secondary" : "primary",
                text: installed ? Strings.UNINSTALL : Strings.INSTALL,
                onPress: installOrRemove,
                icon: findAssetId(installed ? "TrashIcon" : "DownloadIcon"),
                style: {
                  marginLeft: 8
                }
              })
            })
          ]
        });
      });
      forumPost_default = () => {
        var patches2 = [
          // actionSheetPatch(),
          installButtonPatch()
        ];
        return () => patches2.map((p) => p());
      };
    }
  });

  // src/lib/ui/components/InputAlert.tsx
  function InputAlert2({ title, confirmText, confirmColor, onConfirm, cancelText, placeholder, initialValue = "", secureTextEntry }) {
    var [value, setValue] = React.useState(initialValue);
    var [error, setError] = React.useState("");
    function onConfirmWrapper() {
      var asyncOnConfirm = Promise.resolve(onConfirm(value));
      asyncOnConfirm.then(() => {
        Alerts.close();
      }).catch((e) => {
        setError(e.message);
      });
    }
    return /* @__PURE__ */ jsx(LegacyAlert, {
      title,
      confirmText,
      confirmColor,
      isConfirmButtonDisabled: error.length !== 0,
      onConfirm: onConfirmWrapper,
      cancelText,
      onCancel: () => Alerts.close(),
      children: /* @__PURE__ */ jsx(LegacyFormInput, {
        placeholder,
        value,
        onChange: (v2) => {
          setValue(typeof v2 === "string" ? v2 : v2.text);
          if (error)
            setError("");
        },
        returnKeyType: "done",
        onSubmitEditing: onConfirmWrapper,
        error: error || void 0,
        secureTextEntry,
        autoFocus: true,
        showBorder: true,
        style: {
          alignSelf: "stretch"
        }
      })
    });
  }
  var Alerts;
  var init_InputAlert = __esm({
    "src/lib/ui/components/InputAlert.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_jsxRuntime();
      init_components();
      init_wrappers();
      Alerts = findByPropsLazy("openLazy", "close");
    }
  });

  // src/core/vendetta/alerts.ts
  function showConfirmationAlert(options) {
    var internalOptions = options;
    internalOptions.body = options.content;
    delete internalOptions.content;
    internalOptions.isDismissable ??= true;
    return Alerts2.show(internalOptions);
  }
  var Alerts2, showCustomAlert, showInputAlert;
  var init_alerts2 = __esm({
    "src/core/vendetta/alerts.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_async_to_generator();
      init_wrappers();
      init_InputAlert();
      Alerts2 = findByPropsLazy("openLazy", "close");
      showCustomAlert = (component, props) => Alerts2.openLazy({
        importer: () => _async_to_generator(function* () {
          return () => React.createElement(component, props);
        })()
      });
      showInputAlert = (options) => showCustomAlert(InputAlert2, options);
    }
  });

  // src/core/plugins/quickinstall/url.tsx
  function typeFromUrl(url2) {
    if (url2.startsWith(VD_PROXY_PREFIX)) {
      return "plugin";
    } else if (url2.endsWith(".json") && isThemeSupported()) {
      return "theme";
    }
  }
  function installWithToast(type, url2) {
    (type === "plugin" ? VdPluginManager.installPlugin.bind(VdPluginManager) : installTheme)(url2).then(() => {
      showToast(Strings.SUCCESSFULLY_INSTALLED, findAssetId("DownloadIcon"));
    }).catch((e) => {
      showToast(e.message, findAssetId("XSmallIcon"));
    });
  }
  var import_react_native20, showSimpleActionSheet2, handleClick, getChannelId, getChannel, url_default;
  var init_url = __esm({
    "src/core/plugins/quickinstall/url.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_async_to_generator();
      init_i18n();
      init_alerts2();
      init_plugins();
      init_themes();
      init_assets();
      init_loader();
      init_patcher();
      init_constants();
      init_lazy();
      init_common();
      init_filters();
      init_finders();
      init_wrappers();
      init_toasts();
      import_react_native20 = __toESM(require_react_native());
      showSimpleActionSheet2 = findExports(byMutableProp("showSimpleActionSheet"));
      handleClick = findByPropsLazy("handleClick");
      ({ getChannelId } = lazyDestructure(() => channels));
      ({ getChannel } = lazyDestructure(() => findByProps("getChannel")));
      url_default = () => {
        var patches2 = new Array();
        patches2.push(after("showSimpleActionSheet", showSimpleActionSheet2, (args) => {
          if (args[0].key !== "LongPressUrl")
            return;
          var { header: { title: url2 }, options } = args[0];
          var urlType = typeFromUrl(url2);
          if (!urlType)
            return;
          options.push({
            label: Strings.INSTALL_ADDON,
            onPress: () => installWithToast(urlType, url2)
          });
        }));
        patches2.push(instead("handleClick", handleClick, function(args, orig) {
          return _async_to_generator(function* () {
            var { href: url2 } = args[0];
            var urlType = typeFromUrl(url2);
            if (!urlType)
              return orig.apply(this, args);
            if (urlType === "theme" && getChannel(getChannelId())?.parent_id !== VD_THEMES_CHANNEL_ID)
              return orig.apply(this, args);
            showConfirmationAlert({
              title: Strings.HOLD_UP,
              content: formatString("CONFIRMATION_LINK_IS_A_TYPE", {
                urlType
              }),
              onConfirm: () => installWithToast(urlType, url2),
              confirmText: Strings.INSTALL,
              cancelText: Strings.CANCEL,
              secondaryConfirmText: Strings.OPEN_IN_BROWSER,
              onConfirmSecondary: () => import_react_native20.Linking.openURL(url2)
            });
          }).call(this);
        }));
        return () => patches2.forEach((p) => p());
      };
    }
  });

  // src/core/plugins/quickinstall/index.ts
  var quickinstall_exports = {};
  __export(quickinstall_exports, {
    default: () => quickinstall_default
  });
  var patches, quickinstall_default;
  var init_quickinstall = __esm({
    "src/core/plugins/quickinstall/index.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_plugins2();
      init_forumPost();
      init_url();
      patches = [];
      quickinstall_default = defineCorePlugin({
        manifest: {
          id: "bunny.quickinstall",
          name: "QuickInstall",
          version: "1.0.0",
          description: "Quickly install plugins and themes",
          authors: [
            {
              name: "YumiCord"
            }
          ]
        },
        start() {
          patches = [
            forumPost_default(),
            url_default()
          ];
        },
        stop() {
          patches.forEach((p) => p());
        }
      });
    }
  });

  // src/lib/api/react/jsx.ts
  var jsx_exports = {};
  __export(jsx_exports, {
    deleteJsxCreate: () => deleteJsxCreate,
    onJsxCreate: () => onJsxCreate,
    patchJsx: () => patchJsx
  });
  function onJsxCreate(Component, callback) {
    if (!callbacks.has(Component))
      callbacks.set(Component, []);
    callbacks.get(Component).push(callback);
  }
  function deleteJsxCreate(Component, callback) {
    if (!callbacks.has(Component))
      return;
    var cbs = callbacks.get(Component);
    cbs.splice(cbs.indexOf(callback), 1);
    if (cbs.length === 0)
      callbacks.delete(Component);
  }
  function patchJsx() {
    var callback = ([Component], ret) => {
      if (typeof ret.type === "undefined") {
        ret.type = "RCTView";
        return ret;
      }
      if (typeof Component === "function" && callbacks.has(Component.name)) {
        var cbs = callbacks.get(Component.name);
        for (var cb of cbs) {
          var _ret = cb(Component, ret);
          if (_ret !== void 0)
            ret = _ret;
        }
        return ret;
      }
    };
    var patches2 = [
      after("jsx", jsxRuntime2, callback),
      after("jsxs", jsxRuntime2, callback)
    ];
    return () => patches2.forEach((unpatch) => unpatch());
  }
  var callbacks, jsxRuntime2;
  var init_jsx = __esm({
    "src/lib/api/react/jsx.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_patcher();
      init_metro();
      callbacks = /* @__PURE__ */ new Map();
      jsxRuntime2 = findByPropsLazy("jsx", "jsxs");
    }
  });

  // src/core/plugins/badges/index.tsx
  var badges_exports = {};
  __export(badges_exports, {
    default: () => badges_default
  });
  var import_react6, useBadgesModule, badges_default;
  var init_badges = __esm({
    "src/core/plugins/badges/index.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_patcher();
      init_jsx();
      init_metro();
      import_react6 = __toESM(require_react());
      init_plugins2();
      useBadgesModule = findByName("useBadges", false);
      badges_default = defineCorePlugin({
        manifest: {
          id: "bunny.badges",
          name: "Badges",
          version: "1.0.0",
          description: "Adds badges to user's profile",
          authors: [
            {
              name: "pylixonly"
            }
          ]
        },
        start() {
          var propHolder = {};
          var badgeCache = {};
          onJsxCreate("RenderedBadge", (_2, ret) => {
            if (ret.props.id.match(/bunny-\d+-\d+/)) {
              Object.assign(ret.props, propHolder[ret.props.id]);
            }
          });
          after("default", useBadgesModule, ([user], r) => {
            var [badges, setBadges] = (0, import_react6.useState)(user ? badgeCache[user.userId] ??= [] : []);
            (0, import_react6.useEffect)(() => {
              if (user) {
                fetch(`https://raw.githubusercontent.com/pyoncord/badges/refs/heads/main/${user.userId}.json`).then((r2) => r2.json()).then((badges2) => setBadges(badgeCache[user.userId] = badges2));
              }
            }, [
              user
            ]);
            if (user) {
              badges.forEach((badges2, i) => {
                propHolder[`bunny-${user.userId}-${i}`] = {
                  source: {
                    uri: badges2.url
                  },
                  id: `bunny-${i}`,
                  label: badges2.label
                };
                r.push({
                  id: `bunny-${user.userId}-${i}`,
                  description: badges2.label,
                  icon: "_"
                });
              });
            }
          });
        }
      });
    }
  });

  // src/core/plugins/index.ts
  function defineCorePlugin(instance) {
    instance[Symbol.for("bunny.core.plugin")] = true;
    return instance;
  }
  var getCorePlugins;
  var init_plugins2 = __esm({
    "src/core/plugins/index.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      getCorePlugins = () => ({
        "bunny.quickinstall": (init_quickinstall(), __toCommonJS(quickinstall_exports)),
        "bunny.badges": (init_badges(), __toCommonJS(badges_exports))
      });
    }
  });

  // src/lib/api/commands/types.ts
  var ApplicationCommandInputType, ApplicationCommandOptionType, ApplicationCommandType;
  var init_types = __esm({
    "src/lib/api/commands/types.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      ApplicationCommandInputType = /* @__PURE__ */ function(ApplicationCommandInputType2) {
        ApplicationCommandInputType2[ApplicationCommandInputType2["BUILT_IN"] = 0] = "BUILT_IN";
        ApplicationCommandInputType2[ApplicationCommandInputType2["BUILT_IN_TEXT"] = 1] = "BUILT_IN_TEXT";
        ApplicationCommandInputType2[ApplicationCommandInputType2["BUILT_IN_INTEGRATION"] = 2] = "BUILT_IN_INTEGRATION";
        ApplicationCommandInputType2[ApplicationCommandInputType2["BOT"] = 3] = "BOT";
        ApplicationCommandInputType2[ApplicationCommandInputType2["PLACEHOLDER"] = 4] = "PLACEHOLDER";
        return ApplicationCommandInputType2;
      }({});
      ApplicationCommandOptionType = /* @__PURE__ */ function(ApplicationCommandOptionType2) {
        ApplicationCommandOptionType2[ApplicationCommandOptionType2["SUB_COMMAND"] = 1] = "SUB_COMMAND";
        ApplicationCommandOptionType2[ApplicationCommandOptionType2["SUB_COMMAND_GROUP"] = 2] = "SUB_COMMAND_GROUP";
        ApplicationCommandOptionType2[ApplicationCommandOptionType2["STRING"] = 3] = "STRING";
        ApplicationCommandOptionType2[ApplicationCommandOptionType2["INTEGER"] = 4] = "INTEGER";
        ApplicationCommandOptionType2[ApplicationCommandOptionType2["BOOLEAN"] = 5] = "BOOLEAN";
        ApplicationCommandOptionType2[ApplicationCommandOptionType2["USER"] = 6] = "USER";
        ApplicationCommandOptionType2[ApplicationCommandOptionType2["CHANNEL"] = 7] = "CHANNEL";
        ApplicationCommandOptionType2[ApplicationCommandOptionType2["ROLE"] = 8] = "ROLE";
        ApplicationCommandOptionType2[ApplicationCommandOptionType2["MENTIONABLE"] = 9] = "MENTIONABLE";
        ApplicationCommandOptionType2[ApplicationCommandOptionType2["NUMBER"] = 10] = "NUMBER";
        ApplicationCommandOptionType2[ApplicationCommandOptionType2["ATTACHMENT"] = 11] = "ATTACHMENT";
        return ApplicationCommandOptionType2;
      }({});
      ApplicationCommandType = /* @__PURE__ */ function(ApplicationCommandType2) {
        ApplicationCommandType2[ApplicationCommandType2["CHAT"] = 1] = "CHAT";
        ApplicationCommandType2[ApplicationCommandType2["USER"] = 2] = "USER";
        ApplicationCommandType2[ApplicationCommandType2["MESSAGE"] = 3] = "MESSAGE";
        return ApplicationCommandType2;
      }({});
    }
  });

  // src/core/commands/eval.ts
  var eval_exports = {};
  __export(eval_exports, {
    default: () => eval_default
  });
  function wrapInJSCodeblock(resString) {
    return "```js\n" + resString.replaceAll("`", "`" + ZERO_WIDTH_SPACE_CHARACTER) + "\n```";
  }
  var util, AsyncFunction, ZERO_WIDTH_SPACE_CHARACTER, eval_default;
  var init_eval = __esm({
    "src/core/commands/eval.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_async_to_generator();
      init_i18n();
      init_types();
      init_settings();
      init_common();
      init_wrappers();
      util = findByPropsLazy("inspect");
      AsyncFunction = (() => _async_to_generator(function* () {
        return void 0;
      })()).constructor;
      ZERO_WIDTH_SPACE_CHARACTER = "\u200B";
      eval_default = () => ({
        name: "eval",
        description: Strings.COMMAND_EVAL_DESC,
        shouldHide: () => settings.enableEvalCommand === true,
        options: [
          {
            name: "code",
            type: ApplicationCommandOptionType.STRING,
            description: Strings.COMMAND_EVAL_OPT_CODE,
            required: true
          },
          {
            name: "async",
            type: ApplicationCommandOptionType.BOOLEAN,
            description: Strings.COMMAND_EVAL_OPT_ASYNC
          }
        ],
        execute(_0, _1) {
          return _async_to_generator(function* ([code, async], ctx) {
            try {
              var res = util.inspect(async?.value ? yield AsyncFunction(code.value)() : eval?.(code.value));
              var trimmedRes = res.length > 2e3 ? res.slice(0, 2e3) + "..." : res;
              messageUtil.sendBotMessage(ctx.channel.id, wrapInJSCodeblock(trimmedRes));
            } catch (err) {
              messageUtil.sendBotMessage(ctx.channel.id, wrapInJSCodeblock(err?.stack ?? err));
            }
          }).apply(this, arguments);
        }
      });
    }
  });

  // src/core/commands/debug.ts
  var debug_exports2 = {};
  __export(debug_exports2, {
    default: () => debug_default
  });
  var debug_default;
  var init_debug2 = __esm({
    "src/core/commands/debug.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_i18n();
      init_types();
      init_debug();
      init_common();
      debug_default = () => ({
        name: "debug",
        description: Strings.COMMAND_DEBUG_DESC,
        options: [
          {
            name: "ephemeral",
            type: ApplicationCommandOptionType.BOOLEAN,
            description: Strings.COMMAND_DEBUG_OPT_EPHEMERALLY
          }
        ],
        execute([ephemeral], ctx) {
          var info = getDebugInfo();
          var content = [
            "**YumiCord Debug Info**",
            `> YumiCord: ${info.bunny.version} (${info.bunny.loader.name} ${info.bunny.loader.version})`,
            `> Discord: ${info.discord.version} (${info.discord.build})`,
            `> React: ${info.react.version} (RN ${info.react.nativeVersion})`,
            `> Hermes: ${info.hermes.version} (bcv${info.hermes.bytecodeVersion})`,
            `> System: ${info.os.name} ${info.os.version} ${info.os.sdk ? `(SDK ${info.os.sdk})` : ""}`.trimEnd(),
            `> Device: ${info.device.model} (${info.device.codename})`
          ].join("\n");
          if (ephemeral?.value) {
            messageUtil.sendBotMessage(ctx.channel.id, content);
          } else {
            var fixNonce = Date.now().toString();
            messageUtil.sendMessage(ctx.channel.id, {
              content
            }, void 0, {
              nonce: fixNonce
            });
          }
        }
      });
    }
  });

  // src/core/commands/plugins.ts
  var plugins_exports = {};
  __export(plugins_exports, {
    default: () => plugins_default
  });
  var plugins_default;
  var init_plugins3 = __esm({
    "src/core/commands/plugins.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_i18n();
      init_plugins();
      init_types();
      init_common();
      plugins_default = () => ({
        name: "plugins",
        description: Strings.COMMAND_PLUGINS_DESC,
        options: [
          {
            name: "ephemeral",
            displayName: "ephemeral",
            type: ApplicationCommandOptionType.BOOLEAN,
            description: Strings.COMMAND_DEBUG_OPT_EPHEMERALLY
          }
        ],
        execute([ephemeral], ctx) {
          var plugins2 = Object.values(VdPluginManager.plugins).filter(Boolean);
          plugins2.sort((a, b3) => a.manifest.name.localeCompare(b3.manifest.name));
          var enabled = plugins2.filter((p) => p.enabled).map((p) => p.manifest.name);
          var disabled = plugins2.filter((p) => !p.enabled).map((p) => p.manifest.name);
          var content = [
            `**Installed Plugins (${plugins2.length}):**`,
            ...enabled.length > 0 ? [
              `Enabled (${enabled.length}):`,
              "> " + enabled.join(", ")
            ] : [],
            ...disabled.length > 0 ? [
              `Disabled (${disabled.length}):`,
              "> " + disabled.join(", ")
            ] : []
          ].join("\n");
          if (ephemeral?.value) {
            messageUtil.sendBotMessage(ctx.channel.id, content);
          } else {
            var fixNonce = Date.now().toString();
            messageUtil.sendMessage(ctx.channel.id, {
              content
            }, void 0, {
              nonce: fixNonce
            });
          }
        }
      });
    }
  });

  // src/lib/api/commands/index.ts
  var commands_exports = {};
  __export(commands_exports, {
    patchCommands: () => patchCommands,
    registerCommand: () => registerCommand
  });
  function patchCommands() {
    var unpatch = after("getBuiltInCommands", commands, ([type], res) => {
      return [
        ...res,
        ...commands2.filter((c2) => (type instanceof Array ? type.includes(c2.type) : type === c2.type) && c2.__bunny?.shouldHide?.() !== false)
      ];
    });
    [
      (init_eval(), __toCommonJS(eval_exports)),
      (init_debug2(), __toCommonJS(debug_exports2)),
      (init_plugins3(), __toCommonJS(plugins_exports))
    ].forEach((r) => registerCommand(r.default()));
    return () => {
      commands2 = [];
      unpatch();
    };
  }
  function registerCommand(command) {
    var builtInCommands;
    try {
      builtInCommands = commands.getBuiltInCommands(ApplicationCommandType.CHAT, true, false);
    } catch (unused) {
      builtInCommands = commands.getBuiltInCommands(Object.values(ApplicationCommandType), true, false);
    }
    builtInCommands.sort((a, b3) => parseInt(b3.id) - parseInt(a.id));
    var lastCommand = builtInCommands[builtInCommands.length - 1];
    command.id = (parseInt(lastCommand.id, 10) - 1).toString();
    command.__bunny = {
      shouldHide: command.shouldHide
    };
    command.applicationId ??= "-1";
    command.type ??= ApplicationCommandType.CHAT;
    command.inputType = ApplicationCommandInputType.BUILT_IN;
    command.displayName ??= command.name;
    command.untranslatedName ??= command.name;
    command.displayDescription ??= command.description;
    command.untranslatedDescription ??= command.description;
    if (command.options)
      for (var opt of command.options) {
        opt.displayName ??= opt.name;
        opt.displayDescription ??= opt.description;
      }
    instead("execute", command, (args, orig) => {
      Promise.resolve(orig.apply(command, args)).then((ret) => {
        if (ret && typeof ret === "object") {
          messageUtil.sendMessage(args[1].channel.id, ret);
        }
      }).catch((err) => {
        logger.error("Failed to execute command", err);
      });
    });
    commands2.push(command);
    return () => commands2 = commands2.filter(({ id }) => id !== command.id);
  }
  var commands2;
  var init_commands = __esm({
    "src/lib/api/commands/index.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_types();
      init_patcher();
      init_logger();
      init_common();
      commands2 = [];
    }
  });

  // src/lib/api/flux/index.ts
  var flux_exports = {};
  __export(flux_exports, {
    dispatcher: () => dispatcher,
    injectFluxInterceptor: () => injectFluxInterceptor,
    intercept: () => intercept
  });
  function injectFluxInterceptor() {
    var cb = (payload) => {
      for (var intercept2 of intercepts) {
        var res = intercept2(payload);
        if (res == null) {
          continue;
        } else if (!res) {
          payload[blockedSym] = true;
        } else if (typeof res === "object") {
          Object.assign(payload, res);
          payload[modifiedSym] = true;
        }
      }
      return blockedSym in payload;
    };
    (dispatcher._interceptors ??= []).unshift(cb);
    return () => dispatcher._interceptors &&= dispatcher._interceptors.filter((v2) => v2 !== cb);
  }
  function intercept(cb) {
    intercepts.push(cb);
    return () => {
      intercepts = intercepts.filter((i) => i !== cb);
    };
  }
  var blockedSym, modifiedSym, dispatcher, intercepts;
  var init_flux = __esm({
    "src/lib/api/flux/index.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_common();
      blockedSym = Symbol.for("bunny.flux.blocked");
      modifiedSym = Symbol.for("bunny.flux.modified");
      dispatcher = FluxDispatcher;
      intercepts = [];
    }
  });

  // src/lib/api/native/index.ts
  var native_exports = {};
  __export(native_exports, {
    fs: () => fs_exports
  });
  var init_native = __esm({
    "src/lib/api/native/index.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_fs();
    }
  });

  // src/lib/api/react/index.ts
  var react_exports = {};
  __export(react_exports, {
    jsx: () => jsx_exports
  });
  var init_react2 = __esm({
    "src/lib/api/react/index.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_jsx();
    }
  });

  // src/lib/api/index.ts
  var api_exports = {};
  __export(api_exports, {
    assets: () => assets_exports,
    commands: () => commands_exports,
    debug: () => debug_exports,
    flux: () => flux_exports,
    native: () => native_exports,
    patcher: () => patcher_exports,
    react: () => react_exports,
    settings: () => settings_exports,
    storage: () => storage_exports
  });
  var init_api = __esm({
    "src/lib/api/index.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_assets();
      init_commands();
      init_debug();
      init_flux();
      init_native();
      init_patcher();
      init_react2();
      init_settings();
      init_storage2();
    }
  });

  // src/lib/addons/plugins/api.ts
  function shimDisposableFn(unpatches, f) {
    var dummy = (...props) => {
      var up = f(...props);
      unpatches.push(up);
      return up;
    };
    for (var key in f)
      if (typeof f[key] === "function") {
        dummy[key] = shimDisposableFn(unpatches, f[key]);
      }
    return dummy;
  }
  function createBunnyPluginApi(id) {
    var disposers = new Array();
    var object = {
      ...globalThis.bunny,
      api: {
        ...globalThis.bunny.api,
        patcher: {
          before: shimDisposableFn(disposers, patcher_exports.before),
          after: shimDisposableFn(disposers, patcher_exports.after),
          instead: shimDisposableFn(disposers, patcher_exports.instead)
        },
        commands: {
          ...globalThis.bunny.api.commands,
          registerCommand: shimDisposableFn(disposers, registerCommand)
        },
        flux: {
          ...globalThis.bunny.api.flux,
          intercept: shimDisposableFn(disposers, globalThis.bunny.api.flux.intercept)
        }
      },
      // Added something in here? Make sure to also update BunnyPluginProperty in ./types
      plugin: {
        createStorage: () => createStorage2(`plugins/storage/${id}.json`),
        manifest: registeredPlugins.get(id),
        logger
      }
    };
    return {
      object,
      disposers
    };
  }
  var init_api2 = __esm({
    "src/lib/addons/plugins/api.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_api();
      init_commands();
      init_storage2();
      init_logger();
      init_plugins4();
    }
  });

  // src/lib/addons/plugins/index.ts
  var plugins_exports2 = {};
  __export(plugins_exports2, {
    apiObjects: () => apiObjects,
    corePluginInstances: () => corePluginInstances,
    deleteRepository: () => deleteRepository,
    disablePlugin: () => disablePlugin,
    enablePlugin: () => enablePlugin,
    getPluginSettingsComponent: () => getPluginSettingsComponent,
    initPlugins: () => initPlugins,
    installPlugin: () => installPlugin,
    isCorePlugin: () => isCorePlugin,
    isGreaterVersion: () => isGreaterVersion,
    isPluginEnabled: () => isPluginEnabled,
    isPluginInstalled: () => isPluginInstalled,
    pluginInstances: () => pluginInstances,
    pluginRepositories: () => pluginRepositories,
    pluginSettings: () => pluginSettings,
    refreshPlugin: () => refreshPlugin,
    registeredPlugins: () => registeredPlugins,
    startPlugin: () => startPlugin,
    stopPlugin: () => stopPlugin,
    uninstallPlugin: () => uninstallPlugin,
    updateAllRepository: () => updateAllRepository,
    updateAndWritePlugin: () => updateAndWritePlugin,
    updatePlugins: () => updatePlugins,
    updateRepository: () => updateRepository
  });
  function assert(condition, id, attempt) {
    if (!condition)
      throw new Error(`[${id}] Attempted to ${attempt}`);
  }
  function isGreaterVersion(v1, v2) {
    if (semver.gt(v1, v2))
      return true;
    var coerced = semver.coerce(v1);
    if (coerced == null)
      return false;
    return semver.prerelease(v1)?.includes("dev") && semver.eq(coerced, v2);
  }
  function isExternalPlugin(manifest) {
    return "parentRepository" in manifest;
  }
  function isCorePlugin(id) {
    return corePluginInstances.has(id);
  }
  function getPluginSettingsComponent(id) {
    var instance = pluginInstances.get(id);
    if (!instance)
      return null;
    if (instance.SettingsComponent)
      return instance.SettingsComponent;
    return null;
  }
  function isPluginInstalled(id) {
    return pluginSettings[id] != null;
  }
  function isPluginEnabled(id) {
    return Boolean(pluginSettings[id]?.enabled);
  }
  function updateAndWritePlugin(repoUrl, id, fetchScript) {
    return _async_to_generator(function* () {
      var manifest = yield fetchJSON(repoUrl, `builds/${id}/manifest.json`);
      manifest.parentRepository = repoUrl;
      if (fetchScript) {
        manifest.jsPath = `plugins/scripts/${id}.js`;
        var js = yield fetchJS(repoUrl, `builds/${id}/index.js`);
        yield writeFile(manifest.jsPath, js);
      }
      yield updateStorage(`plugins/manifests/${id}.json`, manifest);
      if (registeredPlugins.has(id)) {
        var existingManifest = registeredPlugins.get(id);
        return Object.assign(existingManifest, manifest);
      }
      return manifest;
    })();
  }
  function refreshPlugin(id, repoUrl) {
    return _async_to_generator(function* () {
      var manifest = registeredPlugins.get(id);
      assert(manifest, id, "refresh a non-registered plugin");
      assert(pluginInstances.get(id), id, "refresh a non-started plugin");
      stopPlugin(id);
      if (isExternalPlugin(manifest)) {
        manifest = yield updateAndWritePlugin(repoUrl ?? manifest.parentRepository, id, true);
      }
      registeredPlugins.delete(id);
      registeredPlugins.set(id, manifest);
      yield startPlugin(id);
    })();
  }
  function updateRepository(repoUrl) {
    return _async_to_generator(function* () {
      var repo = yield fetchJSON(repoUrl, "repo.json");
      var storedRepo = pluginRepositories[repoUrl];
      var updated = false;
      if (!storedRepo) {
        for (var id in repo) {
          if (corePluginInstances.has(id)) {
            throw new Error(`Plugins can't have the same ID as any core plugin '${id}'`);
          }
        }
        updated = true;
        pluginRepositories[repoUrl] = repo;
      } else {
        for (var plugin in storedRepo)
          if (!repo[plugin]) {
            delete storedRepo[plugin];
          }
      }
      var pluginIds = Object.keys(repo).filter((id2) => !id2.startsWith("$"));
      yield Promise.all(pluginIds.map((pluginId) => _async_to_generator(function* () {
        if (!storedRepo || !storedRepo[pluginId] || repo[pluginId].alwaysFetch || isGreaterVersion(repo[pluginId].version, storedRepo[pluginId].version)) {
          updated = true;
          pluginRepositories[repoUrl][pluginId] = repo[pluginId];
          yield updateAndWritePlugin(repoUrl, pluginId, Boolean(storedRepo && pluginSettings[pluginId]));
        } else {
          var manifest2 = yield preloadStorageIfExists(`plugins/manifests/${pluginId}.json`);
          if (!manifest2) {
            yield updateAndWritePlugin(repoUrl, pluginId, Boolean(storedRepo && pluginSettings[pluginId]));
          }
        }
      })()));
      for (var id1 of pluginIds) {
        var manifest = getPreloadedStorage(`plugins/manifests/${id1}.json`);
        if (manifest === void 0)
          continue;
        var existing = registeredPlugins.get(id1);
        if (existing && !isGreaterVersion(manifest.version, existing.version)) {
          continue;
        }
        registeredPlugins.set(id1, manifest);
      }
      return updated;
    })();
  }
  function deleteRepository(repoUrl) {
    return _async_to_generator(function* () {
      assert(repoUrl !== OFFICIAL_PLUGINS_REPO_URL, repoUrl, "delete the official repository");
      assert(pluginRepositories[repoUrl], repoUrl, "delete a non-registered repository");
      var promQueues = [];
      for (var [id, manifest] of registeredPlugins) {
        if (!isExternalPlugin(manifest) || manifest.parentRepository !== repoUrl)
          continue;
        if (isPluginInstalled(id)) {
          promQueues.push(uninstallPlugin(id));
        }
        promQueues.push(purgeStorage2(`plugins/manifests/${id}.json`));
        registeredPlugins.delete(id);
      }
      delete pluginRepositories[repoUrl];
      yield Promise.all(promQueues);
      updateAllRepository();
    })();
  }
  function enablePlugin(id, start) {
    return _async_to_generator(function* () {
      assert(isPluginInstalled(id), id, "enable a non-installed plugin");
      if (start)
        yield startPlugin(id);
      pluginSettings[id].enabled = true;
    })();
  }
  function disablePlugin(id) {
    assert(isPluginInstalled(id), id, "disable a non-installed plugin");
    pluginInstances.has(id) && stopPlugin(id);
    pluginSettings[id].enabled = false;
  }
  function installPlugin(id, start) {
    return _async_to_generator(function* () {
      var manifest = registeredPlugins.get(id);
      assert(manifest, id, "install an non-registered plugin");
      assert(!isPluginInstalled(id), id, "install an already installed plugin");
      assert(isExternalPlugin(manifest), id, "install a core plugin");
      yield updateAndWritePlugin(manifest.parentRepository, id, true);
      pluginSettings[id] = {
        enabled: true
      };
      if (start)
        startPlugin(id);
    })();
  }
  function uninstallPlugin(id) {
    return _async_to_generator(function* () {
      var manifest = registeredPlugins.get(id);
      assert(manifest, id, "uninstall an unregistered plugin");
      assert(isPluginInstalled(id), id, "uninstall a non-installed plugin");
      assert(isExternalPlugin(manifest), id, "uninstall a core plugin");
      pluginInstances.has(id) && stopPlugin(id);
      delete pluginSettings[id];
      yield purgeStorage2(`plugins/storage/${id}.json`);
      yield removeFile(`plugins/scripts/${id}.js`);
    })();
  }
  function startPlugin(_0) {
    return _async_to_generator(function* (id, { throwIfDisabled = false, disableWhenThrown = true } = {}) {
      var manifest = registeredPlugins.get(id);
      assert(manifest, id, "start a non-registered plugin");
      assert(isPluginInstalled(id), id, "start a non-installed plugin");
      assert(!throwIfDisabled || pluginSettings[id]?.enabled, id, "start a disabled plugin");
      assert(!pluginInstances.has(id), id, "start an already started plugin");
      yield preloadStorageIfExists(`plugins/storage/${id}.json`);
      var pluginInstance2;
      if (isExternalPlugin(manifest)) {
        try {
          var iife = yield readFile(manifest.jsPath);
          var instantiator = globalEvalWithSourceUrl(`(bunny,definePlugin)=>{${iife};return plugin?.default ?? plugin;}`, `bunny-plugin/${id}-${manifest.version}`);
        } catch (error) {
          throw new Error("An error occured while parsing plugin's code, possibly a syntax error?", {
            cause: error
          });
        }
        try {
          var api = createBunnyPluginApi(id);
          pluginInstance2 = instantiator(api.object, (p) => {
            return Object.assign(p, {
              manifest
            });
          });
          if (!pluginInstance2)
            throw new Error(`Plugin '${id}' does not export a valid plugin instance`);
          apiObjects.set(id, api);
          pluginInstances.set(id, pluginInstance2);
        } catch (error) {
          throw new Error("An error occured while instantiating plugin's code", {
            cause: error
          });
        }
      } else {
        pluginInstance2 = corePluginInstances.get(id);
        assert(pluginInstance2, id, "start a non-existent core plugin");
        pluginInstances.set(id, pluginInstance2);
      }
      try {
        pluginInstance2.start?.();
        pluginSettings[id].enabled = true;
      } catch (error) {
        disableWhenThrown && disablePlugin(id);
        throw new Error("An error occured while starting the plugin", {
          cause: error
        });
      }
    }).apply(this, arguments);
  }
  function stopPlugin(id) {
    var instance = pluginInstances.get(id);
    assert(instance, id, "stop a non-started plugin");
    instance.stop?.();
    var obj = apiObjects.get(id);
    obj?.disposers.forEach((d) => d());
    pluginInstances.delete(id);
  }
  function updateAllRepository() {
    return _async_to_generator(function* () {
      try {
        yield updateRepository(OFFICIAL_PLUGINS_REPO_URL);
      } catch (error) {
        console.error("Failed to update official plugins repository", error);
      }
      yield allSettled(Object.keys(pluginRepositories).map((repo) => _async_to_generator(function* () {
        if (repo !== OFFICIAL_PLUGINS_REPO_URL) {
          yield updateRepository(repo);
        }
      })()));
    })();
  }
  function updatePlugins() {
    return _async_to_generator(function* () {
      yield awaitStorage2(pluginRepositories, pluginSettings);
      var corePlugins = getCorePlugins();
      for (var id in corePlugins) {
        var { default: instance, preenabled } = corePlugins[id];
        pluginSettings[id] ??= {
          enabled: preenabled ?? true
        };
        registeredPlugins.set(id, instance.manifest);
        corePluginInstances.set(id, instance);
      }
      yield updateAllRepository();
    })();
  }
  function initPlugins() {
    return _async_to_generator(function* () {
      yield awaitStorage2(pluginRepositories, pluginSettings);
      yield allSettled([
        ...registeredPlugins.keys()
      ].map((id) => _async_to_generator(function* () {
        if (isPluginEnabled(id)) {
          yield startPlugin(id);
        }
      })()));
    })();
  }
  var corePluginInstances, registeredPlugins, pluginInstances, apiObjects, pluginRepositories, pluginSettings, _fetch, fetchJS, fetchJSON;
  var init_plugins4 = __esm({
    "src/lib/addons/plugins/index.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_async_to_generator();
      init_plugins2();
      init_fs();
      init_storage2();
      init_utils();
      init_constants();
      init_common();
      init_api2();
      corePluginInstances = /* @__PURE__ */ new Map();
      registeredPlugins = /* @__PURE__ */ new Map();
      pluginInstances = /* @__PURE__ */ new Map();
      apiObjects = /* @__PURE__ */ new Map();
      pluginRepositories = createStorage2("plugins/repositories.json");
      pluginSettings = createStorage2("plugins/settings.json");
      _fetch = (repoUrl, path) => safeFetch(new URL(path, repoUrl), {
        cache: "no-store"
      });
      fetchJS = (repoUrl, path) => _fetch(repoUrl, path).then((r) => r.text());
      fetchJSON = (repoUrl, path) => _fetch(repoUrl, path).then((r) => r.json());
    }
  });

  // src/metro/common/stores.ts
  var UserStore;
  var init_stores = __esm({
    "src/metro/common/stores.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_wrappers();
      UserStore = findByStoreNameLazy("UserStore");
    }
  });

  // src/core/ui/settings/pages/Plugins/sheets/TitleComponent.tsx
  function TitleComponent({ plugin }) {
    var users = FluxUtils.useStateFromStoresArray([
      UserStore
    ], () => {
      plugin.authors?.forEach((a) => a.id && maybeFetchUser(a.id));
      return plugin.authors?.map((a) => UserStore.getUser(a.id));
    });
    var { authors } = plugin;
    var authorTextNode = [];
    if (authors) {
      var _loop3 = function(author2) {
        authorTextNode.push(/* @__PURE__ */ jsx(Text, {
          onPress: () => showUserProfileActionSheet({
            userId: author2.id
          }),
          variant: "text-md/medium",
          children: author2.name
        }));
        authorTextNode.push(", ");
      };
      for (var author of authors)
        _loop3(author);
      authorTextNode.pop();
    }
    return /* @__PURE__ */ jsxs(import_react_native21.View, {
      style: {
        gap: 4
      },
      children: [
        /* @__PURE__ */ jsx(import_react_native21.View, {
          children: /* @__PURE__ */ jsx(Text, {
            variant: "heading-xl/semibold",
            children: plugin.name
          })
        }),
        /* @__PURE__ */ jsx(import_react_native21.View, {
          style: {
            flexDirection: "row",
            flexShrink: 1
          },
          children: authors?.length && /* @__PURE__ */ jsxs(import_react_native21.View, {
            style: {
              flexDirection: "row",
              gap: 8,
              alignItems: "center",
              paddingVertical: 4,
              paddingHorizontal: 8,
              backgroundColor: "#00000016",
              borderRadius: 32
            },
            children: [
              users.length && /* @__PURE__ */ jsx(AvatarPile, {
                size: "xxsmall",
                names: plugin.authors?.map((a) => a.name),
                totalCount: plugin.authors?.length,
                children: users.map((a) => /* @__PURE__ */ jsx(Avatar, {
                  size: "xxsmall",
                  user: a
                }))
              }),
              /* @__PURE__ */ jsx(Text, {
                variant: "text-md/medium",
                children: authorTextNode
              })
            ]
          })
        })
      ]
    });
  }
  var import_react_native21, showUserProfileActionSheet, maybeFetchUser;
  var init_TitleComponent = __esm({
    "src/core/ui/settings/pages/Plugins/sheets/TitleComponent.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_jsxRuntime();
      init_lazy();
      init_metro();
      init_common();
      init_components();
      init_stores();
      import_react_native21 = __toESM(require_react_native());
      showUserProfileActionSheet = findByNameLazy("showUserProfileActionSheet");
      ({ getUser: maybeFetchUser } = lazyDestructure(() => findByProps("getUser", "fetchProfile")));
    }
  });

  // src/core/ui/settings/pages/Plugins/sheets/PluginInfoActionSheet.tsx
  var PluginInfoActionSheet_exports = {};
  __export(PluginInfoActionSheet_exports, {
    default: () => PluginInfoActionSheet
  });
  function PluginInfoIconButton(props) {
    var { onPress } = props;
    props.onPress &&= () => {
      hideSheet("PluginInfoActionSheet");
      onPress?.();
    };
    return /* @__PURE__ */ jsx(IconButton, {
      ...props
    });
  }
  function PluginInfoActionSheet({ plugin, navigation: navigation2 }) {
    plugin.usePluginState();
    return /* @__PURE__ */ jsx(ActionSheet, {
      children: /* @__PURE__ */ jsxs(import_react_native22.ScrollView, {
        contentContainerStyle: {
          gap: 12,
          marginBottom: 12
        },
        children: [
          /* @__PURE__ */ jsxs(import_react_native22.View, {
            style: {
              flexDirection: "row",
              alignItems: "center",
              gap: 8,
              paddingVertical: 24,
              justifyContent: "space-between",
              width: "100%"
            },
            children: [
              /* @__PURE__ */ jsx(TitleComponent, {
                plugin
              }),
              /* @__PURE__ */ jsx(ContextMenu, {
                items: [
                  {
                    label: "Details",
                    iconSource: findAssetId("CircleInformationIcon-primary"),
                    action: () => {
                    }
                  },
                  // {
                  //     label: true ? "Disable Updates" : "Enable Updates",
                  //     iconSource: true ? findAssetId("ClockXIcon") : findAssetId("ClockIcon"),
                  //     action: () => {
                  //     }
                  // },
                  {
                    label: "Clear Data",
                    iconSource: findAssetId("FileIcon"),
                    variant: "destructive",
                    action: () => {
                    }
                  },
                  {
                    label: "Uninstall",
                    iconSource: findAssetId("TrashIcon"),
                    variant: "destructive",
                    action: () => {
                    }
                  }
                ],
                children: (props) => /* @__PURE__ */ jsx(IconButton, {
                  ...props,
                  icon: findAssetId("MoreHorizontalIcon"),
                  variant: "secondary",
                  size: "sm"
                })
              })
            ]
          }),
          /* @__PURE__ */ jsxs(import_react_native22.View, {
            style: {
              flexDirection: "row",
              justifyContent: "space-around",
              alignContent: "center"
            },
            children: [
              /* @__PURE__ */ jsx(PluginInfoIconButton, {
                label: "Configure",
                variant: "secondary",
                disabled: !plugin.getPluginSettingsComponent(),
                icon: findAssetId("WrenchIcon"),
                onPress: () => {
                  navigation2.push("BUNNY_CUSTOM_PAGE", {
                    title: plugin.name,
                    render: plugin.getPluginSettingsComponent()
                  });
                }
              }),
              /* @__PURE__ */ jsx(PluginInfoIconButton, {
                label: "Refetch",
                variant: "secondary",
                icon: findAssetId("RetryIcon"),
                onPress: () => {
                  startPlugin(plugin.id);
                }
              }),
              /* @__PURE__ */ jsx(PluginInfoIconButton, {
                label: "Copy URL",
                variant: "secondary",
                icon: findAssetId("LinkIcon"),
                onPress: () => {
                }
              })
            ]
          }),
          /* @__PURE__ */ jsxs(Card, {
            children: [
              /* @__PURE__ */ jsx(Text, {
                variant: "text-md/semibold",
                color: "text-strong",
                style: {
                  marginBottom: 4
                },
                children: "Description"
              }),
              /* @__PURE__ */ jsx(Text, {
                variant: "text-md/medium",
                children: plugin.description
              })
            ]
          })
        ]
      })
    });
  }
  var import_react_native22;
  var init_PluginInfoActionSheet = __esm({
    "src/core/ui/settings/pages/Plugins/sheets/PluginInfoActionSheet.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_jsxRuntime();
      init_plugins4();
      init_assets();
      init_sheets();
      init_components();
      import_react_native22 = __toESM(require_react_native());
      init_TitleComponent();
    }
  });

  // src/core/ui/settings/pages/Plugins/models/bunny.ts
  function unifyBunnyPlugin(manifest) {
    return {
      id: manifest.id,
      name: manifest.display.name,
      description: manifest.display.description,
      authors: manifest.display.authors,
      getBadges() {
        return [
          {
            source: {
              uri: revenge_default
            }
          }
        ];
      },
      isEnabled: () => isPluginEnabled(manifest.id),
      isInstalled: () => manifest.id in pluginSettings,
      usePluginState() {
        useObservable([
          pluginSettings
        ]);
      },
      toggle(start) {
        try {
          start ? enablePlugin(manifest.id, true) : disablePlugin(manifest.id);
        } catch (e) {
          console.error(e);
        }
      },
      resolveSheetComponent() {
        return Promise.resolve().then(() => (init_PluginInfoActionSheet(), PluginInfoActionSheet_exports));
      },
      getPluginSettingsComponent() {
        return getPluginSettingsComponent(manifest.id);
      }
    };
  }
  var init_bunny = __esm({
    "src/core/ui/settings/pages/Plugins/models/bunny.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_settings3();
      init_plugins4();
      init_storage2();
    }
  });

  // src/core/ui/settings/pages/Plugins/sheets/VdPluginInfoActionSheet.tsx
  var VdPluginInfoActionSheet_exports = {};
  __export(VdPluginInfoActionSheet_exports, {
    default: () => PluginInfoActionSheet2
  });
  function PluginInfoActionSheet2({ plugin, navigation: navigation2 }) {
    plugin.usePluginState();
    var vdPlugin = VdPluginManager.plugins[plugin.id];
    var SettingsComponent = plugin.getPluginSettingsComponent();
    return /* @__PURE__ */ jsx(ActionSheet, {
      children: /* @__PURE__ */ jsxs(import_react_native23.ScrollView, {
        children: [
          /* @__PURE__ */ jsxs(import_react_native23.View, {
            style: {
              flexDirection: "row",
              alignItems: "center",
              paddingVertical: 24
            },
            children: [
              /* @__PURE__ */ jsx(Text, {
                variant: "heading-xl/semibold",
                children: plugin.name
              }),
              /* @__PURE__ */ jsx(import_react_native23.View, {
                style: {
                  marginLeft: "auto"
                },
                children: SettingsComponent && /* @__PURE__ */ jsx(Button, {
                  size: "md",
                  text: "Configure",
                  variant: "secondary",
                  icon: findAssetId("WrenchIcon"),
                  onPress: () => {
                    hideSheet("PluginInfoActionSheet");
                    navigation2.push("BUNNY_CUSTOM_PAGE", {
                      title: plugin.name,
                      render: SettingsComponent
                    });
                  }
                })
              })
            ]
          }),
          /* @__PURE__ */ jsxs(ActionSheetRow.Group, {
            children: [
              /* @__PURE__ */ jsx(ActionSheetRow, {
                label: Strings.REFETCH,
                icon: /* @__PURE__ */ jsx(TableRow.Icon, {
                  source: findAssetId("RetryIcon")
                }),
                onPress: () => _async_to_generator(function* () {
                  if (vdPlugin.enabled)
                    VdPluginManager.stopPlugin(plugin.id, false);
                  try {
                    yield VdPluginManager.fetchPlugin(plugin.id);
                    showToast(Strings.PLUGIN_REFETCH_SUCCESSFUL, findAssetId("DownloadIcon"));
                  } catch (unused) {
                    showToast(Strings.PLUGIN_REFETCH_FAILED, findAssetId("XSmallIcon"));
                  }
                  if (vdPlugin.enabled)
                    yield VdPluginManager.startPlugin(plugin.id);
                  hideSheet("PluginInfoActionSheet");
                })()
              }),
              /* @__PURE__ */ jsx(ActionSheetRow, {
                label: Strings.COPY_URL,
                icon: /* @__PURE__ */ jsx(TableRow.Icon, {
                  source: findAssetId("LinkIcon")
                }),
                onPress: () => {
                  clipboard.setString(plugin.id);
                  showToast.showCopyToClipboard();
                }
              }),
              /* @__PURE__ */ jsx(ActionSheetRow, {
                label: vdPlugin.update ? Strings.DISABLE_UPDATES : Strings.ENABLE_UPDATES,
                icon: /* @__PURE__ */ jsx(TableRow.Icon, {
                  source: findAssetId("DownloadIcon")
                }),
                onPress: () => {
                  vdPlugin.update = !vdPlugin.update;
                  showToast(formatString("TOASTS_PLUGIN_UPDATE", {
                    update: vdPlugin.update,
                    name: plugin.name
                  }), findAssetId("DownloadIcon"));
                }
              }),
              /* @__PURE__ */ jsx(ActionSheetRow, {
                label: Strings.CLEAR_DATA,
                icon: /* @__PURE__ */ jsx(TableRow.Icon, {
                  variant: "danger",
                  source: findAssetId("CopyIcon")
                }),
                variant: "danger",
                onPress: () => showConfirmationAlert({
                  title: Strings.HOLD_UP,
                  content: formatString("ARE_YOU_SURE_TO_CLEAR_DATA", {
                    name: plugin.name
                  }),
                  confirmText: Strings.CLEAR,
                  cancelText: Strings.CANCEL,
                  confirmColor: "red",
                  onConfirm: () => _async_to_generator(function* () {
                    if (vdPlugin.enabled)
                      VdPluginManager.stopPlugin(plugin.id, false);
                    try {
                      yield VdPluginManager.fetchPlugin(plugin.id);
                      showToast(Strings.PLUGIN_REFETCH_SUCCESSFUL, findAssetId("DownloadIcon"));
                    } catch (unused) {
                      showToast(Strings.PLUGIN_REFETCH_FAILED, findAssetId("XSmallIcon"));
                    }
                    var message;
                    try {
                      purgeStorage(plugin.id);
                      message = [
                        "CLEAR_DATA_SUCCESSFUL",
                        "TrashIcon"
                      ];
                    } catch (unused) {
                      message = [
                        "CLEAR_DATA_FAILED",
                        "XSmallIcon"
                      ];
                    }
                    showToast(formatString(message[0], {
                      name: plugin.name
                    }), findAssetId(message[1]));
                    if (vdPlugin.enabled)
                      yield VdPluginManager.startPlugin(plugin.id);
                    hideSheet("PluginInfoActionSheet");
                  })()
                })
              }),
              /* @__PURE__ */ jsx(ActionSheetRow, {
                label: Strings.DELETE,
                icon: /* @__PURE__ */ jsx(TableRow.Icon, {
                  variant: "danger",
                  source: findAssetId("TrashIcon")
                }),
                variant: "danger",
                onPress: () => showConfirmationAlert({
                  title: Strings.HOLD_UP,
                  content: formatString("ARE_YOU_SURE_TO_DELETE_PLUGIN", {
                    name: plugin.name
                  }),
                  confirmText: Strings.DELETE,
                  cancelText: Strings.CANCEL,
                  confirmColor: "red",
                  onConfirm: () => {
                    try {
                      VdPluginManager.removePlugin(plugin.id);
                    } catch (e) {
                      showToast(String(e), findAssetId("XSmallIcon"));
                    }
                    hideSheet("PluginInfoActionSheet");
                  }
                })
              })
            ]
          })
        ]
      })
    });
  }
  var import_react_native23;
  var init_VdPluginInfoActionSheet = __esm({
    "src/core/ui/settings/pages/Plugins/sheets/VdPluginInfoActionSheet.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_async_to_generator();
      init_jsxRuntime();
      init_i18n();
      init_alerts2();
      init_plugins();
      init_storage();
      init_assets();
      init_common();
      init_components();
      init_sheets();
      init_toasts();
      import_react_native23 = __toESM(require_react_native());
    }
  });

  // src/core/ui/settings/pages/Plugins/models/vendetta.ts
  function unifyVdPlugin(vdPlugin) {
    return {
      id: vdPlugin.id,
      name: vdPlugin.manifest.name,
      description: vdPlugin.manifest.description,
      authors: vdPlugin.manifest.authors,
      icon: vdPlugin.manifest.vendetta?.icon,
      getBadges() {
        return [];
      },
      isEnabled: () => vdPlugin.enabled,
      isInstalled: () => Boolean(vdPlugin && VdPluginManager.plugins[vdPlugin.id]),
      usePluginState() {
        useProxy(VdPluginManager.plugins[vdPlugin.id]);
      },
      toggle(start) {
        start ? VdPluginManager.startPlugin(vdPlugin.id) : VdPluginManager.stopPlugin(vdPlugin.id);
      },
      resolveSheetComponent() {
        return Promise.resolve().then(() => (init_VdPluginInfoActionSheet(), VdPluginInfoActionSheet_exports));
      },
      getPluginSettingsComponent() {
        return VdPluginManager.getSettings(vdPlugin.id);
      }
    };
  }
  var init_vendetta = __esm({
    "src/core/ui/settings/pages/Plugins/models/vendetta.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_plugins();
      init_storage();
    }
  });

  // src/core/ui/settings/pages/Plugins/index.tsx
  var Plugins_exports = {};
  __export(Plugins_exports, {
    default: () => Plugins
  });
  function PluginPage(props) {
    var items = props.useItems();
    return /* @__PURE__ */ jsx(AddonPage, {
      CardComponent: PluginCard,
      title: Strings.PLUGINS,
      searchKeywords: [
        "name",
        "description",
        (p) => p.authors?.map((a) => typeof a === "string" ? a : a.name).join() || ""
      ],
      sortOptions: {
        "Name (A-Z)": (a, b3) => a.name.localeCompare(b3.name),
        "Name (Z-A)": (a, b3) => b3.name.localeCompare(a.name),
        "Enabled": (a, b3) => Number(b3.isEnabled()) - Number(a.isEnabled()),
        "Disabled": (a, b3) => Number(a.isEnabled()) - Number(b3.isEnabled())
      },
      safeModeHint: {
        message: Strings.SAFE_MODE_NOTICE_PLUGINS
      },
      items,
      ...props
    });
  }
  function Plugins() {
    useProxy(settings);
    var navigation2 = NavigationNative.useNavigation();
    return /* @__PURE__ */ jsx(PluginPage, {
      useItems: () => {
        useProxy(VdPluginManager.plugins);
        useObservable([
          pluginSettings
        ]);
        var vdPlugins = Object.values(VdPluginManager.plugins).map(unifyVdPlugin);
        var bnPlugins = [
          ...registeredPlugins.values()
        ].filter((p) => isPluginInstalled(p.id) && !isCorePlugin(p.id)).map(unifyBunnyPlugin);
        return [
          ...vdPlugins,
          ...bnPlugins
        ];
      },
      ListHeaderComponent: () => {
        var unproxiedPlugins = Object.values(VdPluginManager.plugins).filter((p) => !p.id.startsWith(VD_PROXY_PREFIX) && !p.id.startsWith(BUNNY_PROXY_PREFIX));
        if (!unproxiedPlugins.length)
          return null;
        return /* @__PURE__ */ jsx(import_react_native24.View, {
          style: {
            marginVertical: 12,
            marginHorizontal: 10
          },
          children: /* @__PURE__ */ jsx(Card, {
            border: "strong",
            children: /* @__PURE__ */ jsxs(import_react_native24.View, {
              style: {
                flex: 1,
                justifyContent: "center",
                alignItems: "center",
                flexDirection: "row"
              },
              children: [
                /* @__PURE__ */ jsxs(import_react_native24.View, {
                  style: {
                    gap: 6,
                    flexShrink: 1
                  },
                  children: [
                    /* @__PURE__ */ jsx(Text, {
                      variant: "heading-md/bold",
                      children: "Unproxied Plugins Found"
                    }),
                    /* @__PURE__ */ jsx(Text, {
                      variant: "text-sm/medium",
                      color: "text-muted",
                      children: "Plugins installed from unproxied sources may run unverified code in this app without your awareness."
                    })
                  ]
                }),
                /* @__PURE__ */ jsx(import_react_native24.View, {
                  style: {
                    marginLeft: "auto"
                  },
                  children: /* @__PURE__ */ jsx(IconButton, {
                    size: "sm",
                    variant: "secondary",
                    icon: findAssetId("CircleInformationIcon-primary"),
                    style: {
                      marginLeft: 8
                    },
                    onPress: () => {
                      navigation2.push("BUNNY_CUSTOM_PAGE", {
                        title: "Unproxied Plugins",
                        render: () => {
                          return /* @__PURE__ */ jsx(FlashList, {
                            data: unproxiedPlugins,
                            contentContainerStyle: {
                              padding: 8
                            },
                            ItemSeparatorComponent: () => /* @__PURE__ */ jsx(import_react_native24.View, {
                              style: {
                                height: 8
                              }
                            }),
                            renderItem: ({ item: p }) => /* @__PURE__ */ jsx(Card, {
                              children: /* @__PURE__ */ jsx(Text, {
                                variant: "heading-md/semibold",
                                children: p.id
                              })
                            })
                          });
                        }
                      });
                    }
                  })
                })
              ]
            })
          })
        });
      },
      ListFooterComponent: () => false,
      installAction: {
        label: "Install a plugin",
        fetchFn: (url2) => _async_to_generator(function* () {
          if (!url2.startsWith(VD_PROXY_PREFIX) && !url2.startsWith(BUNNY_PROXY_PREFIX) && !settings.developerSettings) {
            openAlert2("bunny-plugin-unproxied-confirmation", /* @__PURE__ */ jsx(AlertModal3, {
              title: "Hold On!",
              content: "You're trying to install a plugin from an unproxied external source. This means you're trusting the creator to run their code in this app without your knowledge. Are you sure you want to continue?",
              extraContent: /* @__PURE__ */ jsx(Card, {
                children: /* @__PURE__ */ jsx(Text, {
                  variant: "text-md/bold",
                  children: url2
                })
              }),
              actions: /* @__PURE__ */ jsxs(AlertActions2, {
                children: [
                  /* @__PURE__ */ jsx(AlertActionButton3, {
                    text: "Continue",
                    variant: "primary",
                    onPress: () => {
                      VdPluginManager.installPlugin(url2).then(() => showToast(Strings.TOASTS_INSTALLED_PLUGIN, findAssetId("DownloadIcon"))).catch((e) => openAlert2("bunny-plugin-install-failed", /* @__PURE__ */ jsx(AlertModal3, {
                        title: "Install Failed",
                        content: `Unable to install plugin from '${url2}':`,
                        extraContent: /* @__PURE__ */ jsx(Card, {
                          children: /* @__PURE__ */ jsx(Text, {
                            variant: "text-md/normal",
                            children: e instanceof Error ? e.message : String(e)
                          })
                        }),
                        actions: /* @__PURE__ */ jsx(AlertActionButton3, {
                          text: "Okay",
                          variant: "primary"
                        })
                      })));
                    }
                  }),
                  /* @__PURE__ */ jsx(AlertActionButton3, {
                    text: "Cancel",
                    variant: "secondary"
                  })
                ]
              })
            }));
          } else {
            return yield VdPluginManager.installPlugin(url2);
          }
        })()
      }
    });
  }
  var import_react_native24, openAlert2, AlertModal3, AlertActions2, AlertActionButton3;
  var init_Plugins = __esm({
    "src/core/ui/settings/pages/Plugins/index.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_async_to_generator();
      init_jsxRuntime();
      init_i18n();
      init_AddonPage();
      init_PluginCard();
      init_plugins();
      init_storage();
      init_plugins4();
      init_assets();
      init_settings();
      init_storage2();
      init_toasts();
      init_constants();
      init_lazy();
      init_metro();
      init_common();
      init_components();
      import_react_native24 = __toESM(require_react_native());
      init_bunny();
      init_vendetta();
      ({ openAlert: openAlert2 } = lazyDestructure(() => findByProps("openAlert", "dismissAlert")));
      ({ AlertModal: AlertModal3, AlertActions: AlertActions2, AlertActionButton: AlertActionButton3 } = lazyDestructure(() => findByProps("AlertModal", "AlertActions")));
    }
  });

  // src/core/ui/components/AddonCard.tsx
  function AddonCard(props) {
    var styles3 = useStyles3();
    return /* @__PURE__ */ jsx(Card, {
      children: /* @__PURE__ */ jsxs(Stack, {
        spacing: 16,
        children: [
          /* @__PURE__ */ jsxs(import_react_native25.View, {
            style: {
              flexDirection: "row",
              alignItems: "center"
            },
            children: [
              /* @__PURE__ */ jsxs(import_react_native25.View, {
                style: styles3.headerLeading,
                children: [
                  /* @__PURE__ */ jsx(Text, {
                    style: styles3.headerLabel,
                    children: props.headerLabel
                  }),
                  props.headerSublabel && /* @__PURE__ */ jsx(Text, {
                    style: styles3.headerSubtitle,
                    children: props.headerSublabel
                  })
                ]
              }),
              /* @__PURE__ */ jsxs(import_react_native25.View, {
                style: [
                  styles3.headerTrailing,
                  {
                    marginLeft: "auto"
                  }
                ],
                children: [
                  /* @__PURE__ */ jsxs(import_react_native25.View, {
                    style: styles3.actions,
                    children: [
                      props.overflowActions && /* @__PURE__ */ jsx(IconButton, {
                        onPress: () => showSimpleActionSheet3({
                          key: "CardOverflow",
                          header: {
                            title: props.overflowTitle,
                            icon: props.headerIcon && /* @__PURE__ */ jsx(LegacyFormRow.Icon, {
                              style: {
                                marginRight: 8
                              },
                              source: findAssetId(props.headerIcon)
                            }),
                            onClose: () => hideActionSheet2()
                          },
                          options: props.overflowActions?.map((i) => ({
                            ...i,
                            icon: findAssetId(i.icon)
                          }))
                        }),
                        size: "sm",
                        variant: "secondary",
                        icon: findAssetId("CircleInformationIcon-primary")
                      }),
                      props.actions?.map(({ icon, onPress, disabled }) => /* @__PURE__ */ jsx(IconButton, {
                        onPress,
                        disabled,
                        size: "sm",
                        variant: "secondary",
                        icon: findAssetId(icon)
                      }))
                    ]
                  }),
                  props.toggleType && (props.toggleType === "switch" ? /* @__PURE__ */ jsx(FormSwitch, {
                    value: props.toggleValue(),
                    onValueChange: props.onToggleChange
                  }) : /* @__PURE__ */ jsx(import_react_native25.TouchableOpacity, {
                    onPress: () => {
                      props.onToggleChange?.(!props.toggleValue());
                    },
                    children: /* @__PURE__ */ jsx(FormRadio, {
                      selected: props.toggleValue()
                    })
                  }))
                ]
              })
            ]
          }),
          props.descriptionLabel && /* @__PURE__ */ jsx(Text, {
            variant: "text-md/medium",
            children: props.descriptionLabel
          })
        ]
      })
    });
  }
  var import_react_native25, hideActionSheet2, showSimpleActionSheet3, useStyles3;
  var init_AddonCard = __esm({
    "src/core/ui/components/AddonCard.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_jsxRuntime();
      init_assets();
      init_lazy();
      init_components();
      init_wrappers();
      init_color();
      init_styles();
      import_react_native25 = __toESM(require_react_native());
      ({ hideActionSheet: hideActionSheet2 } = lazyDestructure(() => findByProps("openLazy", "hideActionSheet")));
      ({ showSimpleActionSheet: showSimpleActionSheet3 } = lazyDestructure(() => findByProps("showSimpleActionSheet")));
      useStyles3 = createStyles({
        card: {
          backgroundColor: semanticColors?.CARD_SECONDARY_BG,
          borderRadius: 12,
          overflow: "hidden"
        },
        header: {
          padding: 0
        },
        headerLeading: {
          flexDirection: "column",
          justifyContent: "center",
          scale: 1.2
        },
        headerTrailing: {
          display: "flex",
          flexDirection: "row",
          gap: 15,
          alignItems: "center"
        },
        headerLabel: {
          ...TextStyleSheet["heading-md/semibold"],
          color: semanticColors.TEXT_DEFAULT
        },
        headerSubtitle: {
          ...TextStyleSheet["text-md/semibold"],
          color: semanticColors.TEXT_MUTED
        },
        descriptionLabel: {
          ...TextStyleSheet["text-md/semibold"],
          color: semanticColors.TEXT_DEFAULT
        },
        actions: {
          flexDirection: "row-reverse",
          alignItems: "center",
          gap: 5
        },
        iconStyle: {
          tintColor: semanticColors.INTERACTIVE_ICON_DEFAULT,
          opacity: 0.2,
          height: 64,
          width: 64,
          left: void 0,
          right: "30%",
          top: "-10%"
        }
      });
    }
  });

  // src/core/ui/settings/pages/Themes/ThemeCard.tsx
  function selectAndApply(value, theme) {
    try {
      selectTheme(value ? theme : null);
    } catch (e) {
      console.error("Error while selectAndApply,", e);
    }
  }
  function ThemeCard({ item: theme }) {
    useProxy(theme);
    var [removed, setRemoved] = React.useState(false);
    if (removed)
      return null;
    var { authors } = theme.data;
    return /* @__PURE__ */ jsx(AddonCard, {
      headerLabel: theme.data.name,
      headerSublabel: authors ? `by ${authors.map((i) => i.name).join(", ")}` : "",
      descriptionLabel: theme.data.description ?? "No description.",
      toggleType: !settings.safeMode?.enabled ? "radio" : void 0,
      toggleValue: () => themes[theme.id].selected,
      onToggleChange: (v2) => {
        selectAndApply(v2, theme);
      },
      overflowTitle: theme.data.name,
      overflowActions: [
        {
          icon: "RefreshIcon",
          label: Strings.REFETCH,
          onPress: () => {
            fetchTheme(theme.id, theme.selected).then(() => {
              showToast(Strings.THEME_REFETCH_SUCCESSFUL, findAssetId("DownloadIcon"));
            }).catch(() => {
              showToast(Strings.THEME_REFETCH_FAILED, findAssetId("XSmallIcon"));
            });
          }
        },
        {
          icon: "LinkIcon",
          label: Strings.COPY_URL,
          onPress: () => {
            clipboard.setString(theme.id);
            showToast.showCopyToClipboard();
          }
        },
        {
          icon: "TrashIcon",
          label: Strings.DELETE,
          isDestructive: true,
          onPress: () => showConfirmationAlert({
            title: Strings.HOLD_UP,
            content: formatString("ARE_YOU_SURE_TO_DELETE_THEME", {
              name: theme.data.name
            }),
            confirmText: Strings.DELETE,
            cancelText: Strings.CANCEL,
            confirmColor: "red",
            onConfirm: () => {
              removeTheme(theme.id).then((wasSelected) => {
                setRemoved(true);
                if (wasSelected)
                  selectAndApply(false, theme);
              }).catch((e) => {
                showToast(e.message, findAssetId("XSmallIcon"));
              });
            }
          })
        }
      ]
    });
  }
  var init_ThemeCard = __esm({
    "src/core/ui/settings/pages/Themes/ThemeCard.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_jsxRuntime();
      init_i18n();
      init_AddonCard();
      init_alerts2();
      init_storage();
      init_themes();
      init_assets();
      init_settings();
      init_common();
      init_toasts();
    }
  });

  // src/core/ui/settings/pages/Themes/index.tsx
  var Themes_exports = {};
  __export(Themes_exports, {
    default: () => Themes
  });
  function Themes() {
    useProxy(settings);
    useProxy(themes);
    return /* @__PURE__ */ jsx(AddonPage, {
      title: Strings.THEMES,
      searchKeywords: [
        "data.name",
        "data.description",
        (p) => p.data.authors?.map((a) => a.name).join(", ") ?? ""
      ],
      sortOptions: {
        "Name (A-Z)": (a, b3) => a.data.name.localeCompare(b3.data.name),
        "Name (Z-A)": (a, b3) => b3.data.name.localeCompare(a.data.name)
      },
      installAction: {
        label: "Install a theme",
        fetchFn: installTheme
      },
      items: Object.values(themes),
      safeModeHint: {
        message: formatString("SAFE_MODE_NOTICE_THEMES", {
          enabled: Boolean(settings.safeMode?.currentThemeId)
        }),
        footer: settings.safeMode?.currentThemeId && /* @__PURE__ */ jsx(Button, {
          size: "small",
          text: Strings.DISABLE_THEME,
          onPress: () => delete settings.safeMode?.currentThemeId,
          style: {
            marginTop: 8
          }
        })
      },
      CardComponent: ThemeCard,
      OptionsActionSheetComponent: () => {
        useObservable([
          colorsPref
        ]);
        return /* @__PURE__ */ jsxs(ActionSheet, {
          children: [
            /* @__PURE__ */ jsx(BottomSheetTitleHeader, {
              title: "Options"
            }),
            /* @__PURE__ */ jsxs(import_react_native26.View, {
              style: {
                paddingVertical: 20,
                gap: 12
              },
              children: [
                /* @__PURE__ */ jsxs(TableRadioGroup, {
                  title: "Override Theme Type",
                  defaultValue: colorsPref.type ?? "auto",
                  hasIcons: true,
                  onChange: (type) => {
                    colorsPref.type = type !== "auto" ? type : void 0;
                    getCurrentTheme()?.data && updateBunnyColor(getCurrentTheme().data, {
                      update: true
                    });
                  },
                  children: [
                    /* @__PURE__ */ jsx(TableRadioRow, {
                      icon: /* @__PURE__ */ jsx(TableRowIcon, {
                        source: findAssetId("RobotIcon")
                      }),
                      label: "Auto",
                      value: "auto"
                    }),
                    /* @__PURE__ */ jsx(TableRadioRow, {
                      icon: /* @__PURE__ */ jsx(TableRowIcon, {
                        source: findAssetId("ThemeDarkIcon")
                      }),
                      label: "Dark",
                      value: "dark"
                    }),
                    /* @__PURE__ */ jsx(TableRadioRow, {
                      icon: /* @__PURE__ */ jsx(TableRowIcon, {
                        source: findAssetId("ThemeLightIcon")
                      }),
                      label: "Light",
                      value: "light"
                    })
                  ]
                }),
                /* @__PURE__ */ jsx(TableRowGroup, {
                  title: "Settings",
                  children: /* @__PURE__ */ jsx(TableSwitchRow, {
                    label: "Show Chat Background",
                    subLabel: "Shows or hides the theme's background image in chat",
                    icon: /* @__PURE__ */ jsx(TableRow.Icon, {
                      source: findAssetId("ImageIcon")
                    }),
                    value: colorsPref.customBackground !== "hidden",
                    onValueChange: (value) => {
                      colorsPref.customBackground = value ? null : "hidden";
                    }
                  })
                })
              ]
            })
          ]
        });
      }
    });
  }
  var import_react_native26;
  var init_Themes = __esm({
    "src/core/ui/settings/pages/Themes/index.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_jsxRuntime();
      init_i18n();
      init_AddonPage();
      init_ThemeCard();
      init_storage();
      init_themes();
      init_preferences();
      init_updater();
      init_assets();
      init_settings();
      init_storage2();
      init_components();
      import_react_native26 = __toESM(require_react_native());
    }
  });

  // src/lib/addons/fonts/index.ts
  var fonts_exports = {};
  __export(fonts_exports, {
    fonts: () => fonts,
    installFont: () => installFont,
    removeFont: () => removeFont,
    saveFont: () => saveFont,
    selectFont: () => selectFont,
    updateFont: () => updateFont,
    updateFonts: () => updateFonts,
    validateFont: () => validateFont
  });
  function writeFont(font) {
    return _async_to_generator(function* () {
      if (!font && font !== null)
        throw new Error("Arg font must be a valid object or null");
      if (font) {
        yield writeFile("fonts.json", JSON.stringify(font));
      } else {
        yield removeFile("fonts.json");
      }
    })();
  }
  function validateFont(font) {
    if (!font || typeof font !== "object")
      throw new Error("URL returned a null/non-object JSON");
    if (typeof font.spec !== "number")
      throw new Error("Invalid font 'spec' number");
    if (font.spec !== 1)
      throw new Error("Only fonts which follows spec:1 are supported");
    var requiredFields = [
      "name",
      "main"
    ];
    if (requiredFields.some((f) => !font[f]))
      throw new Error(`Font is missing one of the fields: ${requiredFields}`);
    if (font.name.startsWith("__"))
      throw new Error("Font names cannot start with __");
    if (font.name in fonts)
      throw new Error(`There is already a font named '${font.name}' installed`);
  }
  function saveFont(data, selected = false) {
    return _async_to_generator(function* () {
      var fontDefJson;
      if (typeof data === "string") {
        try {
          fontDefJson = yield (yield safeFetch(data)).json();
        } catch (e) {
          throw new Error(`Failed to fetch fonts at ${data}`, {
            cause: e
          });
        }
      } else {
        fontDefJson = data;
      }
      validateFont(fontDefJson);
      var errors = yield allSettled(Object.entries(fontDefJson.main).map(([font, url2]) => _async_to_generator(function* () {
        var ext = url2.split(".").pop();
        if (ext !== "ttf" && ext !== "otf")
          ext = "ttf";
        var path = `downloads/fonts/${fontDefJson.name}/${font}.${ext}`;
        if (!(yield fileExists(path)))
          yield downloadFile(url2, path);
      })())).then((it) => it.map((it2) => it2.status === "fulfilled" ? void 0 : it2.reason));
      if (errors.some((it) => it))
        throw errors;
      fonts[fontDefJson.name] = fontDefJson;
      if (selected)
        writeFont(fonts[fontDefJson.name]);
      return fontDefJson;
    })();
  }
  function updateFont(fontDef) {
    return _async_to_generator(function* () {
      var fontDefCopy = {
        ...fontDef
      };
      if (fontDefCopy.source)
        fontDefCopy = {
          ...yield fetch(fontDefCopy.source).then((it) => it.json()),
          // Can't change these properties
          name: fontDef.name,
          source: fontDef.source
        };
      var selected = fonts.__selected === fontDef.name;
      yield removeFont(fontDef.name);
      yield saveFont(fontDefCopy, selected);
    })();
  }
  function installFont(url2, selected = false) {
    return _async_to_generator(function* () {
      var font = yield saveFont(url2);
      if (selected)
        yield selectFont(font.name);
    })();
  }
  function selectFont(name) {
    return _async_to_generator(function* () {
      if (name && !(name in fonts))
        throw new Error("Selected font does not exist!");
      if (name) {
        fonts.__selected = name;
      } else {
        delete fonts.__selected;
      }
      yield writeFont(name == null ? null : fonts[name]);
    })();
  }
  function removeFont(name) {
    return _async_to_generator(function* () {
      var selected = fonts.__selected === name;
      if (selected)
        yield selectFont(null);
      delete fonts[name];
      try {
        yield clearFolder(`downloads/fonts/${name}`);
      } catch (unused) {
      }
    })();
  }
  function updateFonts() {
    return _async_to_generator(function* () {
      yield awaitStorage(fonts);
      yield allSettled(Object.keys(fonts).map((name) => saveFont(fonts[name], fonts.__selected === name)));
    })();
  }
  var fonts;
  var init_fonts = __esm({
    "src/lib/addons/fonts/index.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_async_to_generator();
      init_storage();
      init_fs();
      init_utils();
      fonts = wrapSync(createStorage(createMMKVBackend("BUNNY_FONTS")));
    }
  });

  // src/core/ui/settings/pages/Fonts/FontEditor.tsx
  function promptDetachConfirmationForThen(fontName, cb) {
    if (fontName && fonts[fontName].source)
      openAlert3("revenge-fonts-detach-source-confirmation", /* @__PURE__ */ jsx(AlertModal4, {
        title: "Detach font pack URL?",
        content: "You need to detach the font pack URL from this font pack before you can manually edit its font entries. Do you want to detach the font pack URL?",
        actions: /* @__PURE__ */ jsxs(Stack, {
          children: [
            /* @__PURE__ */ jsx(AlertActionButton4, {
              text: "Detach",
              variant: "destructive",
              onPress: () => {
                delete fonts[fontName].source;
                cb();
              }
            }),
            /* @__PURE__ */ jsx(AlertActionButton4, {
              text: Strings.CANCEL,
              variant: "secondary"
            })
          ]
        })
      }));
    else
      cb();
  }
  function guessFontName(urls) {
    var fileNames = urls.map((url2) => {
      var { pathname } = new URL(url2);
      var fileName = pathname.replace(/\.[^/.]+$/, "");
      return fileName.split("/").pop();
    }).filter(Boolean);
    var shortest = fileNames.reduce((shortest2, name) => {
      return name.length < shortest2.length ? name : shortest2;
    }, fileNames[0] || "");
    return shortest?.replace(/-[A-Za-z]*$/, "") || null;
  }
  function RevengeFontsExtractor({ fonts: fonts2, setName }) {
    var currentTheme = getCurrentTheme().data;
    var themeFonts = currentTheme.fonts;
    var [fontName, setFontName] = (0, import_react7.useState)(guessFontName(Object.values(themeFonts)));
    var [error, setError] = (0, import_react7.useState)(void 0);
    return /* @__PURE__ */ jsxs(import_react_native27.View, {
      style: {
        padding: 8,
        paddingBottom: 16,
        gap: 12
      },
      children: [
        /* @__PURE__ */ jsx(TextInput, {
          autoFocus: true,
          size: "md",
          label: Strings.FONT_NAME,
          value: fontName,
          placeholder: fontName || "Whitney",
          onChange: setFontName,
          errorMessage: error,
          state: error ? "error" : void 0
        }),
        /* @__PURE__ */ jsx(Text, {
          variant: "text-xs/normal",
          color: "text-muted",
          children: formatString("THEME_EXTRACTOR_DESC", {
            fonts: Object.keys(themeFonts).join(Strings.SEPARATOR)
          })
        }),
        /* @__PURE__ */ jsx(Button, {
          size: "md",
          variant: "primary",
          text: Strings.EXTRACT,
          disabled: !fontName,
          onPress: () => {
            if (!fontName)
              return;
            try {
              validateFont({
                spec: 1,
                name: fontName,
                main: themeFonts
              });
              setName(fontName);
              Object.assign(fonts2, themeFonts);
              actionSheet2.hideActionSheet();
            } catch (e) {
              setError(String(e));
            }
          }
        })
      ]
    });
  }
  function JsonFontImporter({ fonts: fonts2, setName, setSource }) {
    var [fontLink, setFontLink] = (0, import_react7.useState)("");
    var [saving, setSaving] = (0, import_react7.useState)(false);
    var [error, setError] = (0, import_react7.useState)(void 0);
    return /* @__PURE__ */ jsxs(import_react_native27.View, {
      style: {
        padding: 8,
        paddingBottom: 16,
        gap: 12
      },
      children: [
        /* @__PURE__ */ jsx(TextInput, {
          autoFocus: true,
          size: "md",
          label: "Font Link",
          value: fontLink,
          placeholder: "https://link.to/font/pack.json",
          onChange: setFontLink,
          errorMessage: error,
          state: error ? "error" : void 0
        }),
        /* @__PURE__ */ jsx(Button, {
          size: "md",
          variant: "primary",
          text: "Import",
          disabled: !fontLink || saving,
          loading: saving,
          onPress: () => {
            setSaving(true);
            (() => _async_to_generator(function* () {
              var res = yield safeFetch(fontLink, {
                cache: "no-store"
              });
              var json = yield res.json();
              validateFont(json);
              setName(json.name);
              setSource(fontLink);
              Object.assign(fonts2, json.main);
            })())().then(() => actionSheet2.hideActionSheet()).catch((e) => setError(String(e))).finally(() => setSaving(false));
          }
        })
      ]
    });
  }
  function EntryEditorActionSheet(props) {
    var [familyName, setFamilyName] = (0, import_react7.useState)(props.name);
    var [fontUrl, setFontUrl] = (0, import_react7.useState)(props.fontEntries[props.name]);
    return /* @__PURE__ */ jsxs(import_react_native27.View, {
      style: {
        padding: 8,
        paddingBottom: 16,
        gap: 12
      },
      children: [
        /* @__PURE__ */ jsx(TextInput, {
          autoFocus: true,
          size: "md",
          label: "Family Name (to override)",
          value: familyName,
          placeholder: "ggsans-Bold",
          onChange: setFamilyName
        }),
        /* @__PURE__ */ jsx(TextInput, {
          size: "md",
          label: "Font URL",
          value: fontUrl,
          placeholder: "https://link.to/the/font.ttf",
          onChange: setFontUrl
        }),
        /* @__PURE__ */ jsx(Button, {
          size: "md",
          variant: "primary",
          text: "Apply",
          onPress: () => {
            delete props.fontEntries[props.name];
            props.fontEntries[familyName] = fontUrl;
            props.onChange();
            actionSheet2.hideActionSheet();
          }
        })
      ]
    });
  }
  function promptActionSheet(Component, fontEntries, props) {
    actionSheet2.openLazy(Promise.resolve({
      default: () => /* @__PURE__ */ jsx(ErrorBoundary, {
        children: /* @__PURE__ */ jsxs(ActionSheet, {
          children: [
            /* @__PURE__ */ jsx(BottomSheetTitleHeader, {
              title: "Import Font"
            }),
            /* @__PURE__ */ jsx(Component, {
              fonts: fontEntries,
              ...props
            })
          ]
        })
      })
    }), "FontEditorActionSheet");
  }
  function NewEntryRow({ fontName, fontEntry }) {
    var nameRef = (0, import_react7.useRef)();
    var urlRef = (0, import_react7.useRef)();
    var [nameSet, setNameSet] = (0, import_react7.useState)(false);
    var [error, setError] = (0, import_react7.useState)();
    return /* @__PURE__ */ jsxs(import_react_native27.View, {
      style: {
        flexDirection: "row",
        gap: 8,
        justifyContent: "flex-start"
      },
      children: [
        /* @__PURE__ */ jsx(import_react_native27.View, {
          style: {
            flex: 1
          },
          children: /* @__PURE__ */ jsx(TextInput, {
            isRound: true,
            size: "md",
            label: nameSet ? nameRef.current : void 0,
            placeholder: nameSet ? "https://path.to/the/file.ttf" : "PostScript name (e.g. ggsans-Bold)",
            leadingIcon: () => nameSet ? null : /* @__PURE__ */ jsx(TableRow.Icon, {
              source: findAssetId("PlusSmallIcon")
            }),
            leadingText: nameSet ? nameRef.current : "",
            onChange: (text) => (nameSet ? urlRef : nameRef).current = text,
            errorMessage: error,
            state: error ? "error" : void 0
          })
        }),
        nameSet && /* @__PURE__ */ jsx(IconButton, {
          size: "md",
          variant: "secondary",
          onPress: () => {
            nameRef.current = "";
            setNameSet(false);
          },
          icon: findAssetId("TrashIcon")
        }),
        /* @__PURE__ */ jsx(IconButton, {
          size: "md",
          variant: "primary",
          onPress: () => promptDetachConfirmationForThen(fontName, () => {
            if (!nameSet && nameRef.current) {
              setNameSet(true);
            } else if (nameSet && nameRef.current && urlRef.current) {
              try {
                var parsedUrl = new URL(urlRef.current);
                if (!parsedUrl.protocol || !parsedUrl.host) {
                  throw "Invalid URL";
                }
                fontEntry[nameRef.current] = urlRef.current;
                nameRef.current = void 0;
                urlRef.current = void 0;
                setNameSet(false);
              } catch (e) {
                setError(String(e));
              }
            }
          }),
          icon: findAssetId(nameSet ? "PlusSmallIcon" : "ArrowLargeRightIcon")
        })
      ]
    });
  }
  function FontEditor(props) {
    var [name, setName] = (0, import_react7.useState)(props.name);
    var [source, setSource] = (0, import_react7.useState)(props.name && fonts[props.name].source);
    var [importing, setIsImporting] = (0, import_react7.useState)(false);
    var [errors, setErrors] = (0, import_react7.useState)();
    var memoEntry = (0, import_react7.useMemo)(() => {
      return createProxy(props.name ? {
        ...fonts[props.name].main
      } : {}).proxy;
    }, [
      props.name
    ]);
    var fontEntries = useProxy(memoEntry);
    var navigation2 = NavigationNative.useNavigation();
    var [, forceUpdate] = React.useReducer(() => ({}), 0);
    return /* @__PURE__ */ jsx(import_react_native27.ScrollView, {
      style: {
        flex: 1
      },
      contentContainerStyle: {
        paddingBottom: 38
      },
      children: /* @__PURE__ */ jsxs(Stack, {
        style: {
          paddingVertical: 24,
          paddingHorizontal: 12
        },
        spacing: 12,
        children: [
          !props.name ? /* @__PURE__ */ jsxs(TableRowGroup, {
            title: "Import",
            children: [
              getCurrentTheme()?.data?.fonts && /* @__PURE__ */ jsx(TableRow, {
                label: Strings.LABEL_EXTRACT_FONTS_FROM_THEME,
                subLabel: Strings.DESC_EXTRACT_FONTS_FROM_THEME,
                icon: /* @__PURE__ */ jsx(TableRow.Icon, {
                  source: findAssetId("HammerIcon")
                }),
                onPress: () => promptActionSheet(RevengeFontsExtractor, fontEntries, {
                  setName
                })
              }),
              /* @__PURE__ */ jsx(TableRow, {
                label: "Import font entries from a link",
                subLabel: "Directly import from a link with a pre-configured JSON file",
                icon: /* @__PURE__ */ jsx(TableRow.Icon, {
                  source: findAssetId("LinkIcon")
                }),
                onPress: () => promptActionSheet(JsonFontImporter, fontEntries, {
                  setName,
                  setSource
                })
              })
            ]
          }) : /* @__PURE__ */ jsxs(TableRowGroup, {
            title: "Actions",
            children: [
              /* @__PURE__ */ jsx(TableRow, {
                label: "Refetch fonts from source",
                icon: /* @__PURE__ */ jsx(TableRow.Icon, {
                  source: findAssetId("RetryIcon")
                }),
                onPress: () => _async_to_generator(function* () {
                  yield updateFont(fonts[props.name]);
                  navigation2.goBack();
                })()
              }),
              /* @__PURE__ */ jsx(TableRow, {
                variant: "danger",
                label: "Delete font pack",
                icon: /* @__PURE__ */ jsx(TableRow.Icon, {
                  variant: "danger",
                  source: findAssetId("TrashIcon")
                }),
                onPress: () => removeFont(props.name).then(() => navigation2.goBack())
              })
            ]
          }),
          /* @__PURE__ */ jsx(TextInput, {
            size: "lg",
            value: name,
            label: Strings.FONT_NAME,
            placeholder: "Whitney",
            onChange: setName
          }),
          props.name && fonts[props.name].source && /* @__PURE__ */ jsx(TextInput, {
            size: "lg",
            value: source,
            label: "Font Pack URL",
            onChange: setSource
          }),
          /* @__PURE__ */ jsxs(TableRowGroup, {
            title: "Font Entries",
            children: [
              Object.entries(fontEntries).map(([name2, url2], index) => {
                var error = errors?.[index];
                return /* @__PURE__ */ jsx(TableRow, {
                  label: name2,
                  subLabel: error ? /* @__PURE__ */ jsx(Text, {
                    variant: "text-xs/medium",
                    color: "text-feedback-critical",
                    children: error.message
                  }) : url2,
                  trailing: /* @__PURE__ */ jsxs(Stack, {
                    spacing: 8,
                    direction: "horizontal",
                    children: [
                      /* @__PURE__ */ jsx(IconButton, {
                        size: "sm",
                        variant: "secondary",
                        icon: findAssetId("PencilIcon"),
                        onPress: () => promptDetachConfirmationForThen(props.name, () => promptActionSheet(EntryEditorActionSheet, fontEntries, {
                          name: name2,
                          fontEntries,
                          onChange: () => {
                            setErrors(void 0);
                            forceUpdate();
                          }
                        }))
                      }),
                      /* @__PURE__ */ jsx(IconButton, {
                        size: "sm",
                        variant: "secondary",
                        icon: findAssetId("TrashIcon"),
                        onPress: () => promptDetachConfirmationForThen(props.name, () => {
                          delete fontEntries[name2];
                          setErrors(void 0);
                        })
                      })
                    ]
                  })
                });
              }),
              /* @__PURE__ */ jsx(TableRow, {
                label: /* @__PURE__ */ jsx(NewEntryRow, {
                  fontName: props.name,
                  fontEntry: fontEntries
                })
              })
            ]
          }),
          errors && /* @__PURE__ */ jsx(Text, {
            variant: "text-sm/medium",
            color: "text-feedback-critical",
            children: "Some font entries cannot be imported. Please modify the entries and try again."
          }),
          /* @__PURE__ */ jsx(import_react_native27.View, {
            style: {
              flexDirection: "row",
              justifyContent: "flex-end",
              bottom: 0,
              left: 0
            },
            children: /* @__PURE__ */ jsx(Button, {
              size: "lg",
              loading: importing,
              disabled: importing || !name || Object.keys(fontEntries).length === 0,
              variant: "primary",
              text: props.name ? "Save" : "Import",
              onPress: () => _async_to_generator(function* () {
                if (!name)
                  return;
                setErrors(void 0);
                setIsImporting(true);
                if (!props.name) {
                  saveFont({
                    spec: 1,
                    name,
                    main: fontEntries,
                    source
                  }).then(() => navigation2.goBack()).catch((e) => setErrors(e)).finally(() => setIsImporting(false));
                } else {
                  Object.assign(fonts[props.name], {
                    name,
                    main: fontEntries
                  });
                  updateFont(fonts[props.name]).then(() => navigation2.goBack()).catch((e) => setErrors(e)).finally(() => setIsImporting(false));
                }
              })(),
              icon: findAssetId(props.name ? "UploadIcon" : "DownloadIcon"),
              style: {
                marginLeft: 8
              }
            })
          })
        ]
      })
    });
  }
  var import_react7, import_react_native27, actionSheet2, openAlert3, AlertModal4, AlertActionButton4;
  var init_FontEditor = __esm({
    "src/core/ui/settings/pages/Fonts/FontEditor.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_async_to_generator();
      init_jsxRuntime();
      init_i18n();
      init_storage();
      init_fonts();
      init_themes();
      init_assets();
      init_utils();
      init_lazy();
      init_common();
      init_components();
      init_wrappers();
      init_components2();
      import_react7 = __toESM(require_react());
      import_react_native27 = __toESM(require_react_native());
      actionSheet2 = findByPropsLazy("hideActionSheet");
      ({ openAlert: openAlert3 } = lazyDestructure(() => findByProps("openAlert", "dismissAlert")));
      ({ AlertModal: AlertModal4, AlertActionButton: AlertActionButton4 } = lazyDestructure(() => findByProps("AlertModal", "AlertActions")));
    }
  });

  // globals:react-native-webview
  var require_react_native_webview = __commonJS({
    "globals:react-native-webview"(exports, module) {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      module.exports = require_depsModule()["react-native-webview"];
    }
  });

  // src/core/ui/settings/pages/Fonts/preview.html
  var preview_default;
  var init_preview = __esm({
    "src/core/ui/settings/pages/Fonts/preview.html"() {
      preview_default = '<head><meta name="viewport" content="initial-scale=1.0"></head>\r\n<body style="overflow: hidden; padding: 0; margin: 0;"></body>\r\n<script>\r\n    const props = $$props;\r\n\r\n    new FontFace("Preview", `url(${props.family})`).load().then((font) => {\r\n        document.fonts.add(font);\r\n\r\n        const p = document.createElement("p");\r\n        p.textContent = props.text;\r\n        p.style.fontFamily = font.family;\r\n        p.style.fontSize = `${props.size}px`;\r\n        p.style.color = props.color;\r\n\r\n        document.body.appendChild(p);\r\n        ReactNativeWebView.postMessage(true);\r\n    });\r\n<\/script>';
    }
  });

  // src/core/ui/settings/pages/Fonts/FontCard.tsx
  function FontPreview({ font }) {
    var [loaded, setLoaded] = (0, import_react8.useState)(false);
    var styles3 = useStyles4();
    var TEXT_DEFAULT = useToken2(tokens.colors.TEXT_DEFAULT);
    var { fontFamily: fontFamilyList, fontSize } = TextStyleSheet["text-md/medium"];
    var fontFamily = fontFamilyList.split(/,/g)[0];
    var props = (0, import_react8.useMemo)(() => ({
      family: font.main[fontFamily],
      size: fontSize * import_react_native28.PixelRatio.getFontScale(),
      color: TEXT_DEFAULT,
      text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
    }), [
      font.main,
      fontFamily,
      fontSize,
      TEXT_DEFAULT
    ]);
    return /* @__PURE__ */ jsxs(import_react_native28.View, {
      style: {
        width: "100%",
        height: 64
      },
      children: [
        /* @__PURE__ */ jsx(import_react_native_webview.WebView, {
          onMessage: () => setLoaded(true),
          source: {
            html: preview_default.replace("$$props", JSON.stringify(props))
          },
          javaScriptEnabled: true,
          scrollEnabled: false,
          overScrollMode: "never",
          showsHorizontalScrollIndicator: false,
          showsVerticalScrollIndicator: false,
          pointerEvents: "none",
          style: [
            styles3.full,
            {
              backgroundColor: "transparent",
              opacity: Number(loaded)
            }
          ]
        }),
        !loaded && /* @__PURE__ */ jsx(import_react_native28.View, {
          style: [
            styles3.full,
            {
              justifyContent: "center",
              alignItems: "center"
            }
          ],
          children: /* @__PURE__ */ jsx(Text, {
            color: "text-muted",
            variant: "heading-lg/semibold",
            children: "Loading..."
          })
        })
      ]
    });
  }
  function FontCard({ item: font }) {
    useProxy(fonts);
    var navigation2 = NavigationNative.useNavigation();
    var selected = fonts.__selected === font.name;
    return /* @__PURE__ */ jsx(Card, {
      children: /* @__PURE__ */ jsxs(Stack, {
        spacing: 16,
        children: [
          /* @__PURE__ */ jsxs(import_react_native28.View, {
            style: {
              flexDirection: "row",
              alignItems: "center"
            },
            children: [
              /* @__PURE__ */ jsx(import_react_native28.View, {
                children: /* @__PURE__ */ jsx(Text, {
                  variant: "heading-lg/semibold",
                  children: font.name
                })
              }),
              /* @__PURE__ */ jsx(import_react_native28.View, {
                style: {
                  marginLeft: "auto"
                },
                children: /* @__PURE__ */ jsxs(Stack, {
                  spacing: 12,
                  direction: "horizontal",
                  children: [
                    /* @__PURE__ */ jsx(IconButton, {
                      onPress: () => {
                        navigation2.push("BUNNY_CUSTOM_PAGE", {
                          title: "Edit Font",
                          render: () => /* @__PURE__ */ jsx(FontEditor, {
                            name: font.name
                          })
                        });
                      },
                      size: "sm",
                      variant: "secondary",
                      disabled: selected,
                      icon: findAssetId("WrenchIcon")
                    }),
                    /* @__PURE__ */ jsx(Button, {
                      size: "sm",
                      variant: selected ? "secondary" : "primary",
                      text: selected ? "Unapply" : "Apply",
                      onPress: () => _async_to_generator(function* () {
                        yield selectFont(selected ? null : font.name);
                        showConfirmationAlert({
                          title: Strings.HOLD_UP,
                          content: "Reload Discord to apply changes?",
                          confirmText: Strings.RELOAD,
                          cancelText: Strings.CANCEL,
                          confirmColor: "red",
                          onConfirm: BundleUpdaterManager.reload
                        });
                      })()
                    })
                  ]
                })
              })
            ]
          }),
          /* @__PURE__ */ jsx(FontPreview, {
            font
          })
        ]
      })
    });
  }
  var import_react8, import_react_native28, import_react_native_webview, useToken2, useStyles4;
  var init_FontCard = __esm({
    "src/core/ui/settings/pages/Fonts/FontCard.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_async_to_generator();
      init_jsxRuntime();
      init_i18n();
      init_alerts2();
      init_storage();
      init_fonts();
      init_assets();
      init_lazy();
      init_modules();
      init_styles();
      init_common();
      init_components();
      init_metro();
      import_react8 = __toESM(require_react());
      import_react_native28 = __toESM(require_react_native());
      import_react_native_webview = __toESM(require_react_native_webview());
      init_preview();
      init_FontEditor();
      ({ useToken: useToken2 } = lazyDestructure(() => findByProps("useToken")));
      useStyles4 = createStyles({
        full: {
          position: "absolute",
          inset: 0,
          width: "100%",
          height: "100%"
        }
      });
    }
  });

  // src/core/ui/settings/pages/Fonts/index.tsx
  var Fonts_exports = {};
  __export(Fonts_exports, {
    default: () => Fonts
  });
  function Fonts() {
    useProxy(settings);
    useProxy(fonts);
    var navigation2 = NavigationNative.useNavigation();
    return /* @__PURE__ */ jsx(AddonPage, {
      title: Strings.FONTS,
      searchKeywords: [
        "name",
        "description"
      ],
      sortOptions: {
        "Name (A-Z)": (a, b3) => a.name.localeCompare(b3.name),
        "Name (Z-A)": (a, b3) => b3.name.localeCompare(a.name)
      },
      items: Object.values(fonts),
      safeModeHint: {
        message: Strings.SAFE_MODE_NOTICE_FONTS
      },
      CardComponent: FontCard,
      installAction: {
        label: "Install a font",
        onPress: () => {
          navigation2.push("BUNNY_CUSTOM_PAGE", {
            title: "Import Font",
            render: () => /* @__PURE__ */ jsx(FontEditor, {})
          });
        }
      }
    });
  }
  var init_Fonts = __esm({
    "src/core/ui/settings/pages/Fonts/index.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_jsxRuntime();
      init_i18n();
      init_AddonPage();
      init_FontEditor();
      init_storage();
      init_fonts();
      init_settings();
      init_common();
      init_FontCard();
    }
  });

  // src/core/ui/hooks/useFS.ts
  function useFileExists(path, prefix) {
    var [state, setState] = (0, import_react9.useState)(2);
    var check = () => fileExists(path, {
      prefix
    }).then((exists) => setState(exists ? 1 : 0)).catch(() => setState(3));
    var customFS = (0, import_react9.useMemo)(() => new Proxy(fs_exports, {
      get(target, p, receiver) {
        var val = Reflect.get(target, p, receiver);
        if (typeof val !== "function")
          return;
        return (...args) => {
          var promise = val(...args);
          if (promise?.constructor?.name === "Promise") {
            setState(2);
            promise.finally(check);
          }
          return promise;
        };
      }
    }), []);
    (0, import_react9.useEffect)(() => void check(), []);
    return [
      state,
      customFS
    ];
  }
  var import_react9, CheckState;
  var init_useFS = __esm({
    "src/core/ui/hooks/useFS.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_fs();
      import_react9 = __toESM(require_react());
      CheckState = /* @__PURE__ */ function(CheckState2) {
        CheckState2[CheckState2["FALSE"] = 0] = "FALSE";
        CheckState2[CheckState2["TRUE"] = 1] = "TRUE";
        CheckState2[CheckState2["LOADING"] = 2] = "LOADING";
        CheckState2[CheckState2["ERROR"] = 3] = "ERROR";
        return CheckState2;
      }({});
    }
  });

  // src/core/ui/settings/pages/Developer/AssetDisplay.tsx
  function AssetDisplay({ asset }) {
    return /* @__PURE__ */ jsx(TableRow, {
      variant: displayable.has(asset.type) ? "default" : "danger",
      label: asset.name,
      subLabel: `Index: ${asset.id} Type: ${asset.type}`,
      icon: displayable.has(asset.type) ? /* @__PURE__ */ jsx(import_react_native29.Image, {
        source: asset.id,
        style: {
          width: 32,
          height: 32
        }
      }) : /* @__PURE__ */ jsx(TableRow.Icon, {
        variant: "danger",
        source: findAssetId(asset.type in iconMap ? iconMap[asset.type] : iconMap.default)
      }),
      onPress: () => openAlert4("revenge-asset-display-details", /* @__PURE__ */ jsx(AlertModal5, {
        title: asset.name,
        content: `Index: ${asset.id}
Module ID: ${asset.moduleId}
Type: ${asset.type}`,
        extraContent: displayable.has(asset.type) ? /* @__PURE__ */ jsx(import_react_native29.Image, {
          resizeMode: "contain",
          source: asset.id,
          style: {
            flex: 1,
            width: "auto",
            height: 192
          }
        }) : /* @__PURE__ */ jsxs(Text, {
          variant: "text-sm/medium",
          color: "text-feedback-critical",
          style: {
            width: "100%",
            textAlign: "center"
          },
          children: [
            "Asset type ",
            asset.type.toUpperCase(),
            " is not supported for preview."
          ]
        }),
        actions: /* @__PURE__ */ jsxs(Stack, {
          children: [
            /* @__PURE__ */ jsx(AlertActionButton5, {
              text: "Copy asset name",
              variant: "primary",
              onPress: () => copyToClipboard(asset.name)
            }),
            /* @__PURE__ */ jsx(AlertActionButton5, {
              text: "Copy asset index",
              variant: "secondary",
              onPress: () => copyToClipboard(asset.id.toString())
            })
          ]
        })
      }))
    });
  }
  var import_react_native29, openAlert4, AlertModal5, AlertActionButton5, displayable, iconMap, copyToClipboard;
  var init_AssetDisplay = __esm({
    "src/core/ui/settings/pages/Developer/AssetDisplay.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_jsxRuntime();
      init_assets();
      init_lazy();
      init_metro();
      init_common();
      init_components();
      init_toasts();
      import_react_native29 = __toESM(require_react_native());
      ({ openAlert: openAlert4 } = lazyDestructure(() => findByProps("openAlert", "dismissAlert")));
      ({ AlertModal: AlertModal5, AlertActionButton: AlertActionButton5 } = lazyDestructure(() => findByProps("AlertModal", "AlertActions")));
      displayable = /* @__PURE__ */ new Set([
        "png",
        "jpg",
        "svg"
      ]);
      iconMap = {
        jsona: "PaperIcon",
        lottie: "ImageTextIcon",
        webm: "CirclePlayIcon-primary",
        ttf: "LettersIcon",
        default: "UnknownGameIcon"
      };
      copyToClipboard = (text) => {
        clipboard.setString(text);
        showToast.showCopyToClipboard();
      };
    }
  });

  // src/core/ui/settings/pages/Developer/AssetBrowser.tsx
  function AssetBrowser() {
    var [search, setSearch] = React.useState("");
    var all = (0, import_react10.useMemo)(() => Array.from(iterateAssets()), []);
    return /* @__PURE__ */ jsx(ErrorBoundary, {
      children: /* @__PURE__ */ jsxs(import_react_native30.View, {
        style: {
          flex: 1
        },
        children: [
          /* @__PURE__ */ jsx(Search_default, {
            style: {
              margin: 10
            },
            onChangeText: (v2) => setSearch(v2)
          }),
          /* @__PURE__ */ jsxs(import_react_native30.View, {
            style: {
              flex: 1,
              borderRadius: 16,
              paddingHorizontal: 12,
              overflow: "hidden",
              backgroundColor: "transparent"
            },
            children: [
              /* @__PURE__ */ jsx(Text, {
                variant: "text-sm/medium",
                color: "text-feedback-critical",
                style: {
                  marginBottom: 16
                },
                children: "Some assets types cannot be displayed and will be marked in red."
              }),
              /* @__PURE__ */ jsx(import_react_native30.FlatList, {
                data: all.filter((a) => a.name.includes(search) || a.id.toString() === search),
                renderItem: ({ item }) => /* @__PURE__ */ jsx(AssetDisplay, {
                  asset: item
                }),
                contentContainerStyle: {
                  overflow: "hidden",
                  backgroundColor: "transparent",
                  borderRadius: 16
                },
                keyExtractor: (a) => a.name
              })
            ]
          })
        ]
      })
    });
  }
  var import_react10, import_react_native30;
  var init_AssetBrowser = __esm({
    "src/core/ui/settings/pages/Developer/AssetBrowser.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_jsxRuntime();
      init_AssetDisplay();
      init_assets();
      init_components();
      init_components2();
      import_react10 = __toESM(require_react());
      import_react_native30 = __toESM(require_react_native());
    }
  });

  // src/core/ui/settings/pages/Developer/index.tsx
  var Developer_exports = {};
  __export(Developer_exports, {
    default: () => Developer
  });
  function Developer() {
    var [rdtFileExists, fs] = useFileExists("preloads/reactDevtools.js");
    var dtConnected2 = useIsDtConnected();
    var rdtConnected2 = useIsRdtConnected();
    var styles3 = useStyles5();
    var navigation2 = NavigationNative.useNavigation();
    useProxy(settings);
    useProxy(loaderConfig);
    return /* @__PURE__ */ jsx(ErrorBoundary, {
      children: /* @__PURE__ */ jsx(import_react_native32.ScrollView, {
        style: {
          flex: 1
        },
        contentContainerStyle: {
          paddingBottom: 38
        },
        children: /* @__PURE__ */ jsxs(Stack, {
          style: {
            paddingVertical: 24,
            paddingHorizontal: 12
          },
          spacing: 24,
          children: [
            /* @__PURE__ */ jsx(TextInput, {
              label: Strings.DEBUGGER_URL,
              placeholder: "localhost:7864",
              size: "md",
              leadingIcon: () => /* @__PURE__ */ jsx(LegacyFormText, {
                style: styles3.leadingText,
                children: "ws://"
              }),
              defaultValue: settings.debuggerUrl,
              onChange: (v2) => settings.debuggerUrl = v2
            }),
            /* @__PURE__ */ jsxs(TableRowGroup, {
              title: Strings.DEBUG,
              children: [
                /* @__PURE__ */ jsx(TableSwitchRow, {
                  label: Strings.DEBUGGER_AUTOCONNECT,
                  subLabel: Strings.DEBUGGER_AUTOCONNECT_DESC,
                  icon: /* @__PURE__ */ jsx(TableRow.Icon, {
                    source: findAssetId("BookmarkIcon")
                  }),
                  value: !!settings.enableAutoDebugger,
                  onValueChange: (v2) => {
                    settings.enableAutoDebugger = v2;
                  }
                }),
                /* @__PURE__ */ jsx(TableRow, {
                  label: dtConnected2 ? Strings.DISCONNECT_FROM_DEBUG_WEBSOCKET : Strings.CONNECT_TO_DEBUG_WEBSOCKET,
                  subLabel: `Version ${DevToolsClient.version}`,
                  icon: /* @__PURE__ */ jsx(TableRow.Icon, {
                    source: findAssetId(dtConnected2 ? "DenyIcon" : "LinkIcon")
                  }),
                  onPress: () => dtConnected2 ? disconnectDt() : connectToDebugger(settings.debuggerUrl)
                }),
                isReactDevToolsPreloaded() && /* @__PURE__ */ jsx(Fragment, {
                  children: /* @__PURE__ */ jsx(TableRow, {
                    label: rdtConnected2 ? Strings.DISCONNECT_FROM_REACT_DEVTOOLS : Strings.CONNECT_TO_REACT_DEVTOOLS,
                    subLabel: `Version ${getReactDevToolsVersion()}`,
                    icon: /* @__PURE__ */ jsx(TableRow.Icon, {
                      source: findAssetId(rdtConnected2 ? "DenyIcon" : "StaffBadgeIcon")
                    }),
                    onPress: () => rdtConnected2 ? disconnectRdt() : connectToReactDevTools(settings.debuggerUrl)
                  })
                })
              ]
            }),
            isLoaderConfigSupported() && /* @__PURE__ */ jsx(Fragment, {
              children: /* @__PURE__ */ jsxs(TableRowGroup, {
                title: "Loader config",
                children: [
                  /* @__PURE__ */ jsx(TableSwitchRow, {
                    label: Strings.LOAD_FROM_CUSTOM_URL,
                    subLabel: Strings.LOAD_FROM_CUSTOM_URL_DEC,
                    icon: /* @__PURE__ */ jsx(TableRow.Icon, {
                      source: findAssetId("LinkIcon")
                    }),
                    value: loaderConfig.customLoadUrl.enabled,
                    onValueChange: (v2) => {
                      loaderConfig.customLoadUrl.enabled = v2;
                    }
                  }),
                  loaderConfig.customLoadUrl.enabled && /* @__PURE__ */ jsx(TableRow, {
                    label: /* @__PURE__ */ jsx(TextInput, {
                      defaultValue: loaderConfig.customLoadUrl.url,
                      size: "md",
                      onChange: (v2) => loaderConfig.customLoadUrl.url = v2,
                      placeholder: "http://localhost:4040/revenge.js",
                      label: Strings.BUNNY_URL
                    })
                  }),
                  isReactDevToolsPreloaded() && isVendettaLoader() && /* @__PURE__ */ jsx(TableSwitchRow, {
                    label: Strings.LOAD_REACT_DEVTOOLS,
                    subLabel: `${Strings.VERSION}: ${getReactDevToolsVersion()}`,
                    icon: /* @__PURE__ */ jsx(TableRow.Icon, {
                      source: findAssetId("StaffBadgeIcon")
                    }),
                    value: loaderConfig.loadReactDevTools,
                    onValueChange: (v2) => {
                      loaderConfig.loadReactDevTools = v2;
                    }
                  })
                ]
              })
            }),
            /* @__PURE__ */ jsxs(TableRowGroup, {
              title: "Other",
              children: [
                /* @__PURE__ */ jsx(TableRow, {
                  label: Strings.CLEAR_BUNDLE,
                  subLabel: Strings.CLEAR_BUNDLE_DESC,
                  icon: /* @__PURE__ */ jsx(TableRow.Icon, {
                    source: findAssetId("TrashIcon"),
                    variant: "danger"
                  }),
                  onPress: () => {
                    openAlert5("revenge-clear-bundle-reload-confirmation", /* @__PURE__ */ jsx(AlertModal6, {
                      title: Strings.MODAL_RELOAD_REQUIRED,
                      content: Strings.MODAL_RELOAD_REQUIRED_DESC,
                      actions: /* @__PURE__ */ jsxs(Stack, {
                        children: [
                          /* @__PURE__ */ jsx(AlertActionButton6, {
                            text: Strings.RELOAD,
                            variant: "destructive",
                            onPress: () => import_react_native31.NativeModules.BundleUpdaterManager.reload()
                          }),
                          /* @__PURE__ */ jsx(AlertActionButton6, {
                            text: Strings.CANCEL,
                            variant: "secondary"
                          })
                        ]
                      })
                    }));
                  },
                  variant: "danger"
                }),
                /* @__PURE__ */ jsx(TableRow, {
                  arrow: true,
                  label: Strings.ASSET_BROWSER,
                  icon: /* @__PURE__ */ jsx(TableRow.Icon, {
                    source: findAssetId("ImageIcon")
                  }),
                  trailing: TableRow.Arrow,
                  onPress: () => navigation2.push("BUNNY_CUSTOM_PAGE", {
                    title: Strings.ASSET_BROWSER,
                    render: AssetBrowser
                  })
                }),
                /* @__PURE__ */ jsx(TableRow, {
                  arrow: true,
                  label: Strings.ERROR_BOUNDARY_TOOLS_LABEL,
                  icon: /* @__PURE__ */ jsx(TableRow.Icon, {
                    source: findAssetId("WarningIcon")
                  }),
                  onPress: () => showSimpleActionSheet4({
                    key: "ErrorBoundaryTools",
                    header: {
                      title: "Which ErrorBoundary do you want to trip?",
                      icon: /* @__PURE__ */ jsx(TableRow.Icon, {
                        style: {
                          marginRight: 8
                        },
                        source: findAssetId("WarningIcon")
                      }),
                      onClose: () => hideActionSheet3()
                    },
                    options: [
                      // @ts-expect-error
                      // Of course, to trigger an error, we need to do something incorrectly. The below will do!
                      {
                        label: Strings.BUNNY,
                        onPress: () => navigation2.push("BUNNY_CUSTOM_PAGE", {
                          render: () => /* @__PURE__ */ jsx("undefined", {})
                        })
                      },
                      {
                        label: "Discord",
                        isDestructive: true,
                        onPress: () => navigation2.push("BUNNY_CUSTOM_PAGE", {
                          noErrorBoundary: true
                        })
                      }
                    ]
                  })
                }),
                /* @__PURE__ */ jsx(TableRow, {
                  label: Strings.INSTALL_REACT_DEVTOOLS,
                  subLabel: Strings.RESTART_REQUIRED_TO_TAKE_EFFECT,
                  icon: /* @__PURE__ */ jsx(TableRow.Icon, {
                    source: findAssetId("DownloadIcon")
                  }),
                  trailing: /* @__PURE__ */ jsx(Button, {
                    size: "sm",
                    loading: rdtFileExists === CheckState.LOADING,
                    disabled: rdtFileExists === CheckState.LOADING,
                    variant: rdtFileExists === CheckState.TRUE ? "secondary" : "primary",
                    text: rdtFileExists === CheckState.TRUE ? Strings.UNINSTALL : Strings.INSTALL,
                    onPress: () => _async_to_generator(function* () {
                      if (rdtFileExists === CheckState.FALSE) {
                        fs.downloadFile(RDT_EMBED_LINK, "preloads/reactDevtools.js").then(() => showToast("Successfully installed! A reload is required", findAssetId("DownloadIcon")));
                      } else if (rdtFileExists === CheckState.TRUE) {
                        fs.removeFile("preloads/reactDevtools.js");
                      }
                    })(),
                    icon: findAssetId(rdtFileExists === CheckState.TRUE ? "TrashIcon" : "DownloadIcon"),
                    style: {
                      marginLeft: 8
                    }
                  })
                }),
                /* @__PURE__ */ jsx(TableSwitchRow, {
                  label: Strings.ENABLE_EVAL_COMMAND,
                  subLabel: Strings.ENABLE_EVAL_COMMAND_DESC,
                  icon: /* @__PURE__ */ jsx(TableRow.Icon, {
                    source: findAssetId("PencilIcon")
                  }),
                  value: !!settings.enableEvalCommand,
                  onValueChange: (v2) => {
                    settings.enableEvalCommand = v2;
                  }
                })
              ]
            })
          ]
        })
      })
    });
  }
  var import_react_native31, import_react_native32, hideActionSheet3, showSimpleActionSheet4, openAlert5, AlertModal6, AlertActionButton6, RDT_EMBED_LINK, useStyles5;
  var init_Developer = __esm({
    "src/core/ui/settings/pages/Developer/index.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_async_to_generator();
      init_jsxRuntime();
      init_i18n();
      init_useFS();
      init_AssetBrowser();
      init_storage();
      init_assets();
      init_debug();
      init_devtools();
      init_react();
      init_loader();
      init_settings();
      init_toasts();
      init_lazy();
      init_common();
      init_components();
      init_wrappers();
      init_dist3();
      init_color();
      init_components2();
      init_styles();
      import_react_native31 = __toESM(require_react_native());
      import_react_native32 = __toESM(require_react_native());
      ({ hideActionSheet: hideActionSheet3 } = lazyDestructure(() => findByProps("openLazy", "hideActionSheet")));
      ({ showSimpleActionSheet: showSimpleActionSheet4 } = lazyDestructure(() => findByProps("showSimpleActionSheet")));
      ({ openAlert: openAlert5 } = lazyDestructure(() => findByProps("openAlert", "dismissAlert")));
      ({ AlertModal: AlertModal6, AlertActionButton: AlertActionButton6 } = lazyDestructure(() => findByProps("AlertModal", "AlertActions")));
      RDT_EMBED_LINK = "https://github.com/revenge-mod/react-devtools-core/releases/latest/download/index.bundle";
      useStyles5 = createStyles({
        leadingText: {
          ...TextStyleSheet["heading-md/semibold"],
          color: semanticColors.TEXT_MUTED,
          marginRight: -4
        }
      });
    }
  });

  // src/core/ui/settings/index.ts
  function initSettings() {
    registerSection({
      name: Strings.BUNNY,
      items: [
        {
          key: "BUNNY",
          title: () => Strings.BUNNY,
          icon: {
            uri: revenge_default
          },
          render: () => Promise.resolve().then(() => (init_General(), General_exports)),
          useTrailing: () => "(v2.1)"
        },
        {
          key: "YUMICORD_BUILTINS",
          title: () => "Built-in features",
          icon: findAssetId("StaffBadgeIcon"),
          render: () => Promise.resolve({
            default: YumiBuiltinsPage
          }),
          useTrailing: () => "Badges, Platforms"
        },
        {
          key: "BUNNY_PLUGINS",
          title: () => Strings.PLUGINS,
          icon: findAssetId("PuzzlePieceIcon"),
          render: () => Promise.resolve().then(() => (init_Plugins(), Plugins_exports))
        },
        {
          key: "BUNNY_THEMES",
          title: () => Strings.THEMES,
          icon: findAssetId("PaintPaletteIcon"),
          render: () => Promise.resolve().then(() => (init_Themes(), Themes_exports)),
          usePredicate: () => isThemeSupported()
        },
        {
          key: "BUNNY_FONTS",
          title: () => Strings.FONTS,
          icon: findAssetId("LettersIcon"),
          render: () => Promise.resolve().then(() => (init_Fonts(), Fonts_exports)),
          usePredicate: () => isFontSupported()
        },
        {
          key: "BUNNY_DEVELOPER",
          title: () => Strings.DEVELOPER,
          icon: findAssetId("WrenchIcon"),
          render: () => Promise.resolve().then(() => (init_Developer(), Developer_exports)),
          usePredicate: () => useProxy(settings).developerSettings ?? false
        }
      ]
    });
    registerSection({
      name: "Bunny",
      items: []
    });
    registerSection({
      name: "Vendetta",
      items: []
    });
  }
  var init_settings3 = __esm({
    "src/core/ui/settings/index.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_revenge();
      init_i18n();
      init_storage();
      init_assets();
      init_loader();
      init_settings();
      init_settings2();
    }
  });

  // globals:lodash
  var require_lodash = __commonJS({
    "globals:lodash"(exports, module) {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      module.exports = require_depsModule()["lodash"];
    }
  });

  // globals:util
  var require_util = __commonJS({
    "globals:util"(exports, module) {
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      module.exports = require_depsModule()["util"];
    }
  });

  // src/core/vendetta/api.tsx
  var import_react12, import_react_native33, initVendettaObject;
  var init_api3 = __esm({
    "src/core/vendetta/api.tsx"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_jsxRuntime();
      init_alerts2();
      init_storage();
      init_storage();
      init_themes();
      init_assets();
      init_commands();
      init_debug();
      init_loader();
      init_patcher();
      init_settings();
      init_utils();
      init_cyrb64();
      init_logger();
      init_metro();
      init_common();
      init_components();
      init_components();
      init_color();
      init_components2();
      init_styles();
      init_toasts();
      init_dist();
      import_react12 = __toESM(require_react());
      import_react_native33 = __toESM(require_react_native());
      init_plugins();
      initVendettaObject = () => {
        var createStackBasedFilter = (fn) => {
          return (filter) => {
            return fn(factories_exports.createSimpleFilter(filter, cyrb64Hash(new Error().stack)));
          };
        };
        var api = globalThis.vendetta = {
          patcher: {
            before: patcher_default.before,
            after: patcher_default.after,
            instead: patcher_default.instead
          },
          metro: {
            modules: globalThis.modules,
            find: createStackBasedFilter(findExports),
            findAll: createStackBasedFilter(findAllExports),
            findByProps: (...props) => {
              if (props.length === 1 && props[0] === "KeyboardAwareScrollView") {
                props.push("listenToKeyboardEvents");
              }
              var ret = findByProps(...props);
              if (ret == null) {
                if (props.includes("ActionSheetTitleHeader")) {
                  var module = findByProps("ActionSheetRow");
                  return {
                    ...module,
                    ActionSheetTitleHeader: module.BottomSheetTitleHeader,
                    ActionSheetContentContainer: ({ children }) => {
                      (0, import_react12.useEffect)(() => console.warn("Discord has removed 'ActionSheetContentContainer', please move into something else. This has been temporarily replaced with View"), []);
                      return /* @__PURE__ */ (0, import_react12.createElement)(import_react_native33.View, null, children);
                    }
                  };
                }
              }
              return ret;
            },
            findByPropsAll: (...props) => findByPropsAll(...props),
            findByName: (name, defaultExp) => {
              if (name === "create" && typeof defaultExp === "undefined") {
                return findByName("create", false).default;
              }
              return findByName(name, defaultExp ?? true);
            },
            findByNameAll: (name, defaultExp = true) => findByNameAll(name, defaultExp),
            findByDisplayName: (displayName, defaultExp = true) => findByDisplayName(displayName, defaultExp),
            findByDisplayNameAll: (displayName, defaultExp = true) => findByDisplayNameAll(displayName, defaultExp),
            findByTypeName: (typeName, defaultExp = true) => findByTypeName(typeName, defaultExp),
            findByTypeNameAll: (typeName, defaultExp = true) => findByTypeNameAll(typeName, defaultExp),
            findByStoreName: (name) => findByStoreName(name),
            common: {
              constants,
              channels,
              i18n,
              url,
              toasts,
              stylesheet: {
                createThemedStyleSheet
              },
              clipboard,
              assets,
              invites,
              commands,
              navigation,
              navigationStack,
              NavigationNative,
              Flux,
              FluxDispatcher,
              React: React2,
              ReactNative,
              moment: require_moment(),
              chroma: require_chroma_js(),
              lodash: require_lodash(),
              util: require_util()
            }
          },
          constants: {
            DISCORD_SERVER: "https://discord.gg/n9QQ4XhhJP",
            GITHUB: "https://github.com/vendetta-mod",
            PROXY_PREFIX: "https://vd-plugins.github.io/proxy",
            HTTP_REGEX: /^https?:\/\/(?:www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_+.~#?&/=]*)$/,
            HTTP_REGEX_MULTI: /https?:\/\/(?:www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_+.~#?&//=]*)/g,
            DISCORD_SERVER_ID: "1015931589865246730",
            PLUGINS_CHANNEL_ID: "1091880384561684561",
            THEMES_CHANNEL_ID: "1091880434939482202"
          },
          utils: {
            findInReactTree: (tree, filter) => findInReactTree(tree, filter),
            findInTree: (tree, filter, options) => findInTree(tree, filter, options),
            safeFetch: (input, options, timeout) => safeFetch(input, options, timeout),
            unfreeze: (obj) => Object.isFrozen(obj) ? {
              ...obj
            } : obj,
            without: (object, ...keys) => omit(object, keys)
          },
          debug: {
            connectToDebugger: (url2) => connectToDebugger(url2),
            getDebugInfo: () => getDebugInfo()
          },
          ui: {
            components: {
              Forms,
              General: ReactNative,
              Alert: LegacyAlert,
              Button: CompatButton,
              HelpMessage: (...props) => /* @__PURE__ */ jsx(HelpMessage, {
                ...props
              }),
              SafeAreaView: (...props) => /* @__PURE__ */ jsx(SafeAreaView, {
                ...props
              }),
              Summary,
              ErrorBoundary,
              Codeblock,
              Search: Search_default
            },
            toasts: {
              showToast: (content, asset) => showToast(content, asset)
            },
            alerts: {
              showConfirmationAlert: (options) => showConfirmationAlert(options),
              showCustomAlert: (component, props) => showCustomAlert(component, props),
              showInputAlert: (options) => showInputAlert(options)
            },
            assets: {
              all: new Proxy({}, {
                get(cache, p) {
                  if (typeof p !== "string")
                    return void 0;
                  if (cache[p])
                    return cache[p];
                  for (var asset of iterateAssets()) {
                    if (asset.name)
                      return cache[p] = asset;
                  }
                },
                ownKeys(cache) {
                  var keys = /* @__PURE__ */ new Set();
                  for (var asset of iterateAssets()) {
                    cache[asset.name] = asset;
                    keys.add(asset.name);
                  }
                  return [
                    ...keys
                  ];
                }
              }),
              find: (filter) => findAsset(filter),
              getAssetByName: (name) => findAsset(name),
              getAssetByID: (id) => findAsset(id),
              getAssetIDByName: (name) => findAssetId(name)
            },
            semanticColors,
            rawColors
          },
          plugins: {
            plugins: VdPluginManager.plugins,
            fetchPlugin: (source) => VdPluginManager.fetchPlugin(source),
            installPlugin: (source, enabled = true) => VdPluginManager.installPlugin(source, enabled),
            startPlugin: (id) => VdPluginManager.startPlugin(id),
            stopPlugin: (id, disable = true) => VdPluginManager.stopPlugin(id, disable),
            removePlugin: (id) => VdPluginManager.removePlugin(id),
            getSettings: (id) => VdPluginManager.getSettings(id)
          },
          themes: {
            themes,
            fetchTheme: (id, selected) => fetchTheme(id, selected),
            installTheme: (id) => installTheme(id),
            selectTheme: (id) => selectTheme(id === "default" ? null : themes[id]),
            removeTheme: (id) => removeTheme(id),
            getCurrentTheme: () => getThemeFromLoader(),
            updateThemes: () => updateThemes()
          },
          commands: {
            registerCommand
          },
          storage: {
            createProxy: (target) => createProxy(target),
            useProxy: (_storage) => useProxy(_storage),
            createStorage: (backend) => createStorage(backend),
            wrapSync: (store) => wrapSync(store),
            awaitSyncWrapper: (store) => awaitStorage(store),
            createMMKVBackend: (store) => createMMKVBackend(store),
            createFileBackend: (file) => {
              if (isPyonLoader() && file === "vendetta_theme.json") {
                file = "pyoncord/current-theme.json";
              }
              return createFileBackend(file);
            }
          },
          settings,
          loader: {
            identity: getVendettaLoaderIdentity() ?? void 0,
            config: loaderConfig
          },
          logger: {
            log: (...message) => console.log(...message),
            info: (...message) => console.info(...message),
            warn: (...message) => console.warn(...message),
            error: (...message) => console.error(...message),
            time: (...message) => console.time(...message),
            trace: (...message) => console.trace(...message),
            verbose: (...message) => console.log(...message)
          },
          version: versionHash,
          unload: () => {
            delete globalThis.vendetta;
          }
        };
        return () => api.unload();
      };
    }
  });

  // src/global.d.ts
  var init_global_d = __esm({
    "src/global.d.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
    }
  });

  // src/modules.d.ts
  var init_modules_d = __esm({
    "src/modules.d.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
    }
  });

  // src/lib/ui/index.ts
  var ui_exports = {};
  __export(ui_exports, {
    alerts: () => alerts_exports,
    components: () => components_exports2,
    settings: () => settings_exports2,
    sheets: () => sheets_exports,
    styles: () => styles_exports,
    toasts: () => toasts_exports
  });
  var init_ui = __esm({
    "src/lib/ui/index.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_alerts();
      init_components2();
      init_settings2();
      init_sheets();
      init_styles();
      init_toasts();
    }
  });

  // src/lib/index.ts
  var lib_exports = {};
  __export(lib_exports, {
    _jsx: () => jsxRuntime_exports,
    api: () => api_exports,
    fonts: () => fonts_exports,
    managers: () => managers,
    metro: () => metro_exports,
    plugins: () => plugins_exports2,
    themes: () => themes_exports,
    ui: () => ui_exports,
    unload: () => unload,
    utils: () => utils_exports
  });
  function unload() {
    for (var d of _disposer)
      if (typeof d === "function")
        d();
    delete globalThis.bunny;
  }
  var managers, _disposer;
  var init_lib = __esm({
    "src/lib/index.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_global_d();
      init_modules_d();
      init_fonts();
      init_plugins4();
      init_themes();
      init_api();
      init_ui();
      init_utils();
      init_metro();
      init_fonts();
      init_plugins4();
      init_themes();
      init_jsxRuntime();
      init_lazy();
      managers = proxyLazy(() => {
        console.warn("bunny.managers.* is deprecated, and moved the top level (bunny.*). bunny.managers will be eventually removed soon");
        return {
          get fonts() {
            return fonts_exports;
          },
          get plugins() {
            return plugins_exports2;
          },
          get themes() {
            return themes_exports;
          }
        };
      }, {
        hint: "object"
      });
      _disposer = [];
      unload.push = (fn) => {
        _disposer.push(fn);
      };
    }
  });


  // ---- YumiCord v2.1: built-in features + pre-installed (disabled) plugins ----
  // Built-ins run at startup like a plugin would (same vendetta API), wrapped so a failure can never stop the app.
  // The seed list below only puts plugin URLs into the Plugins page, DISABLED. Plugin code is fetched from its own
  // proxy URL, unmodified; nothing is ever enabled automatically and nothing the user installed/removed is touched.
  var YUMI_SEED = {
    "version": 1,
    "note": "YumiCord v2.1 pre-installed plugins (added DISABLED). Edit this list to change them; bump version to re-run for new entries.",
    "plugins": [
      {
        "id": "https://vd-plugins.github.io/proxy/meqativ.github.io/dumsane/NoDelete/",
        "name": "NoDelete",
        "hi": "Koi message delete kare to bhi tumhe dikhta rahega"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/redstonekasi.github.io/vendetta-plugins/message-logger/",
        "name": "Message Logger",
        "hi": "Delete/edit hue messages ka record rakhta hai (app restart tak)"
      },
      {
        "id": "https://bn-plugins.github.io/vd-proxy/rico040.github.io/bunny-plugins/freemoji/",
        "name": "Freemoji",
        "hi": "Bina Nitro ke Nitro wale emoji use karo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/aliernfrog.github.io/vd-plugins/FreeStickers/",
        "name": "FreeStickers",
        "hi": "Bina Nitro ke stickers bhejo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/fierdetta.github.io/stealmoji/",
        "name": "Stealmoji",
        "hi": "Kisi bhi emoji ko copy karke apne server mein daal lo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/c10udburst-discord.github.io/vendetta-plugins/hidden-channels/",
        "name": "Hidden channels",
        "hi": "Jo channel lock hain unka naam aur description dikhata hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/aeongdesu.github.io/vdplugins/Dislate/",
        "name": "Dislate Lite",
        "hi": "Message ko kisi bhi language mein translate karo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/vendetta.nexpid.xyz/better-timestamps/",
        "name": "BetterTimestamps",
        "hi": "Time/date ko Discord ke smart timestamp mein badalta hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/redstonekasi.github.io/vendetta-plugins/no-typing/",
        "name": "No typing",
        "hi": "Tum type kar rahe ho ye dusron ko nahi dikhega"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/amsyarasyiq.github.io/letup/NoIdle/",
        "name": "NoIdle",
        "hi": "App background mein ho to bhi status Idle nahi hoga"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/martinz64.github.io/vendetta-plugins/NoCompression/",
        "name": "NoCompression",
        "hi": "Photo/file bhejte waqt quality kam nahi hogi"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/redstonekasi.github.io/vendetta-plugins/picture-links/",
        "name": "Picture Links",
        "hi": "Profile photo aur banner pe tap karke full size kholo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/twnlink.github.io/vendetta-plugins/FreeProfileColors/",
        "name": "Free Profile Colors",
        "hi": "Bina Nitro ke profile colors lagao (dusre plugin users ko dikhte hain)"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/decor-discord.github.io/vendetta-plugin/",
        "name": "Decor",
        "hi": "Apni custom avatar decoration banao aur lagao"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/fres621.github.io/vendetta-plugins/SpotifyPreview/",
        "name": "SpotifyPreview",
        "hi": "Spotify gaane ka 30 second preview chat mein hi suno"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/vendetta.nexpid.xyz/song-spotlight/",
        "name": "SongSpotlight",
        "hi": "Apni profile pe gaane pin karo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/vendetta.nexpid.xyz/local-pins/",
        "name": "LocalPins",
        "hi": "Message ko sirf apne liye pin karo"
      },
      {
        "id": "https://bn-plugins.github.io/vd-proxy/castdrian.github.io/discord-plugins/FavoriteGifs/",
        "name": "FavoriteGifs",
        "hi": "GIF ko favourite / unfavourite karo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/vendetta.nexpid.xyz/clean-urls/",
        "name": "CleanURLs",
        "hi": "Links se tracking wala kachra hata deta hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/maisymoe.github.io/strife/NoTrack/",
        "name": "NoTrack",
        "hi": "Discord ki tracking band karta hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/aeongdesu.github.io/vdplugins/ViewRaw/",
        "name": "ViewRaw",
        "hi": "Message ka raw data dekho aur copy karo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/fres621.github.io/vendetta-plugins/LastMessage/",
        "name": "LastMessageDate",
        "hi": "Dekho kisi ne last message kab bheja tha"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/aeongdesu.github.io/vdplugins/FirstMessage/",
        "name": "FirstMessage",
        "hi": "/firstmessage se channel ke pehle message pe jao"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/actuallythesun.github.io/vendetta-plugins/QuickDelete/",
        "name": "QuickDelete",
        "hi": "Message delete karte waqt 'Are you sure' wala popup nahi aayega"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/fres621.github.io/vendetta-plugins/AlwaysTrust/",
        "name": "AlwaysTrust",
        "hi": "Link kholte waqt 'untrusted link' wala popup hata deta hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/actuallythesun.github.io/vendetta-plugins/SplitLargeMessages/",
        "name": "SplitLargeMessages",
        "hi": "2000 se lambe message apne aap tukdon mein bhej deta hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/redstonekasi.github.io/vendetta-plugins/audiofix/",
        "name": "Blueooth Audio Fix",
        "hi": "Bluetooth headphone pe call/audio ki quality theek karta hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/meqativ.github.io/dumsane/NoBandwidthKick/",
        "name": "NoBandwidthKick",
        "hi": "VC mein akele hone pe kick nahi hoga"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/fierdetta.github.io/typing-avatars/",
        "name": "Typing Avatars",
        "hi": "Kaun type kar raha hai uski photo dikhata hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/cynosphere.github.io/VendettaPlugins/AlwaysAnimate/",
        "name": "Always Animate",
        "hi": "Animated avatar aur server icon hamesha chalte rahenge"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/maisymoe.github.io/strife/Experiments/",
        "name": "Experiments",
        "hi": "Discord ke developer / experiment wale features kholta hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/vendetta.nexpid.xyz/hide-servers/",
        "name": "HideServers",
        "hi": "Server list se server chhupa do (sirf tumhare liye)"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/vendetta.nexpid.xyz/char-counter/",
        "name": "CharCounter",
        "hi": "Chat box ke upar character count dikhata hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/github.com/acquitelol/vd-pronoun-db/releases/latest/download/",
        "name": "PronounDB",
        "hi": "Logon ke pronouns tag ke roop mein dikhata hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/github.com/acquitelol/better-chat-gestures/releases/latest/download/",
        "name": "BetterChatGestures",
        "hi": "Chat mein naye gestures (double tap se reply/edit, etc.)"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/vendicated.github.io/its-called-vendetta-cause-its-owned-by-ven-plugins/ClickableBioLinks/",
        "name": "BetterBios",
        "hi": "Bio ka text select / copy kar sakte ho, links click hote hain"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/fres621.github.io/vendetta-plugins/BetterSearch/",
        "name": "BetterSearch",
        "hi": "Message search ko behtar banata hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/cynosphere.github.io/VendettaPlugins/ChatboxAvatar/",
        "name": "Chatbox Avatar",
        "hi": "Chat box se jaldi apni profile kholo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/martinz64.github.io/vendetta-plugins/CopyRoleColor/",
        "name": "CopyRoleColor",
        "hi": "Role pe long press karke uska color code copy karo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/c10udburst-discord.github.io/vendetta-plugins/delete-embeds/",
        "name": "Delete embeds",
        "hi": "Message ka link preview (embed) hata do"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/ryan-0324.github.io/vendetta-plugins/FakeProfileThemesAndEffects/",
        "name": "FakeProfileThemesAndEffects",
        "hi": "Profile theme aur effects bina Nitro (plugin users ko dikhte hain)"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/fres621.github.io/vendetta-plugins/FileContentPreview/",
        "name": "FileContentPreview",
        "hi": "Text file ko download kiye bina andar ka content dekho"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/martinz64.github.io/vendetta-plugins/FileSizeOnPicker/",
        "name": "FileSizeOnPicker",
        "hi": "File chunte waqt uska size dikhata hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/dziurwa14.github.io/vendetta-plugins/Freecons/",
        "name": "Freecons",
        "hi": "Nitro wale app icons free mein"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/nikosszzz.github.io/vd-plugins/friendInvites/",
        "name": "FriendInvites",
        "hi": "Friend add karne wala invite link banao"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/janisslsm.github.io/vdplugins/HideCallButtons/",
        "name": "Hide call buttons",
        "hi": "DM aur profile se call wale buttons chhupao"
      },
      {
        "id": "https://bn-plugins.github.io/vd-proxy/rico040.github.io/bunny-plugins/hideappbutton/",
        "name": "HideAppButton",
        "hi": "Chat box se Apps button hatao"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/zykrah.github.io/vendetta-plugins/HideBlockedMessages/",
        "name": "HideBlockedMessages",
        "hi": "Blocked logon ke messages bilkul chhupa do"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/amsyarasyiq.github.io/letup/HideGiftButton/",
        "name": "HideGiftButton",
        "hi": "Chat box se Gift button hatao"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/mystravil.github.io/vendetta-plugins/HideMessages/",
        "name": "HideMessages",
        "hi": "Koi bhi message sirf apne liye chhupao"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/amsyarasyiq.github.io/letup/HoldGIFSend/",
        "name": "HoldGIFSend",
        "hi": "GIF turant send nahi hogi, pehle chat box mein aayegi"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/redstonekasi.github.io/vendetta-plugins/saucenao/",
        "name": "Image search",
        "hi": "Photo ko Google/Yandex etc. pe reverse search karo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/aliernfrog.github.io/vd-plugins/JumpTo/",
        "name": "JumpTo",
        "hi": "Reply wale message ya channel ki shuruaat pe jao"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/amsyarasyiq.github.io/letup/Last.fm/",
        "name": "Last.fm",
        "hi": "Apna Last.fm gaana status mein dikhao"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/vendetta.nexpid.xyz/message-preview/",
        "name": "MessagePreview",
        "hi": "Bhejne se pehle message ka preview dekho"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/vendetta.nexpid.xyz/monet-theme/",
        "name": "MonetTheme",
        "hi": "Phone ke wallpaper ke rang se theme banao (Material You)"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/aeongdesu.github.io/vdplugins/ClientThemes/",
        "name": "ClientThemes",
        "hi": "Themes ko startup ke baad sahi se load karta hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/amsyarasyiq.github.io/letup/MoreConfirm/",
        "name": "MoreConfirm",
        "hi": "Zaroori kaam (jaise leave server) se pehle confirm poochta hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/carince.github.io/VendettaPlugins/muteNewGuilds/",
        "name": "Mute New Guilds",
        "hi": "Naye join kiye server apne aap mute"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/redstonekasi.github.io/vendetta-plugins/no-embed-copy/",
        "name": "No Embed Copy",
        "hi": "Embed pe tap karne se text copy nahi hoga"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/amsyarasyiq.github.io/letup/NoAutoReplyMention/",
        "name": "NoAutoReplyMention",
        "hi": "Reply karte waqt mention (@) apne aap OFF"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/maisymoe.github.io/strife/PinSettings/",
        "name": "PinSettings",
        "hi": "Plugin settings ko User Settings mein pin karo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/vendetta.nexpid.xyz/plugin-browser/",
        "name": "Plugin Browser",
        "hi": "Saare plugins ki list browse karo aur install karo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/redstonekasi.github.io/vendetta-plugins/realmoji/",
        "name": "Realmoji",
        "hi": "Freemoji wale link ko asli emoji jaisa dikhata hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/cynosphere.github.io/VendettaPlugins/ShowImageLinks/",
        "name": "Show Image Links",
        "hi": "Sirf photo link wale message mein link bhi dikhata hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/cynosphere.github.io/VendettaPlugins/ShowTag/",
        "name": "Show Tag",
        "hi": "Naam ke saath poora username/tag dikhata hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/kitomanari.github.io/vendetta-stuff/spotifyShareCommands/",
        "name": "Spotify Share Commands",
        "hi": "Commands se apna Spotify gaana share karo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/fierdetta.github.io/staff-tags/",
        "name": "Staff Tags",
        "hi": "Server staff (admin/mod) ke naam pe tag dikhata hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/aeongdesu.github.io/vdplugins/StickerUtils/",
        "name": "StickerUtils",
        "hi": "Sticker save / copy karne ke options"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/cynosphere.github.io/VendettaPlugins/TabletMode/",
        "name": "Tablet Mode",
        "hi": "Tablet wala layout ON/OFF"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/vendetta.nexpid.xyz/tenor-gif-fix/",
        "name": "TenorGifFix",
        "hi": "Tenor link ko asli GIF ki tarah share/download karo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/fierdetta.github.io/text-replace/",
        "name": "Text Replace",
        "hi": "Apne words apne aap replace karo (shortcuts)"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/vendetta.nexpid.xyz/twemoji-everywhere/",
        "name": "TwemojiEverywhere",
        "hi": "Har jagah Discord wale emoji dikhata hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/vendetta.nexpid.xyz/use-system-emoji/",
        "name": "UseSystemEmoji",
        "hi": "Messages mein phone ke apne emoji dikhata hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/vendetta.nexpid.xyz/usrpfp/",
        "name": "USRPFP",
        "hi": "Custom animated profile photo (USRPFP) dikhata hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/aeongdesu.github.io/vdplugins/UserBG/",
        "name": "UserBG",
        "hi": "Custom profile banner (USRBG) dikhata hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/aeongdesu.github.io/vdplugins/UtilCommands/",
        "name": "UtilCommands",
        "hi": "Kaam ke commands (/plugins, /debug etc.)"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/dziurwa14.github.io/vendetta-plugins/customVoiceMessages/",
        "name": "Custom Voice Messages",
        "hi": "Koi bhi audio file voice message ki tarah bhejo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/fres621.github.io/vendetta-plugins/AltMediaPicker/",
        "name": "AltMediaPicker",
        "hi": "File bhejne ke liye dusra media picker"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/maisymoe.github.io/strife/AnonymousFileNames/",
        "name": "AnonymousFileNames",
        "hi": "Upload karne se pehle file ka naam random kar deta hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/kitomanari.github.io/vendetta-stuff/addonList/",
        "name": "Addon List",
        "hi": "Commands se apni plugin/theme list share karo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/aeongdesu.github.io/vdplugins/SlowmodeExtended/",
        "name": "SlowmodeExtended",
        "hi": "Slowmode ke zyada options"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/c10udburst-discord.github.io/vendetta-plugins/create-webhooks/",
        "name": "Create webhooks",
        "hi": "Webhook settings se naye webhook banao"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/mugman174.github.io/vendetta-plugins/sysinfo/",
        "name": "System Info",
        "hi": "/sysinfo se phone ki details bhejo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/mugman.catvibers.me/vendetta-plugins/urban/",
        "name": "Urban Dictionary",
        "hi": "Urban Dictionary se kisi word ka matlab dekho"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/cynosphere.github.io/VendettaPlugins/Pastelize/",
        "name": "Pastelize",
        "hi": "Bina color wale naam ko pastel rang deta hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/plugins.obamabot.me/vendetta-plugins/petpet/",
        "name": "petPet",
        "hi": "Kisi ki photo pe pet-pet GIF banao"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/exhq.github.io/vendetta/uwuify/",
        "name": "uwuify",
        "hi": "Apne message ko uwu style mein badlo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/jdev082.github.io/vd-repo2/CatFacts/",
        "name": "CatFacts",
        "hi": "/catfact se random billi fact"
      }
    ]
  };
  var YUMI_BUILTINS = [
    {
      key: "badges", name: "YumiCord Badges", version: "2.0.0", icon: "ic_badge_staff",
      shadow: "yumicord-badges.sites.tab.bot", guard: "__ycBadgesActive",
      // Evaluated exactly the way the loader evaluates an installed plugin (indirect eval, same "vendetta" object shape).
      factory: function(vendettaApi) {
        return (0, eval)("vendetta=>{return " + "(function () {\n  \"use strict\";\n  /*\n   * YumiCord Badges v2.0.0\n   * Shows custom YumiCord badges on user profiles. Badge list: https://yumicord-badges.sites.tab.bot/badges.json\n   * (edited from https://yumicord-badges.sites.tab.bot/admin).\n   *\n   * v2.0.0: crash-safe. Every patch, fetch, timer and the settings screen is wrapped so a failure can never\n   * crash Discord; failures are recorded and shown on the plugin's settings (diagnostics) screen.\n   *\n   * Credits: the badge patching approach (patch Discord's useBadges hook, then fix up the rendered badge\n   * element) comes from Revenge's built-in Badges plugin by pylixonly (revenge-mod/revenge-bundle,\n   * BSD-3-Clause) and Kettu's Badges plugin by cocobo1 (C0C0B01/Kettu, BSD-3-Clause).\n   * Emoji images: Twemoji (jdecked/twemoji), CC-BY 4.0.\n   *\n   * Discord 350.8 (Hermes bytecode) facts this relies on:\n   *  - useBadges(displayProfile) returns [{id, description, icon, ...}] (the \"classic\" list).\n   *  - ProfileBadgeRows({userId, badges, catalogBadges, ...}) renders each classic badge as ProfileBadge with\n   *    source {uri: getProfileBadgeIconUrl(b)}, getProfileBadgeIconUrl(b) = b.iconSrc ?? cdn(b.icon).\n   *  - With Discord's NEW badge system (badge management) on, ProfileBadgeRows renders catalogBadges when they\n   *    are not null and skips the classic list. For users that have YumiCord badges we pass catalogBadges as\n   *    undefined, so the classic list (Discord's badges + ours) renders there, in the full profile, the profile\n   *    sheet and the Edit Profile preview alike.\n   */\n  var SITE = \"https://yumicord-badges.sites.tab.bot/\";\n  var DATA_URL = SITE + \"badges.json\";\n  var VERSION = \"2.0.0\";\n  var REFRESH_MS = 5 * 60 * 1000;\n  var PROFILE_REFRESH_MS = 60 * 1000;\n  var ID_PREFIX = \"yumicord-\";\n\n  var diag = {\n    version: VERSION,\n    loadedAt: 0,\n    useBadges: \"not tried\",\n    rows: \"not tried\",\n    badgeFix: \"not tried\",\n    rowsSeen: 0,\n    rowsChanged: 0,\n    hookCalls: 0,\n    hookAdded: 0,\n    errors: []\n  };\n  var state = { data: null, version: 0, lastTry: 0, lastOk: 0, error: null, fetching: false };\n  var elementProps = {};\n  var memo = typeof WeakMap === \"function\" ? new WeakMap() : null;\n  var unpatches = [];\n  var timer = null;\n  var listeners = [];\n\n  var vd = null, metro = null, patcher = null, React = null, RN = null, storage = {}, log = null;\n\n  function note(where, e) {\n    try {\n      var msg = where + \": \" + String((e && (e.message || e)) || e);\n      diag.errors.unshift(new Date().toLocaleTimeString() + \"  \" + msg);\n      if (diag.errors.length > 8) diag.errors.length = 8;\n      try { log && log.error && log.error(\"YumiCord Badges \" + msg); } catch (x) {}\n      notify();\n    } catch (x) {}\n  }\n  function notify() {\n    for (var i = 0; i < listeners.length; i++) { try { listeners[i](); } catch (e) {} }\n  }\n\n  try {\n    vd = vendetta;\n    metro = vd.metro;\n    patcher = vd.patcher;\n    React = metro.common.React;\n    RN = metro.common.ReactNative;\n    storage = (vd.plugin && vd.plugin.storage) || {};\n    log = vd.logger || null;\n  } catch (e) { note(\"init\", e); }\n\n  function sget(k, d) { try { var v = storage[k]; return v === undefined ? d : v; } catch (e) { return d; } }\n  function sset(k, v) { try { storage[k] = v; } catch (e) {} }\n\n  function emojiToTwemoji(emoji) {\n    var cps = [];\n    var hasZwj = emoji.indexOf(\"\\u200d\") !== -1;\n    for (var i = 0; i < emoji.length; i++) {\n      var c = emoji.charCodeAt(i);\n      if (c >= 0xd800 && c <= 0xdbff && i + 1 < emoji.length) {\n        var d = emoji.charCodeAt(i + 1);\n        c = (c - 0xd800) * 0x400 + (d - 0xdc00) + 0x10000;\n        i++;\n      }\n      if (c === 0xfe0f && !hasZwj) continue;\n      cps.push(c.toString(16));\n    }\n    return \"https://cdn.jsdelivr.net/gh/jdecked/twemoji@15.1.0/assets/72x72/\" + cps.join(\"-\") + \".png\";\n  }\n\n  // Always returns an absolute https URL (or null).\n  function iconUrl(icon) {\n    if (!icon || typeof icon !== \"string\") return null;\n    icon = icon.trim();\n    if (/^https?:\\/\\//i.test(icon)) return icon;\n    if (/^\\/\\//.test(icon)) return \"https:\" + icon;\n    var m = /^<a?:\\w+:(\\d+)>$/.exec(icon);\n    if (m) return \"https://cdn.discordapp.com/emojis/\" + m[1] + \".png?size=64\";\n    if (/\\.(png|jpe?g|webp|gif)(\\?.*)?$/i.test(icon) || icon.indexOf(\"/\") !== -1) return SITE + icon.replace(/^\\.?\\/+/, \"\");\n    return emojiToTwemoji(icon);\n  }\n\n  // {badges:{\"1\":{name,icon}}, users:{\"<id>\":[1,5]}} -> lookup table\n  function normalise(raw) {\n    var out = { defs: {}, users: {} };\n    if (!raw || typeof raw !== \"object\") return out;\n    var defs = raw.badges || {};\n    Object.keys(defs).forEach(function (k) {\n      var b = defs[k] || {};\n      var url = iconUrl(b.image || b.icon) || (b.emoji ? emojiToTwemoji(String(b.emoji)) : null);\n      if (url && b.name) out.defs[String(k)] = { name: String(b.name), url: url };\n    });\n    var users = raw.users || {};\n    Object.keys(users).forEach(function (uid) {\n      var list = users[uid];\n      if (!Array.isArray(list)) return;\n      var clean = [];\n      list.forEach(function (n) {\n        n = String(n);\n        if (out.defs[n] && clean.indexOf(n) === -1) clean.push(n);\n      });\n      if (clean.length) out.users[String(uid).trim()] = clean;\n    });\n    return out;\n  }\n\n  function setData(raw) {\n    state.data = normalise(raw);\n    state.version++;\n    elementProps = {};\n    notify();\n  }\n\n  function doFetch(url) {\n    return fetch(url, { cache: \"no-store\", headers: { \"cache-control\": \"no-cache\" } }).then(function (r) {\n      if (!r.ok) throw new Error(\"HTTP \" + r.status);\n      return r.json();\n    });\n  }\n\n  function refresh(force) {\n    try {\n      var now = Date.now();\n      if (state.fetching) return;\n      if (!force && now - state.lastTry < 10 * 1000) return;\n      state.fetching = true;\n      state.lastTry = now;\n      notify();\n      doFetch(DATA_URL + \"?t=\" + now)\n        .then(function (raw) {\n          state.fetching = false;\n          state.error = null;\n          state.lastOk = Date.now();\n          sset(\"cache\", raw);\n          sset(\"lastOk\", state.lastOk);\n          setData(raw);\n        })\n        .catch(function (e) {\n          state.fetching = false;\n          state.error = String((e && e.message) || e);\n          note(\"download\", e);\n          if (!state.data) {\n            doFetch(SITE + \"badges.static.json\").then(function (raw) { if (raw && !state.data) setData(raw); }).catch(function () {});\n          }\n        });\n    } catch (e) {\n      state.fetching = false;\n      note(\"refresh\", e);\n    }\n  }\n\n  function badgesFor(userId) {\n    var d = state.data;\n    if (!d || !userId) return [];\n    var list = d.users[String(userId)];\n    if (!list) return [];\n    var out = [];\n    list.forEach(function (n) {\n      var def = d.defs[n];\n      if (!def) return;\n      var id = ID_PREFIX + userId + \"-\" + n;\n      elementProps[id] = { source: { uri: def.url }, label: def.name };\n      out.push({ id: id, description: def.name, icon: \"yumicord\", iconSrc: def.url });\n    });\n    return out;\n  }\n\n  function withOurs(userId, base) {\n    var mine = badgesFor(userId);\n    if (!mine.length) return null;\n    var rest = (Array.isArray(base) ? base : []).filter(function (b) {\n      return !(b && typeof b.id === \"string\" && b.id.indexOf(ID_PREFIX) === 0);\n    });\n    return mine.concat(rest);\n  }\n\n  function myId() {\n    try {\n      var US = metro.findByStoreName && metro.findByStoreName(\"UserStore\");\n      var u = US && US.getCurrentUser && US.getCurrentUser();\n      return u && u.id ? String(u.id) : null;\n    } catch (e) { return null; }\n  }\n\n  // 1) classic badge list\n  function patchUseBadges() {\n    try {\n      var mod = null;\n      try { mod = metro.findByName(\"useBadges\", false); } catch (e) {}\n      if (!mod || typeof mod.default !== \"function\") {\n        diag.useBadges = \"NOT FOUND\";\n        return;\n      }\n      unpatches.push(patcher.after(\"default\", mod, function (args, ret) {\n        try {\n          diag.hookCalls++;\n          var user = args && args[0];\n          var userId = user && (user.userId || (user.user && user.user.id));\n          if (!userId) return;\n          userId = String(userId);\n          if (Date.now() - state.lastTry > PROFILE_REFRESH_MS) refresh(false);\n          var sig = state.version + \":\" + userId;\n          var cached = memo && Array.isArray(ret) ? memo.get(ret) : null;\n          if (cached && cached.sig === sig) return cached.arr;\n          var arr = withOurs(userId, ret);\n          if (!arr) return;\n          diag.hookAdded++;\n          if (memo && Array.isArray(ret)) memo.set(ret, { sig: sig, arr: arr });\n          return arr;\n        } catch (e) { note(\"useBadges patch\", e); }\n      }));\n      diag.useBadges = \"OK\";\n    } catch (e) {\n      diag.useBadges = \"FAILED\";\n      note(\"useBadges\", e);\n    }\n  }\n\n  // 2) new badge system + image fix-up, on element creation\n  function patchJsx() {\n    try {\n      var rt = metro.findByProps(\"jsx\", \"jsxs\");\n      if (!rt) { diag.rows = diag.badgeFix = \"NOT FOUND\"; return; }\n      var rowsMemo = memo ? new WeakMap() : null;\n      var before = function (args) {\n        try {\n          var p = args[1];\n          // ProfileBadgeRows-shaped props: {userId, badges, catalogBadges, ...}\n          if (!p || typeof p !== \"object\" || !(\"catalogBadges\" in p) || !p.userId) return;\n          diag.rowsSeen++;\n          var uid = String(p.userId);\n          if (!state.data || !state.data.users[uid]) return;\n          var sig = state.version + \":\" + uid;\n          var c = rowsMemo && p.badges && typeof p.badges === \"object\" ? rowsMemo.get(p.badges) : null;\n          var merged = c && c.sig === sig ? c.arr : withOurs(uid, p.badges);\n          if (!merged) return;\n          if (rowsMemo && p.badges && typeof p.badges === \"object\") rowsMemo.set(p.badges, { sig: sig, arr: merged });\n          var np = {};\n          for (var k in p) np[k] = p[k];\n          np.catalogBadges = undefined;\n          np.badges = merged;\n          args[1] = np;\n          diag.rowsChanged++;\n        } catch (e) { note(\"rows patch\", e); }\n      };\n      var after = function (args, ret) {\n        try {\n          var props = ret && ret.props;\n          var id = props && props.id;\n          if (typeof id !== \"string\" || id.indexOf(ID_PREFIX) !== 0) return;\n          var e = elementProps[id];\n          if (!e) return;\n          if (!props.source || !props.source.uri) props.source = e.source;\n          if (!props.label) props.label = e.label;\n        } catch (x) { note(\"badge image fix\", x); }\n      };\n      unpatches.push(patcher.before(\"jsx\", rt, before));\n      unpatches.push(patcher.before(\"jsxs\", rt, before));\n      diag.rows = \"OK\";\n      unpatches.push(patcher.after(\"jsx\", rt, after));\n      unpatches.push(patcher.after(\"jsxs\", rt, after));\n      diag.badgeFix = \"OK\";\n    } catch (e) {\n      if (diag.rows !== \"OK\") diag.rows = \"FAILED\";\n      if (diag.badgeFix !== \"OK\") diag.badgeFix = \"FAILED\";\n      note(\"jsx\", e);\n    }\n  }\n\n  function ago(t) {\n    if (!t) return \"kabhi nahi\";\n    var s = Math.round((Date.now() - t) / 1000);\n    if (s < 60) return s + \" sec pehle\";\n    if (s < 3600) return Math.round(s / 60) + \" min pehle\";\n    return Math.round(s / 3600) + \" ghante pehle\";\n  }\n\n  function toast(msg) {\n    try {\n      if (vd.ui && vd.ui.toasts && vd.ui.toasts.showToast) vd.ui.toasts.showToast(msg);\n    } catch (e) {}\n  }\n\n  function SettingsInner() {\n    var h = React.createElement;\n    var forceState = React.useState(0);\n    var force = forceState[1];\n    React.useEffect(function () {\n      var fn = function () { try { force(function (x) { return x + 1; }); } catch (e) {} };\n      listeners.push(fn);\n      return function () {\n        var i = listeners.indexOf(fn);\n        if (i !== -1) listeners.splice(i, 1);\n      };\n    }, []);\n    var d = state.data || { defs: {}, users: {} };\n    var me = myId();\n    var mine = me && d.users[me] ? d.users[me] : null;\n    var txt = { color: \"#f2f3f5\", fontSize: 15, marginBottom: 6 };\n    var sub = { color: \"#b5bac1\", fontSize: 13, marginBottom: 6 };\n    var good = { color: \"#3ba55c\", fontSize: 15, marginBottom: 6, fontWeight: \"600\" };\n    var bad = { color: \"#f23f43\", fontSize: 15, marginBottom: 6, fontWeight: \"600\" };\n    var card = { backgroundColor: \"#2b2d31\", borderRadius: 12, padding: 16, marginBottom: 12 };\n    var title = { color: \"#ffffff\", fontSize: 17, fontWeight: \"700\", marginBottom: 10 };\n    function btn(label, color, onPress) {\n      return h(RN.TouchableOpacity, {\n        onPress: function () { try { onPress(); } catch (e) { note(\"button\", e); } },\n        style: { backgroundColor: color, borderRadius: 8, paddingVertical: 12, alignItems: \"center\", marginTop: 8 }\n      }, h(RN.Text, { style: { color: \"#ffffff\", fontSize: 15, fontWeight: \"600\" } }, label));\n    }\n    function line(ok, text) { return h(RN.Text, { style: ok ? good : bad }, (ok ? \"\\u2705 \" : \"\\u274c \") + text); }\n    var names = mine ? mine.map(function (n) { return n + \" \" + d.defs[n].name; }).join(\", \") : \"\";\n    var Switch = RN.Switch;\n    return h(RN.ScrollView, { style: { flex: 1 }, contentContainerStyle: { padding: 16 } },\n      h(RN.View, { style: card },\n        h(RN.Text, { style: title }, \"YumiCord Badges v\" + VERSION),\n        line(true, \"Plugin chal raha hai\"),\n        line(!!state.data, state.data ? \"Badge list mili (\" + Object.keys(d.users).length + \" users, \" + Object.keys(d.defs).length + \" badges)\" : \"Badge list abhi nahi mili\"),\n        h(RN.Text, { style: sub }, \"Last update: \" + ago(state.lastOk) + (state.fetching ? \"  (refresh ho raha hai...)\" : \"\")),\n        state.error ? h(RN.Text, { style: bad }, \"Download error: \" + state.error) : null,\n        btn(state.fetching ? \"Refresh ho raha hai...\" : \"Abhi refresh karo\", \"#5865f2\", function () { refresh(true); })\n      ),\n      h(RN.View, { style: card },\n        h(RN.Text, { style: title }, \"Tumhara account\"),\n        h(RN.Text, { style: txt }, \"Tumhari user ID: \" + (me || \"pata nahi chala\")),\n        me ? line(!!mine, mine ? \"Ye ID list mein hai: \" + names : \"Ye ID list mein NAHI hai. Admin page pe yahi ID daalo.\") : null,\n        me ? btn(\"Meri ID copy karo\", \"#4e5058\", function () {\n          try { metro.common.clipboard.setString(me); toast(\"ID copy ho gayi\"); } catch (e) { note(\"copy\", e); }\n        }) : null,\n        btn(\"Admin page kholo\", \"#3ba55c\", function () { RN.Linking.openURL(SITE + \"admin\"); })\n      ),\n      h(RN.View, { style: card },\n        h(RN.Text, { style: title }, \"Diagnostics\"),\n        line(diag.useBadges === \"OK\", \"Classic badges patch: \" + diag.useBadges),\n        line(diag.rows === \"OK\", \"New badges patch: \" + diag.rows),\n        line(diag.badgeFix === \"OK\", \"Badge image fix: \" + diag.badgeFix),\n        h(RN.Text, { style: sub }, \"Profiles dekhe: \" + diag.hookCalls + \" | badge lagaye: \" + diag.hookAdded + \" | badge rows: \" + diag.rowsSeen + \"/\" + diag.rowsChanged),\n        h(RN.Text, { style: sub }, \"Last error: \" + (diag.errors[0] || \"koi nahi\")),\n        diag.errors.length > 1 ? h(RN.Text, { style: sub }, diag.errors.slice(1).join(\"\\n\")) : null,\n        Switch ? h(RN.View, { style: { flexDirection: \"row\", alignItems: \"center\", justifyContent: \"space-between\", marginTop: 10 } },\n          h(RN.Text, { style: txt }, \"App khulne pe test message\"),\n          h(Switch, { value: !!sget(\"testToast\", false), onValueChange: function (v) { sset(\"testToast\", !!v); notify(); } })\n        ) : null\n      )\n    );\n  }\n\n  // Error boundary so a problem in the settings screen shows a message instead of crashing Discord.\n  var Boundary = null;\n  try {\n    Boundary = function (props) { React.Component.call(this, props); this.state = { err: null }; };\n    Boundary.prototype = Object.create(React.Component.prototype);\n    Boundary.prototype.constructor = Boundary;\n    Boundary.getDerivedStateFromError = function (e) { return { err: e }; };\n    Boundary.prototype.componentDidCatch = function (e) { note(\"settings screen\", e); };\n    Boundary.prototype.render = function () {\n      if (this.state && this.state.err) {\n        return React.createElement(RN.Text, { style: { color: \"#f23f43\", padding: 16 } },\n          \"YumiCord Badges settings error: \" + String((this.state.err && this.state.err.message) || this.state.err));\n      }\n      return this.props.children;\n    };\n  } catch (e) { Boundary = null; note(\"boundary\", e); }\n\n  function Settings() {\n    try {\n      var inner = React.createElement(SettingsInner);\n      return Boundary ? React.createElement(Boundary, null, inner) : inner;\n    } catch (e) {\n      note(\"settings screen\", e);\n      return null;\n    }\n  }\n\n  if (typeof globalThis !== \"undefined\" && globalThis.__YC_TEST__) {\n    var T = globalThis.__YC_TEST__;\n    T.normalise = normalise; T.iconUrl = iconUrl; T.setData = setData; T.badgesFor = badgesFor;\n    T.withOurs = withOurs; T.diag = diag; T.state = state;\n  }\n\n  return {\n    onLoad: function () {\n      try {\n        diag.loadedAt = Date.now();\n        state.lastOk = sget(\"lastOk\", 0) || 0;\n        var cache = sget(\"cache\", null);\n        if (cache) { try { setData(cache); } catch (e) { note(\"cache\", e); } }\n        patchUseBadges();\n        patchJsx();\n        refresh(true);\n        try { timer = setInterval(function () { refresh(true); }, REFRESH_MS); } catch (e) { note(\"timer\", e); }\n        if (sget(\"testToast\", false)) {\n          setTimeout(function () {\n            try {\n              var me = myId();\n              var d = state.data;\n              toast(\"YumiCord Badges ON | ID \" + (me || \"?\") + (d && me && d.users[me] ? \" list mein hai\" : \" list mein nahi\"));\n            } catch (e) {}\n          }, 4000);\n        }\n      } catch (e) { note(\"onLoad\", e); }\n    },\n    onUnload: function () {\n      try { if (timer) clearInterval(timer); } catch (e) {}\n      timer = null;\n      unpatches.forEach(function (u) { try { u(); } catch (e) {} });\n      unpatches = [];\n    },\n    settings: Settings\n  };\n})()" + "}\n//# sourceURL=yumicord-builtin-badges")(vendettaApi);
      }
    },
    {
      key: "platforms", name: "YumiCord Platforms", version: "1.0.0", icon: "ic_person_status",
      shadow: "yumicord-platforms.sites.tab.bot", guard: "__ycPlatformsActive",
      // Evaluated exactly the way the loader evaluates an installed plugin (indirect eval, same "vendetta" object shape).
      factory: function(vendettaApi) {
        return (0, eval)("vendetta=>{return " + "(function () {\n  \"use strict\";\n  /*\n   * YumiCord Platforms v1.0.0\n   * Shows which device(s) a user is online on, next to their name:\n   *   member list rows, the user profile name, and the chat message author.\n   *   desktop / mobile / web / console (embedded) / VR, coloured by status (green online, yellow idle, red dnd).\n   *\n   * Crash-safe by design: every lookup, patch, timer and render is wrapped; a failure is recorded and shown on the\n   * plugin's settings screen (Diagnostics) instead of reaching Discord. Our rendered icons sit inside their own\n   * error boundary, so even a render error inside them shows nothing rather than a crash screen.\n   *\n   * Credits: idea, data source (PresenceStore clientStatuses + SessionsStore for yourself) and the five platform\n   * icon images come from \"PlatformIndicators\" by MSMA / martinz64\n   * (https://github.com/Martinz64/vendetta-plugins, The Unlicense). Re-written for Discord 350.8, where the original\n   * stops at load (module-level lookups that no longer exist throw before the plugin can start).\n   *\n   * Discord 350.8 (Hermes bytecode) facts this relies on, read from the app bundle:\n   *  - PresenceStore.getClientStatus(userId) -> {desktop|mobile|web|embedded|vr: \"online\"|\"idle\"|\"dnd\"}.\n   *  - SessionsStore.getSessions() -> {id: {clientInfo:{client}, status}} for your own account.\n   *  - Profile: component \"DisplayName\" ({user, guildId, name, ...}) renders the profile name.\n   *  - Member list: component \"UserRow\" ({user, nickname, roleColors, ...}) renders a TableRow with props.label.\n   *  - Chat: messages are drawn natively from rows built by RowManager.prototype.generate; we append emoji to\n   *    row.message.username (plain text, so no status colour in chat).\n   */\n  var VERSION = \"1.0.0\";\n  var PLATFORMS = [\"desktop\", \"mobile\", \"web\", \"embedded\", \"vr\"];\n  var EMOJI = { desktop: \"\\ud83d\\udda5\\ufe0f\", mobile: \"\\ud83d\\udcf1\", web: \"\\ud83c\\udf10\", embedded: \"\\ud83c\\udfae\", vr: \"\\ud83e\\udd7d\" };\n  var NAMES = { desktop: \"PC\", mobile: \"Phone\", web: \"Browser\", embedded: \"Console\", vr: \"VR\" };\n  var COLORS = { online: \"#23a55a\", idle: \"#f0b232\", dnd: \"#f23f43\", streaming: \"#593695\", offline: \"#80848e\", invisible: \"#80848e\" };\n  var ICONS = {\n    desktop: \"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAMAAABiM0N1AAAAVFBMVEUAAACvv7+3u7+5u7+2ub+4u726vL65u765vL65vMG5u723ub23v7+3t7+6vL+4ur+6u765u764vL+4ur23t7+7vb+3ur25ur64ur+7u766ur6vr7/+1nXbAAAAHHRSTlMAEEB/UHDv/99fgIAgQJ+f7++fnyB/YN9vTz8QSaZf3QAAAI1JREFUeAHt1tUBwkAURNEXHZzg1n+d2Fc8u4OTOQXcyKqJ3ARh5C22qiQFYTC0khFIYyuYgDYthGagzQuhDLRFIYS7yBPuakLmSaF2CimkkEIKKfT8I5un0MdCT7v6LUFbFUIhaGsr2IAUWcl2B0K2t6pDVKttGR5P3BJvpxCnfdTMHVo9NaRQ1MpKRC5jHSw3VFQzIwAAAABJRU5ErkJggg==\",\n    web: \"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAQAAAD/5HvMAAADgklEQVR42u3a32vVdRzH8VdOv2NzGzM7bkp0E9F9RQSbOmK6groQpeugOzXJfnCW3YwgC4IyHCldrBmFELtQRxfK2MHp1sjVZRfBMSJFYu6cMUnOOZPz9Gb45uyc79fv5/tDvDiPv+DJh/fn8+HL56umpqbHFZsZ4hjjzJOnQJkyBfLMM87H7GWzHh16OcoVKgQpM8N79Cht7GaSVcJa5QK7lBZe5SpRzDCgpLGdH6gS3SRPKzm8xTJxFTmgJNDKtyRllFbFQxfTRLVCvSk6FR3b+J3onuRTlllvgUzk1YmVsyJJdPMN1bqkzmizM00cc1rDIP9SawpPrjhFPAf1AN1cotZJ940ezwKb1q33BLX2Kzx2sBwzZ7vWoYXvAVOkV2FxlqjuMMtBNqkBNpIDzI/h7ywnTsfIP5gquxUGV3EiB7zMPcxlPRwDOJITTgNmpx6GyZSDnqKAOa9g9LKKIzniA0yFbQrC+5B6UDf/Y44oCFdwdUPOGMfkgr8kyrg6Lmf0YUq0yw9DuLnBcTw5YwNFzB754RhmkYaUCH7BDMsPZzDDZFMM+gQzJj/8inlTYiS1oNcws/LD35jnJUtKPOgFzHX5YQmzdmCRTSXoGcyi/FDGtEqWlHhQG6YULsjTA4zg5iZf4CkAXrig25gtUowk+FwB2IpZDDfUz8pEWiUF4DnM9XDbfkiKl6QAvB5u248H38KMJBZ0FDMW7uo4qwbIJhQ0gcnKD3sxN3lCirNKgZfrf5hB+aGdEuYVNUQ2dtAuTIk2+WMG87V8MBIzaBQzrdDDVqBDPuIE0cUy5rCC0MMq5lAqQR9hKmRcPoNu0ZF0EN0sYs7JBAyc+UwNsUJYd7nGO2zUGr4CTL9MqMGu8KIaYB43C2yVJPq4h8kpDAaoYv6kS3U4jKvfaGELeUyVfoXDT4C5wAatg8cfuHqbS4A54/K8UgTMd/WnNjuckyqAKdCj8DhArdO0NFilQ8xxhyiq7JMbRqk1GXAEuDshV3hMUesvXkoo6CKe3NHJArUqfEln7KBrdCgaMnVJcIsPa6OcczKKjk6mqFfkFH20RAi6SIfiweMkjS0xwTBvEFaVE3hKAvspEleBfUoOvTGfOH+mJ40X6ctEkaNfaWEn56kQVoVz9CltZDhCjhJBSuR4l4weHdrZwzBjzJFniTJlbpNnljGyDNLW/BmlqelxdR++AoGbDB4jjAAAAABJRU5ErkJggg==\",\n    mobile: \"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAMAAADVRocKAAAAXVBMVEUAAAAwMDgwMDUwMDUuMDYwMDYvMTcvMTYvMTYwMDYwMDUvMTYwMjUvMTUvMjYvMTUuMDUuMDQvMDUtMTUwMDgvMDUwMDAtMDYuMDYwMDAtMDUvMDYuMDUtMDcpMTo5aAq8AAAAH3RSTlMAIGBvf1C//89fMN9g75+/j3+fP0C/IFBfMGDPb08fcZ9WCgAAAMNJREFUeAHt2YWNxQAMg2EX/fiVud1/zBuhSaRjfwv8UsQx5J9L0iw/VySIyUoaXa7wu93pcE/g9KDTFS4F+amF5Em3ZwK7FwPeMEsYcoNVxZAaViX5uTd6MuQJKwY5A01u9goFWph1fyKggAIKKKCAAgoooIACCiiggAIKKKCAAgoooIACn/l9d/t3gU/fcEqG9LDKGVLB6saQAZ97owZ2w5NuzwEOKd1G4FMLE5wG36Y/w29ZadRviBn2/Nw2HfjTPgD3/UVA1TCAGgAAAABJRU5ErkJggg==\",\n    embedded: \"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAMAAABiM0N1AAAAk1BMVEUAAAC3u7+4ur+5vL+5u765u7+6vL+2ub+3v7+6u7+5vL66v7+6vL65u761ur+4u765vL+3t7+6u765u7+9vb23t7+7vb+6u766ur+5ur6/v7+vv7+9vcW1tb+5u727u763ur25vL+6vL+3ub24ur+5u7+4vL+5ur66ur64ur25vL+6u764ur24u722uby5u76vr7/eehxsAAAAMXRSTlMAQJ/f/8+fUCC/3zDv7zC/UEDvfx8gf88w3xAQHzCAT2Bfb4Bvj5/PP6+vv59wUM8QEONx+AAAAWZJREFUeAHt1dWa6zAMBOA5PSqzs2Vmhvd/uWWcVFHqr5f+r+3JRqtJ8UhBEAT/Mv8lpWwuD02hKHcpFXBTuSJ3qtZwQ0HPUVULiCuJhzpiGuKlCZaTL3gnxEVPaLWdkAxYJznIdfGmy0k9MEkOivChLQSkbwS18KElZEBBLSMIX4QMuRxaEJ0vCBndCkJMbEZjIRO6MTWCqjWlRjO6MTeCpLoooDWuCFvSjcgK0pYzohsrM0hZzhXdWJtBynJyR4rGv19dzrp3EC3nhoJKZpCynNxalzqIlrPKU7WDlOXUym8H0XIOufy+htxZX9tHBU24/L5mXH5fSy6/r4jL/8sOidYJv2x7fu0k84SgIn/Qmb50dT2oB6YXk+tf4hElWuuPdeaIlCFx/fkLeM+Q1Ferw3RQZ9SmP8jQlR9H/NZ3tKmG08+sW/SMnrxzZ6Qy/TrfBWkdL+Lq0RUptaYHJyU+HwRB4O0FjTMnvIkvoBQAAAAASUVORK5CYII=\",\n    vr: \"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAMAAABiM0N1AAAANlBMVEVMaXHv7/Hv7/Hv7/Hv7/Hv7/Hv7/Hv7/Hv7/Hs7PTu7vHv7/Hv7/Hv7/Hv7/Hv7/Hv7/Hv7/EEUZf/AAAAEXRSTlMAzGV4UNr78OcJFDufKb6ri3Gd0SEAAAHQSURBVFjD7VbHdsQgDDRNiOby/z+bjY0N2LRk95C8xxwNHo0KkqZpYGBg4PMwbBa4ZYFiZqaPRVGxNSCoavPwJs0ujLbk2K0TtipKz1s3Zl3RE/PILGKmsqbLL8JcwZ5y9LJmi3E+k8Ib1UH8xcI95Utnaeb2TAnmbzLP01NsnilfBEcBCW9FVXWpwzvxrGYiE785ASC1p2DO3M5xlWty5ZREyrEmKlQK0Tedweu1npUdNPxDVBrlHe5bIHQQue1m/YVIEKjIGKmGG7ZbPKYpqnsMnsGqqxUQNSzpP8WdJoSaNUop7nwFInZF600ijT0F3kE06dXS6RNEXfh7ROI/EMG7RPAM2++I8D48wqefZe0cJy74Bo+HaixBJPbRLXX0k5ueDenWgtzVYojLz670edNL55y2wSgPQPOtFhPbirPlKYlDPOyBPwUtjD8auzr6GwYXDKRrA4RAucMFmR0PvuXjeZ3K+wIiT++MD8Wa32n8KSxc67ArSOYcOzln6rTmi5eKhWbMIbMGyV2gkZkjKE4ZVr6cM1Lp6qxslN6ZoDodeLoVi6igTbqlYmOJ0muIBrIku4oFK7Ix9I7atAQ2SWym1F5HEjB3NDAwMPAuvgCPRUw2yKsaYwAAAABJRU5ErkJggg==\"\n  };\n\n  var diag = {\n    version: VERSION,\n    loadedAt: 0,\n    stores: \"not tried\",\n    jsx: \"not tried\",\n    chat: \"not tried\",\n    live: \"not tried\",\n    profileSeen: 0, profileAdded: 0,\n    membersSeen: 0, membersAdded: 0, membersNoLabel: 0,\n    chatSeen: 0, chatAdded: 0,\n    found: {},\n    errors: []\n  };\n  var unpatches = [];\n  var listeners = [];\n  var subs = [];\n  var active = false;\n  var presenceTimer = null;\n  var storeUnsubs = [];\n\n  var vd = null, metro = null, patcher = null, React = null, RN = null, storage = {}, log = null;\n  var PresenceStore = null, SessionsStore = null, UserStore = null;\n\n  function note(where, e) {\n    try {\n      var msg = where + \": \" + String((e && (e.message || e)) || e);\n      if (diag.errors.length && diag.errors[0].indexOf(msg) !== -1) return;\n      diag.errors.unshift(new Date().toLocaleTimeString() + \"  \" + msg);\n      if (diag.errors.length > 8) diag.errors.length = 8;\n      try { log && log.error && log.error(\"YumiCord Platforms \" + msg); } catch (x) {}\n      notify();\n    } catch (x) {}\n  }\n  function notify() {\n    for (var i = 0; i < listeners.length; i++) { try { listeners[i](); } catch (e) {} }\n  }\n\n  try {\n    vd = vendetta;\n    metro = vd.metro;\n    patcher = vd.patcher;\n    React = metro.common.React;\n    RN = metro.common.ReactNative;\n    storage = (vd.plugin && vd.plugin.storage) || {};\n    log = vd.logger || null;\n  } catch (e) { note(\"init\", e); }\n\n  function sget(k, d) { try { var v = storage[k]; return v === undefined || v === null ? d : v; } catch (e) { return d; } }\n  function sset(k, v) { try { storage[k] = v; } catch (e) {} }\n  function h() { return React.createElement.apply(React, arguments); }\n\n  // ---------- data ----------\n  function findStore(n) {\n    try { return (metro.findByStoreName && metro.findByStoreName(n)) || null; } catch (e) { note(\"store \" + n, e); return null; }\n  }\n  function initStores() {\n    PresenceStore = findStore(\"PresenceStore\");\n    SessionsStore = findStore(\"SessionsStore\");\n    UserStore = findStore(\"UserStore\");\n    diag.stores = (PresenceStore ? \"Presence OK\" : \"Presence MISSING\") + \", \" +\n      (SessionsStore ? \"Sessions OK\" : \"Sessions MISSING\") + \", \" + (UserStore ? \"User OK\" : \"User MISSING\");\n  }\n\n  var cachedMe = null;\n  function myId() {\n    try {\n      if (cachedMe) return cachedMe;\n      var u = UserStore && UserStore.getCurrentUser && UserStore.getCurrentUser();\n      if (u && u.id) cachedMe = String(u.id);\n      return cachedMe;\n    } catch (e) { return null; }\n  }\n\n  function rawStatuses(uid) {\n    var res = null;\n    if (uid && uid === myId() && SessionsStore && typeof SessionsStore.getSessions === \"function\") {\n      var s = SessionsStore.getSessions() || {};\n      var out = {}, any = false;\n      Object.keys(s).forEach(function (k) {\n        var x = s[k];\n        var c = x && x.clientInfo && x.clientInfo.client;\n        if (c && c !== \"unknown\") { out[c] = x.status || \"online\"; any = true; }\n      });\n      if (any) res = out;\n    }\n    if (!res && PresenceStore) {\n      if (typeof PresenceStore.getClientStatus === \"function\") res = PresenceStore.getClientStatus(uid);\n      else if (typeof PresenceStore.getState === \"function\") {\n        var st = PresenceStore.getState();\n        res = st && st.clientStatuses ? st.clientStatuses[uid] : null;\n      }\n    }\n    return res && typeof res === \"object\" ? res : null;\n  }\n\n  // -> [[platform, status], ...] in a fixed order, only active platforms\n  function entries(uid) {\n    try {\n      if (!uid) return [];\n      uid = String(uid);\n      var raw = rawStatuses(uid);\n      if (!raw) return [];\n      var showExtra = !!sget(\"showConsole\", true);\n      var out = [];\n      var keys = PLATFORMS.concat(Object.keys(raw).filter(function (k) { return PLATFORMS.indexOf(k) === -1; }));\n      keys.forEach(function (p) {\n        var s = raw[p];\n        if (!s || typeof s !== \"string\" || s === \"offline\" || s === \"invisible\") return;\n        if (!showExtra && (p === \"embedded\" || p === \"vr\")) return;\n        out.push([p, s]);\n      });\n      return out;\n    } catch (e) { note(\"status read\", e); return []; }\n  }\n  function sigOf(list) { return list.map(function (x) { return x[0] + \":\" + x[1]; }).join(\"|\"); }\n  function emojiText(uid) {\n    var list = entries(uid);\n    return list.map(function (x) { return EMOJI[x[0]] || \"\\u2022\"; }).join(\"\");\n  }\n\n  // live updates: one store listener, batched, each icon re-renders only if its own user's status changed\n  function onPresence() {\n    try {\n      if (presenceTimer) return;\n      presenceTimer = setTimeout(function () {\n        presenceTimer = null;\n        cachedMe = null;\n        var list = subs.slice();\n        for (var i = 0; i < list.length; i++) { try { list[i](); } catch (e) {} }\n      }, 1000);\n    } catch (e) {}\n  }\n  function startLive() {\n    try {\n      var n = 0;\n      [PresenceStore, SessionsStore].forEach(function (st) {\n        if (st && typeof st.addChangeListener === \"function\") {\n          st.addChangeListener(onPresence);\n          storeUnsubs.push(function () { try { st.removeChangeListener(onPresence); } catch (e) {} });\n          n++;\n        }\n      });\n      diag.live = n ? \"OK\" : \"NOT FOUND (icons update when the row re-renders)\";\n    } catch (e) { diag.live = \"FAILED\"; note(\"live updates\", e); }\n  }\n\n  // ---------- error boundary ----------\n  var Boundary = null;\n  try {\n    Boundary = function (props) { React.Component.call(this, props); this.state = { err: null }; };\n    Boundary.prototype = Object.create(React.Component.prototype);\n    Boundary.prototype.constructor = Boundary;\n    Boundary.getDerivedStateFromError = function (e) { return { err: e }; };\n    Boundary.prototype.componentDidCatch = function (e) { note(this.props.where || \"render\", e); };\n    Boundary.prototype.render = function () {\n      if (this.state && this.state.err) {\n        if (this.props.quiet) return null;\n        return React.createElement(RN.Text, { style: { color: \"#f23f43\", padding: 16 } },\n          \"YumiCord Platforms error: \" + String((this.state.err && this.state.err.message) || this.state.err));\n      }\n      return this.props.children === undefined ? null : this.props.children;\n    };\n  } catch (e) { Boundary = null; note(\"boundary\", e); }\n\n  // ---------- icons ----------\n  function IconsInner(props) {\n    var uid = props.userId ? String(props.userId) : null;\n    var tick = React.useState(0);\n    var last = React.useRef(\"\");\n    React.useEffect(function () {\n      var fn = function () {\n        try {\n          var s = sigOf(entries(uid));\n          if (s !== last.current) tick[1](function (x) { return x + 1; });\n        } catch (e) {}\n      };\n      subs.push(fn);\n      return function () { var i = subs.indexOf(fn); if (i !== -1) subs.splice(i, 1); };\n    }, [uid]);\n    var list = entries(uid);\n    last.current = sigOf(list);\n    if (!list.length) return null;\n    var size = props.size || 16;\n    var emoji = sget(\"style\", \"icons\") === \"emoji\";\n    return h(RN.View, { style: { flexDirection: \"row\", alignItems: \"center\", marginLeft: 4, flexShrink: 0 } },\n      list.map(function (x) {\n        var p = x[0], s = x[1], col = COLORS[s] || COLORS.online;\n        var label = (NAMES[p] || p) + \" \" + s;\n        if (emoji || !ICONS[p]) {\n          if (!EMOJI[p]) return h(RN.View, { key: p, accessibilityLabel: label, style: { width: size * 0.6, height: size * 0.6, borderRadius: size, backgroundColor: col, marginLeft: 2 } });\n          return h(RN.Text, { key: p, accessibilityLabel: label, style: { fontSize: Math.round(size * 0.8), marginLeft: 2, color: col } }, EMOJI[p]);\n        }\n        return h(RN.Image, { key: p, accessibilityLabel: label, source: { uri: ICONS[p] }, style: { width: size, height: size, tintColor: col, marginLeft: 2 } });\n      }));\n  }\n  function PlatformIcons(props) {\n    try {\n      var inner = h(IconsInner, props);\n      return Boundary ? h(Boundary, { quiet: true, where: \"icons\" }, inner) : inner;\n    } catch (e) { note(\"icons\", e); return null; }\n  }\n  function withIcons(child, uid, size) {\n    return h(RN.View, { style: { flexDirection: \"row\", alignItems: \"center\", flexShrink: 1 } },\n      h(RN.View, { style: { flexShrink: 1 } }, child),\n      h(PlatformIcons, { userId: uid, size: size }));\n  }\n  function isEl(x) { return !!x && typeof x === \"object\" && \"props\" in x && \"type\" in x; }\n\n  // ---------- where the icons go ----------\n  function modDisplayName(props, out) {\n    if (!active || !sget(\"profile\", true)) return out;\n    diag.profileSeen++;\n    var uid = props && props.user && props.user.id;\n    if (!uid || !isEl(out)) return out;\n    diag.profileAdded++;\n    return withIcons(out, String(uid), 18);\n  }\n  function modUserRow(props, out) {\n    if (!active || !sget(\"members\", true)) return out;\n    diag.membersSeen++;\n    var uid = props && props.user && props.user.id;\n    if (!uid || !isEl(out) || !out.props) return out;\n    var label = out.props.label;\n    if (!label || (typeof label !== \"string\" && !isEl(label))) { diag.membersNoLabel++; return out; }\n    diag.membersAdded++;\n    var lab = typeof label === \"string\" ? h(RN.Text, { numberOfLines: 1, style: { color: \"#f2f3f5\", fontSize: 16, fontWeight: \"600\" } }, label) : label;\n    return React.cloneElement(out, { label: withIcons(lab, String(uid), 16) });\n  }\n  var TARGETS = { DisplayName: modDisplayName, UserRow: modUserRow };\n\n  // ---------- jsx hook: finds DisplayName / UserRow however they are exported ----------\n  var fnCache = typeof WeakMap === \"function\" ? new WeakMap() : null;\n  var objSeen = typeof WeakSet === \"function\" ? new WeakSet() : null;\n\n  function targetOf(fn) {\n    if (typeof fn !== \"function\" || fn.__ycPlatforms) return null;\n    if (fn.prototype && fn.prototype.isReactComponent) return null;\n    var n = fn.displayName || fn.name;\n    return n && Object.prototype.hasOwnProperty.call(TARGETS, n) ? n : null;\n  }\n  function makeWrapper(orig, name) {\n    var mod = TARGETS[name];\n    var W = function () {\n      var out = orig.apply(this, arguments);\n      if (!active) return out;\n      try { return mod(arguments[0], out); } catch (e) { note(name + \" patch\", e); return out; }\n    };\n    W.__ycPlatforms = true;\n    try { W.displayName = name; } catch (e) {}\n    try { if (orig.defaultProps) W.defaultProps = orig.defaultProps; } catch (e) {}\n    return W;\n  }\n  function found(name, how) {\n    diag.found[name] = (diag.found[name] ? diag.found[name] + \", \" : \"\") + how;\n    notify();\n  }\n  function jsxBefore(args) {\n    try {\n      if (!active) return;\n      var t = args[0];\n      if (!t || typeof t === \"string\") return;\n      if (typeof t === \"function\") {\n        if (!fnCache) return;\n        var w = fnCache.get(t);\n        if (w === undefined) {\n          var n = targetOf(t);\n          w = n ? makeWrapper(t, n) : null;\n          fnCache.set(t, w);\n          if (n) found(n, \"function\");\n        }\n        if (w) args[0] = w;\n        return;\n      }\n      if (typeof t === \"object\" && objSeen && !objSeen.has(t)) {\n        objSeen.add(t);\n        var holder = t, key = typeof t.type === \"function\" ? \"type\" : (typeof t.render === \"function\" ? \"render\" : null);\n        if (!key && t.type && typeof t.type === \"object\" && typeof t.type.render === \"function\") { holder = t.type; key = \"render\"; }\n        if (!key) return;\n        var nm = targetOf(holder[key]);\n        if (!nm) return;\n        var mod = TARGETS[nm];\n        unpatches.push(patcher.after(key, holder, function (a, ret) {\n          if (!active) return;\n          try { return mod(a && a[0], ret); } catch (e) { note(nm + \" patch\", e); }\n        }));\n        found(nm, key === \"type\" ? \"memo\" : \"forwardRef\");\n      }\n    } catch (e) { note(\"jsx hook\", e); }\n  }\n  function patchJsx() {\n    try {\n      var rt = metro.findByProps(\"jsx\", \"jsxs\");\n      if (!rt) { diag.jsx = \"NOT FOUND\"; return; }\n      unpatches.push(patcher.before(\"jsx\", rt, jsxBefore));\n      unpatches.push(patcher.before(\"jsxs\", rt, jsxBefore));\n      diag.jsx = \"OK\";\n    } catch (e) { diag.jsx = \"FAILED\"; note(\"jsx\", e); }\n  }\n\n  // ---------- chat (native rows) ----------\n  var baseNames = typeof WeakMap === \"function\" ? new WeakMap() : null;\n  function chatAfter(args, row) {\n    try {\n      if (!active || !sget(\"chat\", true) || !baseNames) return;\n      var m = row && row.message;\n      if (!m || typeof m !== \"object\" || typeof m.username !== \"string\") return;\n      diag.chatSeen++;\n      var base = baseNames.get(m);\n      if (base === undefined) { base = m.username; baseNames.set(m, base); }\n      var src = args && args[0] && args[0].message;\n      var uid = m.authorId || (src && src.author && src.author.id);\n      if (!uid) return;\n      var e = emojiText(String(uid));\n      var next = e ? base + \" \" + e : base;\n      if (m.username !== next) m.username = next;\n      if (e) diag.chatAdded++;\n    } catch (e) { note(\"chat patch\", e); }\n  }\n  function patchChat() {\n    try {\n      var RM = null;\n      try { RM = metro.findByName(\"RowManager\"); } catch (e) {}\n      if (!RM || !RM.prototype || typeof RM.prototype.generate !== \"function\") { diag.chat = \"NOT FOUND\"; return; }\n      unpatches.push(patcher.after(\"generate\", RM.prototype, chatAfter));\n      diag.chat = \"OK\";\n    } catch (e) { diag.chat = \"FAILED\"; note(\"chat\", e); }\n  }\n\n  // ---------- settings ----------\n  function toast(msg) {\n    try { if (vd.ui && vd.ui.toasts && vd.ui.toasts.showToast) vd.ui.toasts.showToast(msg); } catch (e) {}\n  }\n\n  function SettingsInner() {\n    var forceState = React.useState(0);\n    var force = forceState[1];\n    React.useEffect(function () {\n      var fn = function () { try { force(function (x) { return x + 1; }); } catch (e) {} };\n      listeners.push(fn);\n      subs.push(fn);\n      return function () {\n        var i = listeners.indexOf(fn); if (i !== -1) listeners.splice(i, 1);\n        var j = subs.indexOf(fn); if (j !== -1) subs.splice(j, 1);\n      };\n    }, []);\n    var me = myId();\n    var mine = me ? entries(me) : [];\n    var txt = { color: \"#f2f3f5\", fontSize: 15, marginBottom: 6 };\n    var sub = { color: \"#b5bac1\", fontSize: 13, marginBottom: 6 };\n    var good = { color: \"#3ba55c\", fontSize: 15, marginBottom: 6, fontWeight: \"600\" };\n    var bad = { color: \"#f23f43\", fontSize: 15, marginBottom: 6, fontWeight: \"600\" };\n    var card = { backgroundColor: \"#2b2d31\", borderRadius: 12, padding: 16, marginBottom: 12 };\n    var title = { color: \"#ffffff\", fontSize: 17, fontWeight: \"700\", marginBottom: 10 };\n    function line(ok, text) { return h(RN.Text, { style: ok ? good : bad }, (ok ? \"\\u2705 \" : \"\\u274c \") + text); }\n    var Switch = RN.Switch;\n    function toggle(key, def, label, hint) {\n      return h(RN.View, { key: key, style: { flexDirection: \"row\", alignItems: \"center\", justifyContent: \"space-between\", marginTop: 8 } },\n        h(RN.View, { style: { flex: 1, paddingRight: 8 } },\n          h(RN.Text, { style: txt }, label),\n          hint ? h(RN.Text, { style: sub }, hint) : null),\n        Switch ? h(Switch, { value: !!sget(key, def), onValueChange: function (v) { sset(key, !!v); notify(); onPresence(); } }) : null);\n    }\n    var foundTxt = Object.keys(diag.found).map(function (k) { return k + \" (\" + diag.found[k] + \")\"; }).join(\"; \") || \"abhi koi nahi (member list / profile kholo)\";\n    return h(RN.ScrollView, { style: { flex: 1 }, contentContainerStyle: { padding: 16 } },\n      h(RN.View, { style: card },\n        h(RN.Text, { style: title }, \"YumiCord Platforms v\" + VERSION),\n        line(active, active ? \"Plugin chal raha hai\" : \"Plugin band hai\"),\n        h(RN.Text, { style: sub }, \"\\ud83d\\udcf1 Phone   \\ud83d\\udda5\\ufe0f PC   \\ud83c\\udf10 Browser   \\ud83c\\udfae Console\"),\n        h(RN.Text, { style: sub }, \"Rang: hara = online, peela = idle, laal = DND\")\n      ),\n      h(RN.View, { style: card },\n        h(RN.Text, { style: title }, \"Tumhare devices (live)\"),\n        h(RN.Text, { style: txt }, \"User ID: \" + (me || \"pata nahi chala\")),\n        h(RN.View, { style: { flexDirection: \"row\", alignItems: \"center\", marginBottom: 6 } },\n          h(RN.Text, { style: txt }, mine.length ? \"Abhi online: \" : \"Koi device nahi mila\"),\n          me ? h(PlatformIcons, { userId: me, size: 20 }) : null),\n        mine.length ? h(RN.Text, { style: sub }, mine.map(function (x) { return (NAMES[x[0]] || x[0]) + \" = \" + x[1]; }).join(\", \")) : null\n      ),\n      h(RN.View, { style: card },\n        h(RN.Text, { style: title }, \"Kahan dikhana hai\"),\n        toggle(\"members\", true, \"Member list\"),\n        toggle(\"profile\", true, \"Profile pe naam ke paas\"),\n        toggle(\"chat\", true, \"Chat mein naam ke paas\", \"Chat mein emoji aate hain (rang nahi). Naye messages pe dikhte hain.\"),\n        toggle(\"showConsole\", true, \"Console \\ud83c\\udfae / VR bhi dikhao\"),\n        h(RN.View, { style: { flexDirection: \"row\", alignItems: \"center\", justifyContent: \"space-between\", marginTop: 8 } },\n          h(RN.Text, { style: txt }, \"Style: \" + (sget(\"style\", \"icons\") === \"emoji\" ? \"Emoji\" : \"Rangeen icons\")),\n          h(RN.TouchableOpacity, {\n            onPress: function () { try { sset(\"style\", sget(\"style\", \"icons\") === \"emoji\" ? \"icons\" : \"emoji\"); notify(); onPresence(); } catch (e) { note(\"style\", e); } },\n            style: { backgroundColor: \"#5865f2\", borderRadius: 8, paddingVertical: 8, paddingHorizontal: 14 }\n          }, h(RN.Text, { style: { color: \"#ffffff\", fontWeight: \"600\" } }, \"Badlo\")))\n      ),\n      h(RN.View, { style: card },\n        h(RN.Text, { style: title }, \"Diagnostics\"),\n        line(diag.stores.indexOf(\"Presence OK\") === 0, \"Stores: \" + diag.stores),\n        line(diag.jsx === \"OK\", \"Member list + profile hook: \" + diag.jsx),\n        line(diag.chat === \"OK\", \"Chat patch: \" + diag.chat),\n        line(diag.live === \"OK\", \"Live update: \" + diag.live),\n        h(RN.Text, { style: sub }, \"Mile: \" + foundTxt),\n        h(RN.Text, { style: sub }, \"Profile: \" + diag.profileSeen + \"/\" + diag.profileAdded +\n          \" | Members: \" + diag.membersSeen + \"/\" + diag.membersAdded + (diag.membersNoLabel ? \" (no label \" + diag.membersNoLabel + \")\" : \"\") +\n          \" | Chat: \" + diag.chatSeen + \"/\" + diag.chatAdded),\n        h(RN.Text, { style: sub }, \"Last error: \" + (diag.errors[0] || \"koi nahi\")),\n        diag.errors.length > 1 ? h(RN.Text, { style: sub }, diag.errors.slice(1).join(\"\\n\")) : null,\n        toggle(\"testToast\", false, \"App khulne pe test message\")\n      )\n    );\n  }\n  function Settings() {\n    try {\n      var inner = React.createElement(SettingsInner);\n      return Boundary ? React.createElement(Boundary, { where: \"settings screen\" }, inner) : inner;\n    } catch (e) { note(\"settings screen\", e); return null; }\n  }\n\n  if (typeof globalThis !== \"undefined\" && globalThis.__YC_TEST__) {\n    var T = globalThis.__YC_TEST__;\n    T.diag = diag; T.entries = entries; T.emojiText = emojiText; T.jsxBefore = jsxBefore; T.chatAfter = chatAfter;\n    T.modUserRow = modUserRow; T.modDisplayName = modDisplayName; T.PlatformIcons = PlatformIcons; T.IconsInner = IconsInner;\n    T.SettingsInner = SettingsInner; T.subs = subs; T.onPresence = onPresence;\n  }\n\n  return {\n    onLoad: function () {\n      try {\n        active = true;\n        diag.loadedAt = Date.now();\n        initStores();\n        startLive();\n        patchJsx();\n        patchChat();\n        if (sget(\"testToast\", false)) {\n          setTimeout(function () {\n            try {\n              var me = myId();\n              toast(\"YumiCord Platforms ON | \" + (me ? (emojiText(me) || \"koi device nahi\") : \"ID ?\"));\n            } catch (e) {}\n          }, 4000);\n        }\n      } catch (e) { note(\"onLoad\", e); }\n    },\n    onUnload: function () {\n      active = false;\n      try { if (presenceTimer) clearTimeout(presenceTimer); } catch (e) {}\n      presenceTimer = null;\n      storeUnsubs.forEach(function (u) { try { u(); } catch (e) {} });\n      storeUnsubs = [];\n      unpatches.forEach(function (u) { try { u(); } catch (e) {} });\n      unpatches = [];\n      subs.length = 0;\n    },\n    settings: Settings\n  };\n})()" + "}\n//# sourceURL=yumicord-builtin-platforms")(vendettaApi);
      }
    }
  ];
  var yumiState = { ready: null, status: "not started", active: {}, instances: {}, errors: [], seed: { status: "not started", added: 0, skipped: 0, failed: 0 } };
  function yumiNote(where, e) {
    try {
      var msg = where + ": " + String(e && (e.stack || e.message) || e);
      yumiState.errors.unshift(msg);
      if (yumiState.errors.length > 10) yumiState.errors.length = 10;
      try { console.log("[YumiCord] " + msg); } catch (x) {}
    } catch (x) {}
  }
  function yumiShadowOf(id) {
    if (typeof id !== "string") return null;
    for (var i = 0; i < YUMI_BUILTINS.length; i++) {
      var b = YUMI_BUILTINS[i];
      if (b.shadow && id.indexOf(b.shadow) !== -1) return b;
    }
    return null;
  }
  function yumiStartOne(b) {
    return createStorage(createMMKVBackend("YUMICORD_BUILTIN_" + b.key)).then(function(storage) {
      var inst = null;
      try {
        var lg;
        try { lg = new LoggerClass("YumiCord \xBB " + b.name); } catch (e) { lg = { log: function() {}, info: function() {}, warn: function() {}, error: function() {} }; }
        var api = Object.assign({}, globalThis.vendetta, {
          plugin: {
            id: "yumicord-builtin:" + b.key,
            manifest: { name: b.name, description: b.name + " (built into YumiCord)", authors: [{ name: "YumiCord" }], main: "index.js", hash: "builtin-" + b.version, version: b.version, vendetta: { icon: b.icon } },
            storage
          },
          logger: lg
        });
        var raw = b.factory(api);
        inst = typeof raw === "function" ? raw() : raw;
        inst = inst && inst.default || inst || {};
        yumiState.instances[b.key] = inst;
        if (typeof inst.onLoad === "function") inst.onLoad();
        yumiState.active[b.key] = true;
        if (b.guard) globalThis[b.guard] = true;
      } catch (e) {
        yumiNote(b.key, e);
        try { inst && typeof inst.onUnload === "function" && inst.onUnload(); } catch (e2) {}
        yumiState.active[b.key] = false;
        delete yumiState.instances[b.key];
        if (b.guard) globalThis[b.guard] = false;
      }
    });
  }

  var yumiCtl = null;
  function yumiCtlStore() {
    if (!yumiCtl) yumiCtl = wrapSync(createStorage(createMMKVBackend("YUMICORD_BUILTINS")));
    return yumiCtl;
  }
  // Settings page: YumiCord section -> "Built-in features". One switch per built-in (applies after restart)
  // and each built-in's own settings/diagnostics screen.
  function YumiBuiltinsPage() {
    var h = React.createElement;
    var RN = globalThis.vendetta?.metro?.common?.ReactNative;
    var openState = React.useState(null);
    var open = openState[0], setOpen = openState[1];
    var tickState = React.useState(0);
    var setTick = tickState[1];
    if (!RN) return null;
    var ctl = yumiCtlStore();
    var txt = { color: "#f2f3f5", fontSize: 16, fontWeight: "700" };
    var sub = { color: "#b5bac1", fontSize: 13, marginTop: 6 };
    var card = { backgroundColor: "#2b2d31", borderRadius: 12, padding: 16, marginBottom: 12 };
    var btn = function(label, onPress) {
      return h(RN.TouchableOpacity, {
        onPress: function() { try { onPress(); } catch (e) { yumiNote("page button", e); } },
        style: { backgroundColor: "#5865f2", borderRadius: 8, paddingVertical: 10, alignItems: "center", marginTop: 10 }
      }, h(RN.Text, { style: { color: "#ffffff", fontSize: 14, fontWeight: "600" } }, label));
    };
    if (open) {
      var inst = yumiState.instances[open];
      var S = inst && inst.settings;
      return h(RN.View, { style: { flex: 1 } },
        h(RN.View, { style: { padding: 12 } }, btn("\u2190 Wapas", function() { setOpen(null); })),
        S ? h(S, null) : h(RN.Text, { style: [sub, { padding: 16 }] }, "Is feature ki settings abhi available nahi (feature chal nahi raha).")
      );
    }
    var safe = false;
    try { safe = !!settings.safeMode?.enabled; } catch (e) {}
    return h(RN.ScrollView, { style: { flex: 1 }, contentContainerStyle: { padding: 16, paddingBottom: 60 } },
      h(RN.Text, { style: [sub, { marginBottom: 12 }] }, "Ye features YumiCord mein pehle se built-in hain, plugin install karne ki zarurat nahi. Switch badalne ke baad app restart karo."),
      safe ? h(RN.Text, { style: { color: "#f0b232", fontSize: 14, marginBottom: 12 } }, "Safe Mode ON hai, isliye built-in features abhi band hain.") : null,
      YUMI_BUILTINS.map(function(b) {
        var off = false;
        try { off = ctl["off:" + b.key] === true; } catch (e) {}
        var active = !!yumiState.active[b.key];
        var status = active ? "\u2705 Chal raha hai" : off ? "OFF (restart ke baad band)" : safe ? "Safe Mode mein band" : "\u274c Shuru nahi hua";
        if (active && off) status = "\u2705 Chal raha hai (restart ke baad OFF hoga)";
        if (!active && !off && !safe && yumiState.status !== "started") status = "Shuru ho raha hai\u2026";
        return h(RN.View, { key: b.key, style: card },
          h(RN.View, { style: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" } },
            h(RN.Text, { style: txt }, b.name),
            RN.Switch ? h(RN.Switch, {
              value: !off,
              onValueChange: function(v) {
                try { ctl["off:" + b.key] = !v; } catch (e) { yumiNote("switch", e); }
                setTick(function(x) { return x + 1; });
              }
            }) : null
          ),
          h(RN.Text, { style: sub }, status),
          active ? btn("Settings / Diagnostics", function() { setOpen(b.key); }) : null
        );
      }),
      yumiState.errors.length ? h(RN.Text, { style: [sub, { marginTop: 8 }] }, "Last error: " + String(yumiState.errors[0]).slice(0, 300)) : null,
      h(RN.Text, { style: [sub, { marginTop: 12 }] }, "Pre-installed plugins: " + yumiState.seed.status)
    );
  }
  function yumiStartBuiltins() {
    var ctl = yumiCtlStore();
    return awaitStorage(settings, ctl).then(function() {
      if (settings.safeMode?.enabled) {
        yumiState.status = "safe mode: built-ins off";
        return;
      }
      var chain = Promise.resolve();
      YUMI_BUILTINS.forEach(function(b) {
        chain = chain.then(function() {
          var off = false;
          try { off = ctl["off:" + b.key] === true; } catch (e) {}
          if (off) { yumiState.active[b.key] = false; return; }
          return yumiStartOne(b);
        }).catch(function(e) { yumiNote(b.key, e); });
      });
      return chain.then(function() { yumiState.status = "started"; });
    });
  }
  function yumiSetup() {
    try { globalThis.__yumicord = yumiState; } catch (e) {}
    try {
      var origEval = VdPluginManager.evalPlugin;
      VdPluginManager.evalPlugin = function(plugin) {
        var self = this;
        var go = function() {
          try {
            var b = yumiShadowOf(plugin && plugin.id);
            if (b && yumiState.active[b.key]) {
              // Same feature is built in and already running: the installed URL copy becomes a no-op
              // (so nothing shows twice); its settings page shows the built-in's screen.
              var inst = yumiState.instances[b.key] || {};
              return { onLoad: function() {}, onUnload: function() {}, settings: inst.settings };
            }
          } catch (e) { yumiNote("shadow", e); }
          return origEval.call(self, plugin);
        };
        var r = yumiState.ready;
        return r ? r.then(go, go) : go();
      };
    } catch (e) { yumiNote("evalPlugin wrap", e); }
    try {
      var started = yumiStartBuiltins().catch(function(e) { yumiNote("builtins", e); });
      var cap = new Promise(function(res) { setTimeout(res, 10000); });
      yumiState.ready = Promise.race([started, cap]).catch(function() {});
    } catch (e) {
      yumiNote("builtins setup", e);
      yumiState.ready = null;
    }
  }
  function yumiSeedPlugins() {
    var st = yumiState.seed;
    try {
      var store = wrapSync(createStorage(createMMKVBackend("YUMICORD_SEED")));
      return awaitStorage(store, plugins, settings).then(function() {
        if (settings.safeMode?.enabled) { st.status = "safe mode: skipped"; return; }
        if (store.version === YUMI_SEED.version && store.complete === true) { st.status = "already done (v" + YUMI_SEED.version + ")"; return; }
        st.status = "running";
        st.added = 0;
        st.skipped = 0;
        st.failed = 0;
        var names = {};
        try {
          Object.keys(plugins).forEach(function(k) {
            try {
              var n = plugins[k] && plugins[k].manifest && plugins[k].manifest.name;
              if (n) names[String(n).toLowerCase()] = 1;
            } catch (e) {}
          });
        } catch (e) {}
        var list = YUMI_SEED.plugins || [];
        var step = function(i) {
          if (i >= list.length) {
            try {
              store.version = YUMI_SEED.version;
              store.complete = st.failed === 0;
            } catch (e) {}
            st.status = "done: " + st.added + " added, " + st.skipped + " skipped, " + st.failed + " failed";
            return;
          }
          var item = list[i] || {};
          var id = String(item.id || "");
          if (id && !id.endsWith("/")) id += "/";
          var key = "d:" + id;
          try {
            if (!id || store[key]) return step(i + 1);
            if (id in plugins || item.name && names[String(item.name).toLowerCase()]) {
              // Already installed by the user (or same plugin from another URL): leave it exactly as it is.
              store[key] = 1;
              st.skipped++;
              return step(i + 1);
            }
          } catch (e) {
            yumiNote("seed check " + id, e);
            return step(i + 1);
          }
          return VdPluginManager.fetchPlugin(id).then(function() {
            try {
              // fetchPlugin keeps enabled=false for a new entry; make sure of it.
              if (plugins[id] && plugins[id].enabled && !store[key]) plugins[id].enabled = false;
              store[key] = 1;
              if (item.name) names[String(item.name).toLowerCase()] = 1;
              st.added++;
            } catch (e) { yumiNote("seed save " + id, e); }
          }, function(e) {
            st.failed++;
            yumiNote("seed fetch " + id, e);
          }).then(function() {
            return new Promise(function(res) { setTimeout(res, 150); });
          }).then(function() { return step(i + 1); });
        };
        return step(0);
      }).catch(function(e) { st.status = "error"; yumiNote("seed", e); });
    } catch (e) {
      st.status = "error";
      yumiNote("seed", e);
    }
  }
  // ---- end YumiCord v2.1 ----

  // src/index.ts
  var src_exports = {};
  __export(src_exports, {
    default: () => src_default
  });
  var src_default;
  var init_src = __esm({
    "src/index.ts"() {
      "use strict";
      init_asyncIteratorSymbol();
      init_promiseAllSettled();
      init_async_to_generator();
      init_patchErrorBoundary();
      init_fixes();
      init_i18n();
      init_settings3();
      init_api3();
      init_plugins();
      init_fonts();
      init_plugins4();
      init_themes();
      init_commands();
      init_debug();
      init_flux();
      init_jsx();
      init_logger();
      init_settings2();
      init_lib();
      src_default = () => _async_to_generator(function* () {
        yield Promise.all([
          initThemes(),
          injectFluxInterceptor(),
          patchSettings(),
          patchCommands(),
          patchJsx(),
          initVendettaObject(),
          initFetchI18nStrings(),
          initSettings(),
          fixes_default(),
          patchErrorBoundary(),
          updatePlugins()
        ]).then(
          // Push them all to unloader
          (u) => u.forEach((f) => f && unload.push(f))
        );
        globalThis.bunny = lib_exports;
        initDebugger();
        try {
          yumiSetup();
        } catch (e) {
        }
        VdPluginManager.initPlugins().then((u) => unload.push(u)).catch(() => alert("Failed to initialize plugins")).then(() => {
          try {
            setTimeout(yumiSeedPlugins, 12e3);
          } catch (e) {
          }
        });
        initPlugins();
        updateFonts();
        logger.log("YumiCord is ready!");
      })();
    }
  });

  // src/entry.ts
  init_asyncIteratorSymbol();
  init_promiseAllSettled();
  init_async_to_generator();
  var { instead: instead3 } = require_cjs();
  globalThis.window = globalThis;
  function initializeRevenge() {
    return _async_to_generator(function* () {
      try {
        Object.freeze = Object.seal = Object;
        yield (init_caches(), __toCommonJS(caches_exports)).initMetroCache();
        yield (init_src(), __toCommonJS(src_exports)).default();
      } catch (e) {
        var { ClientInfoManager } = (init_modules(), __toCommonJS(modules_exports));
        var stack = e instanceof Error ? e.stack : void 0;
        console.log(stack ?? e?.toString?.() ?? e);
        alert([
          "Failed to load YumiCord!\n",
          `Build Number: ${ClientInfoManager.getConstants().Build}`,
          `YumiCord: ${"577c7f2-main"}`,
          stack || e?.toString?.()
        ].join("\n"));
      }
    })();
  }
  if (typeof globalThis.__r === "undefined") {
    deferredCalls = [];
    unpatches = [];
    deferMethodExecution = (object, method, condition, resume, returnWith) => {
      var restore = instead3(method, object, function(args, original) {
        if (!condition || condition(...args)) {
          var queue = {
            object,
            method,
            args,
            resume
          };
          deferredCalls.push(queue);
          return returnWith ? returnWith(queue) : void 0;
        }
        return original.apply(this, args);
      });
      unpatches.push(restore);
    };
    resumeDeferred = () => {
      for (var queue of deferredCalls) {
        var { object, method, args, resume } = queue;
        if (resume) {
          resume(queue);
        } else {
          object[method](...args);
        }
      }
      deferredCalls.length = 0;
    };
    onceIndexRequired = (originalRequire) => {
      if (globalThis.__fbBatchedBridge) {
        var batchedBridge = globalThis.__fbBatchedBridge;
        deferMethodExecution(
          batchedBridge,
          "callFunctionReturnFlushedQueue",
          // If the call is to AppRegistry, we want to defer it because it is not yet registered (YumiCord delays it)
          // Same goes to the non-callable modules, which are not registered yet, so we ensure that only registered ones can get through
          (...args) => args[0] === "AppRegistry" || !batchedBridge.getCallableModule(args[0]),
          ({ args }) => {
            if (batchedBridge.getCallableModule(args[0])) {
              batchedBridge.__callFunction(...args);
            }
          },
          () => batchedBridge.flushedQueue()
        );
      }
      if (globalThis.RN$AppRegistry) {
        deferMethodExecution(globalThis.RN$AppRegistry, "runApplication");
      }
      var startDiscord = () => _async_to_generator(function* () {
        yield initializeRevenge();
        for (var unpatch of unpatches)
          unpatch();
        unpatches.length = 0;
        originalRequire(0);
        resumeDeferred();
      })();
      startDiscord();
    };
    Object.defineProperties(globalThis, {
      __r: {
        configurable: true,
        get: () => _requireFunc,
        set(v2) {
          _requireFunc = function patchedRequire(a) {
            if (a === 0) {
              if (globalThis.modules instanceof Map)
                globalThis.modules = Object.fromEntries(globalThis.modules);
              onceIndexRequired(v2);
              _requireFunc = v2;
            } else
              return v2(a);
          };
        }
      },
      __d: {
        configurable: true,
        get() {
          if (globalThis.Object && !globalThis.modules) {
            globalThis.modules = globalThis.__c?.();
          }
          return this.value;
        },
        set(v2) {
          this.value = v2;
        }
      }
    });
  } else {
    initializeRevenge();
  }
  var _requireFunc;
  var deferredCalls;
  var unpatches;
  var deferMethodExecution;
  var resumeDeferred;
  var onceIndexRequired;
})();
//# sourceURL=revenge
