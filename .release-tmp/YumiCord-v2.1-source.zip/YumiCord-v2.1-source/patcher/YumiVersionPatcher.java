
import pxb.android.axml.*;
import java.nio.file.*;

public class YumiVersionPatcher {
    public static void main(String[] a) throws Exception {
        byte[] in = Files.readAllBytes(Paths.get(a[0]));
        final int code = Integer.parseInt(a[2]);
        final String name = a[3];
        AxmlReader r = new AxmlReader(in);
        AxmlWriter w = new AxmlWriter();
        r.accept(new AxmlVisitor(w) {
            public NodeVisitor child(String ns, String n) {
                NodeVisitor nv = super.child(ns, n);
                if (!n.equals("manifest")) return nv;
                return new NodeVisitor(nv) {
                    public void attr(String ns2, String an, int rid, int t, Object v) {
                        if (an.equals("versionCode")) { System.out.println("versionCode " + v + " -> " + code); super.attr(ns2, an, rid, 0x10, code); }
                        else if (an.equals("versionName")) { System.out.println("versionName " + v + " -> " + name); super.attr(ns2, an, rid, 0x03, name); }
                        else super.attr(ns2, an, rid, t, v);
                    }
                };
            }
        });
        Files.write(Paths.get(a[1]), w.toByteArray());
    }
}
