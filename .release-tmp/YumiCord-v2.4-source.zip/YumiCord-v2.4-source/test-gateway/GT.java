import com.yumicord.rpc.YumiGateway;
public class GT { public static void main(String[] a) throws Exception {
  YumiGateway g = new YumiGateway("x".repeat(60), (s,d)->System.out.println("STATE "+s+" "+d));
  g.setPresence("{\"since\":null,\"activities\":[{\"name\":\"Free Fire\",\"type\":0}],\"status\":\"online\",\"afk\":false}");
  g.start(); Thread.sleep(8000); System.out.println("close code "+g.lastCloseCode+" ready="+g.isReady()); System.exit(0);
}}
