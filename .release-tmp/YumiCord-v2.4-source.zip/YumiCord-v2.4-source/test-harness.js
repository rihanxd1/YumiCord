
const fs=require('fs');
global.globalThis.window=globalThis;
const files={}; let writes=0;
function createMMKVBackend(name){ return {get:async()=>files[name]?JSON.parse(files[name]):{}, set:async(d)=>{writes++; files[name]=JSON.stringify(d);} }; }
const syncAwaitSymbol=Symbol('sa');
function createStorage(b){ return b.get().then(d=>{ return new Proxy(d,{set(t,p,v){t[p]=v; b.set(t); return true;}, deleteProperty(t,p){delete t[p]; b.set(t); return true;}}); }); }
function wrapSync(store){ let aw; const q=[]; store.then(v=>{aw=v; q.forEach(c=>c());}); return new Proxy({}, {get(t,p){ if(p===syncAwaitSymbol) return cb=>aw?cb():q.push(cb); return Reflect.get(aw??t,p);}, set(t,p,v){return Reflect.set(aw??t,p,v);}, has(t,p){return Reflect.has(aw??t,p);}, ownKeys(t){return Reflect.ownKeys(aw??t);}, getOwnPropertyDescriptor(t,p){return Reflect.getOwnPropertyDescriptor(aw??t,p);}, deleteProperty(t,p){return Reflect.deleteProperty(aw??t,p);} }); }
function awaitStorage(...s){ return Promise.all(s.map(x=>new Promise(r=>x[syncAwaitSymbol](r)))); }
function LoggerClass(n){ this.log=()=>{}; this.error=(...a)=>console.log('LOGERR',n,...a); this.info=()=>{}; this.warn=()=>{}; }
const settings = wrapSync(Promise.resolve({safeMode:{enabled: !!process.env.SAFE}}));
files.VENDETTA_PLUGINS = JSON.stringify(JSON.parse(process.env.PRE||'{}'));
const plugins = wrapSync(createStorage(createMMKVBackend("VENDETTA_PLUGINS")));
let fetchCount=0; const failIds=(process.env.FAIL||'').split(',');
const VdPluginManager={
  fetchPlugin(id){ fetchCount++; return new Promise((res,rej)=>setTimeout(()=>{ if(failIds.some(f=>f&&id.includes(f))) return rej(new Error('net')); const ex=plugins[id]; plugins[id]={id,manifest:{name:'M'+id,hash:'h'},enabled:ex?.enabled??false,update:true,js:'x'}; res(); },1)); },
  evalPlugin(p){ return Promise.resolve({onLoad(){ global.urlLoaded=(global.urlLoaded||0)+1; }, settings:'URLSETTINGS'}); }
};
// mock vendetta for badges plugin
const R={createElement:(...a)=>({a}), Component:function(){}, useState:(v)=>[v,()=>{}], useEffect:()=>{}, useReducer:()=>[0,()=>{}]};
globalThis.vendetta={ metro:{ common:{React:R, ReactNative:{View:'View',Text:'Text',ScrollView:'SV'}, toasts:{showToast(){}}, }, findByProps:()=>null, findByName:()=>null, findByStoreName:()=>({getCurrentUser:()=>({id:'1'})}), findByPropsAll:()=>[], find:()=>null, findAll:()=>[] }, patcher:{after:()=>()=>{}, before:()=>()=>{}, instead:()=>()=>{}}, ui:{toasts:{showToast(){}}, assets:{getAssetIDByName:()=>1}}, ui2:{}, storage:{useProxy:x=>x}, plugin:null };
globalThis.fetch=async()=>({ok:true,json:async()=>({badges:{"1":{name:"A",icon:"x.png"}},users:{"5":[1]}}),text:async()=>""});
const _setTimeout=setTimeout; global.setTimeout=(f,ms)=>_setTimeout(f, Math.min(ms,5));
global.setInterval=()=>0;

  // ---- YumiCord v2.1/v2.2/v2.3: built-in features + pre-installed (disabled) plugins ----
  // Built-ins run at startup like a plugin would (same vendetta API), wrapped so a failure can never stop the app.
  // The seed list below only puts plugin URLs into the Plugins page, DISABLED. Plugin code is fetched from its own
  // proxy URL, unmodified; nothing is ever enabled automatically and nothing the user installed/removed is touched.
  var YUMI_SEED = {
    "version": 1,
    "note": "YumiCord v2.1 pre-installed plugins (added DISABLED). Edit this list to change them; bump version to re-run for new entries.",
    "plugins": [
      {
        "id": "https://vd-plugins.github.io/proxy/meqativ.github.io/dumsane/NoDelete/",
        "name": "NoDelete",
        "hi": "Koi message delete kare to bhi tumhe dikhta rahega"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/redstonekasi.github.io/vendetta-plugins/message-logger/",
        "name": "Message Logger",
        "hi": "Delete/edit hue messages ka record rakhta hai (app restart tak)"
      },
      {
        "id": "https://bn-plugins.github.io/vd-proxy/rico040.github.io/bunny-plugins/freemoji/",
        "name": "Freemoji",
        "hi": "Bina Nitro ke Nitro wale emoji use karo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/aliernfrog.github.io/vd-plugins/FreeStickers/",
        "name": "FreeStickers",
        "hi": "Bina Nitro ke stickers bhejo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/fierdetta.github.io/stealmoji/",
        "name": "Stealmoji",
        "hi": "Kisi bhi emoji ko copy karke apne server mein daal lo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/c10udburst-discord.github.io/vendetta-plugins/hidden-channels/",
        "name": "Hidden channels",
        "hi": "Jo channel lock hain unka naam aur description dikhata hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/aeongdesu.github.io/vdplugins/Dislate/",
        "name": "Dislate Lite",
        "hi": "Message ko kisi bhi language mein translate karo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/vendetta.nexpid.xyz/better-timestamps/",
        "name": "BetterTimestamps",
        "hi": "Time/date ko Discord ke smart timestamp mein badalta hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/redstonekasi.github.io/vendetta-plugins/no-typing/",
        "name": "No typing",
        "hi": "Tum type kar rahe ho ye dusron ko nahi dikhega"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/amsyarasyiq.github.io/letup/NoIdle/",
        "name": "NoIdle",
        "hi": "App background mein ho to bhi status Idle nahi hoga"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/martinz64.github.io/vendetta-plugins/NoCompression/",
        "name": "NoCompression",
        "hi": "Photo/file bhejte waqt quality kam nahi hogi"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/redstonekasi.github.io/vendetta-plugins/picture-links/",
        "name": "Picture Links",
        "hi": "Profile photo aur banner pe tap karke full size kholo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/twnlink.github.io/vendetta-plugins/FreeProfileColors/",
        "name": "Free Profile Colors",
        "hi": "Bina Nitro ke profile colors lagao (dusre plugin users ko dikhte hain)"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/decor-discord.github.io/vendetta-plugin/",
        "name": "Decor",
        "hi": "Apni custom avatar decoration banao aur lagao"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/fres621.github.io/vendetta-plugins/SpotifyPreview/",
        "name": "SpotifyPreview",
        "hi": "Spotify gaane ka 30 second preview chat mein hi suno"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/vendetta.nexpid.xyz/song-spotlight/",
        "name": "SongSpotlight",
        "hi": "Apni profile pe gaane pin karo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/vendetta.nexpid.xyz/local-pins/",
        "name": "LocalPins",
        "hi": "Message ko sirf apne liye pin karo"
      },
      {
        "id": "https://bn-plugins.github.io/vd-proxy/castdrian.github.io/discord-plugins/FavoriteGifs/",
        "name": "FavoriteGifs",
        "hi": "GIF ko favourite / unfavourite karo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/vendetta.nexpid.xyz/clean-urls/",
        "name": "CleanURLs",
        "hi": "Links se tracking wala kachra hata deta hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/maisymoe.github.io/strife/NoTrack/",
        "name": "NoTrack",
        "hi": "Discord ki tracking band karta hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/aeongdesu.github.io/vdplugins/ViewRaw/",
        "name": "ViewRaw",
        "hi": "Message ka raw data dekho aur copy karo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/fres621.github.io/vendetta-plugins/LastMessage/",
        "name": "LastMessageDate",
        "hi": "Dekho kisi ne last message kab bheja tha"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/aeongdesu.github.io/vdplugins/FirstMessage/",
        "name": "FirstMessage",
        "hi": "/firstmessage se channel ke pehle message pe jao"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/actuallythesun.github.io/vendetta-plugins/QuickDelete/",
        "name": "QuickDelete",
        "hi": "Message delete karte waqt 'Are you sure' wala popup nahi aayega"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/fres621.github.io/vendetta-plugins/AlwaysTrust/",
        "name": "AlwaysTrust",
        "hi": "Link kholte waqt 'untrusted link' wala popup hata deta hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/actuallythesun.github.io/vendetta-plugins/SplitLargeMessages/",
        "name": "SplitLargeMessages",
        "hi": "2000 se lambe message apne aap tukdon mein bhej deta hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/redstonekasi.github.io/vendetta-plugins/audiofix/",
        "name": "Blueooth Audio Fix",
        "hi": "Bluetooth headphone pe call/audio ki quality theek karta hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/meqativ.github.io/dumsane/NoBandwidthKick/",
        "name": "NoBandwidthKick",
        "hi": "VC mein akele hone pe kick nahi hoga"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/fierdetta.github.io/typing-avatars/",
        "name": "Typing Avatars",
        "hi": "Kaun type kar raha hai uski photo dikhata hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/cynosphere.github.io/VendettaPlugins/AlwaysAnimate/",
        "name": "Always Animate",
        "hi": "Animated avatar aur server icon hamesha chalte rahenge"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/maisymoe.github.io/strife/Experiments/",
        "name": "Experiments",
        "hi": "Discord ke developer / experiment wale features kholta hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/vendetta.nexpid.xyz/hide-servers/",
        "name": "HideServers",
        "hi": "Server list se server chhupa do (sirf tumhare liye)"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/vendetta.nexpid.xyz/char-counter/",
        "name": "CharCounter",
        "hi": "Chat box ke upar character count dikhata hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/github.com/acquitelol/vd-pronoun-db/releases/latest/download/",
        "name": "PronounDB",
        "hi": "Logon ke pronouns tag ke roop mein dikhata hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/github.com/acquitelol/better-chat-gestures/releases/latest/download/",
        "name": "BetterChatGestures",
        "hi": "Chat mein naye gestures (double tap se reply/edit, etc.)"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/vendicated.github.io/its-called-vendetta-cause-its-owned-by-ven-plugins/ClickableBioLinks/",
        "name": "BetterBios",
        "hi": "Bio ka text select / copy kar sakte ho, links click hote hain"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/fres621.github.io/vendetta-plugins/BetterSearch/",
        "name": "BetterSearch",
        "hi": "Message search ko behtar banata hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/cynosphere.github.io/VendettaPlugins/ChatboxAvatar/",
        "name": "Chatbox Avatar",
        "hi": "Chat box se jaldi apni profile kholo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/martinz64.github.io/vendetta-plugins/CopyRoleColor/",
        "name": "CopyRoleColor",
        "hi": "Role pe long press karke uska color code copy karo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/c10udburst-discord.github.io/vendetta-plugins/delete-embeds/",
        "name": "Delete embeds",
        "hi": "Message ka link preview (embed) hata do"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/ryan-0324.github.io/vendetta-plugins/FakeProfileThemesAndEffects/",
        "name": "FakeProfileThemesAndEffects",
        "hi": "Profile theme aur effects bina Nitro (plugin users ko dikhte hain)"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/fres621.github.io/vendetta-plugins/FileContentPreview/",
        "name": "FileContentPreview",
        "hi": "Text file ko download kiye bina andar ka content dekho"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/martinz64.github.io/vendetta-plugins/FileSizeOnPicker/",
        "name": "FileSizeOnPicker",
        "hi": "File chunte waqt uska size dikhata hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/dziurwa14.github.io/vendetta-plugins/Freecons/",
        "name": "Freecons",
        "hi": "Nitro wale app icons free mein"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/nikosszzz.github.io/vd-plugins/friendInvites/",
        "name": "FriendInvites",
        "hi": "Friend add karne wala invite link banao"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/janisslsm.github.io/vdplugins/HideCallButtons/",
        "name": "Hide call buttons",
        "hi": "DM aur profile se call wale buttons chhupao"
      },
      {
        "id": "https://bn-plugins.github.io/vd-proxy/rico040.github.io/bunny-plugins/hideappbutton/",
        "name": "HideAppButton",
        "hi": "Chat box se Apps button hatao"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/zykrah.github.io/vendetta-plugins/HideBlockedMessages/",
        "name": "HideBlockedMessages",
        "hi": "Blocked logon ke messages bilkul chhupa do"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/amsyarasyiq.github.io/letup/HideGiftButton/",
        "name": "HideGiftButton",
        "hi": "Chat box se Gift button hatao"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/mystravil.github.io/vendetta-plugins/HideMessages/",
        "name": "HideMessages",
        "hi": "Koi bhi message sirf apne liye chhupao"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/amsyarasyiq.github.io/letup/HoldGIFSend/",
        "name": "HoldGIFSend",
        "hi": "GIF turant send nahi hogi, pehle chat box mein aayegi"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/redstonekasi.github.io/vendetta-plugins/saucenao/",
        "name": "Image search",
        "hi": "Photo ko Google/Yandex etc. pe reverse search karo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/aliernfrog.github.io/vd-plugins/JumpTo/",
        "name": "JumpTo",
        "hi": "Reply wale message ya channel ki shuruaat pe jao"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/amsyarasyiq.github.io/letup/Last.fm/",
        "name": "Last.fm",
        "hi": "Apna Last.fm gaana status mein dikhao"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/vendetta.nexpid.xyz/message-preview/",
        "name": "MessagePreview",
        "hi": "Bhejne se pehle message ka preview dekho"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/vendetta.nexpid.xyz/monet-theme/",
        "name": "MonetTheme",
        "hi": "Phone ke wallpaper ke rang se theme banao (Material You)"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/aeongdesu.github.io/vdplugins/ClientThemes/",
        "name": "ClientThemes",
        "hi": "Themes ko startup ke baad sahi se load karta hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/amsyarasyiq.github.io/letup/MoreConfirm/",
        "name": "MoreConfirm",
        "hi": "Zaroori kaam (jaise leave server) se pehle confirm poochta hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/carince.github.io/VendettaPlugins/muteNewGuilds/",
        "name": "Mute New Guilds",
        "hi": "Naye join kiye server apne aap mute"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/redstonekasi.github.io/vendetta-plugins/no-embed-copy/",
        "name": "No Embed Copy",
        "hi": "Embed pe tap karne se text copy nahi hoga"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/amsyarasyiq.github.io/letup/NoAutoReplyMention/",
        "name": "NoAutoReplyMention",
        "hi": "Reply karte waqt mention (@) apne aap OFF"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/maisymoe.github.io/strife/PinSettings/",
        "name": "PinSettings",
        "hi": "Plugin settings ko User Settings mein pin karo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/vendetta.nexpid.xyz/plugin-browser/",
        "name": "Plugin Browser",
        "hi": "Saare plugins ki list browse karo aur install karo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/redstonekasi.github.io/vendetta-plugins/realmoji/",
        "name": "Realmoji",
        "hi": "Freemoji wale link ko asli emoji jaisa dikhata hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/cynosphere.github.io/VendettaPlugins/ShowImageLinks/",
        "name": "Show Image Links",
        "hi": "Sirf photo link wale message mein link bhi dikhata hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/cynosphere.github.io/VendettaPlugins/ShowTag/",
        "name": "Show Tag",
        "hi": "Naam ke saath poora username/tag dikhata hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/kitomanari.github.io/vendetta-stuff/spotifyShareCommands/",
        "name": "Spotify Share Commands",
        "hi": "Commands se apna Spotify gaana share karo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/fierdetta.github.io/staff-tags/",
        "name": "Staff Tags",
        "hi": "Server staff (admin/mod) ke naam pe tag dikhata hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/aeongdesu.github.io/vdplugins/StickerUtils/",
        "name": "StickerUtils",
        "hi": "Sticker save / copy karne ke options"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/cynosphere.github.io/VendettaPlugins/TabletMode/",
        "name": "Tablet Mode",
        "hi": "Tablet wala layout ON/OFF"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/vendetta.nexpid.xyz/tenor-gif-fix/",
        "name": "TenorGifFix",
        "hi": "Tenor link ko asli GIF ki tarah share/download karo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/fierdetta.github.io/text-replace/",
        "name": "Text Replace",
        "hi": "Apne words apne aap replace karo (shortcuts)"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/vendetta.nexpid.xyz/twemoji-everywhere/",
        "name": "TwemojiEverywhere",
        "hi": "Har jagah Discord wale emoji dikhata hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/vendetta.nexpid.xyz/use-system-emoji/",
        "name": "UseSystemEmoji",
        "hi": "Messages mein phone ke apne emoji dikhata hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/vendetta.nexpid.xyz/usrpfp/",
        "name": "USRPFP",
        "hi": "Custom animated profile photo (USRPFP) dikhata hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/aeongdesu.github.io/vdplugins/UserBG/",
        "name": "UserBG",
        "hi": "Custom profile banner (USRBG) dikhata hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/aeongdesu.github.io/vdplugins/UtilCommands/",
        "name": "UtilCommands",
        "hi": "Kaam ke commands (/plugins, /debug etc.)"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/dziurwa14.github.io/vendetta-plugins/customVoiceMessages/",
        "name": "Custom Voice Messages",
        "hi": "Koi bhi audio file voice message ki tarah bhejo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/fres621.github.io/vendetta-plugins/AltMediaPicker/",
        "name": "AltMediaPicker",
        "hi": "File bhejne ke liye dusra media picker"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/maisymoe.github.io/strife/AnonymousFileNames/",
        "name": "AnonymousFileNames",
        "hi": "Upload karne se pehle file ka naam random kar deta hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/kitomanari.github.io/vendetta-stuff/addonList/",
        "name": "Addon List",
        "hi": "Commands se apni plugin/theme list share karo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/aeongdesu.github.io/vdplugins/SlowmodeExtended/",
        "name": "SlowmodeExtended",
        "hi": "Slowmode ke zyada options"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/c10udburst-discord.github.io/vendetta-plugins/create-webhooks/",
        "name": "Create webhooks",
        "hi": "Webhook settings se naye webhook banao"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/mugman174.github.io/vendetta-plugins/sysinfo/",
        "name": "System Info",
        "hi": "/sysinfo se phone ki details bhejo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/mugman.catvibers.me/vendetta-plugins/urban/",
        "name": "Urban Dictionary",
        "hi": "Urban Dictionary se kisi word ka matlab dekho"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/cynosphere.github.io/VendettaPlugins/Pastelize/",
        "name": "Pastelize",
        "hi": "Bina color wale naam ko pastel rang deta hai"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/plugins.obamabot.me/vendetta-plugins/petpet/",
        "name": "petPet",
        "hi": "Kisi ki photo pe pet-pet GIF banao"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/exhq.github.io/vendetta/uwuify/",
        "name": "uwuify",
        "hi": "Apne message ko uwu style mein badlo"
      },
      {
        "id": "https://vd-plugins.github.io/proxy/jdev082.github.io/vd-repo2/CatFacts/",
        "name": "CatFacts",
        "hi": "/catfact se random billi fact"
      }
    ]
  };
  var YUMI_BUILTINS = [
    {
      key: "badges", name: "YumiCord Badges", version: "2.0.0", icon: "ic_badge_staff",
      shadow: "yumicord-badges.sites.tab.bot", guard: "__ycBadgesActive",
      // Evaluated exactly the way the loader evaluates an installed plugin (indirect eval, same "vendetta" object shape).
      factory: function(vendettaApi) {
        return (0, eval)("vendetta=>{return " + "(function () {\n  \"use strict\";\n  /*\n   * YumiCord Badges v2.0.0\n   * Shows custom YumiCord badges on user profiles. Badge list: https://yumicord-badges.sites.tab.bot/badges.json\n   * (edited from https://yumicord-badges.sites.tab.bot/admin).\n   *\n   * v2.0.0: crash-safe. Every patch, fetch, timer and the settings screen is wrapped so a failure can never\n   * crash Discord; failures are recorded and shown on the plugin's settings (diagnostics) screen.\n   *\n   * Credits: the badge patching approach (patch Discord's useBadges hook, then fix up the rendered badge\n   * element) comes from Revenge's built-in Badges plugin by pylixonly (revenge-mod/revenge-bundle,\n   * BSD-3-Clause) and Kettu's Badges plugin by cocobo1 (C0C0B01/Kettu, BSD-3-Clause).\n   * Emoji images: Twemoji (jdecked/twemoji), CC-BY 4.0.\n   *\n   * Discord 350.8 (Hermes bytecode) facts this relies on:\n   *  - useBadges(displayProfile) returns [{id, description, icon, ...}] (the \"classic\" list).\n   *  - ProfileBadgeRows({userId, badges, catalogBadges, ...}) renders each classic badge as ProfileBadge with\n   *    source {uri: getProfileBadgeIconUrl(b)}, getProfileBadgeIconUrl(b) = b.iconSrc ?? cdn(b.icon).\n   *  - With Discord's NEW badge system (badge management) on, ProfileBadgeRows renders catalogBadges when they\n   *    are not null and skips the classic list. For users that have YumiCord badges we pass catalogBadges as\n   *    undefined, so the classic list (Discord's badges + ours) renders there, in the full profile, the profile\n   *    sheet and the Edit Profile preview alike.\n   */\n  var SITE = \"https://yumicord-badges.sites.tab.bot/\";\n  var DATA_URL = SITE + \"badges.json\";\n  var VERSION = \"2.0.0\";\n  var REFRESH_MS = 5 * 60 * 1000;\n  var PROFILE_REFRESH_MS = 60 * 1000;\n  var ID_PREFIX = \"yumicord-\";\n\n  var diag = {\n    version: VERSION,\n    loadedAt: 0,\n    useBadges: \"not tried\",\n    rows: \"not tried\",\n    badgeFix: \"not tried\",\n    rowsSeen: 0,\n    rowsChanged: 0,\n    hookCalls: 0,\n    hookAdded: 0,\n    errors: []\n  };\n  var state = { data: null, version: 0, lastTry: 0, lastOk: 0, error: null, fetching: false };\n  var elementProps = {};\n  var memo = typeof WeakMap === \"function\" ? new WeakMap() : null;\n  var unpatches = [];\n  var timer = null;\n  var listeners = [];\n\n  var vd = null, metro = null, patcher = null, React = null, RN = null, storage = {}, log = null;\n\n  function note(where, e) {\n    try {\n      var msg = where + \": \" + String((e && (e.message || e)) || e);\n      diag.errors.unshift(new Date().toLocaleTimeString() + \"  \" + msg);\n      if (diag.errors.length > 8) diag.errors.length = 8;\n      try { log && log.error && log.error(\"YumiCord Badges \" + msg); } catch (x) {}\n      notify();\n    } catch (x) {}\n  }\n  function notify() {\n    for (var i = 0; i < listeners.length; i++) { try { listeners[i](); } catch (e) {} }\n  }\n\n  try {\n    vd = vendetta;\n    metro = vd.metro;\n    patcher = vd.patcher;\n    React = metro.common.React;\n    RN = metro.common.ReactNative;\n    storage = (vd.plugin && vd.plugin.storage) || {};\n    log = vd.logger || null;\n  } catch (e) { note(\"init\", e); }\n\n  function sget(k, d) { try { var v = storage[k]; return v === undefined ? d : v; } catch (e) { return d; } }\n  function sset(k, v) { try { storage[k] = v; } catch (e) {} }\n\n  function emojiToTwemoji(emoji) {\n    var cps = [];\n    var hasZwj = emoji.indexOf(\"\\u200d\") !== -1;\n    for (var i = 0; i < emoji.length; i++) {\n      var c = emoji.charCodeAt(i);\n      if (c >= 0xd800 && c <= 0xdbff && i + 1 < emoji.length) {\n        var d = emoji.charCodeAt(i + 1);\n        c = (c - 0xd800) * 0x400 + (d - 0xdc00) + 0x10000;\n        i++;\n      }\n      if (c === 0xfe0f && !hasZwj) continue;\n      cps.push(c.toString(16));\n    }\n    return \"https://cdn.jsdelivr.net/gh/jdecked/twemoji@15.1.0/assets/72x72/\" + cps.join(\"-\") + \".png\";\n  }\n\n  // Always returns an absolute https URL (or null).\n  function iconUrl(icon) {\n    if (!icon || typeof icon !== \"string\") return null;\n    icon = icon.trim();\n    if (/^https?:\\/\\//i.test(icon)) return icon;\n    if (/^\\/\\//.test(icon)) return \"https:\" + icon;\n    var m = /^<a?:\\w+:(\\d+)>$/.exec(icon);\n    if (m) return \"https://cdn.discordapp.com/emojis/\" + m[1] + \".png?size=64\";\n    if (/\\.(png|jpe?g|webp|gif)(\\?.*)?$/i.test(icon) || icon.indexOf(\"/\") !== -1) return SITE + icon.replace(/^\\.?\\/+/, \"\");\n    return emojiToTwemoji(icon);\n  }\n\n  // {badges:{\"1\":{name,icon}}, users:{\"<id>\":[1,5]}} -> lookup table\n  function normalise(raw) {\n    var out = { defs: {}, users: {} };\n    if (!raw || typeof raw !== \"object\") return out;\n    var defs = raw.badges || {};\n    Object.keys(defs).forEach(function (k) {\n      var b = defs[k] || {};\n      var url = iconUrl(b.image || b.icon) || (b.emoji ? emojiToTwemoji(String(b.emoji)) : null);\n      if (url && b.name) out.defs[String(k)] = { name: String(b.name), url: url };\n    });\n    var users = raw.users || {};\n    Object.keys(users).forEach(function (uid) {\n      var list = users[uid];\n      if (!Array.isArray(list)) return;\n      var clean = [];\n      list.forEach(function (n) {\n        n = String(n);\n        if (out.defs[n] && clean.indexOf(n) === -1) clean.push(n);\n      });\n      if (clean.length) out.users[String(uid).trim()] = clean;\n    });\n    return out;\n  }\n\n  function setData(raw) {\n    state.data = normalise(raw);\n    state.version++;\n    elementProps = {};\n    notify();\n  }\n\n  function doFetch(url) {\n    return fetch(url, { cache: \"no-store\", headers: { \"cache-control\": \"no-cache\" } }).then(function (r) {\n      if (!r.ok) throw new Error(\"HTTP \" + r.status);\n      return r.json();\n    });\n  }\n\n  function refresh(force) {\n    try {\n      var now = Date.now();\n      if (state.fetching) return;\n      if (!force && now - state.lastTry < 10 * 1000) return;\n      state.fetching = true;\n      state.lastTry = now;\n      notify();\n      doFetch(DATA_URL + \"?t=\" + now)\n        .then(function (raw) {\n          state.fetching = false;\n          state.error = null;\n          state.lastOk = Date.now();\n          sset(\"cache\", raw);\n          sset(\"lastOk\", state.lastOk);\n          setData(raw);\n        })\n        .catch(function (e) {\n          state.fetching = false;\n          state.error = String((e && e.message) || e);\n          note(\"download\", e);\n          if (!state.data) {\n            doFetch(SITE + \"badges.static.json\").then(function (raw) { if (raw && !state.data) setData(raw); }).catch(function () {});\n          }\n        });\n    } catch (e) {\n      state.fetching = false;\n      note(\"refresh\", e);\n    }\n  }\n\n  function badgesFor(userId) {\n    var d = state.data;\n    if (!d || !userId) return [];\n    var list = d.users[String(userId)];\n    if (!list) return [];\n    var out = [];\n    list.forEach(function (n) {\n      var def = d.defs[n];\n      if (!def) return;\n      var id = ID_PREFIX + userId + \"-\" + n;\n      elementProps[id] = { source: { uri: def.url }, label: def.name };\n      out.push({ id: id, description: def.name, icon: \"yumicord\", iconSrc: def.url });\n    });\n    return out;\n  }\n\n  function withOurs(userId, base) {\n    var mine = badgesFor(userId);\n    if (!mine.length) return null;\n    var rest = (Array.isArray(base) ? base : []).filter(function (b) {\n      return !(b && typeof b.id === \"string\" && b.id.indexOf(ID_PREFIX) === 0);\n    });\n    return mine.concat(rest);\n  }\n\n  function myId() {\n    try {\n      var US = metro.findByStoreName && metro.findByStoreName(\"UserStore\");\n      var u = US && US.getCurrentUser && US.getCurrentUser();\n      return u && u.id ? String(u.id) : null;\n    } catch (e) { return null; }\n  }\n\n  // 1) classic badge list\n  function patchUseBadges() {\n    try {\n      var mod = null;\n      try { mod = metro.findByName(\"useBadges\", false); } catch (e) {}\n      if (!mod || typeof mod.default !== \"function\") {\n        diag.useBadges = \"NOT FOUND\";\n        return;\n      }\n      unpatches.push(patcher.after(\"default\", mod, function (args, ret) {\n        try {\n          diag.hookCalls++;\n          var user = args && args[0];\n          var userId = user && (user.userId || (user.user && user.user.id));\n          if (!userId) return;\n          userId = String(userId);\n          if (Date.now() - state.lastTry > PROFILE_REFRESH_MS) refresh(false);\n          var sig = state.version + \":\" + userId;\n          var cached = memo && Array.isArray(ret) ? memo.get(ret) : null;\n          if (cached && cached.sig === sig) return cached.arr;\n          var arr = withOurs(userId, ret);\n          if (!arr) return;\n          diag.hookAdded++;\n          if (memo && Array.isArray(ret)) memo.set(ret, { sig: sig, arr: arr });\n          return arr;\n        } catch (e) { note(\"useBadges patch\", e); }\n      }));\n      diag.useBadges = \"OK\";\n    } catch (e) {\n      diag.useBadges = \"FAILED\";\n      note(\"useBadges\", e);\n    }\n  }\n\n  // 2) new badge system + image fix-up, on element creation\n  function patchJsx() {\n    try {\n      var rt = metro.findByProps(\"jsx\", \"jsxs\");\n      if (!rt) { diag.rows = diag.badgeFix = \"NOT FOUND\"; return; }\n      var rowsMemo = memo ? new WeakMap() : null;\n      var before = function (args) {\n        try {\n          var p = args[1];\n          // ProfileBadgeRows-shaped props: {userId, badges, catalogBadges, ...}\n          if (!p || typeof p !== \"object\" || !(\"catalogBadges\" in p) || !p.userId) return;\n          diag.rowsSeen++;\n          var uid = String(p.userId);\n          if (!state.data || !state.data.users[uid]) return;\n          var sig = state.version + \":\" + uid;\n          var c = rowsMemo && p.badges && typeof p.badges === \"object\" ? rowsMemo.get(p.badges) : null;\n          var merged = c && c.sig === sig ? c.arr : withOurs(uid, p.badges);\n          if (!merged) return;\n          if (rowsMemo && p.badges && typeof p.badges === \"object\") rowsMemo.set(p.badges, { sig: sig, arr: merged });\n          var np = {};\n          for (var k in p) np[k] = p[k];\n          np.catalogBadges = undefined;\n          np.badges = merged;\n          args[1] = np;\n          diag.rowsChanged++;\n        } catch (e) { note(\"rows patch\", e); }\n      };\n      var after = function (args, ret) {\n        try {\n          var props = ret && ret.props;\n          var id = props && props.id;\n          if (typeof id !== \"string\" || id.indexOf(ID_PREFIX) !== 0) return;\n          var e = elementProps[id];\n          if (!e) return;\n          if (!props.source || !props.source.uri) props.source = e.source;\n          if (!props.label) props.label = e.label;\n        } catch (x) { note(\"badge image fix\", x); }\n      };\n      unpatches.push(patcher.before(\"jsx\", rt, before));\n      unpatches.push(patcher.before(\"jsxs\", rt, before));\n      diag.rows = \"OK\";\n      unpatches.push(patcher.after(\"jsx\", rt, after));\n      unpatches.push(patcher.after(\"jsxs\", rt, after));\n      diag.badgeFix = \"OK\";\n    } catch (e) {\n      if (diag.rows !== \"OK\") diag.rows = \"FAILED\";\n      if (diag.badgeFix !== \"OK\") diag.badgeFix = \"FAILED\";\n      note(\"jsx\", e);\n    }\n  }\n\n  function ago(t) {\n    if (!t) return \"kabhi nahi\";\n    var s = Math.round((Date.now() - t) / 1000);\n    if (s < 60) return s + \" sec pehle\";\n    if (s < 3600) return Math.round(s / 60) + \" min pehle\";\n    return Math.round(s / 3600) + \" ghante pehle\";\n  }\n\n  function toast(msg) {\n    try {\n      if (vd.ui && vd.ui.toasts && vd.ui.toasts.showToast) vd.ui.toasts.showToast(msg);\n    } catch (e) {}\n  }\n\n  function SettingsInner() {\n    var h = React.createElement;\n    var forceState = React.useState(0);\n    var force = forceState[1];\n    React.useEffect(function () {\n      var fn = function () { try { force(function (x) { return x + 1; }); } catch (e) {} };\n      listeners.push(fn);\n      return function () {\n        var i = listeners.indexOf(fn);\n        if (i !== -1) listeners.splice(i, 1);\n      };\n    }, []);\n    var d = state.data || { defs: {}, users: {} };\n    var me = myId();\n    var mine = me && d.users[me] ? d.users[me] : null;\n    var txt = { color: \"#f2f3f5\", fontSize: 15, marginBottom: 6 };\n    var sub = { color: \"#b5bac1\", fontSize: 13, marginBottom: 6 };\n    var good = { color: \"#3ba55c\", fontSize: 15, marginBottom: 6, fontWeight: \"600\" };\n    var bad = { color: \"#f23f43\", fontSize: 15, marginBottom: 6, fontWeight: \"600\" };\n    var card = { backgroundColor: \"#2b2d31\", borderRadius: 12, padding: 16, marginBottom: 12 };\n    var title = { color: \"#ffffff\", fontSize: 17, fontWeight: \"700\", marginBottom: 10 };\n    function btn(label, color, onPress) {\n      return h(RN.TouchableOpacity, {\n        onPress: function () { try { onPress(); } catch (e) { note(\"button\", e); } },\n        style: { backgroundColor: color, borderRadius: 8, paddingVertical: 12, alignItems: \"center\", marginTop: 8 }\n      }, h(RN.Text, { style: { color: \"#ffffff\", fontSize: 15, fontWeight: \"600\" } }, label));\n    }\n    function line(ok, text) { return h(RN.Text, { style: ok ? good : bad }, (ok ? \"\\u2705 \" : \"\\u274c \") + text); }\n    var names = mine ? mine.map(function (n) { return n + \" \" + d.defs[n].name; }).join(\", \") : \"\";\n    var Switch = RN.Switch;\n    return h(RN.ScrollView, { style: { flex: 1 }, contentContainerStyle: { padding: 16 } },\n      h(RN.View, { style: card },\n        h(RN.Text, { style: title }, \"YumiCord Badges v\" + VERSION),\n        line(true, \"Plugin chal raha hai\"),\n        line(!!state.data, state.data ? \"Badge list mili (\" + Object.keys(d.users).length + \" users, \" + Object.keys(d.defs).length + \" badges)\" : \"Badge list abhi nahi mili\"),\n        h(RN.Text, { style: sub }, \"Last update: \" + ago(state.lastOk) + (state.fetching ? \"  (refresh ho raha hai...)\" : \"\")),\n        state.error ? h(RN.Text, { style: bad }, \"Download error: \" + state.error) : null,\n        btn(state.fetching ? \"Refresh ho raha hai...\" : \"Abhi refresh karo\", \"#5865f2\", function () { refresh(true); })\n      ),\n      h(RN.View, { style: card },\n        h(RN.Text, { style: title }, \"Tumhara account\"),\n        h(RN.Text, { style: txt }, \"Tumhari user ID: \" + (me || \"pata nahi chala\")),\n        me ? line(!!mine, mine ? \"Ye ID list mein hai: \" + names : \"Ye ID list mein NAHI hai. Admin page pe yahi ID daalo.\") : null,\n        me ? btn(\"Meri ID copy karo\", \"#4e5058\", function () {\n          try { metro.common.clipboard.setString(me); toast(\"ID copy ho gayi\"); } catch (e) { note(\"copy\", e); }\n        }) : null,\n        btn(\"Admin page kholo\", \"#3ba55c\", function () { RN.Linking.openURL(SITE + \"admin\"); })\n      ),\n      h(RN.View, { style: card },\n        h(RN.Text, { style: title }, \"Diagnostics\"),\n        line(diag.useBadges === \"OK\", \"Classic badges patch: \" + diag.useBadges),\n        line(diag.rows === \"OK\", \"New badges patch: \" + diag.rows),\n        line(diag.badgeFix === \"OK\", \"Badge image fix: \" + diag.badgeFix),\n        h(RN.Text, { style: sub }, \"Profiles dekhe: \" + diag.hookCalls + \" | badge lagaye: \" + diag.hookAdded + \" | badge rows: \" + diag.rowsSeen + \"/\" + diag.rowsChanged),\n        h(RN.Text, { style: sub }, \"Last error: \" + (diag.errors[0] || \"koi nahi\")),\n        diag.errors.length > 1 ? h(RN.Text, { style: sub }, diag.errors.slice(1).join(\"\\n\")) : null,\n        Switch ? h(RN.View, { style: { flexDirection: \"row\", alignItems: \"center\", justifyContent: \"space-between\", marginTop: 10 } },\n          h(RN.Text, { style: txt }, \"App khulne pe test message\"),\n          h(Switch, { value: !!sget(\"testToast\", false), onValueChange: function (v) { sset(\"testToast\", !!v); notify(); } })\n        ) : null\n      )\n    );\n  }\n\n  // Error boundary so a problem in the settings screen shows a message instead of crashing Discord.\n  var Boundary = null;\n  try {\n    Boundary = function (props) { React.Component.call(this, props); this.state = { err: null }; };\n    Boundary.prototype = Object.create(React.Component.prototype);\n    Boundary.prototype.constructor = Boundary;\n    Boundary.getDerivedStateFromError = function (e) { return { err: e }; };\n    Boundary.prototype.componentDidCatch = function (e) { note(\"settings screen\", e); };\n    Boundary.prototype.render = function () {\n      if (this.state && this.state.err) {\n        return React.createElement(RN.Text, { style: { color: \"#f23f43\", padding: 16 } },\n          \"YumiCord Badges settings error: \" + String((this.state.err && this.state.err.message) || this.state.err));\n      }\n      return this.props.children;\n    };\n  } catch (e) { Boundary = null; note(\"boundary\", e); }\n\n  function Settings() {\n    try {\n      var inner = React.createElement(SettingsInner);\n      return Boundary ? React.createElement(Boundary, null, inner) : inner;\n    } catch (e) {\n      note(\"settings screen\", e);\n      return null;\n    }\n  }\n\n  if (typeof globalThis !== \"undefined\" && globalThis.__YC_TEST__) {\n    var T = globalThis.__YC_TEST__;\n    T.normalise = normalise; T.iconUrl = iconUrl; T.setData = setData; T.badgesFor = badgesFor;\n    T.withOurs = withOurs; T.diag = diag; T.state = state;\n  }\n\n  return {\n    onLoad: function () {\n      try {\n        diag.loadedAt = Date.now();\n        state.lastOk = sget(\"lastOk\", 0) || 0;\n        var cache = sget(\"cache\", null);\n        if (cache) { try { setData(cache); } catch (e) { note(\"cache\", e); } }\n        patchUseBadges();\n        patchJsx();\n        refresh(true);\n        try { timer = setInterval(function () { refresh(true); }, REFRESH_MS); } catch (e) { note(\"timer\", e); }\n        if (sget(\"testToast\", false)) {\n          setTimeout(function () {\n            try {\n              var me = myId();\n              var d = state.data;\n              toast(\"YumiCord Badges ON | ID \" + (me || \"?\") + (d && me && d.users[me] ? \" list mein hai\" : \" list mein nahi\"));\n            } catch (e) {}\n          }, 4000);\n        }\n      } catch (e) { note(\"onLoad\", e); }\n    },\n    onUnload: function () {\n      try { if (timer) clearInterval(timer); } catch (e) {}\n      timer = null;\n      unpatches.forEach(function (u) { try { u(); } catch (e) {} });\n      unpatches = [];\n    },\n    settings: Settings\n  };\n})()" + "}\n//# sourceURL=yumicord-builtin-badges")(vendettaApi);
      }
    },
    {
      key: "platforms", name: "YumiCord Platforms", version: "1.0.0", icon: "ic_person_status",
      shadow: "yumicord-platforms.sites.tab.bot", guard: "__ycPlatformsActive",
      // Evaluated exactly the way the loader evaluates an installed plugin (indirect eval, same "vendetta" object shape).
      factory: function(vendettaApi) {
        return (0, eval)("vendetta=>{return " + "(function () {\n  \"use strict\";\n  /*\n   * YumiCord Platforms v1.0.0\n   * Shows which device(s) a user is online on, next to their name:\n   *   member list rows, the user profile name, and the chat message author.\n   *   desktop / mobile / web / console (embedded) / VR, coloured by status (green online, yellow idle, red dnd).\n   *\n   * Crash-safe by design: every lookup, patch, timer and render is wrapped; a failure is recorded and shown on the\n   * plugin's settings screen (Diagnostics) instead of reaching Discord. Our rendered icons sit inside their own\n   * error boundary, so even a render error inside them shows nothing rather than a crash screen.\n   *\n   * Credits: idea, data source (PresenceStore clientStatuses + SessionsStore for yourself) and the five platform\n   * icon images come from \"PlatformIndicators\" by MSMA / martinz64\n   * (https://github.com/Martinz64/vendetta-plugins, The Unlicense). Re-written for Discord 350.8, where the original\n   * stops at load (module-level lookups that no longer exist throw before the plugin can start).\n   *\n   * Discord 350.8 (Hermes bytecode) facts this relies on, read from the app bundle:\n   *  - PresenceStore.getClientStatus(userId) -> {desktop|mobile|web|embedded|vr: \"online\"|\"idle\"|\"dnd\"}.\n   *  - SessionsStore.getSessions() -> {id: {clientInfo:{client}, status}} for your own account.\n   *  - Profile: component \"DisplayName\" ({user, guildId, name, ...}) renders the profile name.\n   *  - Member list: component \"UserRow\" ({user, nickname, roleColors, ...}) renders a TableRow with props.label.\n   *  - Chat: messages are drawn natively from rows built by RowManager.prototype.generate; we append emoji to\n   *    row.message.username (plain text, so no status colour in chat).\n   */\n  var VERSION = \"1.0.0\";\n  var PLATFORMS = [\"desktop\", \"mobile\", \"web\", \"embedded\", \"vr\"];\n  var EMOJI = { desktop: \"\\ud83d\\udda5\\ufe0f\", mobile: \"\\ud83d\\udcf1\", web: \"\\ud83c\\udf10\", embedded: \"\\ud83c\\udfae\", vr: \"\\ud83e\\udd7d\" };\n  var NAMES = { desktop: \"PC\", mobile: \"Phone\", web: \"Browser\", embedded: \"Console\", vr: \"VR\" };\n  var COLORS = { online: \"#23a55a\", idle: \"#f0b232\", dnd: \"#f23f43\", streaming: \"#593695\", offline: \"#80848e\", invisible: \"#80848e\" };\n  var ICONS = {\n    desktop: \"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAMAAABiM0N1AAAAVFBMVEUAAACvv7+3u7+5u7+2ub+4u726vL65u765vL65vMG5u723ub23v7+3t7+6vL+4ur+6u765u764vL+4ur23t7+7vb+3ur25ur64ur+7u766ur6vr7/+1nXbAAAAHHRSTlMAEEB/UHDv/99fgIAgQJ+f7++fnyB/YN9vTz8QSaZf3QAAAI1JREFUeAHt1tUBwkAURNEXHZzg1n+d2Fc8u4OTOQXcyKqJ3ARh5C22qiQFYTC0khFIYyuYgDYthGagzQuhDLRFIYS7yBPuakLmSaF2CimkkEIKKfT8I5un0MdCT7v6LUFbFUIhaGsr2IAUWcl2B0K2t6pDVKttGR5P3BJvpxCnfdTMHVo9NaRQ1MpKRC5jHSw3VFQzIwAAAABJRU5ErkJggg==\",\n    web: \"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAQAAAD/5HvMAAADgklEQVR42u3a32vVdRzH8VdOv2NzGzM7bkp0E9F9RQSbOmK6groQpeugOzXJfnCW3YwgC4IyHCldrBmFELtQRxfK2MHp1sjVZRfBMSJFYu6cMUnOOZPz9Gb45uyc79fv5/tDvDiPv+DJh/fn8+HL56umpqbHFZsZ4hjjzJOnQJkyBfLMM87H7GWzHh16OcoVKgQpM8N79Cht7GaSVcJa5QK7lBZe5SpRzDCgpLGdH6gS3SRPKzm8xTJxFTmgJNDKtyRllFbFQxfTRLVCvSk6FR3b+J3onuRTlllvgUzk1YmVsyJJdPMN1bqkzmizM00cc1rDIP9SawpPrjhFPAf1AN1cotZJ940ezwKb1q33BLX2Kzx2sBwzZ7vWoYXvAVOkV2FxlqjuMMtBNqkBNpIDzI/h7ywnTsfIP5gquxUGV3EiB7zMPcxlPRwDOJITTgNmpx6GyZSDnqKAOa9g9LKKIzniA0yFbQrC+5B6UDf/Y44oCFdwdUPOGMfkgr8kyrg6Lmf0YUq0yw9DuLnBcTw5YwNFzB754RhmkYaUCH7BDMsPZzDDZFMM+gQzJj/8inlTYiS1oNcws/LD35jnJUtKPOgFzHX5YQmzdmCRTSXoGcyi/FDGtEqWlHhQG6YULsjTA4zg5iZf4CkAXrig25gtUowk+FwB2IpZDDfUz8pEWiUF4DnM9XDbfkiKl6QAvB5u248H38KMJBZ0FDMW7uo4qwbIJhQ0gcnKD3sxN3lCirNKgZfrf5hB+aGdEuYVNUQ2dtAuTIk2+WMG87V8MBIzaBQzrdDDVqBDPuIE0cUy5rCC0MMq5lAqQR9hKmRcPoNu0ZF0EN0sYs7JBAyc+UwNsUJYd7nGO2zUGr4CTL9MqMGu8KIaYB43C2yVJPq4h8kpDAaoYv6kS3U4jKvfaGELeUyVfoXDT4C5wAatg8cfuHqbS4A54/K8UgTMd/WnNjuckyqAKdCj8DhArdO0NFilQ8xxhyiq7JMbRqk1GXAEuDshV3hMUesvXkoo6CKe3NHJArUqfEln7KBrdCgaMnVJcIsPa6OcczKKjk6mqFfkFH20RAi6SIfiweMkjS0xwTBvEFaVE3hKAvspEleBfUoOvTGfOH+mJ40X6ctEkaNfaWEn56kQVoVz9CltZDhCjhJBSuR4l4weHdrZwzBjzJFniTJlbpNnljGyDNLW/BmlqelxdR++AoGbDB4jjAAAAABJRU5ErkJggg==\",\n    mobile: \"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAMAAADVRocKAAAAXVBMVEUAAAAwMDgwMDUwMDUuMDYwMDYvMTcvMTYvMTYwMDYwMDUvMTYwMjUvMTUvMjYvMTUuMDUuMDQvMDUtMTUwMDgvMDUwMDAtMDYuMDYwMDAtMDUvMDYuMDUtMDcpMTo5aAq8AAAAH3RSTlMAIGBvf1C//89fMN9g75+/j3+fP0C/IFBfMGDPb08fcZ9WCgAAAMNJREFUeAHt2YWNxQAMg2EX/fiVud1/zBuhSaRjfwv8UsQx5J9L0iw/VySIyUoaXa7wu93pcE/g9KDTFS4F+amF5Em3ZwK7FwPeMEsYcoNVxZAaViX5uTd6MuQJKwY5A01u9goFWph1fyKggAIKKKCAAgoooIACCiiggAIKKKCAAgoooIACn/l9d/t3gU/fcEqG9LDKGVLB6saQAZ97owZ2w5NuzwEOKd1G4FMLE5wG36Y/w29ZadRviBn2/Nw2HfjTPgD3/UVA1TCAGgAAAABJRU5ErkJggg==\",\n    embedded: \"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAMAAABiM0N1AAAAk1BMVEUAAAC3u7+4ur+5vL+5u765u7+6vL+2ub+3v7+6u7+5vL66v7+6vL65u761ur+4u765vL+3t7+6u765u7+9vb23t7+7vb+6u766ur+5ur6/v7+vv7+9vcW1tb+5u727u763ur25vL+6vL+3ub24ur+5u7+4vL+5ur66ur64ur25vL+6u764ur24u722uby5u76vr7/eehxsAAAAMXRSTlMAQJ/f/8+fUCC/3zDv7zC/UEDvfx8gf88w3xAQHzCAT2Bfb4Bvj5/PP6+vv59wUM8QEONx+AAAAWZJREFUeAHt1dWa6zAMBOA5PSqzs2Vmhvd/uWWcVFHqr5f+r+3JRqtJ8UhBEAT/Mv8lpWwuD02hKHcpFXBTuSJ3qtZwQ0HPUVULiCuJhzpiGuKlCZaTL3gnxEVPaLWdkAxYJznIdfGmy0k9MEkOivChLQSkbwS18KElZEBBLSMIX4QMuRxaEJ0vCBndCkJMbEZjIRO6MTWCqjWlRjO6MTeCpLoooDWuCFvSjcgK0pYzohsrM0hZzhXdWJtBynJyR4rGv19dzrp3EC3nhoJKZpCynNxalzqIlrPKU7WDlOXUym8H0XIOufy+htxZX9tHBU24/L5mXH5fSy6/r4jL/8sOidYJv2x7fu0k84SgIn/Qmb50dT2oB6YXk+tf4hElWuuPdeaIlCFx/fkLeM+Q1Ferw3RQZ9SmP8jQlR9H/NZ3tKmG08+sW/SMnrxzZ6Qy/TrfBWkdL+Lq0RUptaYHJyU+HwRB4O0FjTMnvIkvoBQAAAAASUVORK5CYII=\",\n    vr: \"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAMAAABiM0N1AAAANlBMVEVMaXHv7/Hv7/Hv7/Hv7/Hv7/Hv7/Hv7/Hv7/Hs7PTu7vHv7/Hv7/Hv7/Hv7/Hv7/Hv7/Hv7/EEUZf/AAAAEXRSTlMAzGV4UNr78OcJFDufKb6ri3Gd0SEAAAHQSURBVFjD7VbHdsQgDDRNiOby/z+bjY0N2LRk95C8xxwNHo0KkqZpYGBg4PMwbBa4ZYFiZqaPRVGxNSCoavPwJs0ujLbk2K0TtipKz1s3Zl3RE/PILGKmsqbLL8JcwZ5y9LJmi3E+k8Ib1UH8xcI95Utnaeb2TAnmbzLP01NsnilfBEcBCW9FVXWpwzvxrGYiE785ASC1p2DO3M5xlWty5ZREyrEmKlQK0Tedweu1npUdNPxDVBrlHe5bIHQQue1m/YVIEKjIGKmGG7ZbPKYpqnsMnsGqqxUQNSzpP8WdJoSaNUop7nwFInZF600ijT0F3kE06dXS6RNEXfh7ROI/EMG7RPAM2++I8D48wqefZe0cJy74Bo+HaixBJPbRLXX0k5ueDenWgtzVYojLz670edNL55y2wSgPQPOtFhPbirPlKYlDPOyBPwUtjD8auzr6GwYXDKRrA4RAucMFmR0PvuXjeZ3K+wIiT++MD8Wa32n8KSxc67ArSOYcOzln6rTmi5eKhWbMIbMGyV2gkZkjKE4ZVr6cM1Lp6qxslN6ZoDodeLoVi6igTbqlYmOJ0muIBrIku4oFK7Ix9I7atAQ2SWym1F5HEjB3NDAwMPAuvgCPRUw2yKsaYwAAAABJRU5ErkJggg==\"\n  };\n\n  var diag = {\n    version: VERSION,\n    loadedAt: 0,\n    stores: \"not tried\",\n    jsx: \"not tried\",\n    chat: \"not tried\",\n    live: \"not tried\",\n    profileSeen: 0, profileAdded: 0,\n    membersSeen: 0, membersAdded: 0, membersNoLabel: 0,\n    chatSeen: 0, chatAdded: 0,\n    found: {},\n    errors: []\n  };\n  var unpatches = [];\n  var listeners = [];\n  var subs = [];\n  var active = false;\n  var presenceTimer = null;\n  var storeUnsubs = [];\n\n  var vd = null, metro = null, patcher = null, React = null, RN = null, storage = {}, log = null;\n  var PresenceStore = null, SessionsStore = null, UserStore = null;\n\n  function note(where, e) {\n    try {\n      var msg = where + \": \" + String((e && (e.message || e)) || e);\n      if (diag.errors.length && diag.errors[0].indexOf(msg) !== -1) return;\n      diag.errors.unshift(new Date().toLocaleTimeString() + \"  \" + msg);\n      if (diag.errors.length > 8) diag.errors.length = 8;\n      try { log && log.error && log.error(\"YumiCord Platforms \" + msg); } catch (x) {}\n      notify();\n    } catch (x) {}\n  }\n  function notify() {\n    for (var i = 0; i < listeners.length; i++) { try { listeners[i](); } catch (e) {} }\n  }\n\n  try {\n    vd = vendetta;\n    metro = vd.metro;\n    patcher = vd.patcher;\n    React = metro.common.React;\n    RN = metro.common.ReactNative;\n    storage = (vd.plugin && vd.plugin.storage) || {};\n    log = vd.logger || null;\n  } catch (e) { note(\"init\", e); }\n\n  function sget(k, d) { try { var v = storage[k]; return v === undefined || v === null ? d : v; } catch (e) { return d; } }\n  function sset(k, v) { try { storage[k] = v; } catch (e) {} }\n  function h() { return React.createElement.apply(React, arguments); }\n\n  // ---------- data ----------\n  function findStore(n) {\n    try { return (metro.findByStoreName && metro.findByStoreName(n)) || null; } catch (e) { note(\"store \" + n, e); return null; }\n  }\n  function initStores() {\n    PresenceStore = findStore(\"PresenceStore\");\n    SessionsStore = findStore(\"SessionsStore\");\n    UserStore = findStore(\"UserStore\");\n    diag.stores = (PresenceStore ? \"Presence OK\" : \"Presence MISSING\") + \", \" +\n      (SessionsStore ? \"Sessions OK\" : \"Sessions MISSING\") + \", \" + (UserStore ? \"User OK\" : \"User MISSING\");\n  }\n\n  var cachedMe = null;\n  function myId() {\n    try {\n      if (cachedMe) return cachedMe;\n      var u = UserStore && UserStore.getCurrentUser && UserStore.getCurrentUser();\n      if (u && u.id) cachedMe = String(u.id);\n      return cachedMe;\n    } catch (e) { return null; }\n  }\n\n  function rawStatuses(uid) {\n    var res = null;\n    if (uid && uid === myId() && SessionsStore && typeof SessionsStore.getSessions === \"function\") {\n      var s = SessionsStore.getSessions() || {};\n      var out = {}, any = false;\n      Object.keys(s).forEach(function (k) {\n        var x = s[k];\n        var c = x && x.clientInfo && x.clientInfo.client;\n        if (c && c !== \"unknown\") { out[c] = x.status || \"online\"; any = true; }\n      });\n      if (any) res = out;\n    }\n    if (!res && PresenceStore) {\n      if (typeof PresenceStore.getClientStatus === \"function\") res = PresenceStore.getClientStatus(uid);\n      else if (typeof PresenceStore.getState === \"function\") {\n        var st = PresenceStore.getState();\n        res = st && st.clientStatuses ? st.clientStatuses[uid] : null;\n      }\n    }\n    return res && typeof res === \"object\" ? res : null;\n  }\n\n  // -> [[platform, status], ...] in a fixed order, only active platforms\n  function entries(uid) {\n    try {\n      if (!uid) return [];\n      uid = String(uid);\n      var raw = rawStatuses(uid);\n      if (!raw) return [];\n      var showExtra = !!sget(\"showConsole\", true);\n      var out = [];\n      var keys = PLATFORMS.concat(Object.keys(raw).filter(function (k) { return PLATFORMS.indexOf(k) === -1; }));\n      keys.forEach(function (p) {\n        var s = raw[p];\n        if (!s || typeof s !== \"string\" || s === \"offline\" || s === \"invisible\") return;\n        if (!showExtra && (p === \"embedded\" || p === \"vr\")) return;\n        out.push([p, s]);\n      });\n      return out;\n    } catch (e) { note(\"status read\", e); return []; }\n  }\n  function sigOf(list) { return list.map(function (x) { return x[0] + \":\" + x[1]; }).join(\"|\"); }\n  function emojiText(uid) {\n    var list = entries(uid);\n    return list.map(function (x) { return EMOJI[x[0]] || \"\\u2022\"; }).join(\"\");\n  }\n\n  // live updates: one store listener, batched, each icon re-renders only if its own user's status changed\n  function onPresence() {\n    try {\n      if (presenceTimer) return;\n      presenceTimer = setTimeout(function () {\n        presenceTimer = null;\n        cachedMe = null;\n        var list = subs.slice();\n        for (var i = 0; i < list.length; i++) { try { list[i](); } catch (e) {} }\n      }, 1000);\n    } catch (e) {}\n  }\n  function startLive() {\n    try {\n      var n = 0;\n      [PresenceStore, SessionsStore].forEach(function (st) {\n        if (st && typeof st.addChangeListener === \"function\") {\n          st.addChangeListener(onPresence);\n          storeUnsubs.push(function () { try { st.removeChangeListener(onPresence); } catch (e) {} });\n          n++;\n        }\n      });\n      diag.live = n ? \"OK\" : \"NOT FOUND (icons update when the row re-renders)\";\n    } catch (e) { diag.live = \"FAILED\"; note(\"live updates\", e); }\n  }\n\n  // ---------- error boundary ----------\n  var Boundary = null;\n  try {\n    Boundary = function (props) { React.Component.call(this, props); this.state = { err: null }; };\n    Boundary.prototype = Object.create(React.Component.prototype);\n    Boundary.prototype.constructor = Boundary;\n    Boundary.getDerivedStateFromError = function (e) { return { err: e }; };\n    Boundary.prototype.componentDidCatch = function (e) { note(this.props.where || \"render\", e); };\n    Boundary.prototype.render = function () {\n      if (this.state && this.state.err) {\n        if (this.props.quiet) return null;\n        return React.createElement(RN.Text, { style: { color: \"#f23f43\", padding: 16 } },\n          \"YumiCord Platforms error: \" + String((this.state.err && this.state.err.message) || this.state.err));\n      }\n      return this.props.children === undefined ? null : this.props.children;\n    };\n  } catch (e) { Boundary = null; note(\"boundary\", e); }\n\n  // ---------- icons ----------\n  function IconsInner(props) {\n    var uid = props.userId ? String(props.userId) : null;\n    var tick = React.useState(0);\n    var last = React.useRef(\"\");\n    React.useEffect(function () {\n      var fn = function () {\n        try {\n          var s = sigOf(entries(uid));\n          if (s !== last.current) tick[1](function (x) { return x + 1; });\n        } catch (e) {}\n      };\n      subs.push(fn);\n      return function () { var i = subs.indexOf(fn); if (i !== -1) subs.splice(i, 1); };\n    }, [uid]);\n    var list = entries(uid);\n    last.current = sigOf(list);\n    if (!list.length) return null;\n    var size = props.size || 16;\n    var emoji = sget(\"style\", \"icons\") === \"emoji\";\n    return h(RN.View, { style: { flexDirection: \"row\", alignItems: \"center\", marginLeft: 4, flexShrink: 0 } },\n      list.map(function (x) {\n        var p = x[0], s = x[1], col = COLORS[s] || COLORS.online;\n        var label = (NAMES[p] || p) + \" \" + s;\n        if (emoji || !ICONS[p]) {\n          if (!EMOJI[p]) return h(RN.View, { key: p, accessibilityLabel: label, style: { width: size * 0.6, height: size * 0.6, borderRadius: size, backgroundColor: col, marginLeft: 2 } });\n          return h(RN.Text, { key: p, accessibilityLabel: label, style: { fontSize: Math.round(size * 0.8), marginLeft: 2, color: col } }, EMOJI[p]);\n        }\n        return h(RN.Image, { key: p, accessibilityLabel: label, source: { uri: ICONS[p] }, style: { width: size, height: size, tintColor: col, marginLeft: 2 } });\n      }));\n  }\n  function PlatformIcons(props) {\n    try {\n      var inner = h(IconsInner, props);\n      return Boundary ? h(Boundary, { quiet: true, where: \"icons\" }, inner) : inner;\n    } catch (e) { note(\"icons\", e); return null; }\n  }\n  function withIcons(child, uid, size) {\n    return h(RN.View, { style: { flexDirection: \"row\", alignItems: \"center\", flexShrink: 1 } },\n      h(RN.View, { style: { flexShrink: 1 } }, child),\n      h(PlatformIcons, { userId: uid, size: size }));\n  }\n  function isEl(x) { return !!x && typeof x === \"object\" && \"props\" in x && \"type\" in x; }\n\n  // ---------- where the icons go ----------\n  function modDisplayName(props, out) {\n    if (!active || !sget(\"profile\", true)) return out;\n    diag.profileSeen++;\n    var uid = props && props.user && props.user.id;\n    if (!uid || !isEl(out)) return out;\n    diag.profileAdded++;\n    return withIcons(out, String(uid), 18);\n  }\n  function modUserRow(props, out) {\n    if (!active || !sget(\"members\", true)) return out;\n    diag.membersSeen++;\n    var uid = props && props.user && props.user.id;\n    if (!uid || !isEl(out) || !out.props) return out;\n    var label = out.props.label;\n    if (!label || (typeof label !== \"string\" && !isEl(label))) { diag.membersNoLabel++; return out; }\n    diag.membersAdded++;\n    var lab = typeof label === \"string\" ? h(RN.Text, { numberOfLines: 1, style: { color: \"#f2f3f5\", fontSize: 16, fontWeight: \"600\" } }, label) : label;\n    return React.cloneElement(out, { label: withIcons(lab, String(uid), 16) });\n  }\n  var TARGETS = { DisplayName: modDisplayName, UserRow: modUserRow };\n\n  // ---------- jsx hook: finds DisplayName / UserRow however they are exported ----------\n  var fnCache = typeof WeakMap === \"function\" ? new WeakMap() : null;\n  var objSeen = typeof WeakSet === \"function\" ? new WeakSet() : null;\n\n  function targetOf(fn) {\n    if (typeof fn !== \"function\" || fn.__ycPlatforms) return null;\n    if (fn.prototype && fn.prototype.isReactComponent) return null;\n    var n = fn.displayName || fn.name;\n    return n && Object.prototype.hasOwnProperty.call(TARGETS, n) ? n : null;\n  }\n  function makeWrapper(orig, name) {\n    var mod = TARGETS[name];\n    var W = function () {\n      var out = orig.apply(this, arguments);\n      if (!active) return out;\n      try { return mod(arguments[0], out); } catch (e) { note(name + \" patch\", e); return out; }\n    };\n    W.__ycPlatforms = true;\n    try { W.displayName = name; } catch (e) {}\n    try { if (orig.defaultProps) W.defaultProps = orig.defaultProps; } catch (e) {}\n    return W;\n  }\n  function found(name, how) {\n    diag.found[name] = (diag.found[name] ? diag.found[name] + \", \" : \"\") + how;\n    notify();\n  }\n  function jsxBefore(args) {\n    try {\n      if (!active) return;\n      var t = args[0];\n      if (!t || typeof t === \"string\") return;\n      if (typeof t === \"function\") {\n        if (!fnCache) return;\n        var w = fnCache.get(t);\n        if (w === undefined) {\n          var n = targetOf(t);\n          w = n ? makeWrapper(t, n) : null;\n          fnCache.set(t, w);\n          if (n) found(n, \"function\");\n        }\n        if (w) args[0] = w;\n        return;\n      }\n      if (typeof t === \"object\" && objSeen && !objSeen.has(t)) {\n        objSeen.add(t);\n        var holder = t, key = typeof t.type === \"function\" ? \"type\" : (typeof t.render === \"function\" ? \"render\" : null);\n        if (!key && t.type && typeof t.type === \"object\" && typeof t.type.render === \"function\") { holder = t.type; key = \"render\"; }\n        if (!key) return;\n        var nm = targetOf(holder[key]);\n        if (!nm) return;\n        var mod = TARGETS[nm];\n        unpatches.push(patcher.after(key, holder, function (a, ret) {\n          if (!active) return;\n          try { return mod(a && a[0], ret); } catch (e) { note(nm + \" patch\", e); }\n        }));\n        found(nm, key === \"type\" ? \"memo\" : \"forwardRef\");\n      }\n    } catch (e) { note(\"jsx hook\", e); }\n  }\n  function patchJsx() {\n    try {\n      var rt = metro.findByProps(\"jsx\", \"jsxs\");\n      if (!rt) { diag.jsx = \"NOT FOUND\"; return; }\n      unpatches.push(patcher.before(\"jsx\", rt, jsxBefore));\n      unpatches.push(patcher.before(\"jsxs\", rt, jsxBefore));\n      diag.jsx = \"OK\";\n    } catch (e) { diag.jsx = \"FAILED\"; note(\"jsx\", e); }\n  }\n\n  // ---------- chat (native rows) ----------\n  var baseNames = typeof WeakMap === \"function\" ? new WeakMap() : null;\n  function chatAfter(args, row) {\n    try {\n      if (!active || !sget(\"chat\", true) || !baseNames) return;\n      var m = row && row.message;\n      if (!m || typeof m !== \"object\" || typeof m.username !== \"string\") return;\n      diag.chatSeen++;\n      var base = baseNames.get(m);\n      if (base === undefined) { base = m.username; baseNames.set(m, base); }\n      var src = args && args[0] && args[0].message;\n      var uid = m.authorId || (src && src.author && src.author.id);\n      if (!uid) return;\n      var e = emojiText(String(uid));\n      var next = e ? base + \" \" + e : base;\n      if (m.username !== next) m.username = next;\n      if (e) diag.chatAdded++;\n    } catch (e) { note(\"chat patch\", e); }\n  }\n  function patchChat() {\n    try {\n      var RM = null;\n      try { RM = metro.findByName(\"RowManager\"); } catch (e) {}\n      if (!RM || !RM.prototype || typeof RM.prototype.generate !== \"function\") { diag.chat = \"NOT FOUND\"; return; }\n      unpatches.push(patcher.after(\"generate\", RM.prototype, chatAfter));\n      diag.chat = \"OK\";\n    } catch (e) { diag.chat = \"FAILED\"; note(\"chat\", e); }\n  }\n\n  // ---------- settings ----------\n  function toast(msg) {\n    try { if (vd.ui && vd.ui.toasts && vd.ui.toasts.showToast) vd.ui.toasts.showToast(msg); } catch (e) {}\n  }\n\n  function SettingsInner() {\n    var forceState = React.useState(0);\n    var force = forceState[1];\n    React.useEffect(function () {\n      var fn = function () { try { force(function (x) { return x + 1; }); } catch (e) {} };\n      listeners.push(fn);\n      subs.push(fn);\n      return function () {\n        var i = listeners.indexOf(fn); if (i !== -1) listeners.splice(i, 1);\n        var j = subs.indexOf(fn); if (j !== -1) subs.splice(j, 1);\n      };\n    }, []);\n    var me = myId();\n    var mine = me ? entries(me) : [];\n    var txt = { color: \"#f2f3f5\", fontSize: 15, marginBottom: 6 };\n    var sub = { color: \"#b5bac1\", fontSize: 13, marginBottom: 6 };\n    var good = { color: \"#3ba55c\", fontSize: 15, marginBottom: 6, fontWeight: \"600\" };\n    var bad = { color: \"#f23f43\", fontSize: 15, marginBottom: 6, fontWeight: \"600\" };\n    var card = { backgroundColor: \"#2b2d31\", borderRadius: 12, padding: 16, marginBottom: 12 };\n    var title = { color: \"#ffffff\", fontSize: 17, fontWeight: \"700\", marginBottom: 10 };\n    function line(ok, text) { return h(RN.Text, { style: ok ? good : bad }, (ok ? \"\\u2705 \" : \"\\u274c \") + text); }\n    var Switch = RN.Switch;\n    function toggle(key, def, label, hint) {\n      return h(RN.View, { key: key, style: { flexDirection: \"row\", alignItems: \"center\", justifyContent: \"space-between\", marginTop: 8 } },\n        h(RN.View, { style: { flex: 1, paddingRight: 8 } },\n          h(RN.Text, { style: txt }, label),\n          hint ? h(RN.Text, { style: sub }, hint) : null),\n        Switch ? h(Switch, { value: !!sget(key, def), onValueChange: function (v) { sset(key, !!v); notify(); onPresence(); } }) : null);\n    }\n    var foundTxt = Object.keys(diag.found).map(function (k) { return k + \" (\" + diag.found[k] + \")\"; }).join(\"; \") || \"abhi koi nahi (member list / profile kholo)\";\n    return h(RN.ScrollView, { style: { flex: 1 }, contentContainerStyle: { padding: 16 } },\n      h(RN.View, { style: card },\n        h(RN.Text, { style: title }, \"YumiCord Platforms v\" + VERSION),\n        line(active, active ? \"Plugin chal raha hai\" : \"Plugin band hai\"),\n        h(RN.Text, { style: sub }, \"\\ud83d\\udcf1 Phone   \\ud83d\\udda5\\ufe0f PC   \\ud83c\\udf10 Browser   \\ud83c\\udfae Console\"),\n        h(RN.Text, { style: sub }, \"Rang: hara = online, peela = idle, laal = DND\")\n      ),\n      h(RN.View, { style: card },\n        h(RN.Text, { style: title }, \"Tumhare devices (live)\"),\n        h(RN.Text, { style: txt }, \"User ID: \" + (me || \"pata nahi chala\")),\n        h(RN.View, { style: { flexDirection: \"row\", alignItems: \"center\", marginBottom: 6 } },\n          h(RN.Text, { style: txt }, mine.length ? \"Abhi online: \" : \"Koi device nahi mila\"),\n          me ? h(PlatformIcons, { userId: me, size: 20 }) : null),\n        mine.length ? h(RN.Text, { style: sub }, mine.map(function (x) { return (NAMES[x[0]] || x[0]) + \" = \" + x[1]; }).join(\", \")) : null\n      ),\n      h(RN.View, { style: card },\n        h(RN.Text, { style: title }, \"Kahan dikhana hai\"),\n        toggle(\"members\", true, \"Member list\"),\n        toggle(\"profile\", true, \"Profile pe naam ke paas\"),\n        toggle(\"chat\", true, \"Chat mein naam ke paas\", \"Chat mein emoji aate hain (rang nahi). Naye messages pe dikhte hain.\"),\n        toggle(\"showConsole\", true, \"Console \\ud83c\\udfae / VR bhi dikhao\"),\n        h(RN.View, { style: { flexDirection: \"row\", alignItems: \"center\", justifyContent: \"space-between\", marginTop: 8 } },\n          h(RN.Text, { style: txt }, \"Style: \" + (sget(\"style\", \"icons\") === \"emoji\" ? \"Emoji\" : \"Rangeen icons\")),\n          h(RN.TouchableOpacity, {\n            onPress: function () { try { sset(\"style\", sget(\"style\", \"icons\") === \"emoji\" ? \"icons\" : \"emoji\"); notify(); onPresence(); } catch (e) { note(\"style\", e); } },\n            style: { backgroundColor: \"#5865f2\", borderRadius: 8, paddingVertical: 8, paddingHorizontal: 14 }\n          }, h(RN.Text, { style: { color: \"#ffffff\", fontWeight: \"600\" } }, \"Badlo\")))\n      ),\n      h(RN.View, { style: card },\n        h(RN.Text, { style: title }, \"Diagnostics\"),\n        line(diag.stores.indexOf(\"Presence OK\") === 0, \"Stores: \" + diag.stores),\n        line(diag.jsx === \"OK\", \"Member list + profile hook: \" + diag.jsx),\n        line(diag.chat === \"OK\", \"Chat patch: \" + diag.chat),\n        line(diag.live === \"OK\", \"Live update: \" + diag.live),\n        h(RN.Text, { style: sub }, \"Mile: \" + foundTxt),\n        h(RN.Text, { style: sub }, \"Profile: \" + diag.profileSeen + \"/\" + diag.profileAdded +\n          \" | Members: \" + diag.membersSeen + \"/\" + diag.membersAdded + (diag.membersNoLabel ? \" (no label \" + diag.membersNoLabel + \")\" : \"\") +\n          \" | Chat: \" + diag.chatSeen + \"/\" + diag.chatAdded),\n        h(RN.Text, { style: sub }, \"Last error: \" + (diag.errors[0] || \"koi nahi\")),\n        diag.errors.length > 1 ? h(RN.Text, { style: sub }, diag.errors.slice(1).join(\"\\n\")) : null,\n        toggle(\"testToast\", false, \"App khulne pe test message\")\n      )\n    );\n  }\n  function Settings() {\n    try {\n      var inner = React.createElement(SettingsInner);\n      return Boundary ? React.createElement(Boundary, { where: \"settings screen\" }, inner) : inner;\n    } catch (e) { note(\"settings screen\", e); return null; }\n  }\n\n  if (typeof globalThis !== \"undefined\" && globalThis.__YC_TEST__) {\n    var T = globalThis.__YC_TEST__;\n    T.diag = diag; T.entries = entries; T.emojiText = emojiText; T.jsxBefore = jsxBefore; T.chatAfter = chatAfter;\n    T.modUserRow = modUserRow; T.modDisplayName = modDisplayName; T.PlatformIcons = PlatformIcons; T.IconsInner = IconsInner;\n    T.SettingsInner = SettingsInner; T.subs = subs; T.onPresence = onPresence;\n  }\n\n  return {\n    onLoad: function () {\n      try {\n        active = true;\n        diag.loadedAt = Date.now();\n        initStores();\n        startLive();\n        patchJsx();\n        patchChat();\n        if (sget(\"testToast\", false)) {\n          setTimeout(function () {\n            try {\n              var me = myId();\n              toast(\"YumiCord Platforms ON | \" + (me ? (emojiText(me) || \"koi device nahi\") : \"ID ?\"));\n            } catch (e) {}\n          }, 4000);\n        }\n      } catch (e) { note(\"onLoad\", e); }\n    },\n    onUnload: function () {\n      active = false;\n      try { if (presenceTimer) clearTimeout(presenceTimer); } catch (e) {}\n      presenceTimer = null;\n      storeUnsubs.forEach(function (u) { try { u(); } catch (e) {} });\n      storeUnsubs = [];\n      unpatches.forEach(function (u) { try { u(); } catch (e) {} });\n      unpatches = [];\n      subs.length = 0;\n    },\n    settings: Settings\n  };\n})()" + "}\n//# sourceURL=yumicord-builtin-platforms")(vendettaApi);
      }
    },
    {
      key: "ffstatus", name: "YumiCord Activity Status", version: "2.1.0", icon: "ic_activity_24px",
      // v2.4: any app shows as "Playing <app>" (was Free Fire only in v2.3). v2.3: always ON, one-tap permission popup, auto "Share my activity". Replaces v2.2's
      // "YumiCord Activity Status" (key "activity"). Activity detection based on Kizzy by dead8309 (GPL-3.0).
      factory: function(vendettaApi) {
        return (0, eval)("vendetta=>{return " + "(function () {\n  \"use strict\";\n  /*\n   * YumiCord Activity Status v2.1.0 (built into YumiCord v2.4; was \"Free Fire Status\" 2.0.0 in v2.3)\n   * Shows \"Playing <app>\" on your Discord profile for whatever app/game is open on your phone, like Discord on PC.\n   * v2.4: any app (native side; Free Fire keeps its icon/app id), never Discord/YumiCord, home screen, SystemUI,\n   * settings, permission controller, installer, keyboard or phone/dialer. Optional \"Chhupao\" list (empty by default).\n   * v2.3: always ON from the first launch, Free Fire only (no app list, no \"any app\", no modes), one-tap permission\n   * popup (native side), and Discord's own \"Share my activity\" setting is switched ON automatically if it is OFF.\n   *\n   * Activity detection based on Kizzy by dead8309 (https://github.com/dead8309/Kizzy, GPL-3.0):\n   * foreground-app detection through Android \"Usage access\" (UsageStatsManager) and a foreground service with its\n   * own gateway session that sends op 3 presence, so the status stays up while Discord sleeps in the background.\n   *\n   * JS <-> native: files in the loader's DocumentsDirPath (yumicord_activity.json = settings + token,\n   * yumicord_activity_status.json = service status) and the yumicord://rpc/<sync|setup> trampoline.\n   */\n  var VERSION = \"2.1.0\";\n  var FF_APP_ID = \"1441993244895477830\";\n  var FF_PKGS = [\"com.garena.game.ffi\", \"com.dts.freefireth\", \"com.dts.freefiremax\"];\n  var CFG_FILE = \"yumicord_activity.json\", STATUS_FILE = \"yumicord_activity_status.json\";\n\n  var diag = { file: \"not tried\", native: null, nativeAt: 0, cfgWrites: 0, syncs: 0, reconnects: 0, share: \"not checked\", shareTries: 0, errors: [] };\n  var listeners = [];\n  var timer = null, fluxUnsub = null, lastCfg = null, lastAutoSync = 0, shareBusy = false, shareDone = false;\n  var vd = null, metro = null, React = null, RN = null, storage = {}, log = null, Flux = null;\n\n  function note(where, e) {\n    try {\n      var msg = where + \": \" + String((e && (e.message || e)) || e);\n      if (diag.errors.length && diag.errors[0].indexOf(msg) !== -1) return;\n      diag.errors.unshift(new Date().toLocaleTimeString() + \"  \" + msg);\n      if (diag.errors.length > 6) diag.errors.length = 6;\n      try { log && log.error && log.error(\"Activity Status \" + msg); } catch (x) {}\n      notify();\n    } catch (x) {}\n  }\n  function notify() { for (var i = 0; i < listeners.length; i++) { try { listeners[i](); } catch (e) {} } }\n\n  try {\n    vd = vendetta; metro = vd.metro; React = metro.common.React; RN = metro.common.ReactNative;\n    storage = (vd.plugin && vd.plugin.storage) || {}; log = vd.logger || null;\n    Flux = metro.common.FluxDispatcher || null;\n  } catch (e) { note(\"init\", e); }\n\n  function sget(k, d) { try { var v = storage[k]; return v === undefined || v === null ? d : v; } catch (e) { return d; } }\n  function sset(k, v) { try { storage[k] = v; } catch (e) { note(\"save\", e); } }\n  function h() { return React.createElement.apply(React, arguments); }\n  // v2.3 keeps its own ON/OFF key (\"off23\"), so v2.2's old switches/modes/app list do not matter: ON by default.\n  var forceOff = false; // set when the whole built-in is switched OFF on the Built-in features page (until restart)\n  function isOn() { return !forceOff && sget(\"off23\", false) !== true; }\n\n  // ---------- native bridge (files + yumicord:// trampoline) ----------\n  function fileMod() {\n    try {\n      var names = [\"NativeFileModule\", \"RTNFileManager\", \"DCDFileManager\"];\n      for (var i = 0; i < names.length; i++) {\n        var m = null;\n        try { if (globalThis.__turboModuleProxy) m = globalThis.__turboModuleProxy(names[i]); } catch (e) {}\n        if (!m) { try { m = globalThis.nativeModuleProxy && globalThis.nativeModuleProxy[names[i]]; } catch (e) {} }\n        if (!m) { try { m = RN.NativeModules && RN.NativeModules[names[i]]; } catch (e) {} }\n        if (m) return m;\n      }\n    } catch (e) { note(\"file module\", e); }\n    return null;\n  }\n  function docDir() { try { return fileMod().getConstants().DocumentsDirPath; } catch (e) { return null; } }\n  function writeFile(name, text) {\n    var fm = fileMod(); if (!fm) { diag.file = \"file module missing\"; return Promise.resolve(false); }\n    return Promise.resolve(fm.writeFile(\"documents\", name, text, \"utf8\")).then(function () { diag.file = \"ok\"; return true; }, function (e) { diag.file = \"write failed\"; note(\"write \" + name, e); return false; });\n  }\n  function readJson(name) {\n    var fm = fileMod(); var d = docDir();\n    if (!fm || !d) return Promise.resolve(null);\n    var path = d + \"/\" + name;\n    return Promise.resolve(fm.fileExists(path)).then(function (ok) {\n      if (!ok) return null;\n      return Promise.resolve(fm.readFile(path, \"utf8\")).then(function (t) { try { return JSON.parse(t); } catch (e) { return null; } });\n    }).catch(function () { return null; });\n  }\n  function nativeAction(action) {\n    try {\n      var d = docDir() || \"\";\n      diag.syncs++;\n      var p = RN.Linking.openURL(\"yumicord://rpc/\" + action + \"?dir=\" + encodeURIComponent(d));\n      if (p && p.catch) p.catch(function (e) { note(\"open \" + action, e); });\n      if (d) sset(\"dirSent\", d);\n    } catch (e) { note(\"open \" + action, e); }\n    setTimeout(refreshNative, 1500); setTimeout(refreshNative, 5000);\n  }\n  function refreshNative() {\n    return readJson(STATUS_FILE).then(function (s) { diag.native = s; diag.nativeAt = Date.now(); notify(); });\n  }\n  function nativeFresh() { var s = diag.native; return !!(s && Date.now() - (s.t || 0) < 25000); }\n  function nativeRunning() { var s = diag.native; return !!(s && s.running && nativeFresh()); }\n  function nativeV24() { var s = diag.native; return !!(s && s.v >= 24); }\n\n  // ---------- account bits ----------\n  function token() {\n    try { var m = metro.findByProps(\"getToken\"); return (m && m.getToken && m.getToken()) || \"\"; } catch (e) { return \"\"; }\n  }\n  function myStatus() {\n    try {\n      var U = metro.findByStoreName(\"UserStore\"), P = metro.findByStoreName(\"PresenceStore\");\n      var me = U && U.getCurrentUser && U.getCurrentUser();\n      var st = me && P && P.getStatus && P.getStatus(me.id);\n      if (st === \"offline\") st = \"invisible\";\n      return /^(online|idle|dnd|invisible)$/.test(st || \"\") ? st : \"online\";\n    } catch (e) { return \"online\"; }\n  }\n\n  function buildCfg() {\n    var on = isOn();\n    var pk = {}; FF_PKGS.forEach(function (p) { pk[p] = { name: \"Free Fire\", appId: FF_APP_ID }; });\n    return {\n      v: 2, enabled: on, mode: \"auto\", name: \"Free Fire\", appId: FF_APP_ID, useTimestamp: true, keepAlive: true,\n      anyApp: true, packages: pk, exclude: Object.keys(hidden()), status: myStatus(), token: on ? token() : \"\"\n    };\n  }\n  // v2.4 \"Chhupao\": apps the user never wants shown, {pkg: label}. Empty by default.\n  function hidden() { var o = sget(\"hide24\", null); return o && typeof o === \"object\" ? o : {}; }\n  function setHidden(pkg, name, hide) {\n    var o = {}, cur = hidden(); for (var k in cur) o[k] = cur[k];\n    if (hide) o[pkg] = name || pkg; else delete o[pkg];\n    sset(\"hide24\", o); lastCfg = null;\n    saveCfg().then(function () { setTimeout(refreshNative, 5000); });\n    notify();\n  }\n  function saveCfg() {\n    try {\n      var text = JSON.stringify(buildCfg());\n      if (text === lastCfg) return Promise.resolve(true);\n      return writeFile(CFG_FILE, text).then(function (ok) { if (ok) { lastCfg = text; diag.cfgWrites++; } return ok; });\n    } catch (e) { note(\"config\", e); return Promise.resolve(false); }\n  }\n\n  // ---------- Discord's own \"Share my activity\" (show_current_game), switched ON through the client itself ----------\n  // Only the client's own settings code is used (it sends the whole \"status\" settings group, as Discord requires);\n  // the raw settings-proto API is NOT used, because a partial status group would reset the user's status.\n  function shareSettingObj() {\n    try { var m = metro.findByProps(\"ShowCurrentGame\"); var s = m && m.ShowCurrentGame; if (s && typeof s.getSetting === \"function\") return s; } catch (e) {}\n    return null;\n  }\n  function protoStore() { try { return metro.findByStoreName(\"UserSettingsProtoStore\"); } catch (e) { return null; } }\n  // true / false / null (unknown: settings not loaded yet)\n  function readShare() {\n    var s = shareSettingObj();\n    if (s) { try { var v = s.getSetting(); if (typeof v === \"boolean\") return v; } catch (e) {} }\n    try {\n      var st = protoStore(); var set = st && st.settings;\n      if (!set) return null;\n      if (!set.status) return set.versions ? true : null; // loaded but no status group = Discord's default (ON)\n      var g = set.status.showCurrentGame;\n      if (g == null) return true; // not set = Discord's default (ON)\n      return typeof g === \"object\" ? g.value !== false : g !== false;\n    } catch (e) { return null; }\n  }\n  function shareMethods() {\n    var out = [];\n    var s = shareSettingObj();\n    if (s && typeof s.updateSetting === \"function\") out.push([\"ShowCurrentGame.updateSetting\", function () { return s.updateSetting(true); }]);\n    var ac = null;\n    try { var m = metro.findByProps(\"PreloadedUserSettingsActionCreators\"); ac = m && m.PreloadedUserSettingsActionCreators; } catch (e) {}\n    if (!ac) { try { var m2 = metro.findByProps(\"UserSettingsActionCreatorsByType\"); ac = m2 && m2.PreloadedUserSettingsActionCreators; } catch (e) {} }\n    if (ac && typeof ac.updateAsync === \"function\")\n      out.push([\"PreloadedUserSettings.updateAsync\", function () { return ac.updateAsync(\"status\", function (st) { st.showCurrentGame = { value: true }; }, 0); }]);\n    return out;\n  }\n  function ensureShare(why) {\n    if (shareBusy || shareDone || !isOn()) return;\n    var cur = readShare();\n    if (cur === true) { diag.share = \"ON (pehle se)\"; shareDone = true; notify(); return; }\n    if (cur === null) { diag.share = \"settings load nahi hui abhi (\" + why + \")\"; notify(); return; }\n    var ms = shareMethods();\n    if (!ms.length) { diag.share = \"OFF, auto-ON ka tareeka nahi mila\"; notify(); return; }\n    if (diag.shareTries >= 4) return;\n    diag.shareTries++;\n    shareBusy = true;\n    var i = 0;\n    (function next() {\n      if (i >= ms.length) { shareBusy = false; diag.share = \"OFF, auto-ON nahi hua\"; notify(); return; }\n      var m = ms[i++];\n      try { var r = m[1](); if (r && r.catch) r.catch(function (e) { note(\"share \" + m[0], e); }); }\n      catch (e) { note(\"share \" + m[0], e); setTimeout(next, 100); return; }\n      setTimeout(function () {\n        if (readShare() === true) { shareBusy = false; shareDone = true; diag.share = \"OFF tha, apne aap ON kiya (\" + m[0] + \")\"; sset(\"shareAutoOn\", Date.now()); notify(); }\n        else next();\n      }, 4000);\n    })();\n  }\n\n  function periodic() {\n    saveCfg().then(refreshNative).then(function () {\n      try {\n        // Self-heal (rate-limited): it should run but the service is not running (e.g. phone killed it) -> start it.\n        var appActive = !RN.AppState || RN.AppState.currentState === \"active\";\n        if (isOn() && !nativeRunning() && appActive && Date.now() - lastAutoSync > 300000) {\n          lastAutoSync = Date.now(); nativeAction(\"sync\");\n        }\n      } catch (e) { note(\"periodic\", e); }\n      if (!shareDone) ensureShare(\"periodic\");\n    });\n  }\n\n  // ---------- settings UI (minimal: status line + OFF switch) ----------\n  var Boundary = null;\n  try {\n    Boundary = function (props) { React.Component.call(this, props); this.state = { err: null }; };\n    Boundary.prototype = Object.create(React.Component.prototype);\n    Boundary.prototype.constructor = Boundary;\n    Boundary.getDerivedStateFromError = function (e) { return { err: e }; };\n    Boundary.prototype.componentDidCatch = function (e) { note(\"settings render\", e); };\n    Boundary.prototype.render = function () {\n      if (this.state.err) return h(RN.Text, { style: { color: \"#f23f43\", padding: 16 } }, \"Settings screen error: \" + String(this.state.err && this.state.err.message || this.state.err));\n      return this.props.children;\n    };\n  } catch (e) { Boundary = null; }\n\n  var C = { txt: { color: \"#f2f3f5\", fontSize: 16, fontWeight: \"600\" }, sub: { color: \"#b5bac1\", fontSize: 13, marginTop: 6 },\n    tiny: { color: \"#80848e\", fontSize: 11, marginTop: 10 },\n    card: { backgroundColor: \"#2b2d31\", borderRadius: 12, padding: 16, marginBottom: 12 },\n    good: { color: \"#3ba55c\", fontSize: 18, fontWeight: \"700\", marginTop: 4 }, bad: { color: \"#f23f43\", fontSize: 18, fontWeight: \"700\", marginTop: 4 },\n    warn: { color: \"#f0b232\", fontSize: 18, fontWeight: \"700\", marginTop: 4 } };\n\n  function btn(label, onPress) {\n    return h(RN.TouchableOpacity, { onPress: function () { try { onPress(); } catch (e) { note(\"button\", e); } },\n      style: { backgroundColor: \"#5865f2\", borderRadius: 8, paddingVertical: 12, paddingHorizontal: 12, alignItems: \"center\", marginTop: 12 } },\n      h(RN.Text, { style: { color: \"#ffffff\", fontSize: 15, fontWeight: \"700\" } }, label));\n  }\n\n  // [text, style, needsPermission]\n  function statusLine() {\n    if (!isOn()) return [\"OFF hai\", \"warn\", false];\n    var s = diag.native;\n    if (s && s.usageGranted === false) return [\"Permission chahiye\", \"bad\", true];\n    if (!nativeRunning()) return [\"Shuru ho raha hai\\u2026\", \"warn\", false];\n    if (s.authFailed) return [\"Discord login dobara karo\", \"bad\", false];\n    if (s.showing) return [\"Chal raha hai \\u2713  Abhi dikh raha hai: Playing \" + (s.showingName || s.showing), \"good\", false];\n    return [\"Chal raha hai \\u2713\", \"good\", false];\n  }\n\n  // v2.4 \"Chhupao\" (optional): hide the last shown app; hidden apps can be shown again with one tap.\n  function chhupao(s) {\n    var hd = hidden(), keys = Object.keys(hd);\n    var last = s && s.lastShown && !hd[s.lastShown] ? s.lastShown : null;\n    if (!last && !keys.length) return null;\n    var rows = [h(RN.Text, { key: \"t\", style: C.sub }, \"Chhupao: jo app kabhi nahi dikhana\")];\n    if (last) rows.push(h(RN.TouchableOpacity, { key: \"add\", onPress: function () { try { setHidden(last, s.lastShownName, true); } catch (e) { note(\"chhupao\", e); } },\n      style: { backgroundColor: \"#4e5058\", borderRadius: 8, paddingVertical: 10, paddingHorizontal: 12, marginTop: 8 } },\n      h(RN.Text, { style: { color: \"#ffffff\", fontSize: 14, fontWeight: \"600\" } }, \"\\\"\" + (s.lastShownName || last) + \"\\\" mat dikhao\")));\n    keys.forEach(function (p) {\n      rows.push(h(RN.TouchableOpacity, { key: \"h\" + p, onPress: function () { try { setHidden(p, null, false); } catch (e) { note(\"chhupao\", e); } },\n        style: { flexDirection: \"row\", justifyContent: \"space-between\", paddingVertical: 8, marginTop: 4 } },\n        h(RN.Text, { style: { color: \"#f2f3f5\", fontSize: 14 } }, \"\\u2715 \" + hd[p]),\n        h(RN.Text, { style: { color: \"#00a8fc\", fontSize: 13 } }, \"wapas dikhao\")));\n    });\n    return h(RN.View, { style: C.card }, rows);\n  }\n\n  function SettingsInner() {\n    var t = React.useState(0); var setT = t[1];\n    React.useEffect(function () {\n      var fn = function () { setT(function (x) { return x + 1; }); };\n      listeners.push(fn);\n      refreshNative();\n      var iv = setInterval(refreshNative, 3000);\n      return function () { clearInterval(iv); var i = listeners.indexOf(fn); if (i >= 0) listeners.splice(i, 1); };\n    }, []);\n    var st = statusLine();\n    var s = diag.native;\n    return h(RN.ScrollView, { style: { flex: 1 }, contentContainerStyle: { padding: 16, paddingBottom: 60 } },\n      h(RN.View, { style: C.card },\n        h(RN.View, { style: { flexDirection: \"row\", alignItems: \"center\", justifyContent: \"space-between\" } },\n          h(RN.View, { style: { flex: 1, paddingRight: 8 } },\n            h(RN.Text, { style: C.txt }, \"Activity Status\"),\n            h(RN.Text, { style: C.sub }, \"Jo bhi app/game khologe, dosto ko Discord pe \\\"Playing <app>\\\" dikhega. Discord, home screen aur system wali cheezein kabhi nahi.\")),\n          RN.Switch ? h(RN.Switch, { value: isOn(), onValueChange: function (v) {\n            try {\n              sset(\"off23\", !v); lastCfg = null;\n              saveCfg().then(function () { nativeAction(\"sync\"); });\n              if (v) { shareDone = false; diag.shareTries = 0; setTimeout(function () { ensureShare(\"switch\"); }, 1500); }\n              notify();\n            } catch (e) { note(\"switch\", e); }\n          } }) : null),\n        h(RN.Text, { style: C[st[1]] }, st[0]),\n        st[2] ? btn(\"Permission do (Allow)\", function () { saveCfg().then(function () { nativeAction(\"setup\"); }); }) : null\n      ),\n      chhupao(s),\n      h(RN.Text, { style: C.tiny }, \"v\" + VERSION + \" \\u2022 service: \" + (s ? (nativeRunning() ? \"on\" : \"off\") + (s.gateway ? \"/\" + s.gateway : \"\") + (s.usageGranted === false ? \" \\u2022 usage: nahi\" : \"\") : \"?\") +\n        \" \\u2022 Share my activity: \" + diag.share + (diag.errors.length ? \"\\nLast error: \" + diag.errors[0] : \"\")),\n      h(RN.Text, { style: C.tiny }, \"Activity detection based on Kizzy by dead8309 (github.com/dead8309/Kizzy, GPL-3.0).\")\n    );\n  }\n  function Settings() {\n    try { return Boundary ? h(Boundary, null, h(SettingsInner, null)) : h(SettingsInner, null); }\n    catch (e) { note(\"settings\", e); return null; }\n  }\n\n  return {\n    onLoad: function () {\n      try {\n        if (Flux && Flux.subscribe) {\n          var onOpen = function () { diag.reconnects++; setTimeout(function () { saveCfg(); ensureShare(\"connect\"); }, 3000); };\n          Flux.subscribe(\"CONNECTION_OPEN\", onOpen);\n          fluxUnsub = function () { try { Flux.unsubscribe(\"CONNECTION_OPEN\", onOpen); } catch (e) {} };\n        }\n      } catch (e) { note(\"subscribe\", e); }\n      // Start-up: write settings + token, then start the service. The trampoline is opened when the service is not\n      // already running (first launch, after an update, after the phone killed it) or the folder changed; the native\n      // side then shows the one-tap permission popup if Usage access is still missing.\n      setTimeout(function () {\n        try {\n          saveCfg().then(refreshNative).then(function () {\n            var d = docDir();\n            if (isOn() && (!nativeRunning() || !nativeV24() || sget(\"dirSent\", \"\") !== d || !sget(\"synced24\", false))) {\n              lastAutoSync = Date.now(); sset(\"synced24\", true); nativeAction(\"sync\");\n            }\n          });\n        } catch (e) { note(\"start\", e); }\n      }, 4000);\n      setTimeout(function () { ensureShare(\"start\"); }, 9000);\n      try { timer = setInterval(periodic, 15000); } catch (e) { note(\"timer\", e); }\n    },\n    onUnload: function () {\n      try { if (timer) clearInterval(timer); } catch (e) {}\n      try { fluxUnsub && fluxUnsub(); } catch (e) {}\n    },\n    // Called by the Built-in features page when this built-in is switched OFF: stop everything now.\n    onBuiltinOff: function () {\n      try { forceOff = true; lastCfg = null; saveCfg().then(function () { nativeAction(\"sync\"); }); } catch (e) { note(\"off\", e); }\n    },\n    settings: Settings\n  };\n})()\n" + "}\n//# sourceURL=yumicord-builtin-ffstatus")(vendettaApi);
      }
    }
  ];
  var yumiState = { ready: null, status: "not started", active: {}, instances: {}, errors: [], seed: { status: "not started", added: 0, skipped: 0, failed: 0 } };
  function yumiNote(where, e) {
    try {
      var msg = where + ": " + String(e && (e.stack || e.message) || e);
      yumiState.errors.unshift(msg);
      if (yumiState.errors.length > 10) yumiState.errors.length = 10;
      try { console.log("[YumiCord] " + msg); } catch (x) {}
    } catch (x) {}
  }
  function yumiShadowOf(id) {
    if (typeof id !== "string") return null;
    for (var i = 0; i < YUMI_BUILTINS.length; i++) {
      var b = YUMI_BUILTINS[i];
      if (b.shadow && id.indexOf(b.shadow) !== -1) return b;
    }
    return null;
  }
  function yumiStartOne(b) {
    return createStorage(createMMKVBackend("YUMICORD_BUILTIN_" + b.key)).then(function(storage) {
      var inst = null;
      try {
        var lg;
        try { lg = new LoggerClass("YumiCord \xBB " + b.name); } catch (e) { lg = { log: function() {}, info: function() {}, warn: function() {}, error: function() {} }; }
        var api = Object.assign({}, globalThis.vendetta, {
          plugin: {
            id: "yumicord-builtin:" + b.key,
            manifest: { name: b.name, description: b.name + " (built into YumiCord)", authors: [{ name: "YumiCord" }], main: "index.js", hash: "builtin-" + b.version, version: b.version, vendetta: { icon: b.icon } },
            storage
          },
          logger: lg
        });
        var raw = b.factory(api);
        inst = typeof raw === "function" ? raw() : raw;
        inst = inst && inst.default || inst || {};
        yumiState.instances[b.key] = inst;
        if (typeof inst.onLoad === "function") inst.onLoad();
        yumiState.active[b.key] = true;
        if (b.guard) globalThis[b.guard] = true;
      } catch (e) {
        yumiNote(b.key, e);
        try { inst && typeof inst.onUnload === "function" && inst.onUnload(); } catch (e2) {}
        yumiState.active[b.key] = false;
        delete yumiState.instances[b.key];
        if (b.guard) globalThis[b.guard] = false;
      }
    });
  }

  var yumiCtl = null;
  function yumiCtlStore() {
    if (!yumiCtl) yumiCtl = wrapSync(createStorage(createMMKVBackend("YUMICORD_BUILTINS")));
    return yumiCtl;
  }
  // Settings page: YumiCord section -> "Built-in features". One switch per built-in (applies after restart)
  // and each built-in's own settings/diagnostics screen.
  function YumiBuiltinsPage() {
    var h = React.createElement;
    var RN = globalThis.vendetta?.metro?.common?.ReactNative;
    var openState = React.useState(null);
    var open = openState[0], setOpen = openState[1];
    var tickState = React.useState(0);
    var setTick = tickState[1];
    if (!RN) return null;
    var ctl = yumiCtlStore();
    var txt = { color: "#f2f3f5", fontSize: 16, fontWeight: "700" };
    var sub = { color: "#b5bac1", fontSize: 13, marginTop: 6 };
    var card = { backgroundColor: "#2b2d31", borderRadius: 12, padding: 16, marginBottom: 12 };
    var btn = function(label, onPress) {
      return h(RN.TouchableOpacity, {
        onPress: function() { try { onPress(); } catch (e) { yumiNote("page button", e); } },
        style: { backgroundColor: "#5865f2", borderRadius: 8, paddingVertical: 10, alignItems: "center", marginTop: 10 }
      }, h(RN.Text, { style: { color: "#ffffff", fontSize: 14, fontWeight: "600" } }, label));
    };
    if (open) {
      var inst = yumiState.instances[open];
      var S = inst && inst.settings;
      return h(RN.View, { style: { flex: 1 } },
        h(RN.View, { style: { padding: 12 } }, btn("\u2190 Wapas", function() { setOpen(null); })),
        S ? h(S, null) : h(RN.Text, { style: [sub, { padding: 16 }] }, "Is feature ki settings abhi available nahi (feature chal nahi raha).")
      );
    }
    var safe = false;
    try { safe = !!settings.safeMode?.enabled; } catch (e) {}
    return h(RN.ScrollView, { style: { flex: 1 }, contentContainerStyle: { padding: 16, paddingBottom: 60 } },
      h(RN.Text, { style: [sub, { marginBottom: 12 }] }, "Ye features YumiCord mein pehle se built-in hain, plugin install karne ki zarurat nahi. Switch badalne ke baad app restart karo."),
      safe ? h(RN.Text, { style: { color: "#f0b232", fontSize: 14, marginBottom: 12 } }, "Safe Mode ON hai, isliye built-in features abhi band hain.") : null,
      YUMI_BUILTINS.map(function(b) {
        var off = false;
        try { off = ctl["off:" + b.key] === true; } catch (e) {}
        var active = !!yumiState.active[b.key];
        var status = active ? "\u2705 Chal raha hai" : off ? "OFF (restart ke baad band)" : safe ? "Safe Mode mein band" : "\u274c Shuru nahi hua";
        if (active && off) status = "\u2705 Chal raha hai (restart ke baad OFF hoga)";
        if (!active && !off && !safe && yumiState.status !== "started") status = "Shuru ho raha hai\u2026";
        return h(RN.View, { key: b.key, style: card },
          h(RN.View, { style: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" } },
            h(RN.Text, { style: txt }, b.name),
            RN.Switch ? h(RN.Switch, {
              value: !off,
              onValueChange: function(v) {
                try { ctl["off:" + b.key] = !v; } catch (e) { yumiNote("switch", e); }
                if (!v) { try { var bi = yumiState.instances[b.key]; bi && typeof bi.onBuiltinOff === "function" && bi.onBuiltinOff(); } catch (e) { yumiNote("switch off", e); } }
                setTick(function(x) { return x + 1; });
              }
            }) : null
          ),
          h(RN.Text, { style: sub }, status),
          active ? btn("Settings / Diagnostics", function() { setOpen(b.key); }) : null
        );
      }),
      yumiState.errors.length ? h(RN.Text, { style: [sub, { marginTop: 8 }] }, "Last error: " + String(yumiState.errors[0]).slice(0, 300)) : null,
      h(RN.Text, { style: [sub, { marginTop: 12 }] }, "Pre-installed plugins: " + yumiState.seed.status)
    );
  }
  function yumiStartBuiltins() {
    var ctl = yumiCtlStore();
    return awaitStorage(settings, ctl).then(function() {
      if (settings.safeMode?.enabled) {
        yumiState.status = "safe mode: built-ins off";
        return;
      }
      var chain = Promise.resolve();
      YUMI_BUILTINS.forEach(function(b) {
        chain = chain.then(function() {
          var off = false;
          try { off = ctl["off:" + b.key] === true; } catch (e) {}
          if (off) { yumiState.active[b.key] = false; return; }
          return yumiStartOne(b);
        }).catch(function(e) { yumiNote(b.key, e); });
      });
      return chain.then(function() { yumiState.status = "started"; });
    });
  }
  function yumiSetup() {
    try { globalThis.__yumicord = yumiState; } catch (e) {}
    try {
      var origEval = VdPluginManager.evalPlugin;
      VdPluginManager.evalPlugin = function(plugin) {
        var self = this;
        var go = function() {
          try {
            var b = yumiShadowOf(plugin && plugin.id);
            if (b && yumiState.active[b.key]) {
              // Same feature is built in and already running: the installed URL copy becomes a no-op
              // (so nothing shows twice); its settings page shows the built-in's screen.
              var inst = yumiState.instances[b.key] || {};
              return { onLoad: function() {}, onUnload: function() {}, settings: inst.settings };
            }
          } catch (e) { yumiNote("shadow", e); }
          return origEval.call(self, plugin);
        };
        var r = yumiState.ready;
        return r ? r.then(go, go) : go();
      };
    } catch (e) { yumiNote("evalPlugin wrap", e); }
    try {
      var started = yumiStartBuiltins().catch(function(e) { yumiNote("builtins", e); });
      var cap = new Promise(function(res) { setTimeout(res, 10000); });
      yumiState.ready = Promise.race([started, cap]).catch(function() {});
    } catch (e) {
      yumiNote("builtins setup", e);
      yumiState.ready = null;
    }
  }
  function yumiSeedPlugins() {
    var st = yumiState.seed;
    try {
      var store = wrapSync(createStorage(createMMKVBackend("YUMICORD_SEED")));
      return awaitStorage(store, plugins, settings).then(function() {
        if (settings.safeMode?.enabled) { st.status = "safe mode: skipped"; return; }
        if (store.version === YUMI_SEED.version && store.complete === true) { st.status = "already done (v" + YUMI_SEED.version + ")"; return; }
        st.status = "running";
        st.added = 0;
        st.skipped = 0;
        st.failed = 0;
        var names = {};
        try {
          Object.keys(plugins).forEach(function(k) {
            try {
              var n = plugins[k] && plugins[k].manifest && plugins[k].manifest.name;
              if (n) names[String(n).toLowerCase()] = 1;
            } catch (e) {}
          });
        } catch (e) {}
        var list = YUMI_SEED.plugins || [];
        var step = function(i) {
          if (i >= list.length) {
            try {
              store.version = YUMI_SEED.version;
              store.complete = st.failed === 0;
            } catch (e) {}
            st.status = "done: " + st.added + " added, " + st.skipped + " skipped, " + st.failed + " failed";
            return;
          }
          var item = list[i] || {};
          var id = String(item.id || "");
          if (id && !id.endsWith("/")) id += "/";
          var key = "d:" + id;
          try {
            if (!id || store[key]) return step(i + 1);
            if (id in plugins || item.name && names[String(item.name).toLowerCase()]) {
              // Already installed by the user (or same plugin from another URL): leave it exactly as it is.
              store[key] = 1;
              st.skipped++;
              return step(i + 1);
            }
          } catch (e) {
            yumiNote("seed check " + id, e);
            return step(i + 1);
          }
          return VdPluginManager.fetchPlugin(id).then(function() {
            try {
              // fetchPlugin keeps enabled=false for a new entry; make sure of it.
              if (plugins[id] && plugins[id].enabled && !store[key]) plugins[id].enabled = false;
              store[key] = 1;
              if (item.name) names[String(item.name).toLowerCase()] = 1;
              st.added++;
            } catch (e) { yumiNote("seed save " + id, e); }
          }, function(e) {
            st.failed++;
            yumiNote("seed fetch " + id, e);
          }).then(function() {
            return new Promise(function(res) { setTimeout(res, 150); });
          }).then(function() { return step(i + 1); });
        };
        return step(0);
      }).catch(function(e) { st.status = "error"; yumiNote("seed", e); });
    } catch (e) {
      st.status = "error";
      yumiNote("seed", e);
    }
  }
  // ---- end YumiCord v2.1 ----


(async()=>{
  yumiSetup();
  await yumiState.ready;
  console.log('status', yumiState.status, 'ffstatus inst', typeof (yumiState.instances.ffstatus||{}).settings, JSON.stringify(yumiState.active), 'guard', globalThis.__ycBadgesActive, 'errors', yumiState.errors.length, yumiState.errors[0]||'');
  const sh = await VdPluginManager.evalPlugin({id:'https://yumicord-badges.sites.tab.bot/'});
  sh.onLoad();
  console.log('shadow settings is builtin:', typeof sh.settings, 'urlLoaded', global.urlLoaded||0);
  const other = await VdPluginManager.evalPlugin({id:'https://x/'}); other.onLoad(); console.log('other urlLoaded', global.urlLoaded);
  await yumiSeedPlugins();
  const ks=Object.keys(plugins);
  console.log('seed', JSON.stringify(yumiState.seed), 'plugins', ks.length, 'enabled', ks.filter(k=>plugins[k].enabled).length, 'fetches', fetchCount);
  const f0=fetchCount; await yumiSeedPlugins(); console.log('2nd run', yumiState.seed.status, 'newfetches', fetchCount-f0);
  // user removes one, rerun with new version
  delete plugins[ks[5]]; YUMI_SEED.version=2; YUMI_SEED.plugins.push({id:'https://new/plugin',name:'NewOne'});
  const f1=fetchCount; await yumiSeedPlugins(); console.log('v2 run', yumiState.seed.status, 'newfetches', fetchCount-f1, 'removed back?', ks[5] in plugins, 'new?', 'https://new/plugin/' in plugins);
  console.log('preexisting kept:', JSON.stringify(plugins['https://vd-plugins.github.io/proxy/meqativ.github.io/dumsane/NoDelete/']), JSON.stringify(plugins['https://bn-plugins.github.io/vd-proxy/beefers.github.io/strife/Freemoji/']));
})().catch(e=>{console.log('THROWN',e); process.exit(1)});
