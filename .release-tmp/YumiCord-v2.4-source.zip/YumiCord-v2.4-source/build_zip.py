import sys, zipfile
# YumiCord v2.2: take the v2 patched (pre-LSPatch) APK, swap in the new manifest and loader bundle, add classes5.dex.
src, dst, manifest, bundle, dex = sys.argv[1:6]
rep = {"AndroidManifest.xml": manifest, "assets/yumicord/bundle.js": bundle}
zin = zipfile.ZipFile(src); zout = zipfile.ZipFile(dst, "w")
seen = set(); dexes = set()
for info in zin.infolist():
    data = open(rep[info.filename], "rb").read() if info.filename in rep else zin.read(info.filename)
    seen.add(info.filename)
    if info.filename.startswith("classes") and info.filename.endswith(".dex"): dexes.add(info.filename)
    ni = zipfile.ZipInfo(info.filename, date_time=info.date_time); ni.compress_type = info.compress_type; ni.external_attr = info.external_attr
    zout.writestr(ni, data)
assert set(rep) <= seen, set(rep) - seen
n = 2
while ("classes%d.dex" % n) in dexes: n += 1
name = "classes%d.dex" % n
assert name not in seen
ni = zipfile.ZipInfo(name, date_time=(1981, 1, 1, 1, 1, 0)); ni.compress_type = zipfile.ZIP_DEFLATED
zout.writestr(ni, open(dex, "rb").read())
print("added", name, "after", sorted(dexes))
zout.close()
