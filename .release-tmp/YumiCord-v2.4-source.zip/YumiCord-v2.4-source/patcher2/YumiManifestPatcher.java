
import pxb.android.axml.*;
import java.nio.file.*;

public class YumiManifestPatcher {
    static final String NS = "http://schemas.android.com/apk/res/android";
    static final int NAME=0x01010003, EXPORTED=0x01010010, ENABLED=0x0101000e, AUTH=0x01010018, THEME=0x01010000,
        FGS=0x01010599, VALUE=0x01010024, SCHEME=0x01010027, HOST=0x01010028, EXCL=0x01010017, NOHIST=0x0101022d,
        TASKAFF=0x01010012, LAUNCHMODE=0x0101001d, INITORDER=0x0101001a;
    static void s(NodeVisitor n, String a, int id, String v) { n.attr(NS, a, id, NodeVisitor.TYPE_STRING, v); }
    static void b(NodeVisitor n, String a, int id, boolean v) { n.attr(NS, a, id, NodeVisitor.TYPE_INT_BOOLEAN, v); }
    static void i(NodeVisitor n, String a, int id, int type, int v) { n.attr(NS, a, id, type, v); }
    static void perm(NodeVisitor m, String p) { NodeVisitor u = m.child(null, "uses-permission"); s(u, "name", NAME, p); u.end(); }

    public static void main(String[] a) throws Exception {
        byte[] in = Files.readAllBytes(Paths.get(a[0]));
        final int code = Integer.parseInt(a[2]);
        final String vname = a[3];
        final boolean dump = a.length > 4;
        AxmlReader r = new AxmlReader(in);
        AxmlWriter w = new AxmlWriter();
        r.accept(new AxmlVisitor(w) {
            public NodeVisitor child(String ns, String n) {
                NodeVisitor nv = super.child(ns, n);
                if (!n.equals("manifest")) return nv;
                return new NodeVisitor(nv) {
                    public void attr(String ns2, String an, int rid, int t, Object v) {
                        if (an.equals("versionCode")) { System.out.println("versionCode " + v + " -> " + code); super.attr(ns2, an, rid, 0x10, code); }
                        else if (an.equals("versionName")) { System.out.println("versionName " + v + " -> " + vname); super.attr(ns2, an, rid, 0x03, vname); }
                        else super.attr(ns2, an, rid, t, v);
                    }
                    public NodeVisitor child(String ns3, String cn) {
                        NodeVisitor c = super.child(ns3, cn);
                        if (!cn.equals("application")) return c;
                        return new NodeVisitor(c) {
                            boolean shown = false;
                            public NodeVisitor child(String ns4, String n4) {
                                NodeVisitor x = super.child(ns4, n4);
                                if (dump && !shown && (n4.equals("service") || n4.equals("activity"))) {
                                    shown = true;
                                    return new NodeVisitor(x) { public void attr(String q, String an, int id, int t, Object v) {
                                        System.out.println("DUMP " + an + " type=" + t + " val=" + v + " cls=" + (v == null ? null : v.getClass().getName())); super.attr(q, an, id, t, v); } };
                                }
                                return x;
                            }
                            public void end() {
                                String P = "com.yumicord.rpc.";
                                NodeVisitor sv = child(null, "service");
                                s(sv, "name", NAME, P + "YumiRpcService");
                                b(sv, "exported", EXPORTED, false);
                                i(sv, "foregroundServiceType", FGS, NodeVisitor.TYPE_INT_HEX, 0x40000001);
                                NodeVisitor pr = sv.child(null, "property");
                                s(pr, "name", NAME, "android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE");
                                s(pr, "value", VALUE, "Shows the game you are playing as your Discord activity status (Rich Presence) while YumiCord is in the background");
                                pr.end();
                                sv.end();
                                NodeVisitor pv = child(null, "provider");
                                s(pv, "name", NAME, P + "YumiRpcProvider");
                                s(pv, "authorities", AUTH, "com.bluecord.yumicord.rpc");
                                b(pv, "exported", EXPORTED, false);
                                pv.end();
                                NodeVisitor av = child(null, "activity");
                                s(av, "name", NAME, P + "YumiRpcActivity");
                                b(av, "exported", EXPORTED, true);
                                i(av, "theme", THEME, NodeVisitor.TYPE_REFERENCE, 0x0103000f);
                                b(av, "excludeFromRecents", EXCL, true);
                                b(av, "noHistory", NOHIST, true);
                                s(av, "taskAffinity", TASKAFF, "");
                                NodeVisitor f = av.child(null, "intent-filter");
                                NodeVisitor x1 = f.child(null, "action"); s(x1, "name", NAME, "android.intent.action.VIEW"); x1.end();
                                NodeVisitor x2 = f.child(null, "category"); s(x2, "name", NAME, "android.intent.category.DEFAULT"); x2.end();
                                NodeVisitor x3 = f.child(null, "category"); s(x3, "name", NAME, "android.intent.category.BROWSABLE"); x3.end();
                                NodeVisitor x4 = f.child(null, "data"); s(x4, "scheme", SCHEME, "yumicord"); s(x4, "host", HOST, "rpc"); x4.end();
                                f.end();
                                av.end();
                                // v2.3: one-tap setup popup (translucent, not exported)
                                NodeVisitor su = child(null, "activity");
                                s(su, "name", NAME, P + "YumiSetupActivity");
                                b(su, "exported", EXPORTED, false);
                                i(su, "theme", THEME, NodeVisitor.TYPE_REFERENCE, 0x01030010 /* Theme.Translucent.NoTitleBar */);
                                b(su, "excludeFromRecents", EXCL, true);
                                su.end();
                                NodeVisitor rv = child(null, "receiver");
                                s(rv, "name", NAME, P + "YumiRpcBoot");
                                b(rv, "exported", EXPORTED, true);
                                NodeVisitor f2 = rv.child(null, "intent-filter");
                                NodeVisitor y1 = f2.child(null, "action"); s(y1, "name", NAME, "android.intent.action.BOOT_COMPLETED"); y1.end();
                                NodeVisitor y2 = f2.child(null, "action"); s(y2, "name", NAME, "android.intent.action.MY_PACKAGE_REPLACED"); y2.end();
                                f2.end();
                                rv.end();
                                super.end();
                            }
                        };
                    }
                    public void end() {
                        perm(this, "android.permission.PACKAGE_USAGE_STATS");
                        perm(this, "android.permission.QUERY_ALL_PACKAGES");
                        perm(this, "android.permission.FOREGROUND_SERVICE_SPECIAL_USE");
                        perm(this, "android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS");
                        super.end();
                    }
                };
            }
        });
        Files.write(Paths.get(a[1]), w.toByteArray());
    }
}
