(function () {
  "use strict";
  /*
   * YumiCord Activity Status v2.1.0 (built into YumiCord v2.4; was "Free Fire Status" 2.0.0 in v2.3)
   * Shows "Playing <app>" on your Discord profile for whatever app/game is open on your phone, like Discord on PC.
   * v2.4: any app (native side; Free Fire keeps its icon/app id), never Discord/YumiCord, home screen, SystemUI,
   * settings, permission controller, installer, keyboard or phone/dialer. Optional "Chhupao" list (empty by default).
   * v2.3: always ON from the first launch, Free Fire only (no app list, no "any app", no modes), one-tap permission
   * popup (native side), and Discord's own "Share my activity" setting is switched ON automatically if it is OFF.
   *
   * Activity detection based on Kizzy by dead8309 (https://github.com/dead8309/Kizzy, GPL-3.0):
   * foreground-app detection through Android "Usage access" (UsageStatsManager) and a foreground service with its
   * own gateway session that sends op 3 presence, so the status stays up while Discord sleeps in the background.
   *
   * JS <-> native: files in the loader's DocumentsDirPath (yumicord_activity.json = settings + token,
   * yumicord_activity_status.json = service status) and the yumicord://rpc/<sync|setup> trampoline.
   */
  var VERSION = "2.1.0";
  var FF_APP_ID = "1441993244895477830";
  var FF_PKGS = ["com.garena.game.ffi", "com.dts.freefireth", "com.dts.freefiremax"];
  var CFG_FILE = "yumicord_activity.json", STATUS_FILE = "yumicord_activity_status.json";

  var diag = { file: "not tried", native: null, nativeAt: 0, cfgWrites: 0, syncs: 0, reconnects: 0, share: "not checked", shareTries: 0, errors: [] };
  var listeners = [];
  var timer = null, fluxUnsub = null, lastCfg = null, lastAutoSync = 0, shareBusy = false, shareDone = false;
  var vd = null, metro = null, React = null, RN = null, storage = {}, log = null, Flux = null;

  function note(where, e) {
    try {
      var msg = where + ": " + String((e && (e.message || e)) || e);
      if (diag.errors.length && diag.errors[0].indexOf(msg) !== -1) return;
      diag.errors.unshift(new Date().toLocaleTimeString() + "  " + msg);
      if (diag.errors.length > 6) diag.errors.length = 6;
      try { log && log.error && log.error("Activity Status " + msg); } catch (x) {}
      notify();
    } catch (x) {}
  }
  function notify() { for (var i = 0; i < listeners.length; i++) { try { listeners[i](); } catch (e) {} } }

  try {
    vd = vendetta; metro = vd.metro; React = metro.common.React; RN = metro.common.ReactNative;
    storage = (vd.plugin && vd.plugin.storage) || {}; log = vd.logger || null;
    Flux = metro.common.FluxDispatcher || null;
  } catch (e) { note("init", e); }

  function sget(k, d) { try { var v = storage[k]; return v === undefined || v === null ? d : v; } catch (e) { return d; } }
  function sset(k, v) { try { storage[k] = v; } catch (e) { note("save", e); } }
  function h() { return React.createElement.apply(React, arguments); }
  // v2.3 keeps its own ON/OFF key ("off23"), so v2.2's old switches/modes/app list do not matter: ON by default.
  var forceOff = false; // set when the whole built-in is switched OFF on the Built-in features page (until restart)
  function isOn() { return !forceOff && sget("off23", false) !== true; }

  // ---------- native bridge (files + yumicord:// trampoline) ----------
  function fileMod() {
    try {
      var names = ["NativeFileModule", "RTNFileManager", "DCDFileManager"];
      for (var i = 0; i < names.length; i++) {
        var m = null;
        try { if (globalThis.__turboModuleProxy) m = globalThis.__turboModuleProxy(names[i]); } catch (e) {}
        if (!m) { try { m = globalThis.nativeModuleProxy && globalThis.nativeModuleProxy[names[i]]; } catch (e) {} }
        if (!m) { try { m = RN.NativeModules && RN.NativeModules[names[i]]; } catch (e) {} }
        if (m) return m;
      }
    } catch (e) { note("file module", e); }
    return null;
  }
  function docDir() { try { return fileMod().getConstants().DocumentsDirPath; } catch (e) { return null; } }
  function writeFile(name, text) {
    var fm = fileMod(); if (!fm) { diag.file = "file module missing"; return Promise.resolve(false); }
    return Promise.resolve(fm.writeFile("documents", name, text, "utf8")).then(function () { diag.file = "ok"; return true; }, function (e) { diag.file = "write failed"; note("write " + name, e); return false; });
  }
  function readJson(name) {
    var fm = fileMod(); var d = docDir();
    if (!fm || !d) return Promise.resolve(null);
    var path = d + "/" + name;
    return Promise.resolve(fm.fileExists(path)).then(function (ok) {
      if (!ok) return null;
      return Promise.resolve(fm.readFile(path, "utf8")).then(function (t) { try { return JSON.parse(t); } catch (e) { return null; } });
    }).catch(function () { return null; });
  }
  function nativeAction(action) {
    try {
      var d = docDir() || "";
      diag.syncs++;
      var p = RN.Linking.openURL("yumicord://rpc/" + action + "?dir=" + encodeURIComponent(d));
      if (p && p.catch) p.catch(function (e) { note("open " + action, e); });
      if (d) sset("dirSent", d);
    } catch (e) { note("open " + action, e); }
    setTimeout(refreshNative, 1500); setTimeout(refreshNative, 5000);
  }
  function refreshNative() {
    return readJson(STATUS_FILE).then(function (s) { diag.native = s; diag.nativeAt = Date.now(); notify(); });
  }
  function nativeFresh() { var s = diag.native; return !!(s && Date.now() - (s.t || 0) < 25000); }
  function nativeRunning() { var s = diag.native; return !!(s && s.running && nativeFresh()); }
  function nativeV24() { var s = diag.native; return !!(s && s.v >= 24); }

  // ---------- account bits ----------
  function token() {
    try { var m = metro.findByProps("getToken"); return (m && m.getToken && m.getToken()) || ""; } catch (e) { return ""; }
  }
  function myStatus() {
    try {
      var U = metro.findByStoreName("UserStore"), P = metro.findByStoreName("PresenceStore");
      var me = U && U.getCurrentUser && U.getCurrentUser();
      var st = me && P && P.getStatus && P.getStatus(me.id);
      if (st === "offline") st = "invisible";
      return /^(online|idle|dnd|invisible)$/.test(st || "") ? st : "online";
    } catch (e) { return "online"; }
  }

  function buildCfg() {
    var on = isOn();
    var pk = {}; FF_PKGS.forEach(function (p) { pk[p] = { name: "Free Fire", appId: FF_APP_ID }; });
    return {
      v: 2, enabled: on, mode: "auto", name: "Free Fire", appId: FF_APP_ID, useTimestamp: true, keepAlive: true,
      anyApp: true, packages: pk, exclude: Object.keys(hidden()), status: myStatus(), token: on ? token() : ""
    };
  }
  // v2.4 "Chhupao": apps the user never wants shown, {pkg: label}. Empty by default.
  function hidden() { var o = sget("hide24", null); return o && typeof o === "object" ? o : {}; }
  function setHidden(pkg, name, hide) {
    var o = {}, cur = hidden(); for (var k in cur) o[k] = cur[k];
    if (hide) o[pkg] = name || pkg; else delete o[pkg];
    sset("hide24", o); lastCfg = null;
    saveCfg().then(function () { setTimeout(refreshNative, 5000); });
    notify();
  }
  function saveCfg() {
    try {
      var text = JSON.stringify(buildCfg());
      if (text === lastCfg) return Promise.resolve(true);
      return writeFile(CFG_FILE, text).then(function (ok) { if (ok) { lastCfg = text; diag.cfgWrites++; } return ok; });
    } catch (e) { note("config", e); return Promise.resolve(false); }
  }

  // ---------- Discord's own "Share my activity" (show_current_game), switched ON through the client itself ----------
  // Only the client's own settings code is used (it sends the whole "status" settings group, as Discord requires);
  // the raw settings-proto API is NOT used, because a partial status group would reset the user's status.
  function shareSettingObj() {
    try { var m = metro.findByProps("ShowCurrentGame"); var s = m && m.ShowCurrentGame; if (s && typeof s.getSetting === "function") return s; } catch (e) {}
    return null;
  }
  function protoStore() { try { return metro.findByStoreName("UserSettingsProtoStore"); } catch (e) { return null; } }
  // true / false / null (unknown: settings not loaded yet)
  function readShare() {
    var s = shareSettingObj();
    if (s) { try { var v = s.getSetting(); if (typeof v === "boolean") return v; } catch (e) {} }
    try {
      var st = protoStore(); var set = st && st.settings;
      if (!set) return null;
      if (!set.status) return set.versions ? true : null; // loaded but no status group = Discord's default (ON)
      var g = set.status.showCurrentGame;
      if (g == null) return true; // not set = Discord's default (ON)
      return typeof g === "object" ? g.value !== false : g !== false;
    } catch (e) { return null; }
  }
  function shareMethods() {
    var out = [];
    var s = shareSettingObj();
    if (s && typeof s.updateSetting === "function") out.push(["ShowCurrentGame.updateSetting", function () { return s.updateSetting(true); }]);
    var ac = null;
    try { var m = metro.findByProps("PreloadedUserSettingsActionCreators"); ac = m && m.PreloadedUserSettingsActionCreators; } catch (e) {}
    if (!ac) { try { var m2 = metro.findByProps("UserSettingsActionCreatorsByType"); ac = m2 && m2.PreloadedUserSettingsActionCreators; } catch (e) {} }
    if (ac && typeof ac.updateAsync === "function")
      out.push(["PreloadedUserSettings.updateAsync", function () { return ac.updateAsync("status", function (st) { st.showCurrentGame = { value: true }; }, 0); }]);
    return out;
  }
  function ensureShare(why) {
    if (shareBusy || shareDone || !isOn()) return;
    var cur = readShare();
    if (cur === true) { diag.share = "ON (pehle se)"; shareDone = true; notify(); return; }
    if (cur === null) { diag.share = "settings load nahi hui abhi (" + why + ")"; notify(); return; }
    var ms = shareMethods();
    if (!ms.length) { diag.share = "OFF, auto-ON ka tareeka nahi mila"; notify(); return; }
    if (diag.shareTries >= 4) return;
    diag.shareTries++;
    shareBusy = true;
    var i = 0;
    (function next() {
      if (i >= ms.length) { shareBusy = false; diag.share = "OFF, auto-ON nahi hua"; notify(); return; }
      var m = ms[i++];
      try { var r = m[1](); if (r && r.catch) r.catch(function (e) { note("share " + m[0], e); }); }
      catch (e) { note("share " + m[0], e); setTimeout(next, 100); return; }
      setTimeout(function () {
        if (readShare() === true) { shareBusy = false; shareDone = true; diag.share = "OFF tha, apne aap ON kiya (" + m[0] + ")"; sset("shareAutoOn", Date.now()); notify(); }
        else next();
      }, 4000);
    })();
  }

  function periodic() {
    saveCfg().then(refreshNative).then(function () {
      try {
        // Self-heal (rate-limited): it should run but the service is not running (e.g. phone killed it) -> start it.
        var appActive = !RN.AppState || RN.AppState.currentState === "active";
        if (isOn() && !nativeRunning() && appActive && Date.now() - lastAutoSync > 300000) {
          lastAutoSync = Date.now(); nativeAction("sync");
        }
      } catch (e) { note("periodic", e); }
      if (!shareDone) ensureShare("periodic");
    });
  }

  // ---------- settings UI (minimal: status line + OFF switch) ----------
  var Boundary = null;
  try {
    Boundary = function (props) { React.Component.call(this, props); this.state = { err: null }; };
    Boundary.prototype = Object.create(React.Component.prototype);
    Boundary.prototype.constructor = Boundary;
    Boundary.getDerivedStateFromError = function (e) { return { err: e }; };
    Boundary.prototype.componentDidCatch = function (e) { note("settings render", e); };
    Boundary.prototype.render = function () {
      if (this.state.err) return h(RN.Text, { style: { color: "#f23f43", padding: 16 } }, "Settings screen error: " + String(this.state.err && this.state.err.message || this.state.err));
      return this.props.children;
    };
  } catch (e) { Boundary = null; }

  var C = { txt: { color: "#f2f3f5", fontSize: 16, fontWeight: "600" }, sub: { color: "#b5bac1", fontSize: 13, marginTop: 6 },
    tiny: { color: "#80848e", fontSize: 11, marginTop: 10 },
    card: { backgroundColor: "#2b2d31", borderRadius: 12, padding: 16, marginBottom: 12 },
    good: { color: "#3ba55c", fontSize: 18, fontWeight: "700", marginTop: 4 }, bad: { color: "#f23f43", fontSize: 18, fontWeight: "700", marginTop: 4 },
    warn: { color: "#f0b232", fontSize: 18, fontWeight: "700", marginTop: 4 } };

  function btn(label, onPress) {
    return h(RN.TouchableOpacity, { onPress: function () { try { onPress(); } catch (e) { note("button", e); } },
      style: { backgroundColor: "#5865f2", borderRadius: 8, paddingVertical: 12, paddingHorizontal: 12, alignItems: "center", marginTop: 12 } },
      h(RN.Text, { style: { color: "#ffffff", fontSize: 15, fontWeight: "700" } }, label));
  }

  // [text, style, needsPermission]
  function statusLine() {
    if (!isOn()) return ["OFF hai", "warn", false];
    var s = diag.native;
    if (s && s.usageGranted === false) return ["Permission chahiye", "bad", true];
    if (!nativeRunning()) return ["Shuru ho raha hai\u2026", "warn", false];
    if (s.authFailed) return ["Discord login dobara karo", "bad", false];
    if (s.showing) return ["Chal raha hai \u2713  Abhi dikh raha hai: Playing " + (s.showingName || s.showing), "good", false];
    return ["Chal raha hai \u2713", "good", false];
  }

  // v2.4 "Chhupao" (optional): hide the last shown app; hidden apps can be shown again with one tap.
  function chhupao(s) {
    var hd = hidden(), keys = Object.keys(hd);
    var last = s && s.lastShown && !hd[s.lastShown] ? s.lastShown : null;
    if (!last && !keys.length) return null;
    var rows = [h(RN.Text, { key: "t", style: C.sub }, "Chhupao: jo app kabhi nahi dikhana")];
    if (last) rows.push(h(RN.TouchableOpacity, { key: "add", onPress: function () { try { setHidden(last, s.lastShownName, true); } catch (e) { note("chhupao", e); } },
      style: { backgroundColor: "#4e5058", borderRadius: 8, paddingVertical: 10, paddingHorizontal: 12, marginTop: 8 } },
      h(RN.Text, { style: { color: "#ffffff", fontSize: 14, fontWeight: "600" } }, "\"" + (s.lastShownName || last) + "\" mat dikhao")));
    keys.forEach(function (p) {
      rows.push(h(RN.TouchableOpacity, { key: "h" + p, onPress: function () { try { setHidden(p, null, false); } catch (e) { note("chhupao", e); } },
        style: { flexDirection: "row", justifyContent: "space-between", paddingVertical: 8, marginTop: 4 } },
        h(RN.Text, { style: { color: "#f2f3f5", fontSize: 14 } }, "\u2715 " + hd[p]),
        h(RN.Text, { style: { color: "#00a8fc", fontSize: 13 } }, "wapas dikhao")));
    });
    return h(RN.View, { style: C.card }, rows);
  }

  function SettingsInner() {
    var t = React.useState(0); var setT = t[1];
    React.useEffect(function () {
      var fn = function () { setT(function (x) { return x + 1; }); };
      listeners.push(fn);
      refreshNative();
      var iv = setInterval(refreshNative, 3000);
      return function () { clearInterval(iv); var i = listeners.indexOf(fn); if (i >= 0) listeners.splice(i, 1); };
    }, []);
    var st = statusLine();
    var s = diag.native;
    return h(RN.ScrollView, { style: { flex: 1 }, contentContainerStyle: { padding: 16, paddingBottom: 60 } },
      h(RN.View, { style: C.card },
        h(RN.View, { style: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" } },
          h(RN.View, { style: { flex: 1, paddingRight: 8 } },
            h(RN.Text, { style: C.txt }, "Activity Status"),
            h(RN.Text, { style: C.sub }, "Jo bhi app/game khologe, dosto ko Discord pe \"Playing <app>\" dikhega. Discord, home screen aur system wali cheezein kabhi nahi.")),
          RN.Switch ? h(RN.Switch, { value: isOn(), onValueChange: function (v) {
            try {
              sset("off23", !v); lastCfg = null;
              saveCfg().then(function () { nativeAction("sync"); });
              if (v) { shareDone = false; diag.shareTries = 0; setTimeout(function () { ensureShare("switch"); }, 1500); }
              notify();
            } catch (e) { note("switch", e); }
          } }) : null),
        h(RN.Text, { style: C[st[1]] }, st[0]),
        st[2] ? btn("Permission do (Allow)", function () { saveCfg().then(function () { nativeAction("setup"); }); }) : null
      ),
      chhupao(s),
      h(RN.Text, { style: C.tiny }, "v" + VERSION + " \u2022 service: " + (s ? (nativeRunning() ? "on" : "off") + (s.gateway ? "/" + s.gateway : "") + (s.usageGranted === false ? " \u2022 usage: nahi" : "") : "?") +
        " \u2022 Share my activity: " + diag.share + (diag.errors.length ? "\nLast error: " + diag.errors[0] : "")),
      h(RN.Text, { style: C.tiny }, "Activity detection based on Kizzy by dead8309 (github.com/dead8309/Kizzy, GPL-3.0).")
    );
  }
  function Settings() {
    try { return Boundary ? h(Boundary, null, h(SettingsInner, null)) : h(SettingsInner, null); }
    catch (e) { note("settings", e); return null; }
  }

  return {
    onLoad: function () {
      try {
        if (Flux && Flux.subscribe) {
          var onOpen = function () { diag.reconnects++; setTimeout(function () { saveCfg(); ensureShare("connect"); }, 3000); };
          Flux.subscribe("CONNECTION_OPEN", onOpen);
          fluxUnsub = function () { try { Flux.unsubscribe("CONNECTION_OPEN", onOpen); } catch (e) {} };
        }
      } catch (e) { note("subscribe", e); }
      // Start-up: write settings + token, then start the service. The trampoline is opened when the service is not
      // already running (first launch, after an update, after the phone killed it) or the folder changed; the native
      // side then shows the one-tap permission popup if Usage access is still missing.
      setTimeout(function () {
        try {
          saveCfg().then(refreshNative).then(function () {
            var d = docDir();
            if (isOn() && (!nativeRunning() || !nativeV24() || sget("dirSent", "") !== d || !sget("synced24", false))) {
              lastAutoSync = Date.now(); sset("synced24", true); nativeAction("sync");
            }
          });
        } catch (e) { note("start", e); }
      }, 4000);
      setTimeout(function () { ensureShare("start"); }, 9000);
      try { timer = setInterval(periodic, 15000); } catch (e) { note("timer", e); }
    },
    onUnload: function () {
      try { if (timer) clearInterval(timer); } catch (e) {}
      try { fluxUnsub && fluxUnsub(); } catch (e) {}
    },
    // Called by the Built-in features page when this built-in is switched OFF: stop everything now.
    onBuiltinOff: function () {
      try { forceOff = true; lastCfg = null; saveCfg().then(function () { nativeAction("sync"); }); } catch (e) { note("off", e); }
    },
    settings: Settings
  };
})()
