/*
 * YumiCord Activity Status - minimal Discord gateway client (plain TLS socket + RFC 6455 websocket).
 * Activity detection based on Kizzy by dead8309 (https://github.com/dead8309/Kizzy, GPL-3.0):
 * the idea of a separate gateway session that identifies with the user's token and sends op 3 presence.
 */
package com.yumicord.rpc;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.security.SecureRandom;
import javax.net.ssl.*;
import org.json.JSONObject;
import android.util.Base64;

public class YumiGateway {
    public interface Listener { void onState(String state, String detail); }

    private final String token;
    private final Listener listener;
    private volatile SSLSocket sock;
    private volatile OutputStream out;
    private volatile boolean closed = false;
    private volatile boolean ready = false;
    private volatile long seq = -1;
    private volatile boolean acked = true;
    private volatile String pendingPresence = null;
    private Thread reader, beater;
    private final SecureRandom rnd = new SecureRandom();
    public volatile int lastCloseCode = 0;
    private boolean endpointChecked = false;

    public YumiGateway(String token, Listener l) { this.token = token; this.listener = l; }

    public boolean isReady() { return ready && !closed; }

    public void start() {
        reader = new Thread(new Runnable() { public void run() { loop(); } }, "YumiGateway");
        reader.setDaemon(true);
        reader.start();
    }

    /** Sets (or replaces) the presence; sent now if connected, else right after READY. */
    public void setPresence(String presenceJson) {
        pendingPresence = presenceJson;
        if (ready) sendOp(3, presenceJson);
    }

    public void close() {
        closed = true; ready = false;
        try { if (sock != null) sock.close(); } catch (Throwable t) {}
        if (beater != null) beater.interrupt();
    }

    private void state(String s, String d) { try { listener.onState(s, d); } catch (Throwable t) {} }

    private void loop() {
        try {
            state("connecting", null);
            SSLSocketFactory f = (SSLSocketFactory) SSLSocketFactory.getDefault();
            Socket raw = new Socket();
            raw.connect(new InetSocketAddress("gateway.discord.gg", 443), 15000);
            sock = (SSLSocket) f.createSocket(raw, "gateway.discord.gg", 443, true);
            try {
                SSLParameters p = sock.getSSLParameters();
                p.setServerNames(java.util.Collections.<SNIServerName>singletonList(new SNIHostName("gateway.discord.gg")));
                p.setEndpointIdentificationAlgorithm("HTTPS");
                sock.setSSLParameters(p);
                endpointChecked = "HTTPS".equals(sock.getSSLParameters().getEndpointIdentificationAlgorithm());
            } catch (Throwable t) {}
            sock.startHandshake();
            if (!endpointChecked && !HttpsURLConnection.getDefaultHostnameVerifier().verify("gateway.discord.gg", sock.getSession()))
                throw new IOException("TLS hostname mismatch");
            sock.setSoTimeout(0);
            InputStream in = new BufferedInputStream(sock.getInputStream(), 65536);
            out = sock.getOutputStream();
            byte[] k = new byte[16]; rnd.nextBytes(k);
            String key = Base64.encodeToString(k, Base64.NO_WRAP);
            String req = "GET /?v=10&encoding=json HTTP/1.1\r\nHost: gateway.discord.gg\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                    + "Sec-WebSocket-Key: " + key + "\r\nSec-WebSocket-Version: 13\r\nOrigin: https://discord.com\r\n"
                    + "User-Agent: Mozilla/5.0\r\n\r\n";
            synchronized (this) { out.write(req.getBytes("UTF-8")); out.flush(); }
            String status = readLine(in);
            if (status == null || !status.contains(" 101")) throw new IOException("handshake: " + status);
            while (true) { String h = readLine(in); if (h == null) throw new IOException("eof in headers"); if (h.length() == 0) break; }
            state("open", null);
            ByteArrayOutputStream msg = new ByteArrayOutputStream();
            while (!closed) {
                int b0 = in.read(); if (b0 < 0) throw new EOFException("socket closed");
                int b1 = in.read(); if (b1 < 0) throw new EOFException("socket closed");
                boolean fin = (b0 & 0x80) != 0; int opc = b0 & 0x0f;
                long len = b1 & 0x7f;
                if (len == 126) len = (in.read() << 8) | in.read();
                else if (len == 127) { len = 0; for (int i = 0; i < 8; i++) len = (len << 8) | (in.read() & 0xff); }
                byte[] mask = null;
                if ((b1 & 0x80) != 0) { mask = new byte[4]; readFully(in, mask); }
                if (len > 64L * 1024 * 1024) throw new IOException("frame too large");
                byte[] data = new byte[(int) len]; readFully(in, data);
                if (mask != null) for (int i = 0; i < data.length; i++) data[i] ^= mask[i & 3];
                if (opc == 8) {
                    int code = data.length >= 2 ? ((data[0] & 0xff) << 8) | (data[1] & 0xff) : 0;
                    lastCloseCode = code;
                    String reason = data.length > 2 ? new String(data, 2, data.length - 2, "UTF-8") : "";
                    try { sendFrame(8, data.length >= 2 ? new byte[]{data[0], data[1]} : new byte[0]); } catch (Throwable t) {}
                    throw new IOException("closed by Discord: " + code + " " + reason);
                } else if (opc == 9) { sendFrame(10, data); continue; }
                else if (opc == 10) continue;
                msg.write(data);
                if (fin) { byte[] all = msg.toByteArray(); msg.reset(); onMessage(new String(all, "UTF-8")); }
            }
        } catch (Throwable t) {
            ready = false;
            if (!closed) state("closed", String.valueOf(t.getMessage()));
        } finally {
            ready = false;
            closed = true;
            try { if (sock != null) sock.close(); } catch (Throwable t) {}
            if (beater != null) beater.interrupt();
            state("dead", null);
        }
    }

    private static String head(String s) { return s.length() > 300 ? s.substring(0, 300) : s; }

    private void onMessage(String s) {
        // Big dispatches (READY can be megabytes) are not fully parsed: only the leading t/s/op fields matter.
        String h = head(s);
        java.util.regex.Matcher ms = java.util.regex.Pattern.compile("\"s\":(\\d+)").matcher(h);
        if (ms.find()) { try { seq = Long.parseLong(ms.group(1)); } catch (Throwable t) {} }
        int op = -1;
        java.util.regex.Matcher mo = java.util.regex.Pattern.compile("\"op\":(\\d+)").matcher(h);
        if (mo.find()) op = Integer.parseInt(mo.group(1));
        String t = null;
        java.util.regex.Matcher mt = java.util.regex.Pattern.compile("\"t\":\"([A-Z_]+)\"").matcher(h);
        if (mt.find()) t = mt.group(1);
        try {
            if (op == 10) {
                long iv = new JSONObject(s).getJSONObject("d").getLong("heartbeat_interval");
                startHeartbeat(iv);
                identify();
            } else if (op == 11) { acked = true; }
            else if (op == 1) { sendHeartbeat(); }
            else if (op == 7) { throw new IOException("reconnect requested"); }
            else if (op == 9) { lastCloseCode = 9; throw new IOException("invalid session"); }
            else if (op == 0 && "READY".equals(t)) {
                ready = true;
                state("ready", null);
                String p = pendingPresence;
                if (p != null) sendOp(3, p);
            }
        } catch (IOException e) {
            close();
        } catch (Throwable e) {
            state("error", String.valueOf(e));
        }
    }

    private void identify() throws Exception {
        JSONObject props = new JSONObject();
        props.put("os", "Windows"); props.put("browser", "Discord Client"); props.put("device", "ktor");
        JSONObject d = new JSONObject();
        d.put("token", token); d.put("capabilities", 65); d.put("compress", false); d.put("large_threshold", 100);
        d.put("properties", props);
        sendOp(2, d.toString());
    }

    private void startHeartbeat(final long interval) {
        if (beater != null) beater.interrupt();
        beater = new Thread(new Runnable() { public void run() {
            try {
                Thread.sleep((long) (interval * rnd.nextDouble()));
                while (!closed) {
                    if (!acked) { close(); return; }
                    acked = false;
                    sendHeartbeat();
                    Thread.sleep(interval);
                }
            } catch (InterruptedException ie) { }
        }}, "YumiGatewayHB");
        beater.setDaemon(true);
        beater.start();
    }

    private void sendHeartbeat() { sendOp(1, seq < 0 ? "null" : String.valueOf(seq)); }

    private void sendOp(int op, String dJson) {
        try { sendFrame(1, ("{\"op\":" + op + ",\"d\":" + dJson + "}").getBytes("UTF-8")); }
        catch (Throwable t) { state("error", "send: " + t.getMessage()); close(); }
    }

    private void sendFrame(int opcode, byte[] payload) throws IOException {
        OutputStream o = out; if (o == null) throw new IOException("not connected");
        ByteArrayOutputStream f = new ByteArrayOutputStream(payload.length + 14);
        f.write(0x80 | opcode);
        int n = payload.length;
        if (n < 126) f.write(0x80 | n);
        else if (n < 65536) { f.write(0x80 | 126); f.write(n >> 8); f.write(n & 0xff); }
        else { f.write(0x80 | 127); for (int i = 7; i >= 0; i--) f.write((int) (((long) n >> (8 * i)) & 0xff)); }
        byte[] m = new byte[4]; rnd.nextBytes(m); f.write(m);
        for (int i = 0; i < n; i++) f.write(payload[i] ^ m[i & 3]);
        synchronized (this) { o.write(f.toByteArray()); o.flush(); }
    }

    private static void readFully(InputStream in, byte[] b) throws IOException {
        int off = 0; while (off < b.length) { int r = in.read(b, off, b.length - off); if (r < 0) throw new EOFException(); off += r; }
    }

    private static String readLine(InputStream in) throws IOException {
        StringBuilder sb = new StringBuilder(); int c;
        while ((c = in.read()) >= 0) { if (c == '\n') break; if (c != '\r') sb.append((char) c); if (sb.length() > 8192) break; }
        if (c < 0 && sb.length() == 0) return null;
        return sb.toString();
    }
}
