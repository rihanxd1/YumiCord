/*
 * YumiCord v2.3/v2.4 - one-tap setup for Activity Status (v2.4: any app).
 * One Hinglish popup -> Allow -> notification permission (Android 13+) -> battery-optimization exemption ->
 * the Usage access screen for YumiCord (Android needs the user's own tap there). Then the service is synced.
 * Activity detection based on Kizzy by dead8309 (https://github.com/dead8309/Kizzy, GPL-3.0).
 */
package com.yumicord.rpc;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;

public class YumiSetupActivity extends Activity {
    private static final int REQ_NOTIF = 4101, REQ_BATTERY = 4102;
    private boolean moved = false;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (b != null) { finishQuiet(); return; }
        try {
            if (YumiRpc.usageGranted(this)) { afterUsage(); return; }
            AlertDialog.Builder d = Build.VERSION.SDK_INT >= 21
                ? new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                : new AlertDialog.Builder(this);
            d.setTitle("YumiCord \u2022 Activity Status")
             .setMessage("Discord pe \"Playing <app>\" dikhane ke liye ek permission chahiye.\n\n\"Allow\" dabao, phir agli screen pe YumiCord ka switch ON kar do. Bas.")
             .setCancelable(true)
             .setPositiveButton("Allow", new DialogInterface.OnClickListener() { public void onClick(DialogInterface di, int w) { moved = true; stepNotif(); } })
             .setNegativeButton("Baad me", new DialogInterface.OnClickListener() { public void onClick(DialogInterface di, int w) { finishQuiet(); } })
             .setOnCancelListener(new DialogInterface.OnCancelListener() { public void onCancel(DialogInterface di) { if (!moved) finishQuiet(); } });
            d.show();
        } catch (Throwable t) { stepUsage(); }
    }

    /** 1) Android 13+: notification permission (so the small "Free Fire status ON" notification can show). */
    private void stepNotif() {
        try {
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{ "android.permission.POST_NOTIFICATIONS" }, REQ_NOTIF);
                return;
            }
        } catch (Throwable t) {}
        stepBattery();
    }

    @Override public void onRequestPermissionsResult(int code, String[] p, int[] r) {
        if (code == REQ_NOTIF) stepBattery();
    }

    /** 2) Battery-optimization exemption, so the phone does not kill the status while Free Fire runs. */
    private void stepBattery() {
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
                    Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName()));
                    startActivityForResult(i, REQ_BATTERY);
                    return;
                }
            }
        } catch (Throwable t) {}
        stepUsage();
    }

    @Override protected void onActivityResult(int code, int res, Intent data) {
        if (code == REQ_BATTERY) stepUsage();
    }

    /** 3) Usage access: straight to YumiCord's own switch where the phone supports it, else the list. */
    private void stepUsage() {
        try { YumiRpc.sync(getApplicationContext(), true); } catch (Throwable t) {}
        if (!YumiRpc.usageGranted(this)) {
            boolean ok = false;
            try {
                Intent i = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
                i.setData(Uri.parse("package:" + getPackageName()));
                startActivity(i); ok = true;
            } catch (Throwable t) {}
            if (!ok) { try { startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)); } catch (Throwable t2) {} }
        }
        finishQuiet();
    }

    private void afterUsage() { try { YumiRpc.sync(getApplicationContext(), true); } catch (Throwable t) {} finishQuiet(); }

    private void finishQuiet() {
        try { finish(); overridePendingTransition(0, 0); } catch (Throwable t) {}
    }
}
