/*
 * YumiCord Activity Status - starts with the app process: re-applies the saved settings (restart survival)
 * and (v2.3) watches app opens for the one-tap permission popup. Activity detection based on Kizzy by dead8309 (GPL-3.0).
 */
package com.yumicord.rpc;

import android.content.*;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;

public class YumiRpcProvider extends ContentProvider {
    @Override public boolean onCreate() {
        try {
            final Context c = getContext().getApplicationContext();
            try { YumiRpc.watch(c); } catch (Throwable t) {} // v2.3: one-tap permission popup when the app opens
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() { public void run() {
                try { YumiRpc.sync(c, false); } catch (Throwable t) {}
            }}, 4000);
        } catch (Throwable t) {}
        return true;
    }
    @Override public Cursor query(Uri u, String[] p, String s, String[] a, String o) { return null; }
    @Override public String getType(Uri u) { return null; }
    @Override public Uri insert(Uri u, ContentValues v) { return null; }
    @Override public int delete(Uri u, String s, String[] a) { return 0; }
    @Override public int update(Uri u, ContentValues v, String s, String[] a) { return 0; }
}
