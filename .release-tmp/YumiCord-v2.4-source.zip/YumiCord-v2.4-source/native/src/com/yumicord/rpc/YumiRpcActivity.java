/*
 * YumiCord Activity Status - invisible trampoline opened by the JS side through yumicord://rpc/<action>.
 * Activity detection based on Kizzy by dead8309 (https://github.com/dead8309/Kizzy, GPL-3.0).
 */
package com.yumicord.rpc;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;


public class YumiRpcActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        try { handle(getIntent()); } catch (Throwable t) {}
        finish();
        try { overridePendingTransition(0, 0); } catch (Throwable t) {}
    }

    private void handle(Intent in) {
        Uri u = in == null ? null : in.getData();
        if (u == null) return;
        String action = u.getLastPathSegment();
        try { YumiRpc.setDir(this, u.getQueryParameter("dir")); } catch (Throwable t) {}
        final android.content.Context app = getApplicationContext();
        if ("usage".equals(action)) {
            try {
                Intent i = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
                i.setData(Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } catch (Throwable t) {
                try { startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)); } catch (Throwable t2) {}
            }
        } else if ("battery".equals(action)) {
            try {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } catch (Throwable t) {}
        } else if ("notifications".equals(action)) {
            try {
                Intent i = new Intent("android.settings.APP_NOTIFICATION_SETTINGS");
                i.putExtra("android.provider.extra.APP_PACKAGE", getPackageName());
                startActivity(i);
            } catch (Throwable t) {}
        } else if ("setup".equals(action)) {
            YumiRpc.requestSetup(app, true, 700);   // v2.3: "Permission do" button in settings
        }
        // every action also brings the service in line with the saved settings ("sync")
        YumiRpc.sync(app, true);
        YumiRpc.writeStatusIdleIfStopped(app);
        // v2.3: right after the app's start-up sync, the one-tap permission popup if Usage access is still missing
        if ("sync".equals(action)) YumiRpc.requestSetup(app, false, 900);
    }
}
