/*
 * YumiCord Activity Status - foreground service.
 * Activity detection based on Kizzy by dead8309 (https://github.com/dead8309/Kizzy, GPL-3.0).
 * v2.3: always on. v2.4: ANY app in front shows as "Playing <app label>" (Free Fire keeps "Free Fire" + its app id);
 * never Discord/YumiCord, home screen, SystemUI, settings, permission controller, installer, keyboard, phone/dialer.
 * Polls Usage access for the app in front and keeps its own Discord gateway session open
 * while there is something to show, so the status stays up while Discord itself sleeps in the background.
 */
package com.yumicord.rpc;

import android.app.*;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.*;
import android.os.*;
import java.io.File;
import java.util.*;
import org.json.*;

public class YumiRpcService extends Service {
    public static final String ACTION_STOP = "com.yumicord.rpc.STOP";
    public static final String ACTION_SYNC = "com.yumicord.rpc.SYNC";
    private static final String CH = "yumicord_activity";
    private static final int NID = 0x59554D49;
    private static final long TICK = 4000, GRACE = 30000;

    private HandlerThread ht; private Handler h;
    private JSONObject cfg; private long cfgMtime = -1;
    private volatile YumiGateway gw; private String gwToken; private String gwState = "idle", gwDetail = null;
    private int fails = 0; private long nextConnectAt = 0; private boolean authFailed = false;
    private String lastPresence = null, lastNotif = null;
    private long lastEventTs = 0; private String fgPkg = null;
    private String showPkg = null; private long showStart = 0; private long lostAt = 0;
    private String showName = null, lastShownPkg = null, lastShownName = null;
    private final Map<String, String[]> names = new HashMap<String, String[]>();
    private long manualStart = 0;
    private Set<String> excluded = null; private long excludedAt = 0;
    private String error = null;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        goForeground("Activity Status shuru ho raha hai\u2026");
        ht = new HandlerThread("YumiRpc"); ht.start(); h = new Handler(ht.getLooper());
        lastEventTs = System.currentTimeMillis() - 3 * 3600 * 1000L;
        h.post(tick);
    }

    @Override public int onStartCommand(Intent i, int flags, int id) {
        goForeground(lastNotif != null ? lastNotif : "Activity Status ON");
        if (i != null && ACTION_STOP.equals(i.getAction())) {
            YumiRpc.prefs(this).edit().putBoolean("userStopped", true).apply();
            stopSelf();
            return START_NOT_STICKY;
        }
        if (h != null) { cfgMtime = -1; h.removeCallbacks(tick); h.post(tick); }
        return START_STICKY;
    }

    @Override public void onDestroy() {
        try { if (h != null) h.removeCallbacksAndMessages(null); } catch (Throwable t) {}
        closeGateway();
        try { if (ht != null) ht.quitSafely(); } catch (Throwable t) {}
        try {
            JSONObject s = new JSONObject();
            s.put("t", System.currentTimeMillis()); s.put("running", false); s.put("native", 1);
            s.put("detail", YumiRpc.prefs(this).getBoolean("userStopped", false) ? "notification se band kiya" : "service band");
            s.put("usageGranted", YumiRpc.usageGranted(this));
            YumiRpc.writeText(new File(YumiRpc.dir(this), "yumicord_activity_status.json"), s.toString());
        } catch (Throwable t) {}
        super.onDestroy();
    }

    private final Runnable tick = new Runnable() { public void run() {
        try { step(); error = null; } catch (Throwable t) { error = String.valueOf(t); }
        try { writeStatus(); } catch (Throwable t) {}
        if (h != null) h.postDelayed(this, TICK);
    }};

    private void step() throws Exception {
        File f = new File(YumiRpc.dir(this), "yumicord_activity.json");
        long mt = f.lastModified();
        if (mt != cfgMtime) {
            cfgMtime = mt; cfg = YumiRpc.config(this);
            lastPresence = null; authFailed = false; fails = 0; nextConnectAt = 0;
        }
        if (!YumiRpc.wantsService(cfg)) { stopSelf(); return; }
        String token = cfg.optString("token");
        if (gw != null && gwToken != null && !gwToken.equals(token)) closeGateway();

        JSONObject act = null; String notif;
        boolean auto = true; // v2.3: always auto (Free Fire only); manual mode removed
        if (!auto) {
            String name = cfg.optString("name", "").trim();
            if (name.length() == 0) name = "Free Fire";
            if (manualStart == 0) manualStart = cfg.optLong("startTs", System.currentTimeMillis());
            act = activity(name, cfg.optString("appId", ""), cfg.optBoolean("useTimestamp", true) ? cfg.optLong("startTs", manualStart) : 0);
            notif = "Discord pe dikh raha hai: Playing " + name;
        } else {
            boolean granted = YumiRpc.usageGranted(this);
            String fg = granted ? foreground() : null;
            long now = System.currentTimeMillis();
            if (showPkg != null && userHidden(showPkg)) { showPkg = null; lostAt = 0; } // v2.4: "Chhupao" applies at once
            if (fg != null && matches(fg)) {
                if (!fg.equals(showPkg)) { showPkg = fg; showStart = now; }
                lostAt = 0;
            } else if (showPkg != null) {
                if (lostAt == 0) lostAt = now;
                if (now - lostAt > GRACE) { showPkg = null; lostAt = 0; }
            }
            if (showPkg != null) {
                String[] na = nameFor(showPkg);
                act = activity(na[0], na[1], cfg.optBoolean("useTimestamp", true) ? showStart : 0);
                notif = "Discord pe dikh raha hai: Playing " + na[0];
                showName = na[0]; lastShownPkg = showPkg; lastShownName = na[0];
            } else {
                showName = null;
                notif = granted ? "Koi bhi app/game kholo, Discord pe dikhega" : "Permission chahiye: YumiCord kholo aur Allow dabao";
            }
        }

        if (act == null) {
            if (gw != null) closeGateway();
            lastPresence = null;
        } else {
            JSONObject p = new JSONObject();
            p.put("since", JSONObject.NULL);
            JSONArray arr = new JSONArray(); arr.put(act); p.put("activities", arr);
            String st = cfg.optString("status", "online");
            if (!st.matches("online|idle|dnd|invisible")) st = "online";
            p.put("status", st); p.put("afk", false);
            String pj = p.toString();
            ensureGateway(token);
            if (gw != null && !pj.equals(lastPresence)) { gw.setPresence(pj); lastPresence = pj; }
            if (authFailed) notif = "Discord ne token reject kiya: YumiCord kholo";
        }
        if (!notif.equals(lastNotif)) { lastNotif = notif; goForeground(notif); }
    }

    private JSONObject activity(String name, String appId, long start) throws JSONException {
        JSONObject a = new JSONObject();
        a.put("name", name); a.put("type", 0);
        if (appId != null && appId.matches("\\d{15,21}")) a.put("application_id", appId);
        if (start > 0) { JSONObject ts = new JSONObject(); ts.put("start", start); a.put("timestamps", ts); }
        return a;
    }

    private String[] nameFor(String pkg) {
        if (YumiRpc.isFreeFire(pkg)) return new String[]{ YumiRpc.FF_NAME, YumiRpc.FF_APP_ID }; // v2.3
        String[] c = names.get(pkg); // v2.4: the app's own label from PackageManager, no app id
        if (c == null) {
            String l = YumiRpc.label(this, pkg);
            if (l == null || l.trim().length() == 0) l = pkg;
            l = l.trim(); if (l.length() > 128) l = l.substring(0, 128);
            c = new String[]{ l, "" }; names.put(pkg, c);
        }
        return c;
    }

    private String[] nameForV23(String pkg) {
        String name = null, appId = "";
        JSONObject pk = cfg.optJSONObject("packages");
        JSONObject e = pk == null ? null : pk.optJSONObject(pkg);
        if (e != null) { name = e.optString("name", null); appId = e.optString("appId", ""); }
        JSONObject games = cfg.optJSONObject("games");
        JSONArray g = games == null ? null : games.optJSONArray(pkg);
        if (g != null) { if (appId.length() == 0) appId = g.optString(0, ""); if (name == null || name.length() == 0) name = g.optString(1, null); }
        if (name == null || name.length() == 0) name = YumiRpc.label(this, pkg);
        return new String[]{ name, appId };
    }

    /** v2.4: any app in front, except the never-shown list and the user's own "Chhupao" list. */
    private boolean matches(String pkg) {
        if (pkg == null) return false;
        if (YumiRpc.isDiscordClient(this, pkg)) return false;
        if (userHidden(pkg)) return false;
        if (YumiRpc.isFreeFire(pkg)) return true;
        long now = System.currentTimeMillis();
        if (excluded == null || now - excludedAt > 600000) { excluded = YumiRpc.neverShow(this); excludedAt = now; launchable.clear(); names.clear(); }
        if (excluded.contains(pkg)) return false;
        Boolean l = launchable.get(pkg);
        if (l == null) { l = YumiRpc.hasLauncherIcon(this, pkg); launchable.put(pkg, l); }
        return l;
    }
    private final Map<String, Boolean> launchable = new HashMap<String, Boolean>();

    /** v2.4 "Chhupao": packages the user chose never to show (config "exclude", empty by default). */
    private boolean userHidden(String pkg) {
        JSONArray ex = cfg == null ? null : cfg.optJSONArray("exclude");
        if (ex != null) for (int i = 0; i < ex.length(); i++) if (pkg.equals(ex.optString(i))) return true;
        return false;
    }

    private boolean matchesV22(String pkg) {
        JSONObject pk = cfg.optJSONObject("packages");
        if (pk != null && pk.has(pkg)) return true;
        if (!cfg.optBoolean("anyApp", false)) return false;
        long now = System.currentTimeMillis();
        if (excluded == null || now - excludedAt > 600000) { excluded = YumiRpc.launchers(this); excludedAt = now; }
        if (excluded.contains(pkg)) return false;
        JSONArray ex = cfg.optJSONArray("exclude");
        if (ex != null) for (int i = 0; i < ex.length(); i++) if (pkg.equals(ex.optString(i))) return false;
        return !YumiRpc.isSystem(this, pkg);
    }

    /** Package of the app in front, from Usage access events (last resumed activity). */
    private String foreground() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null && !pm.isInteractive()) return null;
            UsageStatsManager um = (UsageStatsManager) getSystemService(USAGE_STATS_SERVICE);
            long now = System.currentTimeMillis();
            UsageEvents ev = um.queryEvents(lastEventTs - 2000, now);
            UsageEvents.Event e = new UsageEvents.Event();
            long newest = lastEventTs;
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e);
                if (e.getEventType() == 1 /* ACTIVITY_RESUMED / MOVE_TO_FOREGROUND */ && e.getTimeStamp() >= newest) {
                    fgPkg = e.getPackageName(); newest = e.getTimeStamp();
                }
            }
            lastEventTs = Math.max(newest, now - 60000);
            return fgPkg;
        } catch (Throwable t) { error = "usage: " + t; return null; }
    }

    private void ensureGateway(final String token) {
        if (authFailed) return;
        long now = System.currentTimeMillis();
        if (gw != null && !gwDead) return;
        if (gw != null) {
            int code = gw.lastCloseCode;
            gw = null; fails++;
            if (code == 4004) { authFailed = true; gwState = "token rejected (4004)"; return; }
            nextConnectAt = now + Math.min(60000L, 3000L * (1L << Math.min(fails, 5)));
            return;
        }
        if (now < nextConnectAt) return;
        gwDead = false; lastPresence = null; gwToken = token;
        final YumiGateway[] me = new YumiGateway[1];
        YumiGateway g = new YumiGateway(token, new YumiGateway.Listener() {
            public void onState(String st, String d) {
                if (gw != me[0]) return;
                gwState = st; if (d != null) gwDetail = d;
                if ("ready".equals(st)) fails = 0;
                if ("dead".equals(st)) { gwDead = true; Handler hh = h; if (hh != null) { hh.removeCallbacks(tick); hh.postDelayed(tick, 500); } }
            }
        });
        me[0] = g; gw = g; g.start();
    }
    private volatile boolean gwDead = false;

    private void closeGateway() {
        YumiGateway g = gw; gw = null;
        if (g != null) { try { g.close(); } catch (Throwable t) {} }
        gwState = "idle"; lastPresence = null;
    }

    private void writeStatus() throws JSONException {
        JSONObject s = new JSONObject();
        s.put("t", System.currentTimeMillis()); s.put("running", true); s.put("native", 1); s.put("v", 24);
        s.put("gateway", gw == null ? "idle" : (gw.isReady() ? "connected" : gwState));
        if (gwDetail != null) s.put("gatewayDetail", gwDetail);
        s.put("authFailed", authFailed);
        s.put("usageGranted", YumiRpc.usageGranted(this));
        if (fgPkg != null) s.put("foreground", fgPkg);
        if (lastNotif != null) s.put("detail", lastNotif);
        if (showPkg != null) s.put("showing", showPkg);
        if (showPkg != null && showName != null) s.put("showingName", showName);
        if (lastShownPkg != null) { s.put("lastShown", lastShownPkg); s.put("lastShownName", lastShownName); }
        if (error != null) s.put("error", error);
        YumiRpc.writeText(new File(YumiRpc.dir(this), "yumicord_activity_status.json"), s.toString());
    }

    private void goForeground(String text) {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            Notification.Builder b;
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = new NotificationChannel(CH, "YumiCord Activity Status", NotificationManager.IMPORTANCE_LOW);
                ch.setShowBadge(false);
                nm.createNotificationChannel(ch);
                b = new Notification.Builder(this, CH);
            } else b = new Notification.Builder(this);
            int fl = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0;
            Intent stop = new Intent(this, YumiRpcService.class).setAction(ACTION_STOP);
            PendingIntent ps = PendingIntent.getService(this, 1, stop, fl | PendingIntent.FLAG_UPDATE_CURRENT);
            Intent open = getPackageManager().getLaunchIntentForPackage(getPackageName());
            b.setSmallIcon(android.R.drawable.ic_media_play)
             .setContentTitle("YumiCord \u2022 Activity Status")
             .setContentText(text)
             .setOngoing(true); // v2.3: no Stop button; the OFF switch lives in YumiCord settings
            if (open != null) b.setContentIntent(PendingIntent.getActivity(this, 2, open, fl | PendingIntent.FLAG_UPDATE_CURRENT));
            Notification n = b.build();
            if (Build.VERSION.SDK_INT >= 34) startForeground(NID, n, 0x40000000 /* FOREGROUND_SERVICE_TYPE_SPECIAL_USE */);
            else if (Build.VERSION.SDK_INT >= 29) startForeground(NID, n, 1 /* FOREGROUND_SERVICE_TYPE_DATA_SYNC */);
            else startForeground(NID, n);
        } catch (Throwable t) {
            error = "foreground: " + t;
            try { YumiRpc.prefs(this).edit().putString("lastFgError", String.valueOf(t)).apply(); } catch (Throwable t2) {}
            try { stopSelf(); } catch (Throwable t2) {}
        }
    }
}
