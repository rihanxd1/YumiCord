/*
 * YumiCord Activity Status - native helpers.
 * Activity detection based on Kizzy by dead8309 (https://github.com/dead8309/Kizzy, GPL-3.0):
 * UsageStatsManager ("Usage access") foreground-app detection + a foreground service holding its own gateway session.
 */
package com.yumicord.rpc;

import android.app.AppOpsManager;
import android.content.*;
import android.content.pm.*;
import android.os.Build;
import android.os.Process;
import java.io.*;
import java.util.*;
import org.json.*;

public class YumiRpc {
    public static final String PREFS = "yumicord_rpc";
    public static final String SUB = "yumicord";

    public static SharedPreferences prefs(Context c) { return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }

    /** Folder shared with the JS side: the loader's DocumentsDirPath (told to us by the JS side via yumicord://rpc/...?dir=). */
    public static File dir(Context c) {
        String d = prefs(c).getString("dir", null);
        File f = d != null ? new File(d) : c.getFilesDir();
        if (!f.exists()) f.mkdirs();
        return f;
    }

    public static void setDir(Context c, String d) {
        if (d == null || d.length() == 0) return;
        File f = new File(d);
        if (!f.isAbsolute()) return;
        prefs(c).edit().putString("dir", d).apply();
    }

    public static String readText(File f) {
        try {
            if (!f.exists()) return null;
            FileInputStream in = new FileInputStream(f);
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] b = new byte[8192]; int n;
            while ((n = in.read(b)) > 0) bo.write(b, 0, n);
            in.close();
            return bo.toString("UTF-8");
        } catch (Throwable t) { return null; }
    }

    public static void writeText(File f, String s) {
        try {
            File tmp = new File(f.getPath() + ".tmp");
            FileOutputStream o = new FileOutputStream(tmp);
            o.write(s.getBytes("UTF-8")); o.close();
            if (!tmp.renameTo(f)) { o = new FileOutputStream(f); o.write(s.getBytes("UTF-8")); o.close(); tmp.delete(); }
        } catch (Throwable t) {}
    }

    public static JSONObject config(Context c) {
        try { String s = readText(new File(dir(c), "yumicord_activity.json")); return s == null ? null : new JSONObject(s); }
        catch (Throwable t) { return null; }
    }

    /** True when the saved settings need the background service (auto mode, or manual with keep-alive). */
    public static boolean wantsService(JSONObject cfg) {
        if (cfg == null) return false;
        if (!cfg.optBoolean("enabled", false)) return false;
        return cfg.optString("token", "").length() >= 20; // v2.3+: always auto
    }

    /** Free Fire keeps its own name + Discord app id (so the icon can show). v2.4: every other app shows by its label. */
    public static final String[] FF_PKGS = { "com.garena.game.ffi", "com.dts.freefireth", "com.dts.freefiremax" };
    public static final String FF_NAME = "Free Fire";
    public static final String FF_APP_ID = "1441993244895477830";
    public static boolean isFreeFire(String pkg) {
        if (pkg == null) return false;
        for (String p : FF_PKGS) if (p.equals(pkg)) return true;
        return pkg.toLowerCase(java.util.Locale.ROOT).contains("freefire");
    }

    // ---------- v2.4: any app, except these (never shown) ----------
    /** Fixed package names that are never shown: Discord clients, settings, permission controller, package installer, phone/dialer. */
    public static final String[] NEVER = {
        "android", "com.android.systemui",
        "com.discord", "com.aliucord", "com.bluecord",
        "com.android.settings", "com.android.settings.intelligence", "com.samsung.android.settings", "com.miui.securitycenter",
        "com.coloros.safecenter", "com.oplus.safecenter", "com.iqoo.secure", "com.vivo.permissionmanager", "com.huawei.systemmanager",
        "com.google.android.permissioncontroller", "com.android.permissioncontroller",
        "com.google.android.packageinstaller", "com.android.packageinstaller", "com.miui.packageinstaller",
        "com.samsung.android.packageinstaller", "com.oplus.appdetail", "com.coloros.packageinstaller",
        "com.android.dialer", "com.google.android.dialer", "com.samsung.android.dialer", "com.android.incallui",
        "com.samsung.android.incallui", "com.android.server.telecom", "com.android.phone", "com.android.contacts",
        "com.oplus.dialer", "com.coloros.dialer", "com.asus.contacts", "com.android.emergency", "com.google.android.apps.safetyhub"
    };

    /** True for Discord / YumiCord / Bluecord-style clients (any package naming discord, bluecord, yumicord, aliucord). */
    public static boolean isDiscordClient(Context c, String pkg) {
        if (pkg == null) return true;
        if (pkg.equals(c.getPackageName())) return true;
        String l = pkg.toLowerCase(java.util.Locale.ROOT);
        return l.contains("discord") || l.contains("bluecord") || l.contains("yumicord") || l.contains("aliucord");
    }

    private static void addResolvers(PackageManager pm, Intent i, Set<String> out) {
        try { for (ResolveInfo r : pm.queryIntentActivities(i, 0)) if (r.activityInfo != null) out.add(r.activityInfo.packageName); } catch (Throwable t) {}
    }

    /** v2.4: everything that is never shown on this phone: NEVER + launchers (home), keyboards, whatever handles
     *  Settings / permission requests / app installs / the dialer, the default dialer, and YumiCord itself. */
    public static Set<String> neverShow(Context c) {
        Set<String> out = launchers(c); // home screens, IMEs, SystemUI, "android", own package
        out.addAll(Arrays.asList(NEVER));
        PackageManager pm = c.getPackageManager();
        addResolvers(pm, new Intent(android.provider.Settings.ACTION_SETTINGS), out);
        addResolvers(pm, new Intent(android.provider.Settings.ACTION_USAGE_ACCESS_SETTINGS), out);
        addResolvers(pm, new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:" + c.getPackageName())), out);
        addResolvers(pm, new Intent("android.content.pm.action.REQUEST_PERMISSIONS"), out);
        try {
            Intent ins = new Intent(Intent.ACTION_INSTALL_PACKAGE);
            ins.setDataAndType(android.net.Uri.parse("content://yumicord/x.apk"), "application/vnd.android.package-archive");
            addResolvers(pm, ins, out);
        } catch (Throwable t) {}
        addResolvers(pm, new Intent(Intent.ACTION_DIAL), out);
        addResolvers(pm, new Intent(Intent.ACTION_DIAL, android.net.Uri.parse("tel:123")), out);
        addResolvers(pm, new Intent(Intent.ACTION_CALL_BUTTON), out);
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                android.telecom.TelecomManager tm = (android.telecom.TelecomManager) c.getSystemService(Context.TELECOM_SERVICE);
                String dd = tm == null ? null : tm.getDefaultDialerPackage();
                if (dd != null) out.add(dd);
                if (Build.VERSION.SDK_INT >= 29) { String sd = tm == null ? null : tm.getSystemDialerPackage(); if (sd != null) out.add(sd); }
            }
        } catch (Throwable t) {}
        return out;
    }

    /** v2.4: an app the user can open (has a launcher icon). Overlays, services and system dialogs without one are not shown. */
    public static boolean hasLauncherIcon(Context c, String pkg) {
        try { return c.getPackageManager().getLaunchIntentForPackage(pkg) != null; } catch (Throwable t) { return false; }
    }

    /** True when the user switched Activity Status OFF in YumiCord (config says enabled:false). No config yet = ON. */
    public static boolean userOff(Context c) {
        JSONObject cfg = config(c);
        return cfg != null && cfg.has("enabled") && !cfg.optBoolean("enabled", true);
    }

    // ---------- v2.3 first-run permission popup ----------
    static android.app.Activity current;          // Discord's own resumed activity (not ours)
    static int started = 0;                        // started activities, to see "app came to front"
    static long lastSetupAt = 0;                   // when the popup was last shown (this process)
    static boolean callbacksOn = false;
    static final android.os.Handler MAIN = new android.os.Handler(android.os.Looper.getMainLooper());

    static boolean ours(android.app.Activity a) { return a instanceof YumiRpcActivity || a instanceof YumiSetupActivity; }

    public static void watch(Context c) {
        if (callbacksOn) return;
        Context ac = c.getApplicationContext();
        if (!(ac instanceof android.app.Application)) return;
        callbacksOn = true;
        ((android.app.Application) ac).registerActivityLifecycleCallbacks(new android.app.Application.ActivityLifecycleCallbacks() {
            public void onActivityCreated(android.app.Activity a, android.os.Bundle b) {}
            public void onActivityStarted(android.app.Activity a) {
                if (ours(a)) return;
                started++;
                if (started == 1) requestSetup(a.getApplicationContext(), false, 9000); // app opened / came back to front
            }
            public void onActivityResumed(android.app.Activity a) { if (!ours(a)) current = a; }
            public void onActivityPaused(android.app.Activity a) { if (current == a) current = null; }
            public void onActivityStopped(android.app.Activity a) { if (!ours(a) && started > 0) started--; }
            public void onActivitySaveInstanceState(android.app.Activity a, android.os.Bundle b) {}
            public void onActivityDestroyed(android.app.Activity a) { if (current == a) current = null; }
        });
    }

    /** Shows the one-tap permission popup over Discord if Usage access is still missing (at most every 20 min unless forced). */
    public static void requestSetup(final Context app, final boolean force, long delayMs) {
        MAIN.postDelayed(new Runnable() { public void run() {
            try {
                if (usageGranted(app)) return;
                if (!force && userOff(app)) return;
                long now = System.currentTimeMillis();
                if (!force && lastSetupAt != 0 && now - lastSetupAt < 20 * 60 * 1000L) return;
                android.app.Activity a = current;
                if (a == null || a.isFinishing()) { if (force) { Intent i = new Intent(app, YumiSetupActivity.class); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); app.startActivity(i); lastSetupAt = now; } return; }
                lastSetupAt = now;
                a.startActivity(new Intent(a, YumiSetupActivity.class));
            } catch (Throwable t) {
                try { prefs(app).edit().putString("lastSetupError", String.valueOf(t)).apply(); } catch (Throwable t2) {}
            }
        }}, delayMs);
    }

    public static boolean usageGranted(Context c) {
        try {
            AppOpsManager ops = (AppOpsManager) c.getSystemService(Context.APP_OPS_SERVICE);
            int mode;
            if (Build.VERSION.SDK_INT >= 29) mode = ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.getPackageName());
            else mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.getPackageName());
            if (mode == AppOpsManager.MODE_DEFAULT)
                return c.checkCallingOrSelfPermission("android.permission.PACKAGE_USAGE_STATS") == PackageManager.PERMISSION_GRANTED;
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Throwable t) { return false; }
    }

    /** Starts or stops the service to match the saved settings. Never throws. */
    public static String sync(Context c, boolean fromForeground) {
        try {
            JSONObject cfg = config(c);
            Intent i = new Intent(c, YumiRpcService.class);
            if (!wantsService(cfg)) {
                try { c.stopService(i); } catch (Throwable t) {}
                writeStatusIdle(c, cfg == null ? "no settings yet" : "off");
                return "stopped";
            }
            if (!fromForeground && prefs(c).getBoolean("userStopped", false)) return "user stopped";
            if (fromForeground) prefs(c).edit().putBoolean("userStopped", false).apply();
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
            return "started";
        } catch (Throwable t) {
            try {
                JSONObject s = new JSONObject();
                s.put("t", System.currentTimeMillis()); s.put("running", false); s.put("error", "start failed: " + t);
                s.put("usageGranted", usageGranted(c));
                writeText(new File(dir(c), "yumicord_activity_status.json"), s.toString());
            } catch (Throwable t2) {}
            return "error: " + t;
        }
    }

    public static void writeStatusIdle(Context c, String why) {
        try {
            JSONObject s = new JSONObject();
            s.put("t", System.currentTimeMillis()); s.put("running", false); s.put("detail", why);
            s.put("usageGranted", usageGranted(c)); s.put("native", 1); s.put("v", 24);
            writeText(new File(dir(c), "yumicord_activity_status.json"), s.toString());
        } catch (Throwable t) {}
    }

    public static void writeStatusIdleIfStopped(Context c) {
        try { if (!wantsService(config(c))) writeStatusIdle(c, "off"); } catch (Throwable t) {}
    }

    public static Set<String> launchers(Context c) {
        Set<String> out = new HashSet<String>();
        try {
            Intent h = new Intent(Intent.ACTION_MAIN); h.addCategory(Intent.CATEGORY_HOME);
            for (ResolveInfo r : c.getPackageManager().queryIntentActivities(h, 0)) out.add(r.activityInfo.packageName);
        } catch (Throwable t) {}
        try {
            android.view.inputmethod.InputMethodManager imm = (android.view.inputmethod.InputMethodManager) c.getSystemService(Context.INPUT_METHOD_SERVICE);
            for (android.view.inputmethod.InputMethodInfo m : imm.getInputMethodList()) out.add(m.getPackageName());
        } catch (Throwable t) {}
        out.add("com.android.systemui"); out.add("android"); out.add(c.getPackageName());
        return out;
    }

    /** Installed apps that have a launcher icon, written to apps.json for the settings picker. */
    public static int writeApps(Context c) {
        try {
            PackageManager pm = c.getPackageManager();
            Intent m = new Intent(Intent.ACTION_MAIN); m.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> list = pm.queryIntentActivities(m, 0);
            Set<String> skip = launchers(c);
            Map<String, JSONObject> byPkg = new TreeMap<String, JSONObject>();
            for (ResolveInfo r : list) {
                String p = r.activityInfo.packageName;
                if (byPkg.containsKey(p) || skip.contains(p)) continue;
                ApplicationInfo ai = r.activityInfo.applicationInfo;
                JSONObject o = new JSONObject();
                o.put("p", p);
                o.put("l", String.valueOf(ai.loadLabel(pm)));
                boolean sys = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                if (sys) o.put("s", (ai.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0 ? 2 : 1);
                byPkg.put(p, o);
            }
            JSONArray arr = new JSONArray();
            for (JSONObject o : byPkg.values()) arr.put(o);
            JSONObject root = new JSONObject();
            root.put("t", System.currentTimeMillis()); root.put("apps", arr);
            writeText(new File(dir(c), "yumicord_apps.json"), root.toString());
            return arr.length();
        } catch (Throwable t) { return -1; }
    }

    public static String label(Context c, String pkg) {
        try { PackageManager pm = c.getPackageManager(); return String.valueOf(pm.getApplicationInfo(pkg, 0).loadLabel(pm)); }
        catch (Throwable t) { return pkg; }
    }

    public static boolean isSystem(Context c, String pkg) {
        try { return (c.getPackageManager().getApplicationInfo(pkg, 0).flags & ApplicationInfo.FLAG_SYSTEM) != 0; }
        catch (Throwable t) { return true; }
    }
}
