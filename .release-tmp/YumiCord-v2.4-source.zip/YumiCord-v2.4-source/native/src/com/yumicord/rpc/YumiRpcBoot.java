/* YumiCord Activity Status - after a phone restart, brings auto mode back. Based on Kizzy by dead8309 (GPL-3.0). */
package com.yumicord.rpc;

import android.content.*;

public class YumiRpcBoot extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        try {
            String a = i == null ? null : i.getAction();
            if (Intent.ACTION_BOOT_COMPLETED.equals(a) || "android.intent.action.MY_PACKAGE_REPLACED".equals(a))
                YumiRpc.sync(c.getApplicationContext(), true);
        } catch (Throwable t) {}
    }
}
