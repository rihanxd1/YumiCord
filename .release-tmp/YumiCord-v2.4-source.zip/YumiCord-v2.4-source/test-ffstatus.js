
// YumiCord v2.4 Activity Status built-in (was v2.3 Free Fire Status): node test with mocks (react-test-renderer for the settings screen).
const NM='/home/user/tab/tasks/c9e5db90-35fe-4395-be28-a8efed31b6cf/w/t/node_modules/';
const React=require(NM+'react'); const TR=require(NM+'react-test-renderer');
const fs=require('fs');
const SRC=fs.readFileSync(__dirname+'/builtins/yumicord-activity-2.1.0.js','utf8');
const DIR='/data/user/0/com.bluecord/files';
let pass=0, fail=0; function ok(c,m){ if(c){pass++;console.log('ok  ',m);} else {fail++;console.log('FAIL',m);} }
const _st=setTimeout; const timers=[];
function run(scn){
  const files={}; const opened=[]; const subs={}; const calls=[];
  const fm={ getConstants:()=>({DocumentsDirPath:DIR}), writeFile:async(s,p,d)=>{files[DIR+'/'+p]=d;}, fileExists:async p=>p in files, readFile:async p=>files[p] };
  globalThis.nativeModuleProxy={RTNFileManager:fm};
  const mk=n=>(p)=>React.createElement(n,p,p&&p.children);
  const RN={View:mk('View'),Text:mk('Text'),ScrollView:mk('ScrollView'),TouchableOpacity:mk('Touch'),Switch:mk('Switch'),
    Linking:{openURL:async u=>{opened.push(u);}}, AppState:{currentState:'active'}};
  let share=scn.share; // true/false/undefined
  const setting = scn.settingObj ? { getSetting:()=>share===undefined?true:share, updateSetting:(v)=>{calls.push('updateSetting:'+v); if(scn.settingWorks) share=v; return Promise.resolve();} } : null;
  const ac = scn.ac ? { updateAsync:(g,fn,d)=>{ const draft={}; fn(draft); calls.push('updateAsync:'+g+':'+JSON.stringify(draft)+':'+d); if(g==='status'&&draft.showCurrentGame&&draft.showCurrentGame.value===true) share=true; return Promise.resolve(); } } : null;
  const store = { get settings(){ if(scn.unloaded) return undefined; const s={versions:{}}; if(share!==undefined) s.status={showCurrentGame:{value:share}}; return s; } };
  const metro={ common:{React,ReactNative:RN,FluxDispatcher:{subscribe:(t,f)=>{subs[t]=f;},unsubscribe(){},dispatch(a){calls.push('dispatch:'+a.type);}}},
    findByProps:(...p)=>{ if(p[0]==='getToken') return {getToken:()=>'TOKEN_abcdefghijklmnopqrstuvwxyz'}; if(p[0]==='ShowCurrentGame') return setting?{ShowCurrentGame:setting}:null; if(p[0]==='PreloadedUserSettingsActionCreators') return ac?{PreloadedUserSettingsActionCreators:ac}:null; return null; },
    findByStoreName:(n)=>{ if(n==='UserSettingsProtoStore') return store; if(n==='UserStore') return {getCurrentUser:()=>({id:'1'})}; if(n==='PresenceStore') return {getStatus:()=>'dnd'}; return null; } };
  const storage=Object.assign({}, scn.storage||{});
  globalThis.vendetta={metro, plugin:{storage}, logger:{error(){}}};
  timers.length=0;
  global.setTimeout=(f,ms)=>{timers.push([ms,f]); return timers.length;};
  global.setInterval=(f,ms)=>{ timers.push([ms,f,'iv']); return 99; }; global.clearInterval=()=>{};
  const inst=(0,eval)(SRC);
  return {inst,files,opened,subs,calls,storage,setStatus:(o)=>{files[DIR+'/yumicord_activity_status.json']=JSON.stringify(Object.assign({t:Date.now(),running:true,native:1,v:24},o));}, share:()=>share};
}
async function flush(n){ for(let i=0;i<(n||20);i++) await new Promise(r=>_st(r,0)); }
async function fire(maxMs){ // fire queued timeouts up to maxMs, repeatedly
  for(let round=0;round<12;round++){ const due=timers.filter(t=>t[0]<=maxMs && !t[2]); if(!due.length) break; for(const t of due){ timers.splice(timers.indexOf(t),1); try{t[1]();}catch(e){console.log('timer err',e);} } await flush(); }
}
function texts(tree){ const out=[]; (function w(n){ if(n==null) return; if(typeof n==='string'){out.push(n);return;} if(Array.isArray(n)){n.forEach(w);return;} (n.children||[]).forEach(w); })(tree.toJSON()); return out.join(' | '); }

(async()=>{
  // 1) first launch: config written ON + auto + token, sync opened, share OFF -> updateSetting
  let t=run({share:false, settingObj:true, settingWorks:true});
  t.inst.onLoad(); await fire(4000);
  const cfg=JSON.parse(t.files[DIR+'/yumicord_activity.json']||'{}');
  ok(cfg.enabled===true && cfg.mode==='auto' && cfg.token.length>20 && cfg.anyApp===true && Array.isArray(cfg.exclude) && cfg.exclude.length===0 && cfg.status==='dnd', 'first launch config ON/auto/token/anyApp true/exclude empty/status dnd: '+JSON.stringify({e:cfg.enabled,m:cfg.mode,a:cfg.anyApp,s:cfg.status}));
  ok(Object.keys(cfg.packages).join()==='com.garena.game.ffi,com.dts.freefireth,com.dts.freefiremax' && !cfg.games, 'Free Fire entries kept for its app id, no games map');
  ok(t.opened.length===1 && /^yumicord:\/\/rpc\/sync\?dir=/.test(t.opened[0]), 'start opens yumicord://rpc/sync once: '+t.opened);
  await fire(9000); await fire(13000);
  ok(t.calls.includes('updateSetting:true') && t.share()===true, 'Share my activity OFF -> ShowCurrentGame.updateSetting(true): '+t.calls);
  // 2) share already ON -> no call
  t=run({share:true, settingObj:true}); t.inst.onLoad(); await fire(13000);
  ok(!t.calls.some(c=>/update/.test(c)), 'share already ON -> nothing changed');
  // 3) unset (default) -> no call
  t=run({share:undefined, settingObj:false, ac:true}); t.inst.onLoad(); await fire(13000);
  ok(!t.calls.some(c=>/update/.test(c)), 'share unset (Discord default ON) -> nothing changed');
  // 4) no setting object, action creators -> updateAsync("status", {showCurrentGame:{value:true}}, 0)
  t=run({share:false, settingObj:false, ac:true}); t.inst.onLoad(); await fire(13000);
  ok(t.calls.some(c=>c==='updateAsync:status:{"showCurrentGame":{"value":true}}:0') && t.share()===true, 'fallback updateAsync status group: '+t.calls);
  // 5) setting object present but does not take -> falls to updateAsync
  t=run({share:false, settingObj:true, settingWorks:false, ac:true}); t.inst.onLoad(); await fire(13000);
  ok(t.calls[0]==='updateSetting:true' && t.calls.some(c=>/^updateAsync/.test(c)) && t.share()===true, 'updateSetting no effect -> updateAsync: '+t.calls);
  // 6) settings not loaded -> nothing, retried on CONNECTION_OPEN
  t=run({share:false, settingObj:false, ac:true, unloaded:true}); t.inst.onLoad(); await fire(13000);
  ok(!t.calls.some(c=>/update/.test(c)), 'settings not loaded -> no change yet');
  // 7) service already running v23 -> no trampoline on start (no flicker); settings render states
  t=run({share:true, settingObj:true, storage:{synced24:true, dirSent:DIR}}); t.setStatus({usageGranted:true, gateway:'idle'});
  t.inst.onLoad(); await fire(4000);
  ok(t.opened.length===0, 'running v2.4 service -> no link opened at start');
  let tree; await TR.act(async()=>{ tree=TR.create(React.createElement(t.inst.settings)); }); await flush();
  let tx=texts(tree); ok(/Chal raha hai \u2713/.test(tx) && /Kizzy by dead8309/.test(tx) && !/Koi bhi app|Usage access do|Manual|Chhupao/.test(tx), 'settings: running line + credit, no picker, no Chhupao card by default: '+tx.slice(0,200));
  t.setStatus({usageGranted:false}); await TR.act(async()=>{ timers.filter(x=>x[2]).forEach(x=>{}); }); 
  await TR.act(async()=>{ tree.update(React.createElement(t.inst.settings)); }); await TR.act(async()=>{ await new Promise(r=>_st(r,5)); });
  // force a refresh by toggling: call the periodic-like refresh through re-render after reading file
  const ivs=timers.filter(x=>x[2]); for(const iv of ivs){ await TR.act(async()=>{ iv[1](); await flush(); }); }
  tx=texts(tree); ok(/Permission chahiye/.test(tx) && /Permission do/.test(tx), 'settings: permission missing line + button: '+tx.slice(0,160));
  const btn=tree.root.findAll(n=>n.type==='Touch')[0];
  await TR.act(async()=>{ btn.props.onPress(); await flush(); });
  ok(t.opened.some(u=>/rpc\/setup/.test(u)), 'Permission do -> yumicord://rpc/setup');
  t.setStatus({usageGranted:true, showing:'com.garena.game.ffi', showingName:'Free Fire', lastShown:'com.garena.game.ffi', lastShownName:'Free Fire', gateway:'connected'});
  for(const iv of ivs){ await TR.act(async()=>{ iv[1](); await flush(); }); }
  tx=texts(tree); ok(/Playing Free Fire/.test(tx), 'settings: showing line: '+tx.slice(0,120));
  t.setStatus({usageGranted:true, showing:'com.pubg.imobile', showingName:'BGMI', lastShown:'com.pubg.imobile', lastShownName:'BGMI', gateway:'connected'});
  for(const iv of ivs){ await TR.act(async()=>{ iv[1](); await flush(); }); }
  tx=texts(tree); ok(/Abhi dikh raha hai: Playing BGMI/.test(tx) && /"BGMI" mat dikhao/.test(tx), 'v2.4: any app line "Playing BGMI" + Chhupao button: '+tx.slice(0,200));
  // Chhupao: hide BGMI -> storage + config exclude; row with "wapas dikhao"; tap -> removed again
  let hb=tree.root.findAll(n=>n.type==='Touch' && JSON.stringify(n.props.children&&n.props.children.props||{}).indexOf('mat dikhao')>=0)[0];
  await TR.act(async()=>{ hb.props.onPress(); await flush(); });
  let cfgH=JSON.parse(t.files[DIR+'/yumicord_activity.json']);
  tx=texts(tree); ok(t.storage.hide24 && t.storage.hide24['com.pubg.imobile']==='BGMI' && cfgH.exclude.join()==='com.pubg.imobile' && /BGMI/.test(tx) && /wapas dikhao/.test(tx) && !/mat dikhao/.test(tx), 'Chhupao -> hidden list + config exclude: '+JSON.stringify(cfgH.exclude));
  let wb=tree.root.findAll(n=>n.type==='Touch' && JSON.stringify((n.props.children||[]).map?n.props.children.map(c=>c&&c.props):[]).indexOf('wapas dikhao')>=0)[0];
  await TR.act(async()=>{ wb.props.onPress(); await flush(); });
  cfgH=JSON.parse(t.files[DIR+'/yumicord_activity.json']);
  ok(Object.keys(t.storage.hide24).length===0 && cfgH.exclude.length===0, 'wapas dikhao -> removed from list and config');
  // OFF switch
  const sw=tree.root.findAll(n=>n.type==='Switch')[0];
  await TR.act(async()=>{ sw.props.onValueChange(false); await flush(); });
  const cfg2=JSON.parse(t.files[DIR+'/yumicord_activity.json']);
  ok(cfg2.enabled===false && cfg2.token==='' && t.storage.off23===true && t.opened.some(u=>/rpc\/sync/.test(u)), 'OFF switch -> config enabled false, token removed, sync');
  tx=texts(tree); ok(/OFF hai/.test(tx), 'settings: OFF line');
  await TR.act(async()=>{ sw.props.onValueChange(true); await flush(); });
  ok(JSON.parse(t.files[DIR+'/yumicord_activity.json']).enabled===true, 'ON again -> config enabled');
  // Built-in page OFF (whole built-in) -> config disabled, storage untouched
  t=run({share:true, settingObj:true}); t.inst.onLoad(); await fire(4000); t.inst.onBuiltinOff(); await flush();
  ok(JSON.parse(t.files[DIR+'/yumicord_activity.json']).enabled===false && t.storage.off23===undefined, 'onBuiltinOff -> config disabled, own switch untouched');
  console.log('\n'+pass+' passed, '+fail+' failed'); process.exit(fail?1:0);
})().catch(e=>{console.log('THROWN',e); process.exit(1);});
