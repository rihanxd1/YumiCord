#!/usr/bin/env bash
# YumiCord v2.4 build (same steps as v2.2/v2.3): v2's patched APK (work_patched.apk from the v2 build) + v2.2 manifest (version + Activity Status
# components/permissions) + new loader bundle + classes5.dex (native Activity Status service), then LSPatch with the
# same module and key as v2/v2.1.
set -euo pipefail
cd "$(dirname "$0")"
B=${B:-/home/user/tab/tasks/b26877ff-c305-4644-9e1b-f19ee17b2617}
BT=${BT:-/home/user/android-sdk/build-tools/35.0.0}
AJ=${AJ:-/home/user/android-sdk/platforms/android-35/android.jar}
J=${J:-$B/tools/jdk-21.0.13+9/bin}
KS=${KS:?keystore}; KSPASS=${KSPASS:?password}
E=$B/tools/node/node_modules/esbuild/bin/esbuild
LSP=$B/tools/lspatch-vd.jar
# 1) native Activity Status (Java -> dex)
rm -rf native/cls native/dex; mkdir -p native/cls native/dex
$J/javac -source 8 -target 8 -Xlint:-options -nowarn -bootclasspath "$AJ" -d native/cls $(find native/src -name "*.java")
$BT/d8 --min-api 24 --release --output native/dex $(find native/cls -name "*.class")
# 2) manifest (from v2.1's: versionCode 350013 / "YumiCord v2.4" + service/provider/2 activities/receiver + 4 permissions)
$J/javac -cp $LSP -d patcher2 patcher2/YumiManifestPatcher.java
$J/java -cp patcher2:$LSP YumiManifestPatcher AndroidManifest.xml AndroidManifest.v24.xml 350013 "YumiCord v2.4"
# 3) loader bundle
cp bundle/yumicord.js yumicord.js; node --check yumicord.js
$E yumicord.js --minify-whitespace --log-level=error > yumicord.min.js
node --check yumicord.min.js
# 4) zip, align, LSPatch
python3 build_zip.py $B/work_patched.apk patched_unaligned.apk AndroidManifest.v24.xml yumicord.min.js native/dex/classes.dex
$BT/zipalign -f -p 4 patched_unaligned.apk patched.apk
rm -f patched_unaligned.apk
rm -rf lsp_out; mkdir -p lsp_out
$J/java -jar $LSP patched.apk -o lsp_out -l 0 -v -m $B/mod/yumicord-module.apk -k "$KS" "$KSPASS" rihan "$KSPASS"
rm -f patched.apk
ls -la lsp_out
