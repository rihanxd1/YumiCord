YumiCord v2.4 — source & build notes (UNTESTED build: not run on a phone)
==========================================================================
Base: YumiCord v2.3 source. versionCode 350013, versionName "YumiCord v2.4", same key (cert SHA-256 3651ab84...097c).
Rihan asked (Oct 31, 2026): Free Fire alone is not enough, every app should show; still no settings system.
Changes from v2.3:
- Native (YumiRpcService.matches / YumiRpc.neverShow): ANY app in front shows as "Playing <app label>" (label from
  PackageManager, cached). Free Fire packages keep "Free Fire" + app id 1441993244895477830. Other apps: no application_id.
- Never shown: Discord-style clients (own package com.bluecord, com.discord, any pkg containing discord/bluecord/
  yumicord/aliucord); home screens (CATEGORY_HOME resolvers); SystemUI and "android"; all keyboards (IMEs);
  whatever resolves Settings / Usage-access settings / App-details settings, the permission controller
  (REQUEST_PERMISSIONS resolver + com.google.android.permissioncontroller/com.android.permissioncontroller), the package
  installer (ACTION_INSTALL_PACKAGE resolver + known installer packages), the phone/dialer (ACTION_DIAL /
  CALL_BUTTON resolvers, TelecomManager default + system dialer, com.android.dialer, com.google.android.dialer,
  com.samsung.android.dialer, in-call UIs, telecom, com.android.phone, com.android.contacts), plus OEM security/settings
  centers (MIUI securitycenter, ColorOS/OPlus safecenter, vivo/iQOO, Huawei systemmanager). Apps with no launcher icon
  (overlays, system dialogs) are also not shown. List rebuilt every 10 min.
  When one of these is in front, the last real app stays for the same 30 s grace, then the status clears.
- Optional "Chhupao" (JS settings page only, empty by default): "<last app> mat dikhao" button + hidden list with
  "wapas dikhao". Stored in plugin storage "hide24", sent to native as config "exclude"; a hidden app clears at once.
- Status file v:24 with showingName / lastShown / lastShownName. Settings status line: "Abhi dikh raha hai: Playing <app>".
  Built-in renamed "YumiCord Activity Status" 2.1.0 (same key "ffstatus", same OFF switch "off23"). Notification and
  permission popup texts say Activity Status instead of Free Fire. Kizzy GPL-3.0 credit unchanged.
- Bundle diff: bundle/yumicord-v2.3-to-v2.4.diff. Builtin source: builtins/yumicord-activity-2.1.0.js.
Tests: test-ffstatus.js 21/21 (incl. any-app line and Chhupao add/remove), test-harness.js (3 built-ins, 0 errors).
Build: KS=... KSPASS=... bash build.sh (~15 s).

---- v2.3 README ----
YumiCord v2.3 — source & build notes (UNTESTED build: not run on a phone; no emulator on the build box)
==========================================================================================================
Rihan, Oct 31 2026 2:40 PM IST: "Yumi me jo system banaya hai usko hata do, direct kar do, q ki bahut sari chijen enable
karni padati hai" -> remove the settings system; Free Fire status should just work.

Changes from v2.2 (versionCode 350012, "YumiCord v2.3", same key: cert SHA-256 3651ab84...097c, installs over v2.2):
- Built-in "YumiCord Free Fire Status" 2.0.0 (builtins/yumicord-activity-2.0.0.js, key "ffstatus") replaces v2.2's
  "YumiCord Activity Status" 1.0.0 (key "activity"). ON by default from the first launch (own switch key "off23"), always
  auto. No manual mode, no app picker, no "any app", no 1664-game map.
  Settings screen = one status line ("Chal raha hai ✓" / "Permission chahiye" / "OFF hai"), one OFF switch, a
  "Permission do (Allow)" button only while Usage access is missing, one tiny diagnostics line, the Kizzy credit.
- Detection is Free Fire only, hard-coded in native code (YumiRpc.isFreeFire): com.garena.game.ffi, com.dts.freefireth,
  com.dts.freefiremax, or any package containing "freefire". Shows "Playing Free Fire" with app id 1441993244895477830
  (same payload as v2.2). Never any other app (the v2.2 config's packages/anyApp are ignored by the service).
- One-tap permission popup (native, YumiSetupActivity, Theme.Translucent.NoTitleBar, not exported):
  "Free Fire status ke liye ek permission chahiye" [Allow] [Baad me]. Allow -> POST_NOTIFICATIONS request (Android 13+,
  if missing) -> ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS (if not exempt) -> Usage access screen for YumiCord.
  Shown when the app opens while Usage access is missing: right after the JS start-up sync (yumicord://rpc/sync), or 9 s
  after the app comes to the front (ActivityLifecycleCallbacks registered from YumiRpcProvider); at most every 20 min per
  process unless forced by the settings button (yumicord://rpc/setup). Not shown when the user switched the feature OFF.
- Discord "Share my activity" (status.show_current_game) switched ON automatically when it is explicitly OFF, through
  the client's own settings code: ShowCurrentGame.updateSetting(true), else
  PreloadedUserSettingsActionCreators.updateAsync("status", s => s.showCurrentGame = {value:true}, 0). Checked 9 s
  after start, every 15 s until settled, and after each CONNECTION_OPEN; verified by re-reading the setting. The raw
  settings-proto PATCH is deliberately NOT used: Discord resets every unsent field of a top-level group, so a partial
  "status" group would wipe the user's status/custom status.
- Notification: "YumiCord • Free Fire status", no Stop button (the OFF switch is in settings).
- Kept from v2.2: YumiRpcService (FGS specialUse/dataSync, own gateway websocket, op 3, 30 s grace, reconnect backoff),
  YumiRpcBoot (BOOT_COMPLETED / MY_PACKAGE_REPLACED), YumiRpcProvider start-up sync, YumiGateway unchanged.
- Manifest: + YumiSetupActivity, + REQUEST_IGNORE_BATTERY_OPTIMIZATIONS (patcher2/YumiManifestPatcher.java).
- Loader: "(v2.3)", versionHash v2.3, Built-in features trailing "Badges, Platforms, Free Fire Status".
  Diff: bundle/yumicord-v2.2-to-v2.3.diff.
Build: build.sh (KS, KSPASS env; base = v2 build dir's work_patched.apk; ~10 s). Tests: test-ffstatus.js (18 checks:
config, Free Fire only, start-up sync, Share-my-activity paths, settings screen states, OFF switch), test-harness.js
(loader + 3 built-ins start with 0 errors), test-gateway/ (JVM run of YumiGateway, unchanged).
Activity detection based on Kizzy by dead8309 (https://github.com/dead8309/Kizzy, GPL-3.0); licenses/ as before.

---- v2.2 README ----
YumiCord v2.2 — source & build notes (UNTESTED build: not run on a phone; no emulator available)
=====================================================================================================

Base: YumiCord v2.1 (see YumiCord-v2.1-source.zip; its README is kept below). Same Discord 350.8, same RevengeXposed
module, same LSPatch, same signing key (cert SHA-256 3651ab84d07aecf03a36855e0db40aebbbbf88fb3cd8e53110d626a1ed13097c),
so it installs as an update over v2.1.

New in v2.2: built-in "YumiCord Activity Status" — "Playing <game>" on your Discord profile, like Discord on PC.
Activity detection based on Kizzy by dead8309 (https://github.com/dead8309/Kizzy, GPL-3.0; licenses/Kizzy-LICENSE-GPL-3.0.txt).

- AndroidManifest (patcher2/YumiManifestPatcher.java, pxb axml): versionCode 350009 -> 350010, versionName "YumiCord v2.2";
  adds permissions PACKAGE_USAGE_STATS, QUERY_ALL_PACKAGES, FOREGROUND_SERVICE_SPECIAL_USE and four components:
    com.yumicord.rpc.YumiRpcService   foreground service (type specialUse|dataSync) — own Discord gateway session
    com.yumicord.rpc.YumiRpcProvider  starts with the app process, re-applies saved settings, refreshes app list
    com.yumicord.rpc.YumiRpcActivity  invisible trampoline for yumicord://rpc/<sync|usage|apps|battery|notifications>
    com.yumicord.rpc.YumiRpcBoot      BOOT_COMPLETED / MY_PACKAGE_REPLACED -> re-apply settings
- classes5.dex (native/src, Java 8, compiled with javac + d8 --min-api 24) added to the base APK before LSPatch.
  YumiGateway.java is a small dependency-free websocket client (TLS socket + RFC 6455) for wss://gateway.discord.gg
  (v=10, json): HELLO -> heartbeat, IDENTIFY with the user's token (same properties as Kizzy), op 3 presence after READY,
  reconnect with backoff, stops on 4004 (token rejected). Tested on the build box against the real gateway with a fake
  token (HELLO, heartbeat, identify, close 4004 all handled); never tested with a real account.
- Loader bundle (bundle/yumicord-v2.1-to-v2.2.diff): third built-in "activity" (builtins/yumicord-activity-1.0.0.js),
  version labels v2.2, and the Built-in features switch calls onBuiltinOff() so turning the built-in off also stops the service.
  * In-app path: FluxDispatcher LOCAL_ACTIVITY_UPDATE (socketId "YumiCordActivity"), re-applied on CONNECTION_OPEN.
  * Background path: JS writes <DocumentsDirPath>/yumicord_activity.json (settings + token + status), opens
    yumicord://rpc/sync?dir=<DocumentsDirPath>; the service writes yumicord_activity_status.json and yumicord_apps.json.
  * In-app is used only while the background service is not connected (no double "Playing").
  * Auto mode: UsageStatsManager.queryEvents, last ACTIVITY_RESUMED package, polled every 4 s; screen off = nothing;
    30 s grace after the game leaves the front. Free Fire packages pre-ticked: com.dts.freefireth, com.dts.freefiremax,
    com.garena.game.ffi. Discord application ids for 1664 Android games (games map) so the game icon can show
    (Free Fire = 1441993244895477830).
- Build: build.sh (KS, KSPASS env; ~40 s). Tests: test-harness.js (loader built-ins), test-activity-plugin.js
  (react-test-renderer smoke test of the settings screen / config / in-app dispatch), test-gateway/ (JVM run of YumiGateway).

---- v2.1 README ----
YumiCord v2.1 — source & build notes (UNTESTED build: not run on a phone)
==========================================================================

Base: YumiCord v2 (see YumiCord-v2-source.zip). Same Discord 350.8, same RevengeXposed module (byte-identical), same
LSPatch, same signing key (cert SHA-256 3651ab84d07aecf03a36855e0db40aebbbbf88fb3cd8e53110d626a1ed13097c).
Changes in v2.1:
- AndroidManifest: versionCode 350008 -> 350009, versionName "YumiCord v2.1" (patcher/YumiVersionPatcher.java, pxb axml).
  Discord's own client info uses compiled-in constants ("350.8", 350008), so this does not change what Discord reports.
- Loader bundle (bundle/yumicord-v2-to-v2.1.diff):
  * Built-in features, started at app start like a plugin (same 'vendetta' API, indirect eval like the plugin loader),
    every step in try/catch, skipped in Safe Mode:
      - YumiCord Badges 2.0.0 (builtins/yumicord-badges-2.0.0.js, unmodified copy of the URL plugin) — sets globalThis.__ycBadgesActive
      - YumiCord Platforms 1.0.0 (builtins/yumicord-platforms-1.0.0.js, unmodified copy of the URL plugin) — sets globalThis.__ycPlatformsActive
    If the same plugin is ALSO installed from its URL (yumicord-badges / yumicord-platforms .sites.tab.bot), that copy is
    turned into a no-op while the built-in runs, so nothing shows twice; its settings page shows the built-in's screen.
    Settings -> YumiCord section -> "Built-in features": an ON/OFF switch per built-in (applies after restart) and each one's
    settings/diagnostics. globalThis.__yumicord holds status/errors.
  * Pre-installed plugins: plugins-seed.json (also inline in the bundle as YUMI_SEED). ~12 s after start (once per seed
    version), each URL not already present is fetched with the loader's own fetchPlugin, which adds it DISABLED. Skipped:
    URLs already installed and any plugin whose name matches an installed one. Each URL is seeded once (a plugin the user
    removes is not re-added). Failed fetches retry on the next start. Plugin code is NOT modified or bundled; only URLs are listed.
  * Loader tweaks for a big list: fetchPlugin no longer rewrites storage when the plugin's hash is unchanged; the
    background refresh of disabled plugins runs 30 s after start instead of immediately.
  * Settings row shows "(v2.1)", version string "v2.1".
Build: build.sh (needs the v2 build dir for work_patched.apk, tools, module APK; keystore not included).
Tests: test-harness.js (mock storage/fetch: built-ins, dedupe, seeding, safe mode, failures), test-settings-page.js (react-test-renderer).
Licenses: as v2 (Revenge BSD-3-Clause, RevengeXposed GPL-3.0, LSPatch GPL-3.0). Seeded plugins belong to their authors;
YumiCord Platforms credits PlatformIndicators by MSMA/martinz64 (The Unlicense).
